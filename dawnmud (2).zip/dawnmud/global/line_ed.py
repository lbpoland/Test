# File: /home/archaon/mud/lib/global/line_ed.py
# Purpose: Provides a multi-mode line editor for players to edit text.
# Linked Files: /home/archaon/mud/lib/secure/prestos_ed.py
# Updated Features: None identified from live Discworld MUD updates as of 2025-03-20; editor system consistent per dwwiki.mooo.com and developer blogs.
# Translated by: Archaon

class LineEditor:
    """
    Implements a versatile line editor with menu, ed, magic, and command modes for text editing.
    """

    TMP_FILE = "/home/archaon/mud/lib/tmp/editor_temp"  # Assumed temporary file path
    ED_HELP_FILE = "/home/archaon/mud/lib/doc/help/editor_help"  # Assumed help file path
    LOG_FILE = "/home/archaon/mud/lib/log/EDITOR_ERRORS"  # Assumed log file path
    PRESTOS_ED = "/home/archaon/mud/lib/secure/prestos_ed.py"  # Full path for magic editor

    def __init__(self, driver):
        self.driver = driver
        self._lines = []
        self._end_func = None
        self._ed_ob = None
        self._insertion_point = 0
        self.editor = "menu"
        self._filename = None
        self._in_editor = 0
        self.create()

    def create(self):
        """
        Initializes the line editor with default settings.
        """
        pass

    def editor_commands(self):
        """
        Sets up the 'editor' command to switch editing modes.
        """
        self.driver.add_command("editor", "{menu|magic|ed|command}", 
                                lambda _, args: self.set_editor(args[0]))

    def do_edit(self, str_=None, end_f=None, end_o=None, fname="", extra=None):
        """
        Starts the editing process in the selected mode.
        
        @param str_ initial text to edit
        @param end_f function or method name to call on finish
        @param end_o object to call end_f on (defaults to previous_object)
        @param fname file to edit (defaults to TMP_FILE)
        @param extra additional argument for end_f
        @return True if started, False on error
        """
        if not end_f:
            self.driver.printf("Someone has stuffed up - there is no end function.\n")
            return False
        self._end_func = end_f
        end_o = end_o or self.driver.previous_object()
        str_ = str_ or ""
        self._filename = fname if fname else self.TMP_FILE
        
        if not callable(end_f):
            if extra:
                self._end_func = lambda result: self.driver.call_other(end_o, end_f, result, extra)
            else:
                self._end_func = lambda result: self.driver.call_other(end_o, end_f, result)
        else:
            if extra:
                self._end_func = lambda result: end_f(result, extra)
            else:
                self._end_func = lambda result: end_f(result)
        
        if self.editor == "menu":
            self._lines = [line for line in str_.split("\n") if line]
            self.driver.printf("Enter your text.  Use ** on a line by itself to exit.\n")
            self._insertion_point = len(self._lines)
            self.driver.printf("%-2d] ", self._insertion_point + 1)
            self._in_editor = 1
            self.driver.input_to(self.editor_loop)
            return True
        
        elif self.editor == "ed":
            if str_ and self._filename == self.TMP_FILE:
                self.driver.write_file(self._filename, str_)
            self._in_editor = 1
            self.driver.ed(self._filename, "editor_finish_ed", not self.query_creator())
            return True
        
        elif self.editor == "magic":
            if str_ and self._filename == self.TMP_FILE:
                self.driver.write_file(self._filename, str_)
            self._in_editor = 1
            self._ed_ob = self.driver.new_object(self.PRESTOS_ED, self._filename, self._filename != self.TMP_FILE)
            return True
        
        elif self.editor == "command":
            self._lines = [line for line in str_.split("\n") if line]
            self.driver.printf("Enter your text.  Use ** on a line by itself to exit or ~h for help.\n")
            self._insertion_point = len(self._lines)
            self.driver.printf("%-2d] ", self._insertion_point + 1)
            self._in_editor = 1
            self.driver.input_to(self.editor_loop)
            return True
        
        return False

    def main_bit(self, str_):
        """
        Main editor loop for menu and command modes.
        
        @param str_ the input command
        """
        str_ = str_.lstrip()
        if not str_:
            if self.editor == "menu":
                self.driver.printf(f"{len(self._lines)} lines - Choose from IDLMCESQ or H for help.")
                self.driver.input_to(self.main_bit)
            else:
                self.driver.printf("%-2d] ", self._insertion_point + 1)
                self.driver.input_to(self.editor_loop)
            return
        
        cmd = str_[0].lower()
        rest = str_[1:].strip()
        
        actions = {
            "i": lambda: (self.driver.printf("Insert before line: "), self.driver.input_to(self.editor_insert)),
            "d": lambda: (self.driver.printf("Delete (line no, or n..m ie 1..2): "), self.driver.input_to(self.editor_delete)),
            "l": lambda: self.list_lines(),
            "m": lambda: (self.driver.printf("Modify which line (line no, or n..m ie 1..2): "), self.driver.input_to(self.editor_modify)),
            "c": lambda: self.back_to_insert(),
            "e": lambda: self.enter_ed_mode(),
            "s": lambda: (self.driver.printf("Quitting and saving.\n"), self.editor_do_quit("\n".join(self._lines))),
            "q": lambda: (self.driver.printf("Are you sure you want to quit? (Y/N) "), self.driver.input_to(self.editor_check_quit)),
            "h": lambda: self.show_help()
        }
        
        if cmd in actions:
            actions[cmd]()
        else:
            self.driver.printf(f"I do not understand you.  Try {'~h' if self.editor == 'command' else 'h'} for help.\n")
            self.main_bit("")

    def list_lines(self):
        """
        Lists all lines in the editor.
        """
        if not self._lines:
            self.main_bit("")
        else:
            s = "\n".join(f"{i + 1:3d}: {line}" for i, line in enumerate(self._lines))
            self.set_finish_func("end_of_edit_more")
            self.more_string(s)

    def back_to_insert(self):
        """
        Returns to insertion mode.
        """
        self._insertion_point = len(self._lines)
        self.driver.printf(f"Okay, back into insertion mode.  Use ** on a line by itself to exit.\n%-2d] ", self._insertion_point + 1)
        self.driver.input_to(self.editor_loop)

    def enter_ed_mode(self):
        """
        Switches to ed mode from menu/command mode.
        """
        self.driver.printf("Entering ed... Use \"q\" to quit, \"x\" to save and quit, \"Q\" to quit without saving changes and \"h\" for help.\n")
        self.driver.write_file(self._filename, "\n".join(self._lines))
        self.driver.ed(self._filename, "editor_exit_ed", not self.query_creator())

    def show_help(self):
        """
        Displays editor help text.
        """
        s = self.driver.read_file(self.ED_HELP_FILE)
        self.set_finish_func("end_of_edit_more")
        self.more_string(s)

    def end_of_edit_more(self):
        """
        Callback after displaying more text.
        """
        self.set_finish_func(None)
        self.main_bit("")

    def editor_delete(self, str_):
        """
        Deletes lines based on input range.
        
        @param str_ line number or range (e.g., "1" or "1..3")
        """
        try:
            if ".." in str_:
                num1, num2 = map(int, str_.split(".."))
                num1, num2 = min(num1, num2), max(num1, num2)
                if not (1 <= num1 <= num2 <= len(self._lines) + 1):
                    raise ValueError
                self.driver.printf(f"Deleting from line {num1} to line {num2}.\n")
                self._lines = self._lines[:num1 - 1] + self._lines[num2:]
            else:
                num1 = int(str_)
                if not (1 <= num1 <= len(self._lines) + 1):
                    raise ValueError
                self.driver.printf(f"Deleting line {num1}.\n")
                self._lines.pop(num1 - 1)
            self.driver.printf("Okay.\n")
        except:
            self.driver.printf(f"Error: invalid data {str_}.\n")
        self.main_bit("")

    def editor_insert(self, str_):
        """
        Inserts text before a specified line.
        
        @param str_ line number to insert before
        """
        try:
            num = int(str_)
            if not (1 <= num <= len(self._lines) + 1):
                raise ValueError
            self._insertion_point = num - 1
            self.driver.printf(f"Inserting before line {num}.  Entering insertion mode.  Use ** on a line by itself to exit\n%-2d] ", num)
            self.driver.input_to(self.editor_loop)
        except:
            self.driver.printf("Error: must be a number.\n")
            self.main_bit("")

    def editor_loop(self, str_):
        """
        Handles text input in insertion mode.
        
        @param str_ the input line
        """
        if self.editor == "command" and str_.startswith("~"):
            self.main_bit(str_[1:])
            return
        if str_ == "**":
            if self.editor == "menu":
                self.main_bit("")
            elif self._lines:
                self.editor_do_quit("\n".join(self._lines))
            else:
                self.editor_do_quit(None)
            return
        self._lines.insert(self._insertion_point, str_)
        self._insertion_point += 1
        self.driver.printf("%-2d] ", self._insertion_point + 1)
        self.driver.input_to(self.editor_loop)

    def editor_modify(self, str_):
        """
        Initiates modification of lines.
        
        @param str_ line number or range (e.g., "1" or "1..3")
        """
        try:
            if ".." in str_:
                num1, num2 = map(int, str_.split(".."))
                num1, num2 = min(num1, num2), max(num1, num2)
                if not (1 <= num1 <= num2 <= len(self._lines) + 1):
                    raise ValueError
                self.driver.printf(f"Modifying from line {num1} to line {num2}.\n")
            else:
                num1 = int(str_)
                if not (1 <= num1 <= len(self._lines) + 1):
                    raise ValueError
                self.driver.printf(f"Modifying line {num1}.\n")
                num2 = num1
            self.driver.printf("Text to change? ")
            self.driver.input_to(lambda s: self.editor_modify2(s, num1, num2))
        except:
            self.driver.printf(f"Error: invalid data {str_}.\n")
            self.main_bit("")

    def editor_modify2(self, str_, range1, range2):
        """
        Prompts for replacement text in modification.
        
        @param str_ text to replace
        @param range1 start line
        @param range2 end line
        """
        if not str_:
            self.driver.printf("Aborting.\n")
            self.main_bit("")
            return
        self.driver.printf("Change to: ")
        self.driver.input_to(lambda s: self.editor_modify3(s, range1, range2, str_))

    def editor_modify3(self, str_, range1, range2, modify_string):
        """
        Applies modification to specified lines.
        
        @param str_ replacement text
        @param range1 start line
        @param range2 end line
        @param modify_string text to replace
        """
        self.driver.printf(f"Changing all occurrences of \"{modify_string}\" to \"{str_}\" from line {range1} to line {range2}.\n")
        for i in range(range1 - 1, min(range2, len(self._lines))):
            self._lines[i] = self._lines[i].replace(modify_string, str_)
            self.driver.printf(f"{i + 1:3d}: {self._lines[i]}\n")
        self.driver.printf("Done.\n")
        self.main_bit("")

    def editor_exit_ed(self):
        """
        Exits ed mode and returns to main editor.
        """
        str_ = self.driver.read_file(self._filename)
        if self.driver.file_size(self._filename) >= 0 and not self.driver.rm(self._filename):
            self.driver.log_file(self.LOG_FILE, f"ed: couldn't rm {self._filename}\n")
        self._lines = [line for line in f"#{str_}".split("\n")]
        self._lines[0] = self._lines[0][1:]
        self.main_bit("")

    def editor_finish_ed(self):
        """
        Finishes ed mode and processes the result.
        """
        str_ = self.driver.read_file(self._filename)
        if self.driver.file_size(self._filename) >= 0 and self._filename == self.TMP_FILE and not self.driver.rm(self._filename):
            self.driver.log_file(self.LOG_FILE, f"ed: couldn't rm {self._filename}\n")
        if not str_:
            self.driver.printf("Aborted.\n")
            self.editor_do_quit(None)
        elif self._filename == self.TMP_FILE:
            self.editor_do_quit(str_)
        else:
            self.editor_do_quit(None)

    def editor_do_quit(self, str_):
        """
        Quits the editor and calls the end function.
        
        @param str_ the final text
        """
        self._lines = []
        if self.editor == "magic" and self._filename == self.TMP_FILE and self.driver.file_size(self._filename) >= 0:
            if not self.driver.rm(self._filename):
                self.driver.printf(f"magic: couldn't remove {self._filename}\n")
                str_ = None
        self._in_editor = 0
        if self._ed_ob:
            self.driver.destruct(self._ed_ob)
            self._ed_ob = None
        self._end_func(str_)

    def editor_check_quit(self, str_):
        """
        Confirms quitting without saving.
        
        @param str_ confirmation input
        """
        if str_ and str_[0].lower() != "y":
            self.driver.printf("Returning to the editor.\n")
            self.main_bit("")
        else:
            self.driver.printf("Quitting.\n")
            self.editor_do_quit(None)

    def set_editor(self, str_):
        """
        Sets the editor mode.
        
        @param str_ the editor type (menu, magic, ed, command)
        @return True if set
        """
        self.editor = str_
        self.driver.printf(f"Editor set to {str_}.\n")
        return True

    def append_signature(self):
        """
        Appends the player's signature to the text.
        
        @return signature string
        """
        from home.archaon.mud.lib.secure.player_handler import PlayerHandler
        player_handler = self.driver.find_object("/home/archaon/mud/lib/secure/player_handler.py")
        return player_handler.query_signature(self.query_name())

    def editor_check_do_quit(self):
        """
        Checks and saves editor content on forced quit.
        """
        if self._in_editor:
            self.driver.printf("Saving what you are editing.\n")
            if self.editor != "ed":
                self.editor_do_quit("\n".join(self._lines))
            else:
                self.editor_finish_ed()

    def query_editor(self):
        """
        Returns the current editor mode.
        
        @return editor mode string
        """
        return self.editor

    def query_in_editor(self):
        """
        Checks if the player is currently editing.
        
        @return True if in editor, False otherwise
        """
        return self._in_editor