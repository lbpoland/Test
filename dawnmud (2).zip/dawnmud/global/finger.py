# File: /home/archaon/mud/lib/global/finger.py
# Purpose: Manages player profile information and password handling.
# Linked Files: /home/archaon/mud/lib/secure/clothing_handler.py
# Updated Features: None identified from live Discworld MUD updates as of 2025-03-20; finger system consistent.
# Translated by: Archaon

class Finger:
    """
    Manages player-specific information such as description, password, and personal details.
    """

    def __init__(self, driver):
        self.driver = driver
        self.player_info = {}
        self.password = None
        self.tmppassword = None

    def finger_commands(self):
        """
        Sets up commands for password management.
        """
        self.driver.add_command("password", self, "", lambda: self.change_password())
        self.driver.add_command("passwd", self, "", lambda: self.change_password())

    def set_desc(self, str_):
        """
        Sets the player's description.
        
        @param str_ the description text
        """
        if not self.player_info:
            self.player_info = {}
        if str_:
            self.player_info["desc"] = str_
        elif "desc" in self.player_info:
            del self.player_info["desc"]

    def query_desc(self):
        """
        Returns the player's description.
        
        @return description string or empty string
        """
        if not self.player_info or "desc" not in self.player_info:
            return ""
        return f"{self.player_info['desc']}%^RESET%^"

    def set_zone_desc(self, zone, desc):
        """
        Sets a description for a specific zone.
        
        @param zone the zone name
        @param desc the description text
        """
        if not self.player_info:
            self.player_info = {}
        if "zone desc" not in self.player_info:
            self.player_info["zone desc"] = {}
        if desc:
            self.player_info["zone desc"][zone] = desc
        elif zone in self.player_info["zone desc"]:
            del self.player_info["zone desc"][zone]

    def query_zone_desc(self, zone):
        """
        Returns the description for a specific zone.
        
        @param zone the zone name
        @return description string or None
        """
        return self.player_info.get("zone desc", {}).get(zone, None)

    def query_zone_desc_names(self):
        """
        Returns the list of zones with descriptions.
        
        @return list of zone names
        """
        return list(self.player_info.get("zone desc", {}).keys())

    def query_main_zone_desc(self, wearing):
        """
        Returns the main zone description, excluding covered areas.
        
        @param wearing list of worn objects
        @return combined description string
        """
        from home.archaon.mud.lib.secure.clothing_handler import ClothingHandler
        clothing_handler = self.driver.find_object("/home/archaon/mud/lib/secure/clothing_handler.py")
        
        if not self.player_info.get("zone desc"):
            return ""
        
        covered = set()
        for bing in wearing:
            types = bing.query_type()
            if not isinstance(types, list):
                types = [types]
            for type_ in types:
                eq_type = clothing_handler.query_equivilant_type(type_)
                zones = clothing_handler.query_zone_names(eq_type or type_)
                covered.update(zones)
        
        return " ".join(desc.replace("$NEW_LINE$", "\n") 
                        for zone, desc in self.player_info["zone desc"].items() 
                        if zone not in covered)

    def set_password(self, pass_):
        """
        Sets the player's password, restricted to login objects.
        
        @param pass_ the password
        """
        prev_obj = self.driver.previous_object()
        fname = self.driver.file_name(prev_obj)
        if fname.startswith("/home/archaon/mud/lib/secure/login#") or fname.startswith("/home/archaon/mud/lib/secure/nlogin#"):
            self.password = pass_

    def change_password(self):
        """
        Initiates the password change process.
        
        @return True to indicate process started
        """
        if self.password:
            self.driver.write("Please enter your old password : ")
            self.driver.input_to(self.change_password2, 1)
        else:
            self.change_password2(None)
        return True

    def change_password2(self, pass_):
        """
        Verifies the old password or skips if none exists.
        
        @param pass_ the entered old password
        @return True to continue process
        """
        if self.password:
            if self.driver.crypt(pass_, self.password) != self.password:
                self.driver.write("\nIncorrect.\n")
                return True
        self.driver.write("\nEnter new Password : ")
        self.driver.input_to(self.change_password3, 1)
        return True

    def change_password3(self, pass_):
        """
        Sets a temporary new password and prompts for confirmation.
        
        @param pass_ the new password
        @return True to continue process
        """
        self.tmppassword = pass_
        if len(pass_) < 6:
            self.driver.write("\nPassword is too short, must be at least 6 characters.\n")
            self.driver.write("Enter new Password :")
            self.driver.input_to(self.change_password3, 1)
            return True
        self.driver.write("\nPlease enter again : ")
        self.driver.input_to(self.change_password4, 1)
        return True

    def change_password4(self, pass_):
        """
        Confirms and sets the new password.
        
        @param pass_ the confirmed password
        @return True if successful, False if mismatch
        """
        if self.tmppassword != pass_:
            self.driver.write("\nIncorrect.\n")
            return True
        self.password = self.driver.crypt(pass_, self.password)
        self.driver.write("\nOk.\n")
        return True

    def query_rhosts(self):
        """
        Returns the list of allowed IP addresses.
        
        @return list of IPs or None
        """
        return self.player_info.get("allowed_ips") if self.player_info else None

    def set_rhosts(self, ips):
        """
        Sets allowed IP addresses, restricted to specific commands.
        
        @param ips list of IP addresses
        """
        prev_obj = self.driver.previous_object()
        fname = self.driver.file_name(prev_obj)
        if fname not in ["/home/archaon/mud/lib/cmds/player/access.py", "/home/archaon/mud/lib/cmds/lord/authorise.py"]:
            return
        if not self.player_info:
            self.player_info = {}
        self.player_info["allowed_ips"] = ips

    def query_real_name(self):
        """
        Returns the player's real name.
        
        @return real name string or None
        """
        return self.player_info.get("real_name") if self.player_info else None

    def set_real_name(self, str_):
        """
        Sets the player's real name.
        
        @param str_ the real name
        """
        if not self.player_info:
            self.player_info = {}
        self.player_info["real_name"] = str_

    def query_where(self):
        """
        Returns the player's location.
        
        @return location string or empty string
        """
        return self.player_info.get("location", "") if self.player_info else ""

    def set_where(self, str_):
        """
        Sets the player's location.
        
        @param str_ the location
        """
        if not self.player_info:
            self.player_info = {}
        self.player_info["location"] = str_

    def query_birthday(self):
        """
        Returns the player's birthday.
        
        @return birthday string or "Unknown"
        """
        UNKNOWN_BIRTHDAY = "Unknown"  # Assumed constant
        if not self.player_info or "birthday" not in self.player_info:
            return UNKNOWN_BIRTHDAY
        return self.player_info["birthday"]

    def set_birthday(self, i):
        """
        Sets the player's birthday.
        
        @param i the birthday string
        """
        if not self.player_info:
            self.player_info = {}
        self.player_info["birthday"] = i

    def query_is_birthday_today(self):
        """
        Checks if today is the player's birthday.
        
        @return True if today is birthday, False otherwise
        """
        import time
        ctime = self.driver.ctime(self.driver.time())
        try:
            _, cmonth, cdate, _ = ctime.split(None, 3)
            cdate = int(cdate)
        except:
            return False
        
        birthday = self.query_birthday()
        try:
            bdate, _, bmonth = birthday.split(None, 2)
            bdate = int(bdate)
            bmonth = bmonth[:3]
        except:
            return False
        
        return cmonth == bmonth and cdate == bdate

    def query_email(self):
        """
        Returns the player's email, restricted to specific objects.
        
        @return email string or empty string
        """
        prev_obj = self.driver.previous_object()
        fname = self.driver.file_name(prev_obj)
        allowed = ["/home/archaon/mud/lib/secure/finger.py", 
                   "/home/archaon/mud/lib/obj/handlers/player_handler.py", 
                   "/home/archaon/mud/lib/obj/handlers/options_handler.py"]
        if not any(fname.startswith(a) for a in allowed):
            return ""
        return self.player_info.get("email", "") if self.player_info else ""

    def set_email(self, str_):
        """
        Sets the player's email.
        
        @param str_ the email address
        """
        if not self.player_info:
            self.player_info = {}
        self.player_info["email"] = str_

    def query_homepage(self):
        """
        Returns the player's homepage URL.
        
        @return homepage string or None
        """
        return self.player_info.get("homepage") if self.player_info else None

    def set_homepage(self, str_):
        """
        Sets the player's homepage URL.
        
        @param str_ the homepage URL
        """
        if not self.player_info:
            self.player_info = {}
        self.player_info["homepage"] = str_

    def finger_set(self):
        """
        Checks if finger information is set.
        
        @return True if info exists, False otherwise
        """
        return bool(self.player_info and len(self.player_info) > 1)