# File: /home/archaon/mud/lib/global/log.py
# Purpose: Manages logging of errors for a player.
# Updated Features: None identified from live Discworld MUD updates as of 2025-03-20; log system consistent.
# Translated by: Archaon

class Log:
    """
    Tracks and provides access to the last error encountered by the player.
    """

    def __init__(self, driver):
        self.driver = driver
        self.last_error = {}

    def logging_commands(self):
        """
        Placeholder for logging-related commands (none in original).
        """
        pass

    def set_last_error(self, err):
        """
        Sets the last error encountered.
        
        @param err dictionary of error details
        """
        self.last_error = err

    def get_last_error(self):
        """
        Returns the last error if it exists.
        
        @return error dictionary or None
        """
        return self.last_error if isinstance(self.last_error, dict) else None