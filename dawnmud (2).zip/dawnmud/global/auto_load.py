# File: /home/archaon/mud/lib/global/auto_load.py
# Purpose: Handles the creation and loading of auto-load data for objects, managing inventory persistence.
# Linked Files: /home/archaon/mud/lib/obj/misc/al_receipt.py, /home/archaon/mud/lib/global/cloner.py
# Updated Features: None identified from live Discworld MUD updates as of 2025-03-20; auto-load system remains consistent.
# Translated by: Archaon

class AutoLoad:
    """
    Manages the auto-loading of objects, including serialization and deserialization of object states.
    Supports static and dynamic arguments for object persistence across sessions.
    """

    AUTO_STR_LENGTH = 3
    AUTO_LOAD_TYPE = 0
    AUTO_LOAD_NAME = 1
    AUTO_LOAD_DATA = 2
    AUTO_LOAD_STATIC_ARG = 0
    AUTO_LOAD_DYNAMIC_ARG = 1

    def __init__(self, driver):
        self.driver = driver  # Driver reference for efun delegation
        self.auto_load = None  # Stores auto-load data
        self._no_calls = 0     # Tracks pending auto-load operations
        self._finished = None  # Callback function for completion

    def fragile_auto_str_ob(self, ob):
        """
        Generates fragile auto-load data for an object without error handling.
        
        @param ob the object to serialize
        @return list containing type, name, and data (static and dynamic args)
        """
        static_arg = ob.query_static_auto_load()
        dynamic_arg = ob.query_dynamic_auto_load()
        if not static_arg and not dynamic_arg:
            return []
        fname = self.driver.file_name(ob)
        if "#" in fname:
            fname = fname.split("#")[0]
            return [1, fname, [static_arg, dynamic_arg]]
        return [0, fname, [static_arg, dynamic_arg]]

    def auto_str_ob(self, ob):
        """
        Generates auto-load data for an object with error handling and receipt fallback.
        
        @param ob the object to serialize
        @return list containing type, name, and data, or receipt data on failure
        """
        static_arg = None
        dynamic_arg = None
        catch_static = None
        catch_dynamic = None
        try:
            static_arg = ob.query_static_auto_load()
        except Exception as e:
            catch_static = str(e)
        try:
            dynamic_arg = ob.query_dynamic_auto_load()
        except Exception as e:
            catch_dynamic = str(e)

        if not static_arg and not dynamic_arg:
            if catch_static or catch_dynamic:
                value = 0
                ob_name = "unknown object"
                try:
                    value = ob.query_value()
                except:
                    pass
                try:
                    ob_name = ob.short(1)
                except:
                    pass
                receipt = self.driver.find_object("/home/archaon/mud/lib/obj/misc/al_receipt.py")
                try:
                    receipt.set_object(self.driver.file_name(ob))
                    receipt.set_obname(ob_name)
                    receipt.set_value(value)
                    receipt.set_static_data([static_arg, dynamic_arg])
                except:
                    pass
                tmp = self.fragile_auto_str_ob(receipt)
                tmp[0] = 1
                if "::" in tmp[2][1] and "cloned by" not in tmp[2][1]["::"]:
                    tmp[2][1]["::"]["cloned by"] = "greco"
                return tmp
            return []

        fname = self.driver.file_name(ob)
        if "#" in fname:
            fname = fname.split("#")[0]
            return [1, fname, [static_arg, dynamic_arg]]
        return [0, fname, [static_arg, dynamic_arg]]

    def create_auto_load(self, obs, into_array):
        """
        Creates auto-load data for a list of objects.
        
        @param obs list of objects to serialize
        @param into_array if True, stores in self.auto_load; if False, returns list
        @return list of auto-load data if not into_array
        """
        if into_array:
            self.auto_load = []
        else:
            tmp = []

        for ob in reversed(obs):
            if not hasattr(ob, "query_static_auto_load"):  # Check if object-like
                continue
            try:
                al_tmp = self.auto_str_ob(ob)
                if into_array:
                    self.auto_load.extend(al_tmp)
                else:
                    tmp.extend(al_tmp)
            except:
                pass

        return tmp if not into_array else None

    def load_auto_load_alt(self, auto_string, dest, tell_pl, finished):
        """
        Loads objects from auto-load data with a callback on completion.
        
        @param auto_string the auto-load data
        @param dest destination object for loaded items
        @param tell_pl player to notify
        @param finished callback function to call when done
        """
        if not auto_string or not isinstance(auto_string, list) or len(auto_string) == 0:
            return

        if dest == self and tell_pl == self and not self.query_no_check():
            self.set_no_check(1)
            self.set_max_weight(self.query_max_weight() + 100)

        self._finished = finished
        for i in range(0, len(auto_string), self.AUTO_STR_LENGTH):
            self._no_calls += 1
            self.driver.call_out(self.int_auto_load, i // 6,
                                 auto_string[i + self.AUTO_LOAD_TYPE],
                                 auto_string[i + self.AUTO_LOAD_NAME],
                                 auto_string[i + self.AUTO_LOAD_DATA],
                                 dest, tell_pl, 0, lambda thing, place: thing.move(place))

    def load_auto_load_to_array(self, auto_string, tell_pl):
        """
        Loads objects into an array synchronously.
        
        @param auto_string the auto-load data
        @param tell_pl player to notify
        @return list of loaded objects
        """
        obs = []
        tell_pl = tell_pl or self.driver.this_player() or self
        for i in range(0, len(auto_string), self.AUTO_STR_LENGTH):
            self._no_calls += 1
            obs.extend(self.int_auto_load(auto_string[i + self.AUTO_LOAD_TYPE],
                                          auto_string[i + self.AUTO_LOAD_NAME],
                                          auto_string[i + self.AUTO_LOAD_DATA],
                                          None, tell_pl, 1, lambda *_: 0))  # MOVE_OK equivalent
        return [ob for ob in obs if ob]

    def load_auto_load_to_inventory(self, auto_string, dest, tell_pl, move_f):
        """
        Loads objects into an inventory asynchronously.
        
        @param auto_string the auto-load data
        @param dest destination object
        @param tell_pl player to notify
        @param move_f movement function
        """
        tell_pl = tell_pl or self.driver.this_player() or self
        for i in range(0, len(auto_string), self.AUTO_STR_LENGTH):
            self._no_calls += 1
            self.int_auto_load(auto_string[i + self.AUTO_LOAD_TYPE],
                               auto_string[i + self.AUTO_LOAD_NAME],
                               auto_string[i + self.AUTO_LOAD_DATA],
                               dest, tell_pl, 0, move_f)

    def create_auto_load_object(self, name, load_info, dest, tell_pl, move_f):
        """
        Creates and initializes an object from auto-load data.
        
        @param name object file name
        @param load_info static and dynamic args
        @param dest destination object
        @param tell_pl player to notify
        @param move_f movement function
        @return the created object
        """
        from home.archaon.mud.lib.global.cloner import Cloner
        cloner = self.driver.find_object("/home/archaon/mud/lib/global/cloner.py")
        try:
            name = cloner.other_file(name)
            thing = cloner.clone(name)
            if thing:
                if self.driver.base_name(thing) == name:
                    self.auto_clone_alt(thing, load_info, dest, tell_pl, move_f, name)
                else:
                    self.move_to_destination(thing, dest, tell_pl, move_f)
            else:
                raise Exception("Clone failed")
        except Exception as e:
            self.driver.tell_object(tell_pl, f"%^RED%^Could not clone {name}.%^RESET%^\n")
            thing = self.driver.clone_object("/home/archaon/mud/lib/obj/misc/al_receipt.py")
            thing.set_object(name)
            thing.set_static_save(load_info)
            self.move_to_destination(thing, dest, tell_pl, move_f)
        return thing

    def int_auto_load(self, type_, name, load_info, dest, tell_pl, now, move_f):
        """
        Internal method to load an object from auto-load data.
        
        @param type_ 1 for clone, 0 for load
        @param name object file name
        @param load_info static and dynamic args
        @param dest destination object
        @param tell_pl player to notify
        @param now synchronous flag
        @param move_f movement function
        @return list with loaded object or empty list
        """
        self._no_calls -= 1
        thing = None

        if type_:
            thing = self.create_auto_load_object(name, load_info, dest, tell_pl, move_f)
            if name == "/home/archaon/mud/lib/obj/misc/al_receipt.py":
                stuff = thing.query_static_save()
                if stuff:
                    new_thing = self.create_auto_load_object(name, load_info, dest, tell_pl, move_f)
                    if new_thing:
                        thing.dest_me()
                        thing = new_thing
        else:
            if not self.driver.find_object(name):
                try:
                    self.driver.load_object(name)
                    thing = self.driver.find_object(name)
                    if thing:
                        self.auto_clone_alt(thing, load_info, dest, tell_pl, move_f, name)
                    else:
                        self.driver.tell_object(tell_pl, f"%^RED%^Could not load {name}.%^RESET%^\n")
                except:
                    self.driver.tell_object(tell_pl, f"%^RED%^Error in loading {name}.%^RESET%^\n")
            else:
                self.driver.tell_object(tell_pl, f"%^RED%^Object {name} exists.%^RESET%^\n")

        if self._no_calls == 0 and self._finished:
            self._finished(self)
            self._finished = None
            self.set_no_check(0)
            reduce = self.query_max_weight() - self.query_loc_weight()
            if reduce > 1:
                reduce = min(reduce, 100)
                self.set_max_weight(self.query_max_weight() - reduce)
            self.calc_burden()

        return [thing] if thing else []

    def ident(self, thing):
        """
        Returns a readable identifier for an object.
        
        @param thing the object to identify
        @return string identifier
        """
        try:
            word = thing.query_short()
            if isinstance(word, str):
                return f"\"{word}\""
        except:
            pass
        return self.driver.file_name(thing)

    def auto_clone_alt(self, thing, load_info, dest, tell_pl, move_f, name):
        """
        Applies auto-load arguments to a cloned object.
        
        @param thing the cloned object
        @param load_info static and dynamic args
        @param dest destination object
        @param tell_pl player to notify
        @param move_f movement function
        @param name original object name
        """
        from home.archaon.mud.lib.global.cloner import Cloner
        cloner = self.driver.find_object("/home/archaon/mud/lib/global/cloner.py")
        
        if load_info[self.AUTO_LOAD_STATIC_ARG]:
            try:
                thing.init_static_arg(load_info[self.AUTO_LOAD_STATIC_ARG], tell_pl)
            except:
                pass
        try:
            thing.set_player(tell_pl)
        except:
            pass
        if load_info[self.AUTO_LOAD_DYNAMIC_ARG]:
            try:
                thing.init_dynamic_arg(load_info[self.AUTO_LOAD_DYNAMIC_ARG], tell_pl)
            except:
                pass

        ob_path = thing.query_property("virtual_name")
        if ob_path:
            ob_path = cloner.other_file(ob_path)
            if self.driver.file_size(ob_path) < 0:
                thing.dest_me()
                thing = self.driver.clone_object("/home/archaon/mud/lib/obj/misc/al_receipt.py")
                thing.set_object(name)
                thing.set_static_save(load_info)
                thing.set_virtobname(ob_path)
            else:
                thing.add_property("virtual_name", ob_path)

        ob_path = cloner.illegal_thing(self.driver.base_name(thing), thing.query_short())
        if ob_path:
            thing.dest_me()
            thing = self.driver.clone_object(ob_path)

        self.move_to_destination(thing, dest, tell_pl, move_f)

    def move_to_destination(self, thing, dest, tell_pl, move_f):
        """
        Moves an object to its destination, handling failures gracefully.
        
        @param thing the object to move
        @param dest destination object
        @param tell_pl player to notify
        @param move_f movement function
        """
        place = dest
        ret_val = -1  # MOVE_OK - 1
        while place and ret_val != 0:  # 0 is MOVE_OK
            try:
                ret_val = move_f(thing, place)
            except Exception as e:
                self.driver.tell_object(tell_pl, f"%^RED%^Error moving object: {str(e)}.%^RESET%^\n")
                ret_val = -1
            if ret_val != 0:
                env = self.driver.environment(place)
                if env:
                    self.driver.tell_object(tell_pl, f"%^RED%^Cannot move {self.ident(thing)} into "
                                            f"{self.ident(place)} (move returned {ret_val}); "
                                            f"attempting to move it into {self.ident(env)}.%^RESET%^\n")
                    place = env
                elif place != self.driver.environment(tell_pl) and self.driver.environment(tell_pl):
                    self.driver.tell_object(tell_pl, f"%^RED%^Cannot move {self.ident(thing)} into "
                                            f"{self.ident(place)} (move returned {ret_val}); "
                                            f"attempting to move it into environment of "
                                            f"{tell_pl.query_name()}.%^RESET%^\n")
                    place = self.driver.environment(tell_pl)
                elif place != self.driver.find_object("/home/archaon/mud/lib/room/broken.py"):
                    self.driver.tell_object(tell_pl, f"%^RED%^Cannot move {self.ident(thing)} into "
                                            f"{self.ident(place)} (move returned {ret_val}); "
                                            f"moving it to the room for broken objects --- "
                                            f"please ask a creator for help.%^RESET%^\n")
                    self.driver.load_object("/home/archaon/mud/lib/room/broken.py")
                    place = self.driver.find_object("/home/archaon/mud/lib/room/broken.py")
                else:
                    self.driver.tell_object(tell_pl, f"%^RED%^Cannot move {self.ident(thing)} into "
                                            f"the room for broken objects --- This is a serious error! "
                                            f"Please tell a creator immediately.%^RESET%^\n")
                    place = None
                move_f = lambda thing, place: thing.move(place)

    def query_auto_loading(self):
        """
        Checks if auto-loading is in progress.
        
        @return True if loading, False otherwise
        """
        return self._no_calls > 0

    def query_auto_load_string(self):
        """
        Returns the current auto-load string.
        
        @return the auto-load data
        """
        return self.auto_load

    def set_auto_load_string(self, str_):
        """
        Sets the auto-load string.
        
        @param str_ the auto-load data to set
        """
        self.auto_load = str_