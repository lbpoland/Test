# File: /home/archaon/mud/lib/global/auto_mailer.py
# Purpose: Provides automated mailing functionality for players.
# Linked Files: /home/archaon/mud/lib/secure/mailer.py, /home/archaon/mud/lib/secure/player_handler.py
# Updated Features: None identified from live Discworld MUD updates as of 2025-03-20; mail system consistent.
# Translated by: Archaon

class AutoMailer:
    """
    Facilitates sending automated mail messages, with security checks to prevent unauthorized use.
    """

    def __init__(self, driver):
        self.driver = driver  # Driver reference for efun delegation

    def auto_mail(self, to, from_, sub, cc, body, send_inter, only_to, flag):
        """
        Sends an automated mail message with security validation.
        
        @param to the recipient(s) of the mail
        @param from_ the sender's name
        @param sub the subject of the mail
        @param cc carbon copy recipient(s)
        @param body the mail content
        @param send_inter flag for interactive sending
        @param only_to restrict to specific recipients
        @param flag additional mail flags
        @return True if mail sent, False otherwise
        """
        from home.archaon.mud.lib.secure.player_handler import PlayerHandler
        player_handler = self.driver.find_object("/home/archaon/mud/lib/secure/player_handler.py")
        
        this_player = self.driver.this_player()
        if (player_handler.test_player(from_) and this_player and 
                from_ != this_player.query_name()):
            self.driver.write("AUTO_MAILER: Illegal access!\n")
            self.driver.unguarded(lambda: self.driver.write_file(
                "/log/CHEAT", f"Illegal access to AUTO_MAILER.\nBacktrace: {self.driver.back_trace()}"
            ))
            return False
        
        mailer = self.driver.find_object("/home/archaon/mud/lib/secure/mailer.py")
        return mailer.do_mail_message(to, from_, sub, cc, body, send_inter, only_to, flag)