# File: /home/archaon/mud/lib/global/command.py
# Purpose: Manages command execution and search paths for players.
# Linked Files: /home/archaon/mud/lib/secure/cmd.py
# Updated Features: None identified from live Discworld MUD updates as of 2025-03-20; command system consistent.
# Translated by: Archaon

class Command:
    """
    Handles command parsing, execution, and search path management for player inputs.
    """

    DIR_LIVING_CMDS = "/home/archaon/mud/lib/cmds/living"

    def __init__(self, driver):
        self.driver = driver
        self.current_verb = ""
        self.current_cmd = ""
        self.Forced = False
        self.SearchPath = [self.DIR_LIVING_CMDS]

    def query_current_verb(self):
        """
        Returns the current command verb.
        
        @return the current verb
        """
        return self.current_verb

    def query_current_cmd(self):
        """
        Returns the current full command.
        
        @return the current command
        """
        return self.current_cmd

    def cmdAll(self, args):
        """
        Executes a command from the input arguments.
        
        @param args the command arguments
        @return True if executed, False otherwise
        """
        from home.archaon.mud.lib.secure.cmd import CommandHandler
        cmd_d = self.driver.find_object("/home/archaon/mud/lib/secure/cmd.py")
        
        verb = type('Command', (), {'args': args, 'verb': '', 'filepart': '', 'file': ''})()
        self.current_cmd = args
        if not cmd_d.GetCommand(verb, self.SearchPath):
            return False
        
        self.current_verb = verb.verb
        if (cmd_d.IsGRCommand(verb.filepart) and 
                not self.query_known_command(verb.verb)):
            return False
        
        if self.command_shadowed(verb.verb, verb.args):
            return True
        
        try:
            tmp = self.driver.call_other(verb.file, "cmd", verb.args, verb.verb)
            if not tmp:
                return False
            if isinstance(tmp, str):
                self.driver.write(f"Error: {tmp}\n")
                return True
            return True
        except:
            return False

    def cmdPatterns(self, verb):
        """
        Retrieves command patterns for a verb.
        
        @param verb the command verb
        @return patterns or None if restricted
        """
        from home.archaon.mud.lib.secure.cmd import CommandHandler
        cmd_d = self.driver.find_object("/home/archaon/mud/lib/secure/cmd.py")
        
        if cmd_d.IsGRCommand(verb) and not self.query_known_command(verb):
            return None
        return cmd_d.GetCommandPatterns(verb, self.SearchPath)

    def command_commands(self):
        """
        Sets up command hooks if supported by the driver.
        """
        if hasattr(self.driver, "add_action"):
            self.driver.add_action(self.cmdAll, "*", -1)

    def eventForce(self, cmd):
        """
        Forces execution of a command with security checks.
        
        @param cmd the command to force
        @return result of command execution
        """
        allowed = [
            "/home/archaon/mud/lib/cmds/creator/show_help.py",
            "/home/archaon/mud/lib/d/am/broad_way/cryer_order.py",
            "/home/archaon/mud/lib/obj/handlers/new_soul.py",
            "/home/archaon/mud/lib/std/living/force.py"
        ]
        caller = self.driver.call_stack(0)[1]
        if caller not in allowed:
            raise Exception("illegal force")
        
        self.Forced = True
        try:
            res = self.driver.command(cmd)
        except Exception as e:
            self.Forced = False
            raise e
        self.Forced = False
        return res

    def AddSearchPath(self, val):
        """
        Adds paths to the command search list.
        
        @param val single path or list of paths
        @return updated search paths
        """
        if isinstance(val, str):
            val = [val]
        elif not isinstance(val, list):
            raise Exception("Bad argument 1 to AddSearchPath()")
        self.SearchPath = list(set(self.SearchPath + val))
        return self.SearchPath

    def RemoveSearchPath(self, val):
        """
        Removes paths from the command search list.
        
        @param val single path or list of paths
        @return updated search paths
        """
        if isinstance(val, str):
            val = [val]
        elif not isinstance(val, list):
            raise Exception("Bad argument 1 to RemoveSearchPath()")
        self.SearchPath = [p for p in self.SearchPath if p not in val]
        return self.SearchPath

    def GetSearchPath(self):
        """
        Returns the current search paths.
        
        @return list of search paths
        """
        return self.SearchPath

    def GetForced(self):
        """
        Checks if the last command was forced.
        
        @return True if forced, False otherwise
        """
        return self.Forced

    def GetClient(self):
        """
        Placeholder for client identification (not implemented).
        
        @return None
        """
        return None