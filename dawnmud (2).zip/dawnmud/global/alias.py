# File: /home/archaon/mud/lib/global/alias.py
# Purpose: Manages player aliases, allowing custom command shortcuts and their execution.
# Linked Files: /home/archaon/mud/lib/global/history.py, /home/archaon/mud/lib/cmds/player/alias.py,
#               /home/archaon/mud/lib/cmds/player/ealias.py, /home/archaon/mud/lib/cmds/player/unalias.py
# Updated Features: None identified from live Discworld MUD updates as of 2025-03-20; alias system remains consistent.
# Translated by: Archaon

from home.archaon.mud.lib.global.history import History

class Alias(History):
    """
    This class handles player-defined aliases, enabling custom command shortcuts.
    It integrates with the driver for command execution and maintains alias state.
    """

    def __init__(self, driver):
        super().__init__(driver)
        self.driver = driver  # Driver reference for efun delegation
        self.aliases = {}     # Mapping of alias names to their expansions
        self.doing_alias = {} # Tracks aliases currently being executed to prevent recursion
        self.in_alias_command = 0  # Counter for nested alias commands

    def add_player_alias(self, name, value):
        """
        Adds a new alias for the player, restricted to specific command objects.
        
        @param name the alias name to add
        @param value the alias expansion (list of strings or commands)
        @return True if added successfully, False otherwise
        """
        prev_obj = self.driver.previous_object()
        if (self.driver.file_name(prev_obj) not in ["/home/archaon/mud/lib/cmds/player/alias.py",
                                                    "/home/archaon/mud/lib/cmds/player/ealias.py"]):
            return False
        if name in ["unalias", "alias", "ealias"]:
            return False
        self.aliases[name] = value[:1024]  # Limit to 1024 elements per original LPC
        return True

    def query_player_alias(self, name):
        """
        Retrieves the expansion for a given alias name.
        
        @param name the alias name to query
        @return the alias expansion or None if not found
        """
        if not isinstance(self.aliases, dict):
            self.aliases = {}
            return None
        return self.aliases.get(name, None)

    def remove_player_alias(self, name):
        """
        Removes an alias, restricted to unalias command or lords.
        
        @param name the alias name to remove
        @return True if removed, False otherwise
        """
        prev_obj = self.driver.previous_object()
        this_player = self.driver.this_player(1)
        if (self.driver.file_name(prev_obj) != "/home/archaon/mud/lib/cmds/player/unalias.py" and
            name != "" and not this_player.query_lord()):
            self.driver.write(f"{self.driver.file_name(prev_obj)}\n")
            return False
        if name in self.aliases:
            del self.aliases[name]
            return True
        return False

    def alias_commands(self):
        """
        Sets up the END_ALIAS command for alias termination.
        """
        self.driver.add_command("END_ALIAS", "<string>", lambda verb, args: self.remove_alias_thing(args[0]))

    def remove_all_aliases(self):
        """
        Removes all aliases, restricted to lords.
        
        @return True if successful, False otherwise
        """
        this_player = self.driver.this_player(1)
        if not this_player.query_lord():
            self.driver.write("You can't do that :)\n")
            return False
        self.aliases = {}
        return True

    def query_aliases(self):
        """
        Returns a copy of the current aliases mapping.
        
        @return a dictionary of aliases
        """
        return self.aliases.copy()

    def is_alias(self, verb):
        """
        Checks if a verb is an alias.
        
        @param verb the command verb to check
        @return True if it’s an alias, False otherwise
        """
        return verb in self.aliases

    def exec_alias(self, verb, args):
        """
        Executes an alias by expanding and running its commands.
        
        @param verb the alias name
        @param args the arguments provided to the alias
        """
        commands = self.run_alias(verb, args)
        if commands:
            self.set_doing_alias(verb)
            for comm in commands:
                self.driver.command(comm)

    def run_alias(self, verb, args):
        """
        Prepares an alias for execution, checking recursion.
        
        @param verb the alias name
        @param args the arguments provided
        @return list of expanded commands or None if invalid
        """
        if not isinstance(self.aliases, dict):
            self.aliases = {}
        if verb not in self.aliases or self.is_doing_alias(verb):
            return None
        return self.expand_alias(verb, args)

    def is_doing_alias(self, verb):
        """
        Checks if an alias is currently being executed to prevent recursion.
        
        @param verb the alias name
        @return True if executing, False otherwise
        """
        if not isinstance(self.doing_alias, dict):
            self.doing_alias = {}
        return verb in self.doing_alias

    def set_doing_alias(self, verb):
        """
        Marks an alias as being executed.
        
        @param verb the alias name
        """
        self.doing_alias[verb] = True
        self.in_alias_command += 1

    def expand_alias(self, verb, args):
        """
        Expands an alias into a list of executable commands based on its definition.
        
        @param verb the alias name
        @param args the arguments provided
        @return list of command strings
        """
        if verb not in self.aliases:
            return [f"{verb} {args}"]
        
        ret = []
        stuff = self.aliases[verb]
        line = ""
        args = args or ""
        bits = (verb + " " + args).split()
        i = 0
        
        # Alias mask constants (simplified from LPC bitmask approach)
        ALIAS_MASK = 0xFF
        NEW_LINE, ALL_ARGS, ONE_ARG, TO_ARG, FROM_ARG, ALL_ARG, ARG_THING, ALL_IFARG, IFARG_THING, ELSE_THING, CURR_LOC, END_IF = range(12)

        while i < len(stuff):
            if isinstance(stuff[i], str):
                line += stuff[i]
            else:
                num = stuff[i] & ALIAS_MASK
                action = stuff[i] - num
                if action == NEW_LINE:
                    ret.append(line)
                    line = ""
                elif action == ALL_ARGS:
                    line += args
                elif action == ONE_ARG:
                    if num < len(bits):
                        line += bits[num]
                elif action == TO_ARG:
                    line += " ".join(bits[1:num + 1])
                elif action == FROM_ARG:
                    line += " ".join(bits[num:101])
                elif action == ALL_ARG:
                    i += 1
                    line += stuff[i] if args == "" else args
                elif action == ARG_THING:
                    i += 1
                    line += bits[num] if num < len(bits) else stuff[i]
                elif action == ALL_IFARG:
                    i += 1
                    if args == "":
                        i += stuff[i]
                elif action == IFARG_THING:
                    i += 1
                    if num >= len(bits):
                        i += stuff[i]
                elif action == ELSE_THING:
                    i += 1
                    i += stuff[i]
                elif action == CURR_LOC:
                    i += 1
                    env = self.driver.environment()
                    line += f"{self.driver.file_name(env)}.py" if env else ""
                elif action == END_IF:
                    pass
            i += 1

        if line:
            ret.append(line)
        ret.append(f"END_ALIAS {verb}")
        return ret[:1024]  # Limit per original LPC

    def remove_alias_thing(self, verb):
        """
        Cleans up after alias execution, adjusting time left.
        
        @param verb the alias name to clean up
        @return True on success
        """
        self.in_alias_command -= 1
        if verb in self.doing_alias:
            del self.doing_alias[verb]
        self.driver.this_player().adjust_time_left(-self.driver.DEFAULT_TIME)
        return True