# File: /home/archaon/mud/lib/global/communicate.py
# Purpose: Manages player communication, including speech, language, and social interactions.
# Linked Files: /home/archaon/mud/lib/cmds/player/t_ell.py, /home/archaon/mud/lib/cmds/player/rem_ote.py,
#               /home/archaon/mud/lib/secure/language_handler.py
# Updated Features: Language system updated per Discworld MUD as of 2025-03-20; uses new language tree.
# @updated: 2025-03-21 - Updated language handling to reflect new language command - Verified via https://dwwiki.mooo.com/wiki/Languages
# Translated by: Archaon

class LanguageInfo:
    def __init__(self):
        self.cur_lang = "common"
        self.mangle_accent = 1
        self.default_lang = "common"

class Communicate:
    """
    Handles communication mechanics, including speech, language selection, and social commands.
    """

    TELL_CMD = "/home/archaon/mud/lib/cmds/player/t_ell.py"
    REMOTE_CMD = "/home/archaon/mud/lib/cmds/player/rem_ote.py"

    def __init__(self, driver):
        self.driver = driver
        self._sp = [0, 0]  # Social points [current, max]
        self.cur_lang = LanguageInfo()
        self.tell_reply_list = [0, None]  # [expiry time, list]
        self.converse_ob = None

    def communicate_commands(self):
        """
        Sets up communication-related commands.
        """
        self.driver.add_command("converse", "", lambda: self.converse(None))
        self.driver.add_command("converse", "<string'person'>", lambda verb, args: self.converse(args[0]))
        self.driver.add_command("frimble", "<string>", lambda verb, args: self.do_write(args[0]))
        self.driver.add_command("repeat", "<string'command'>", lambda verb, args: self.do_repeat(args[0]))

    def query_real_max_sp(self):
        """
        Calculates the real maximum social points based on time online.
        
        @return calculated max social points
        """
        import math
        ret = int(math.sqrt(self.driver.time_on() / -15))
        return max(50, min(ret, 500))

    def query_max_sp(self):
        """
        Returns the current maximum social points.
        
        @return max social points
        """
        return self._sp[1]

    def adjust_max_sp(self, number):
        """
        Adjusts the maximum social points.
        
        @param number amount to adjust by
        @return new max social points
        """
        self._sp[1] = max(0, self._sp[1] + number)
        real_max = self.query_real_max_sp()
        self._sp[1] = min(self._sp[1], real_max)
        return self._sp[1]

    def set_max_sp(self, number):
        """
        Sets the maximum social points directly.
        
        @param number new max value
        @return adjusted max social points
        """
        return self.adjust_max_sp(number - self._sp[1])

    def query_sp(self):
        """
        Returns the current social points.
        
        @return current social points
        """
        return self._sp[0]

    def adjust_sp(self, number):
        """
        Adjusts the current social points.
        
        @param number amount to adjust by
        @return new social points or -1 if insufficient
        """
        if self._sp[0] + number < 0:
            return -1
        if number < 0:
            self.adjust_max_sp(1)
        self._sp[0] = min(self._sp[0] + number, self._sp[1])
        return self._sp[0]

    def set_sp(self, number):
        """
        Sets the current social points directly.
        
        @param number new value
        @return adjusted social points
        """
        return self.adjust_sp(number - self._sp[0])

    def comm_event(self, thing, type_, start, rest, lang, accent):
        """
        Triggers a communication event.
        
        @param thing target of the event (object or list)
        @param type_ event type
        @param start initial message
        @param rest remaining message
        @param lang language used
        @param accent accent applied
        """
        if not (hasattr(thing, "event") or isinstance(thing, list)):
            return
        self.driver.event(thing, type_, start, rest, lang, accent)
        for inv in self.driver.all_inventory():
            self.driver.call_other(inv, f"event_{type_}", self, start, rest, lang, accent)

    def comm_event_to(self, ob, event_type, start, type_, words, others, lang, me, accent):
        """
        Sends a communication event to a specific object.
        
        @param ob target object
        @param event_type event type
        @param start initial message
        @param type_ message type
        @param words message content
        @param others other involved objects
        @param lang language used
        @param me sender object
        @param accent accent applied
        """
        self.driver.event(ob, event_type, start, type_, words, others, lang, me, accent)

    def do_whisper(self, ob, event_type, start, type_, words, others, lang, me, accent):
        """
        Handles whispering to a specific object.
        
        @param ob target object
        @param event_type event type
        @param start initial message
        @param type_ message type
        @param words message content
        @param others other involved objects
        @param lang language used
        @param me sender object
        @param accent accent applied
        """
        self.driver.event(ob, event_type, start, type_, words, others, lang, me, accent)

    def do_write(self, arg):
        """
        Outputs a string directly to the player.
        
        @param arg the string to write
        @return True if successful, False otherwise
        """
        if not arg:
            self.driver.notify_fail(f"Syntax: {self.driver.query_verb()} <string>\n")
            return False
        self.driver.write(f"$I$0={arg}\n")
        self.driver.this_player().adjust_time_left(-self.driver.DEFAULT_TIME)
        return True

    def converse(self, str_=None):
        """
        Initiates a conversation mode.
        
        @param str_ optional target player name
        @return True if started, False otherwise
        """
        from home.archaon.mud.lib.secure.language_handler import LanguageHandler
        lang_hand = self.driver.find_object("/home/archaon/mud/lib/secure/language_handler.py")
        
        if not lang_hand.query_language_spoken(self.query_current_language()):
            self.driver.notify_fail(f"{self.query_current_language().capitalize()} is not a spoken language.\n")
            return False
        
        if str_:
            if not lang_hand.query_language_distance(self.query_current_language()):
                self.driver.notify_fail(f"{self.query_current_language().capitalize()} is not able to spoken at a distance.\n")
                return False
            str_ = str_.lower()
            str_ = self.expand_nickname(str_)
            self.converse_ob = self.driver.find_player(str_) or self.driver.find_living(str_)
            if not self.converse_ob:
                self.driver.notify_fail("Syntax: converse [player]\n")
                return False
            if self.converse_ob == self:
                self.driver.notify_fail("You have a nice conversation with yourself. Gee, what fun.\n")
                return False
        
        self.driver.write("Give '**' to stop.\n")
        self.driver.write("] ")
        self.driver.input_to(self.do_converse)
        return True

    def do_converse(self, str_):
        """
        Handles input during conversation mode.
        
        @param str_ the input string
        """
        if str_ == "**":
            self.driver.write("Ok.\n")
            self.converse_ob = None
            return
        if str_:
            if not self.converse_ob:
                self.driver.call_other("/home/archaon/mud/lib/cmds/living/sa_y.py", "cmd", str_)
            else:
                env = self.driver.environment()
                if hasattr(env, "trap_tell"):
                    env.trap_tell(str_, self.converse_ob, 1)
                else:
                    self.driver.call_other(self.TELL_CMD, "cmd", str_, self.converse_ob, 1)
        self.driver.write("] ")
        self.driver.input_to(self.do_converse)

    def add_language(self, lang):
        """
        Adds proficiency in a language.
        
        @param lang the language to add
        """
        from home.archaon.mud.lib.secure.language_handler import LanguageHandler
        lang_hand = self.driver.find_object("/home/archaon/mud/lib/secure/language_handler.py")
        
        if not lang_hand.test_language(lang):
            return
        if lang_hand.query_language_spoken(lang):
            skill = lang_hand.query_language_spoken_skill(lang)
            lvl = self.query_skill(skill)
            self.add_skill_level(skill, 100 - lvl)
        if lang_hand.query_language_written(lang) or lang_hand.query_language_magic(lang):
            skill = lang_hand.query_language_written_skill(lang)
            lvl = self.query_skill(skill)
            self.add_skill_level(skill, 100 - lvl)

    def fixup_lang_class(self):
        """
        Ensures the language info is properly initialized.
        """
        if not isinstance(self.cur_lang, LanguageInfo):
            tmp = self.cur_lang or "common"
            self.cur_lang = LanguageInfo()
            self.cur_lang.cur_lang = tmp

    def set_language(self, str_):
        """
        Sets the current language.
        
        @param str_ the language to set
        @return True if set, False otherwise
        """
        from home.archaon.mud.lib.secure.language_handler import LanguageHandler
        lang_hand = self.driver.find_object("/home/archaon/mud/lib/secure/language_handler.py")
        
        if not lang_hand.test_language(str_):
            return False
        self.fixup_lang_class()
        self.cur_lang.cur_lang = str_
        return True

    def query_current_language(self):
        """
        Returns the current language.
        
        @return current language string
        """
        self.fixup_lang_class()
        return self.cur_lang.cur_lang

    def set_default_language(self, def_):
        """
        Sets the default language.
        
        @param def_ the default language
        """
        self.fixup_lang_class()
        self.cur_lang.default_lang = def_

    def query_default_language(self):
        """
        Returns the default language.
        
        @return default language string
        """
        self.fixup_lang_class()
        return self.cur_lang.default_lang

    def set_mangle_accent(self, flag):
        """
        Sets whether to mangle accents.
        
        @param flag 1 to enable, 0 to disable
        """
        self.fixup_lang_class()
        self.cur_lang.mangle_accent = flag

    def query_mangle_accent(self):
        """
        Checks if accents are mangled.
        
        @return 1 if enabled, 0 if disabled
        """
        self.fixup_lang_class()
        return self.cur_lang.mangle_accent

    def do_repeat(self, str_):
        """
        Initiates repeat command mode.
        
        @param str_ the command to repeat
        @return True if started, False otherwise
        """
        if not str_:
            self.driver.notify_fail("Syntax: repeat <cmd>\n")
            return False
        self.driver.input_to(self.do_wombat_repeat, 0, str_)
        self.driver.write("Enter the commands you wish to pass to "+str_+".  '**' on a line by itself to exit.\n")
        self.driver.write("] ")
        return True

    def do_wombat_repeat(self, str_, com):
        """
        Handles input during repeat mode.
        
        @param str_ the input string
        @param com the command to repeat
        @return 0 to continue input loop
        """
        if str_ == "**":
            return 0
        self.driver.write(f"Doing '{com} {str_}'\n")
        self.driver.command(f"{com} {str_}")
        self.driver.write("] ")
        self.driver.input_to(self.do_wombat_repeat, 0, com)
        return 0

    def query_ignoring(self, people):
        """
        Returns people ignored by this object.
        
        @param people list of objects to check
        @return list of ignored objects
        """
        ignore = self.query_property("ignoring") or []
        return [p for p in people if p and p.query_name() in ignore]

    def query_ignored_by(self, people):
        """
        Returns people ignoring this object.
        
        @param people list of objects to check
        @return list of objects ignoring this one
        """
        return [p for p in people if len(p.query_ignoring([self.driver.this_player()])) > 0]

    def set_tell_reply_list(self, list_):
        """
        Sets the tell reply list with expiration.
        
        @param list_ the reply list
        @return True if set, False otherwise
        """
        prev_obj = self.driver.previous_object()
        if (not (self.driver.base_name(prev_obj).startswith(self.TELL_CMD) or 
                 self.driver.base_name(prev_obj).startswith(self.REMOTE_CMD)) and 
                not prev_obj.query_lord()):
            return False
        self.tell_reply_list = [self.driver.time() + (60 * 15), list_]
        return True

    def query_tell_reply_list(self):
        """
        Returns the current tell reply list if valid.
        
        @return reply list or None if expired/invalid
        """
        prev_obj = self.driver.previous_object()
        if (not (self.driver.base_name(prev_obj).startswith(self.TELL_CMD) or 
                 self.driver.base_name(prev_obj).startswith(self.REMOTE_CMD)) and 
                not prev_obj.query_lord()):
            return None
        if self.tell_reply_list[0] < self.driver.time():
            return None
        return self.tell_reply_list[1]