# File: /home/archaon/mud/lib/global/family.py
# Purpose: Manages family-related data and titles for a player.
# Linked Files: /home/archaon/mud/lib/secure/club_handler.py
# Updated Features: None identified from live Discworld MUD updates as of 2025-03-20; family system consistent.
# Translated by: Archaon

class FamilyInformation:
    def __init__(self):
        self.name = None
        self.adjectives = []
        self.id = None
        self.titles = ["mr", "miss", "mrs", "ms"]
        self.cur_title = None
        self.clubs = []
        self.force_title = None
        self.force_timeout = 0

class Family:
    """
    Manages a player's family affiliation, titles, and club memberships.
    """

    FAMILY_CLASS_SIZE = 8  # Number of fields in FamilyInformation

    def __init__(self, driver):
        self.driver = driver
        self._family_name = None

    def create_family_info(self):
        """
        Creates a new FamilyInformation instance with default values.
        
        @return FamilyInformation object
        """
        return FamilyInformation()

    def setup_default_titles(self):
        """
        Resets titles to default values if family info exists.
        """
        if self._family_name:
            self._family_name.titles = ["mr", "miss", "mrs", "ms"]

    def update_adjectives(self):
        """
        Updates adjectives and id based on family name and title.
        """
        if not self._family_name:
            return
        self._family_name.adjectives = []
        self._family_name.id = None
        if self._family_name.name:
            parts = self._family_name.name.lower().split()
            self._family_name.adjectives = parts[:-1]
            self._family_name.id = parts[-1]
        if self._family_name.cur_title:
            self._family_name.adjectives.extend(self._family_name.cur_title.split())

    def check_family_name(self):
        """
        Validates and updates family information.
        """
        from home.archaon.mud.lib.secure.club_handler import ClubHandler
        club_handler = self.driver.find_object("/home/archaon/mud/lib/secure/club_handler.py")
        
        if self._family_name and not isinstance(self._family_name, FamilyInformation):
            bing = str(self._family_name)
            self._family_name = self.create_family_info()
            self.set_family_name(bing)
        
        if isinstance(self._family_name, FamilyInformation) and len(vars(self._family_name)) < self.FAMILY_CLASS_SIZE:
            frog = FamilyInformation()
            for attr in ["adjectives", "id", "cur_title", "name", "titles", "clubs"]:
                setattr(frog, attr, getattr(self._family_name, attr, [] if attr == "clubs" else None))
            self._family_name = frog
        
        if self._family_name and self._family_name.name:
            if not club_handler.is_family(self._family_name.name) or not club_handler.is_member_of(self._family_name.name, self.query_name()):
                self._family_name.name = None
        
        if self._family_name and self._family_name.cur_title and len(self._family_name.cur_title) > 20:
            self.driver.tell_object(self, "%^YELLOW%^Your title is too long!  Resetting.\n%^RESET%^")
            self._family_name.cur_title = None
        
        if self._family_name and self._family_name.cur_title and self._family_name.cur_title.lower() not in self._family_name.titles:
            self.driver.tell_object(self, "%^YELLOW%^Your title is invalid!  Resetting.\n%^RESET%^")
            self._family_name.cur_title = None
        
        self.update_adjectives()
        if self._family_name and self._family_name.clubs:
            self._family_name.clubs = [club for club in self._family_name.clubs if club_handler.is_club(club)]

    def set_family_name(self, name):
        """
        Sets the player's family name.
        
        @param name the family name
        @return True if set, False otherwise
        """
        from home.archaon.mud.lib.secure.club_handler import ClubHandler
        club_handler = self.driver.find_object("/home/archaon/mud/lib/secure/club_handler.py")
        
        if name and (not club_handler.is_family(name) or not club_handler.is_member_of(name, self.query_name())):
            return False
        if not isinstance(self._family_name, FamilyInformation):
            self._family_name = self.create_family_info()
        if self._family_name.name:
            club_handler.remove_member(self._family_name.name, self.query_name())
        self._family_name.name = club_handler.query_club_name(name) if name else None
        if not name:
            self._family_name = None
        self.update_adjectives()
        return True

    def query_family_name(self):
        """
        Returns the player's family name.
        
        @return family name string or None
        """
        if isinstance(self._family_name, str):
            return self._family_name
        return self._family_name.name if self._family_name else None

    def query_player_title(self):
        """
        Returns the player's current title.
        
        @return title string or None
        """
        self.check_family_name()
        if self._family_name and isinstance(self._family_name, FamilyInformation):
            if self._family_name.force_title:
                if -self.query_time_on() > self._family_name.force_timeout:
                    self._family_name.force_title = None
                else:
                    return self._family_name.force_title.capitalize()
            if self._family_name.cur_title:
                return self._family_name.cur_title.capitalize()
        return None

    def query_all_player_titles(self):
        """
        Returns all available titles.
        
        @return list of title strings
        """
        if not self._family_name:
            self._family_name = self.create_family_info()
        return self._family_name.titles

    def set_player_title(self, title):
        """
        Sets the player's current title.
        
        @param title the title to set
        @return True if set, False otherwise
        """
        if not self._family_name:
            self._family_name = self.create_family_info()
        if title and len(title) > 20:
            return False
        if not title or title.lower() in self._family_name.titles:
            if title:
                bits = title.split()
                self._family_name.cur_title = " ".join(b.capitalize() for b in bits)
            else:
                self._family_name.cur_title = None
            self.update_adjectives()
            return True
        return False

    def set_forced_title(self, title, timeout):
        """
        Sets a forced title with a timeout.
        
        @param title the forced title
        @param timeout duration in seconds
        @return True if set
        """
        if self._family_name:
            self._family_name.force_title = title
            self._family_name.force_timeout = -self.query_time_on() + timeout
            self.driver.tell_object(self, "%^CYAN%^You feel that other peoples perception "
                                          "of you has changed and you title is being "
                                          "misinterpreted.%^RESET%^\n")
            return True
        return False

    def query_forced_title(self):
        """
        Returns the forced title if set.
        
        @return forced title string or None
        """
        return self._family_name.force_title if self._family_name else None

    def add_player_title(self, title):
        """
        Adds a new title to the available list.
        
        @param title the title to add
        @return True if added, False otherwise
        """
        title = title.lower()
        if not self._family_name:
            self._family_name = self.create_family_info()
        if title not in self._family_name.titles:
            self._family_name.titles.append(title)
            return True
        return False

    def remove_player_title(self, title):
        """
        Removes a title from the available list.
        
        @param title the title to remove
        """
        title = title.lower()
        if not self._family_name:
            self._family_name = self.create_family_info()
        if title in self._family_name.titles:
            self._family_name.titles.remove(title)
        if self._family_name.cur_title == title:
            self._family_name.cur_title = None

    def add_player_club(self, club):
        """
        Adds a club to the player's family affiliations.
        
        @param club the club name
        @return True if added, False otherwise
        """
        from home.archaon.mud.lib.secure.club_handler import ClubHandler
        club_handler = self.driver.find_object("/home/archaon/mud/lib/secure/club_handler.py")
        
        if not club:
            return False
        club = club_handler.normalise_name(club)
        if not club_handler.is_club(club):
            return False
        if not self._family_name:
            self._family_name = self.create_family_info()
        if isinstance(self._family_name, FamilyInformation) and len(vars(self._family_name)) < self.FAMILY_CLASS_SIZE:
            frog = FamilyInformation()
            for attr in ["adjectives", "id", "cur_title", "name", "titles"]:
                setattr(frog, attr, getattr(self._family_name, attr))
            frog.clubs = []
            self._family_name = frog
        if club not in self._family_name.clubs:
            self._family_name.clubs.append(club)
            return True
        return False

    def remove_player_club(self, club):
        """
        Removes a club from the player's family affiliations.
        
        @param club the club name
        """
        from home.archaon.mud.lib.secure.club_handler import ClubHandler
        club_handler = self.driver.find_object("/home/archaon/mud/lib/secure/club_handler.py")
        
        if not club:
            return
        club = club_handler.normalise_name(club)
        if self._family_name and club in self._family_name.clubs:
            self._family_name.clubs.remove(club)

    def query_player_clubs(self):
        """
        Returns the list of player's family clubs.
        
        @return list of club names
        """
        return self._family_name.clubs if self._family_name else []

    def parse_command_id_list(self):
        """
        Returns the family ID for command parsing.
        
        @return list of ID strings
        """
        return [self._family_name.id] if self._family_name and self._family_name.id else []

    def parse_command_plural_id_list(self):
        """
        Returns the pluralized family ID for command parsing.
        
        @return list of plural ID strings
        """
        from home.archaon.mud.lib.secure.language_handler import LanguageHandler
        lang_hand = self.driver.find_object("/home/archaon/mud/lib/secure/language_handler.py")
        
        if self._family_name and self._family_name.id:
            return [lang_hand.pluralize(self._family_name.id)]
        return []

    def parse_command_adjectiv_id_list(self):
        """
        Returns the family adjectives for command parsing.
        
        @return list of adjective strings
        """
        return self._family_name.adjectives if self._family_name else []