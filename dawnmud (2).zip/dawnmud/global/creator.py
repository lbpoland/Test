# File: /home/archaon/mud/lib/global/creator.py
# Purpose: Provides creator-specific functionality and overrides.
# Linked Files: /home/archaon/mud/lib/global/wiz_file_comm.py, /home/archaon/mud/lib/secure/login_handler.py
# Updated Features: None identified from live Discworld MUD updates as of 2025-03-20; creator system consistent.
# Translated by: Archaon

from home.archaon.mud.lib.global.wiz_file_comm import WizFileComm

class Creator(WizFileComm):
    """
    Extends player functionality with creator-specific privileges and behaviors.
    """

    def __init__(self, driver):
        super().__init__(driver)
        self.driver = driver

    def move_player_to_start(self, bong, new_pl, c_name, ident, go_invis):
        """
        Moves a creator to their starting location with additional messaging.
        
        @param bong unused parameter (legacy)
        @param new_pl new player flag
        @param c_name creator name
        @param ident identifier
        @param go_invis invisibility flag
        """
        prev_obj = self.driver.file_name(self.driver.previous_object())
        if not (prev_obj.startswith("/secure/login#") or prev_obj.startswith("/secure/nlogin#")):
            return False
        
        super().move_player_to_start(bong, new_pl, c_name, ident, go_invis)
        from home.archaon.mud.lib.secure.login_handler import LoginHandler
        login_handler = self.driver.find_object("/home/archaon/mud/lib/secure/login_handler.py")
        self.driver.write(login_handler.get_message("/doc/CREATORNEWS"))
        if self.query_invis():
            self.driver.tell_object(self, "===> You are currently INVISIBLE! <===\n")

    def query_creator(self):
        """
        Identifies this object as a creator.
        
        @return True
        """
        return True

    def query_object_type(self, obj=None):
        """
        Returns the creator type (Senior or Creator).
        
        @param obj unused parameter (legacy)
        @return 'S' for senior, 'C' for creator
        """
        master = self.driver.master()
        return "S" if master.query_senior(self.query_name()) else "C"

    def receive_snoop(self, bing):
        """
        Displays snoop messages to the creator.
        
        @param bing the snoop message
        """
        self.driver.tell_object(self, f"] {bing}")