# File: /home/archaon/mud/lib/global/cloner.py
# Purpose: Manages object cloning and file mappings for object replacement.
# Linked Files: /home/archaon/mud/lib/std/object.py
# Updated Features: None identified from live Discworld MUD updates as of 2025-03-20; cloner system consistent.
# Translated by: Archaon

from home.archaon.mud.lib.std.object import Object

class Cloner(Object):
    """
    Handles object cloning, maintains mappings for file replacements, and tracks illegal objects.
    """

    SAVE_FILE = "/save/cloner"
    SAVE_FILE_DELAY = 15
    LIFE_TIME = 7257600  # Approx 84 days

    def __init__(self, driver):
        super().__init__(driver)
        self.driver = driver
        self.changes = {}    # Mapping of original to replacement files
        self.illegal = {}    # Mapping of illegal objects to replacements
        self._save_file_call_out = 0
        self.load_file()

    def query_changes(self):
        """
        Returns the current file mappings.
        
        @return dictionary of file mappings
        """
        return self.changes

    def save_file(self):
        """
        Saves the cloner state to disk.
        """
        self._save_file_call_out = 0
        self.driver.unguarded(lambda: self.save_object(self.SAVE_FILE))

    def load_file(self):
        """
        Loads the cloner state from disk if it exists.
        """
        if self.driver.file_size(f"{self.SAVE_FILE}.o") > 0:
            self.driver.unguarded(lambda: self.restore_object(self.SAVE_FILE))

    def setup(self):
        """
        Initializes the cloner with empty mappings.
        """
        self.changes = {}
        self.illegal = {}
        self.load_file()
        self._save_file_call_out = 0

    def clone(self, word):
        """
        Clones an object, applying any file mappings.
        
        @param word the file path to clone
        @return the cloned object or None on failure
        """
        new_file = self.changes.get(word, [word])[0]
        try:
            return self.driver.clone_object(new_file)
        except:
            return None

    def other_file(self, word):
        """
        Returns the mapped file path if it exists.
        
        @param word the original file path
        @return the mapped path or original path
        """
        return self.changes.get(word, [word])[0]

    def add_mapping(self, from_, to):
        """
        Adds a file mapping from one path to another.
        
        @param from_ the original file path
        @param to the replacement file path
        @return True if added, False otherwise
        """
        from_ = from_.rstrip(".c")
        to = to.rstrip(".c")
        if self.driver.file_size(to) < 1 and self.driver.file_size(f"{to}.c") < 1:
            self.driver.write("Destination file does not exist\n")
            return False
        
        self.changes[from_] = [to, self.driver.time()]
        if not self._save_file_call_out:
            self._save_file_call_out = self.driver.call_out(self.save_file, self.SAVE_FILE_DELAY)
        
        obj_name = (self.driver.this_player().query_cap_name() if self.driver.this_player() 
                    else self.driver.file_name(self.driver.previous_object()))
        self.driver.write(f"Mapping of {from_} to {to} added.\n")
        self.driver.log_file("CLONER", f"Mapping of {from_} to {to} added by {obj_name} at {self.driver.ctime(self.driver.time())}.\n")
        
        self.driver.remove_call_out("clean_up")
        self.driver.call_out(self.clean_up, 120 + self.driver.random(500))
        return True

    def remove_mapping(self, from_):
        """
        Removes a file mapping.
        
        @param from_ the original file path to remove
        @return True if removed, False otherwise
        """
        if from_ in self.changes:
            del self.changes[from_]
            self.save_file()
            obj_name = (self.driver.this_player().query_cap_name() if self.driver.this_player() 
                        else self.driver.file_name(self.driver.previous_object()))
            self.driver.write(f"Mapping of {from_} removed.\n")
            self.driver.log_file("CLONER", f"Mapping of {from_} removed by {obj_name} at {self.driver.ctime(self.driver.time())}.\n")
            return True
        self.driver.write(f"No mapping found for {from_}.\n")
        return False

    def list_mappings(self, str_=None):
        """
        Lists all mappings, optionally filtered by a substring.
        
        @param str_ substring to filter mappings
        @return string of mappings
        """
        retval = ""
        for from_, data in self.changes.items():
            if not str_ or str_ in from_ or str_ in data[0]:
                retval += f"{from_} -> {data[0]}\n"
        return retval

    def add_illegal(self, basename, short, replacement):
        """
        Adds an illegal object mapping.
        
        @param basename the base file name
        @param short the short description
        @param replacement the replacement file path
        @return True if added, False otherwise
        """
        if not self.illegal:
            self.illegal = {}
        key = f"{basename}:{short}"
        if key in self.illegal or (self.driver.file_size(replacement) < 1 and 
                                   self.driver.file_size(f"{replacement}.c") < 1):
            return False
        self.illegal[key] = replacement
        self.save_file()
        return True

    def remove_illegal(self, basename, short):
        """
        Removes an illegal object mapping.
        
        @param basename the base file name
        @param short the short description
        @return True if removed, False otherwise
        """
        if not self.illegal:
            return False
        key = f"{basename}:{short}"
        if key in self.illegal:
            del self.illegal[key]
            self.save_file()
            return True
        return False

    def query_illegal(self):
        """
        Returns the illegal object mappings.
        
        @return dictionary of illegal mappings
        """
        return self.illegal

    def illegal_thing(self, basename, short):
        """
        Checks if an object is illegal and returns its replacement.
        
        @param basename the base file name
        @param short the short description
        @return replacement path or None
        """
        return self.illegal.get(f"{basename}:{short}", None)

    def clean_up(self):
        """
        Removes outdated or invalid mappings.
        """
        for from_, data in list(self.changes.items()):
            if (data[1] < self.driver.time() - self.LIFE_TIME or 
                (self.driver.file_size(data[0]) < 1 and self.driver.file_size(f"{data[0]}.c") < 1)):
                del self.changes[from_]
        self.save_file()