# File: /home/archaon/mud/lib/global/guild_race.py
# Purpose: Manages guild and race settings for a player.
# Linked Files: /home/archaon/mud/lib/secure/cmd.py
# Updated Features: None identified from live Discworld MUD updates as of 2025-03-20; guild/race system consistent.
# Translated by: Archaon

class GuildRace:
    """
    Handles guild and race configurations, including command paths and initialization.
    """

    def __init__(self, driver):
        self.driver = driver
        self.race_ob = None
        self.guild_ob = None
        self.known_commands = ["skills", "rearrange", "gp", "newbie"]
        self.guild_data = None
        self._race = None

    def race_guild_commands(self):
        """
        Sets up guild and race-specific commands and initializes player settings.
        """
        from home.archaon.mud.lib.secure.cmd import CommandHandler
        cmd_d = self.driver.find_object("/home/archaon/mud/lib/secure/cmd.py")
        
        paths = []
        for command in self.known_commands:
            bing = cmd_d.GetPaths(command)
            if bing:
                bing = [p for p in bing if p.startswith("/home/archaon/mud/lib/cmds/guild_race")]
                paths.extend(bing)
        
        self.AddSearchPath(paths)
        if self.guild_ob:
            try:
                self.driver.find_object(self.guild_ob).start_player(self)
            except:
                pass
        if self.race_ob:
            try:
                self.driver.find_object(self.race_ob).start_player(self)
            except:
                pass
        self.query_limbs()

    def query_gtitle(self):
        """
        Returns the player's guild title.
        
        @return guild title string or error message
        """
        if not self.guild_ob:
            return None
        try:
            return self.driver.find_object(self.guild_ob).query_title(self)
        except:
            return "Has a broken guild"

    def set_race_ob(self, str_):
        """
        Sets the player's race object.
        
        @param str_ the race object path
        """
        if str_.startswith("/"):
            str_ = str_[1:]
        if not str_.startswith("std/races"):
            self.driver.write("Illegal path to set_race_ob.\n")
            return
        if str_.startswith("std/races/god") and not self.driver.master().god(self.driver.geteuid()):
            self.driver.write("The heavens rumble and the earth shakes.  You stop.\n")
            return
        self.race_ob = f"/home/archaon/mud/lib/{str_}"

    def query_race_ob(self):
        """
        Returns the player's race object path.
        
        @return race object path
        """
        return self.race_ob

    def set_guild_ob(self, str_):
        """
        Sets the player's guild object.
        
        @param str_ the guild object path
        """
        if not str_:
            self.guild_ob = None
            return
        if not str_.startswith("/home/archaon/mud/lib/std/guilds"):
            self.driver.tell_object(self, f"Attempt to set invalid guild object {str_}\n")
            return
        if not self.driver.find_object(str_):
            self.driver.tell_object(self, f"No such object {str_}\n")
            return
        self.guild_ob = str_

    def query_guild_ob(self):
        """
        Returns the player's guild object path.
        
        @return guild object path or None
        """
        if not self.guild_ob or not self.guild_ob.startswith("/home/archaon/mud/lib/std/guilds"):
            return None
        return self.guild_ob

    def set_guild_data(self, dat):
        """
        Sets guild-specific data.
        
        @param dat the guild data
        """
        self.guild_data = dat

    def query_guild_data(self):
        """
        Returns guild-specific data.
        
        @return guild data
        """
        return self.guild_data

    def query_race(self):
        """
        Returns the player's race name.
        
        @return race name string
        """
        if not self._race and self.race_ob:
            self._race = self.driver.find_object(self.race_ob).query_name()
        return self._race

    def help_command(self, str_):
        """
        Retrieves help text for a command.
        
        @param str_ the command name
        @return help text or None
        """
        from home.archaon.mud.lib.secure.cmd import CommandHandler
        cmd_d = self.driver.find_object("/home/archaon/mud/lib/secure/cmd.py")
        
        cmd = type('Command', (), {'verb': str_, 'filepart': '', 'file': ''})()
        if (str_ in self.known_commands or self.query_creator()) and cmd_d.HandleStars(cmd):
            path = f"{cmd_d.GetPaths(cmd.verb)[0]}/{cmd.verb}"
            try:
                func = self.driver.find_object(path).help_function()
                if func:
                    return func
                return self.driver.find_object(path).help()
            except:
                return None
        return None

    def query_known_commands(self):
        """
        Returns a copy of known commands.
        
        @return list of command names
        """
        return self.known_commands[:]

    def query_known_command(self, word):
        """
        Checks if a command is known.
        
        @param word the command name
        @return True if known, False otherwise
        """
        return word in self.known_commands

    def add_known_command(self, str_):
        """
        Adds a known command to the player's list.
        
        @param str_ the command name
        @return True if added, False otherwise
        """
        from home.archaon.mud.lib.secure.cmd import CommandHandler
        cmd_d = self.driver.find_object("/home/archaon/mud/lib/secure/cmd.py")
        
        if str_ in self.known_commands or not cmd_d.IsGRCommand(str_):
            return False
        
        paths = [p for p in cmd_d.GetPaths(str_) if p.startswith("/home/archaon/mud/lib/cmds/guild_race")]
        if paths:
            self.AddSearchPath(paths)
        
        self.known_commands.append(str_)
        if self.driver.interactive(self):
            callers = [f"{self.driver.file_name(o)} ({o.query_name() if hasattr(o, 'query_name') else 'Unknown'})" 
                       for o in self.driver.previous_object(-1)]
            self.driver.log_file("ADD_KNOWN_COMMAND", 
                                 f"{self.driver.ctime(self.driver.time())}: {str_} was added to {self.driver.this_player().query_name()} by: {', '.join(callers)}.\n")
        return True

    def remove_known_command(self, str_):
        """
        Removes a known command from the player's list.
        
        @param str_ the command name
        @return True if removed, False otherwise
        """
        if str_ in self.known_commands:
            self.known_commands.remove(str_)
            return True
        return False