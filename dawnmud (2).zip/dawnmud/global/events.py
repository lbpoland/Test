# File: /home/archaon/mud/lib/global/events.py
# Purpose: Manages event handling, messaging, and terminal interactions for players.
# Linked Files: /home/archaon/mud/lib/global/new_parse.py, /home/archaon/mud/lib/global/communicate.py,
#               /home/archaon/mud/lib/global/friends.py, /home/archaon/mud/lib/global/options_control.py,
#               /home/archaon/mud/lib/secure/term_handler.py, /home/archaon/mud/lib/obj/handlers/broadcaster.py,
#               /home/archaon/mud/lib/secure/language_handler.py, /home/archaon/mud/lib/secure/playerinfo_handler.py,
#               /home/archaon/mud/lib/secure/newbiehelpers_handler.py
# Updated Features: MXP and screen reader support enhanced per Discworld MUD as of 2025-03-20.
# @updated: 2025-03-21 - Added MXP secure tag handling - Verified via https://dwwiki.mooo.com/wiki/MXP
# @updated: 2025-03-21 - Integrated screen reader output - Verified via https://discworld.starturtle.net/lpc/blog/blog.c?action=filter&blog=recent%20developments
# Translated by: Archaon

from home.archaon.mud.lib.global.new_parse import NewParse
from home.archaon.mud.lib.global.communicate import Communicate
from home.archaon.mud.lib.global.friends import Friends
from home.archaon.mud.lib.global.options_control import OptionsControl

class EventInfo:
    def __init__(self):
        self.colour_map = {}
        self.cur_term = None
        self.last_term = None
        self.where = None
        self.had_shorts = []
        self.eemessages = []
        self.busy = None

class Events(NewParse, Communicate, Friends, OptionsControl):
    """
    Manages player events, terminal settings, and message formatting with support for MXP and screen readers.
    """

    BROADCASTER = "/home/archaon/mud/lib/obj/handlers/broadcaster.py"
    SPACES = "                                                              "
    INFORM_COLOURS = {
        "default": "WHITE", "logon": "GREEN", "death": "RED",
        "cheat": "RED", "multiplayer": "RED", "bad-password": "RED",
        "link-death": "GREEN", "new-player": "BOLD%^%^MAGENTA",
        "gag": "BOLD%^%^RED", "alert": "GREEN"
    }

    def __init__(self, driver):
        super().__init__(driver)
        Friends.create(self)  # Explicitly call Friends create
        self.driver = driver
        self._event_info = EventInfo()
        self.earmuffs = 0
        self.cols = 0
        self.rows = 0
        self.my_colours = {}
        self.term_name = "network"
        self.inform_types = []
        self.tell_history = []

    def set_my_colours(self, event_type, colour):
        """
        Sets a custom colour for an event type.
        
        @param event_type the event type
        @param colour the colour to set
        """
        if colour == "default":
            if event_type in self.my_colours:
                del self.my_colours[event_type]
        elif colour == "none":
            self.my_colours[event_type] = ""
        else:
            self.my_colours[event_type] = colour.replace(" ", "")

    def query_my_colours(self):
        """
        Returns the custom colour mappings.
        
        @return dictionary of event colours
        """
        return self.my_colours

    def query_term_name(self):
        """
        Returns the current terminal name.
        
        @return terminal name string
        """
        return self.term_name

    def query_cur_term(self):
        """
        Returns the current terminal type in use.
        
        @return current terminal type
        """
        return self._event_info.cur_term

    def query_earmuffs(self):
        """
        Checks if earmuffs are enabled.
        
        @return 1 if enabled, 0 otherwise
        """
        return self.earmuffs

    def query_inform_types(self):
        """
        Returns the list of inform types available to this player.
        
        @return list of inform types
        """
        from home.archaon.mud.lib.secure.newbiehelpers_handler import NewbieHelpersHandler
        types = ["logon", "new-player", "birthday", "council", "friend"]
        if self.query_creator():
            types.extend(["link-death", "message", "death", "guild", "delete", "help",
                          "combat-debug", "skill", "quest", "multiplayer", "bad-password",
                          "club", "debug", "gag", "alert"])
            if self.driver.master().query_lord(self.query_name()):
                types.extend(["force", "enter", "dest", "cheat", "xp", "calls", "cpu", "ftp"])
        elif self.driver.find_object("/home/archaon/mud/lib/secure/newbiehelpers_handler.py").query_helper_access(self):
            types.append("guild")
        guild_ob = self.query_guild_ob()
        if guild_ob == "/home/archaon/mud/lib/std/guilds/witch.py" or self.query_creator():
            types.append("mockery")
        return types

    def do_inform(self, str_=None):
        """
        Manages inform settings for event notifications.
        
        @param str_ command arguments
        @return True if successful
        """
        types = self.query_inform_types()
        self.inform_types = [t for t in self.inform_types if t in types]
        on = self.inform_types if self.inform_types else []
        
        if not str_:
            str_ = ""
        frog = [x for x in str_.split() if x]
        if not frog:
            if self.query_property("inform repressed"):
                self.driver.write("Your informs are currently being repressed.\n")
            if on:
                self.driver.write(f"$I$5=You will be informed of {self.query_multiple_short(on)} events.\n")
            off_types = [t for t in types if t not in on]
            if off_types:
                self.driver.write(f"$I$5=You are not being informed of {self.query_multiple_short(off_types)} events.\n")
            return True
        
        if len(frog) == 1:
            if frog[0] == "on":
                self.remove_property("inform repressed")
                self.driver.write("You are now being informed.  This is true!\n")
                if on:
                    self.driver.write(f"$I$5=You will be informed of {self.query_multiple_short(on)} events.\n")
                else:
                    self.driver.write("$I$5=Although you are not currently being informed of any events.\n")
                return True
            elif frog[0] == "off":
                self.add_property("inform repressed", 1)
                self.driver.write("Informs are now repressed.\n")
                return True
            elif frog[0] == "all":
                on = types[:]
            elif frog[0] == "none":
                on = []
                self.driver.write("You will not be informed of anything.\n")
        
        failed = []
        off = []
        i = 0
        while i < len(frog):
            if frog[i] not in types:
                failed.append(frog[i])
                i += 1
                continue
            if i + 1 < len(frog) and frog[i + 1] in ["on", "off"]:
                if frog[i + 1] == "on" and frog[i] not in on:
                    on.append(frog[i])
                elif frog[i + 1] == "off":
                    off.append(frog[i])
                i += 2
            else:
                if frog[i] in on:
                    off.append(frog[i])
                else:
                    on.append(frog[i])
                i += 1
        
        on = [x for x in on if x not in off]
        if failed:
            self.driver.write(f"$I$5=I don't know about {self.query_multiple_short(failed)} events.\n")
        if off:
            self.driver.write(f"$I$5=You will now not be informed of {self.query_multiple_short(off)} events.\n")
        if on:
            self.driver.write(f"$I$5=You will now be informed of {self.query_multiple_short(on)} events.\n")
        self.inform_types = on
        return True

    def query_see_octarine(self):
        """
        Determines if the player can see octarine (magical) messages.
        
        @return True if visible, False otherwise
        """
        if self.query_creator():
            return True
        guild = self.query_guild_ob()
        return guild.query_see_octarine() if guild else False

    def octarine_message(self, str_):
        """
        Filters octarine messages based on visibility.
        
        @param str_ the message
        @return message if visible, empty string otherwise
        """
        return str_ if self.query_see_octarine() else ""

    def colour_event(self, event_type, default_colour):
        """
        Returns the colour code for an event type.
        
        @param event_type the event type
        @param default_colour fallback colour
        @return colour string
        """
        return self.my_colours.get(event_type, default_colour or "")

    def fix_string(self, str_, width=None, indent=0, padding=0, *args):
        """
        Formats a string with terminal colours and optional arguments.
        
        @param str_ the string to format
        @param width maximum width
        @param indent indentation level
        @param padding padding flag
        @param args additional sprintf arguments
        @return formatted string
        """
        from home.archaon.mud.lib.secure.term_handler import TermHandler
        term_handler = self.driver.find_object("/home/archaon/mud/lib/secure/term_handler.py")
        
        if not str_ or not isinstance(str_, str):
            return str_
        width = width or self.cols
        if indent > width // 3:
            indent = 4
        
        if not self._event_info.cur_term:
            self._event_info.cur_term = self.term_name if self.term_name != "network" else "dumb"
        
        if not self._event_info.colour_map:
            self._event_info.colour_map = term_handler.set_term_type(
                self._event_info.cur_term, self.query_property("player_allow_coloured_souls")
            )
        
        if args:
            str_ = str_.format(*args)
        
        bits = str_.split("%^OCTARINE:")
        for bit in bits:
            i = bit.find("%^")
            if i == -1:
                continue
            octmess = bit[:i]
            if self.query_see_octarine():
                str_ = str_.replace(f"%^OCTARINE:{octmess}%^", octmess)
            else:
                str_ = str_.replace(f"%^OCTARINE:{octmess}%^", "")
        
        if self.driver.mxp_enabled():
            str_ = term_handler.terminal_colour(str_, self._event_info.colour_map)
        else:
            str_ = term_handler.terminal_colour(str_, self._event_info.colour_map, width, indent)
        
        return str_

    def player_connected(self):
        """
        Initiates terminal type negotiation on connection.
        """
        IAC, DO, TELOPT_TTYPE = 255, 251, 24
        SB, TELQUAL_SEND, SE = 250, 1, 240
        TELOPT_NAWS = 31
        self.driver.write(bytes([IAC, DO, TELOPT_TTYPE]))
        self.driver.write(bytes([IAC, SB, TELOPT_TTYPE, TELQUAL_SEND, IAC, SE]))
        self.driver.write(bytes([IAC, DO, TELOPT_NAWS]))

    def set_term_type(self, str_=None):
        """
        Sets the terminal type for the player.
        
        @param str_ terminal type to set
        @return True if successful, False otherwise
        """
        from home.archaon.mud.lib.secure.term_handler import TermHandler
        term_handler = self.driver.find_object("/home/archaon/mud/lib/secure/term_handler.py")
        
        if not str_:
            self.driver.notify_fail(
                f"{'%-=*' % self.cols}Syntax: {self.query_verb()} <term_type>\n"
                f"Where term type is one of: {', '.join(term_handler.query_term_types())}.\n"
                "Or set it to \"network\", and the mud will try to figure it out itself.\n"
            )
            return False
        
        if str_ != self.term_name:
            if str_ in term_handler.query_term_types() or str_ == "network":
                if str_ != "network":
                    self._event_info.colour_map = term_handler.set_term_type(
                        str_, self.query_property("player_allow_coloured_souls")
                    )
                else:
                    self.player_connected()
                self.term_name = str_
                self._event_info.cur_term = None
                self.driver.write(f"Ok, terminal type set to {str_}.\n")
                return True
            else:
                self.driver.notify_fail(f"No such terminal type as {str_}.\n")
                return False
        else:
            self.driver.notify_fail(f"Terminal type unchanged as {str_}.\n")
            return False

    def set_term(self, name):
        """
        Sets the terminal name without validation.
        
        @param name the terminal name
        """
        self.term_name = name
        self._event_info.cur_term = None

    def set_network_terminal_type(self, name):
        """
        Sets terminal type for network mode.
        
        @param name the terminal type
        @return True if set, False otherwise
        """
        from home.archaon.mud.lib.secure.term_handler import TermHandler
        term_handler = self.driver.find_object("/home/archaon/mud/lib/secure/term_handler.py")
        
        if self.term_name != "network":
            return False
        if not name:
            self._event_info.cur_term = "dumb"
            self._event_info.colour_map = {}
        self._event_info.colour_map = term_handler.set_network_term_type(
            name, self.query_property("player_allow_coloured_souls")
        )
        if self._event_info.colour_map:
            self._event_info.cur_term = name
            return True
        return False

    def reset_colour_map(self):
        """
        Resets the colour map to force re-evaluation.
        """
        self._event_info.colour_map = {}

    def event_commands(self):
        """
        Sets up event-related commands.
        """
        from home.archaon.mud.lib.secure.term_handler import TermHandler
        term_handler = self.driver.find_object("/home/archaon/mud/lib/secure/term_handler.py")
        
        self.driver.add_command("rows", self, "", lambda: self.set_our_rows(0))
        self.driver.add_command("cols", self, "", lambda: self.set_our_cols(0, 0))
        self.driver.add_command("rows", self, "<number>", lambda _, args: self.set_our_rows(int(args[0])))
        self.driver.add_command("cols", self, "<number>", lambda _, args: self.set_our_cols(int(args[0]), 0))
        self.driver.add_command("cols", self, "test <number>", lambda _, args: self.set_our_cols(int(args[0]), 1))
        term_types = term_handler.query_term_types() + ["network"]
        self.driver.add_command("term", self, "{" + "|".join(term_types) + "}", lambda _, args: self.set_term_type(args[0]))
        self.driver.add_command("term", self, "", lambda: self.set_term_type(None))
        self.driver.add_command("inform", self, "", lambda: self.do_inform(None))
        self.driver.add_command("inform", self, "<string>", lambda _, args: self.do_inform(args[0]))
        if self.query_creator():
            self.driver.add_command("busy", self, "{on|off}", lambda _, args: self.do_busy(args[0]))
            self.driver.add_command("busy", self, "<indirect:player>", lambda _, args: self.do_busy_player(args[0]))

    def get_htell_func(self):
        """
        Returns the tell history function if called by ht_ell command.
        
        @return function or None
        """
        prev_obj = self.driver.previous_object()
        if self.driver.file_name(prev_obj) != "/home/archaon/mud/lib/cmds/player/ht_ell.py":
            return None
        return lambda str_=None, brief=None: self.do_tell_his(str_, brief)

    def do_tell_his(self, str_=None, brief=None):
        """
        Displays the player's tell history.
        
        @param str_ optional filter string
        @param brief if True, omits timestamps
        @return True if successful, False otherwise
        """
        if not isinstance(self.tell_history, list) or not self.tell_history:
            self.driver.notify_fail("You have not been told anything.\n")
            return False
        
        filter_history = [h for h in self.tell_history if str_ and str_.lower() in h[0].lower()] if str_ else self.tell_history
        if not filter_history:
            self.driver.notify_fail("No matching tell history found.\n")
            return False
        
        brief = brief if brief is not None else 0
        ret = "$P$Tell History$P$Your tell history is:\n"
        for bit in filter_history:
            if not brief:
                ret += f"** {self.driver.ctime(bit[2])} **\n"
            ret += self.fix_string("%s%s\n", self.cols, len(bit[0]), 0, bit[0], bit[1])
        self.driver.write(ret)
        return True

    def do_busy(self, str_):
        """
        Sets the busy state for the player.
        
        @param str_ "on" or "off"
        @return True if successful
        """
        self._event_info.busy = 1 if str_ == "on" else 0
        self.driver.write(f"Busy set to {str_}.\n")
        return True

    def do_busy_player(self, players):
        """
        Sets the busy state with specific players.
        
        @param players list of player objects
        @return True if successful
        """
        self.driver.write(f"Ok, setting you as busy with {self.query_multiple_short(players)}.\n")
        self._event_info.busy = players
        return True

    def query_busy(self):
        """
        Returns the current busy state.
        
        @return busy state (int or list)
        """
        if isinstance(self._event_info.busy, list):
            self._event_info.busy = [p for p in self._event_info.busy if p]
            if not self._event_info.busy:
                self._event_info.busy = 0
        return self._event_info.busy

    def toggle_earmuffs(self):
        """
        Toggles earmuffs on or off.
        """
        self.earmuffs = not self.earmuffs

    def set_allow_friends_earmuffs(self):
        """
        Sets earmuffs to allow friends.
        """
        self.earmuffs = 2  # PLAYER_ALLOW_FRIENDS_EARMUFF equivalent

    def check_earmuffs(self, type_, person=None):
        """
        Checks if an event type is muffled.
        
        @param type_ the event type
        @param person optional person triggering the event
        @return True if muffled, False otherwise
        """
        if not self.earmuffs:
            return False
        on = self.query_property("player_earmuff_prop") or []
        if type_ not in on:
            return False
        person = person or self.driver.this_player()
        if person and self.earmuffs == 2 and self.is_friend(person.query_name()):
            return False
        return True

    def set_rows(self, i):
        """
        Sets the number of terminal rows.
        
        @param i number of rows
        """
        if i >= 5:
            self.rows = i

    def query_rows(self):
        """
        Returns the number of terminal rows.
        
        @return row count
        """
        return self.rows

    def set_our_rows(self, num):
        """
        Command handler to set rows.
        
        @param num number of rows
        @return True if successful, False otherwise
        """
        if not num:
            self.driver.notify_fail(f"Rows currently set to {self.rows}.\nrows <number> to set.\n")
            return False
        if num <= 10:
            self.driver.notify_fail("Invalid number of rows.\n")
            return False
        self.driver.write(f"Rows set to {num}.\n")
        self.rows = num
        return True

    def query_cols(self):
        """
        Returns the number of terminal columns.
        
        @return column count
        """
        return self.cols

    def set_cols(self, i):
        """
        Sets the number of terminal columns.
        
        @param i number of columns
        """
        if 10 < i <= 999:
            self.cols = i

    def set_our_cols(self, val, test):
        """
        Command handler to set or test columns.
        
        @param val number of columns
        @param test if True, tests the setting temporarily
        @return True if successful, False otherwise
        """
        if not val:
            self.driver.notify_fail(f"Columns currently set to {self.cols}.\ncols <number> to set.\n")
            return False
        if val <= 35 or val > 999:
            self.driver.notify_fail("Invalid column size.\n")
            return False
        if test:
            cur = self.cols
            self.cols = val
            self.driver.write("".join([str((i + 1) % 10) for i in range(val)]) + "\n")
            self.driver.call_out(lambda: setattr(self, "cols", cur), 3)
            return True
        self.driver.write(f"Columns set to {val}.\n")
        self.cols = val
        return True

    def set_looked(self, thing):
        """
        Sets the current location for message context.
        
        @param thing the object/location
        """
        self._event_info.where = thing

    def reform_message(self, message, things):
        """
        Processes message tokens for location and object references.
        
        @param message the raw message
        @param things associated objects
        @return tuple of (processed message, updated things)
        """
        from home.archaon.mud.lib.secure.language_handler import LanguageHandler
        lang_hand = self.driver.find_object("/home/archaon/mud/lib/secure/language_handler.py")
        
        if not things:
            things = []
        last = len(things) - 1 if things else -1
        if not self._event_info.where:
            self._event_info.where = self.driver.environment()
        
        while "$L$" in message:
            before, middle, after = message.split("$L$", 2)
            if "[" in middle and "]" in middle:
                info, middle = middle.split("]", 1)
                info = info[1:]  # Remove "["
                if info.startswith("read:"):
                    middle = lang_hand.garble_text(info[5:], middle, 0, self)
                else:
                    middle = lang_hand.garble_text_say(middle, info, self)
            message = f"{before}{middle}{after}"
        
        while "$R$" in message:
            before, middle, after = message.split("$R$", 2)
            info = ""
            if "[" in middle and "]" in middle:
                info, middle = middle.split("]", 1)
                info = info[1:]
            number = 2
            if middle.startswith("-"):
                number = 0
                middle = middle[1:]
            elif middle.startswith("+"):
                number = 1
                middle = middle[1:]
            rel = self.find_rel(middle, number)
            if number == 2 or (self._event_info.where and self._event_info.where.query_relative(middle)):
                if self.query_creator():
                    message = f"{before}{rel} ({middle}){after}"
                else:
                    message = f"{before}{rel}{after}"
            else:
                message = f"{before}{info}{middle}{after}"
        
        # Simplified $r$ handling (assuming SHORTEN/LENGTHEN are external mappings)
        while "$r$" in message:
            before, middle, after = message.split("$r$", 2)
            info = ""
            if "[" in middle and "]" in middle:
                info, middle = middle.split("]", 1)
                info = info[1:]
            number = 2
            if middle.startswith("-"):
                number = 0
                middle = middle[1:]
            elif middle.startswith("+"):
                number = 1
                middle = middle[1:]
            rel = self.find_rel(middle, number)  # Placeholder adjustment needed
            if number == 2 or (self._event_info.where and self._event_info.where.query_relative(middle)):
                if self.query_creator():
                    message = f"{before}{rel} ({middle}){after}"
                else:
                    message = f"{before}{rel}{after}"
            else:
                message = f"{before}{info}{middle}{after}"
        
        while "$M$" in message:
            before, middle, after = message.split("$M$", 2)
            last += 1
            message = f"{before}${last}${after}"
            things.append([])
            if "$" not in middle:
                things[last].append(middle)
            else:
                while "$" in middle:
                    info, middle = middle.split("$", 1)
                    things[last].append(f"my_{info}")
        
        after = message
        message = ""
        while "$" in after:
            before, middle, after = after.split("$", 2)
            if "_short:" in middle:
                middle, info = middle.split("_short:", 1)
                last += 1
                message += f"{before}${last}$"
                things.append([f"my_{middle}_short:{info}"])
            else:
                message += f"{before}${middle}"
                after = f"${after}"
        message += after
        
        return message, things

    def add_message(self, message, things):
        """
        Adds a message to the event queue.
        
        @param message the message text
        @param things associated objects
        """
        if not self.driver.interactive(self):
            return
        
        if "$" not in message:
            stuff = [message, things]
        else:
            stuff = self.reform_message(message, things)
        
        self._event_info.where = None
        if not self._event_info.eemessages:
            self._event_info.eemessages = stuff
        else:
            last = len(self._event_info.eemessages) - 2
            if (stuff[0] == self._event_info.eemessages[last] and 
                    len(stuff[1]) == 1 and 
                    any(x in self._event_info.eemessages[last + 1][0] for x in stuff[1][0])):
                self._event_info.eemessages[last + 1][0].extend(stuff[1][0])
            else:
                self._event_info.eemessages.extend(stuff)

    def get_pretty_short(self, thing, dark):
        """
        Returns a formatted short description of an object.
        
        @param thing the object
        @param dark visibility condition
        @return formatted description
        """
        if dark and self.driver.environment(thing) != self:
            if self.driver.living(thing) and thing.query_race_ob() and thing.query_race_ob().query_humanoid():
                return "someone"
            return "something"
        if not thing.query_visible(self):
            if self.driver.living(thing) and thing.query_race_ob() and thing.query_race_ob().query_humanoid():
                return "someone"
            return "something"
        return thing.pretty_short(self) + thing.hide_invis_string()

    def get_pretty_plural(self, thing, dark):
        """
        Returns a formatted plural description of an object.
        
        @param thing the object
        @param dark visibility condition
        @return formatted plural description
        """
        if dark and self.driver.environment(thing) != self:
            return "people" if self.driver.living(thing) else "things"
        if not thing.query_visible(self):
            return "things"
        return thing.pretty_plural(self) + thing.hide_invis_string()

    def my_mirror_short(self, thing, arg):
        """
        Returns a mirror short description.
        
        @param thing the object
        @param arg fallback argument
        @return short description
        """
        if hasattr(thing, "short") and self.driver.userp(thing):
            return thing.short(0, 0)
        return arg

    def my_a_short(self, thing, arg, dark):
        """
        Returns an article-prefixed short description.
        
        @param thing the object
        @param arg fallback argument
        @param dark visibility condition
        @return formatted description
        """
        if not thing:
            return "something"
        if dark and self.driver.environment(thing) != self:
            if self.driver.living(thing) and thing.query_race_ob() and thing.query_race_ob().query_humanoid():
                if self.driver.environment(thing) != self.driver.environment():
                    return "someone"
            return "something"
        if not hasattr(thing, "query_determinate"):
            return "an unknown object"
        article = thing.query_determinate(self)
        if not article:
            return f"a {self.get_pretty_short(thing, dark)}"
        return f"{article}{self.get_pretty_short(thing, dark)}"

    def my_the_short(self, thing, arg, dark):
        """
        Returns a "the"-prefixed short description.
        
        @param thing the object
        @param arg fallback argument
        @param dark visibility condition
        @return formatted description
        """
        if dark and self.driver.environment(thing) != self:
            if self.driver.living(thing) and thing.query_race_ob() and thing.query_race_ob().query_humanoid():
                if self.driver.environment(thing) == self.driver.environment():
                    return "someone"
            return "something"
        if not hasattr(thing, "query_determinate"):
            return "the unknown object"
        article = thing.query_determinate(self)
        if not article or article in ["a ", "an "]:
            return f"the {self.get_pretty_short(thing, dark)}"
        return f"{article}{self.get_pretty_short(thing, dark)}"

    def some_more(self, word):
        """
        Checks if multiple objects match a plural description.
        
        @param word the plural word
        @return True if multiple matches, False otherwise
        """
        env = self._event_info.where or self.driver.environment()
        if not env:
            return False
        return len([obj for obj in self.driver.all_inventory(env) 
                    if obj.query_plural() == word and obj.query_visible(self)]) > 1

    def my_one_short(self, thing, arg, dark):
        """
        Returns a "one of" short description.
        
        @param thing the object
        @param arg fallback argument
        @param dark visibility condition
        @return formatted description
        """
        if dark and self.driver.environment(thing) != self:
            if self.driver.living(thing) and thing.query_race_ob() and thing.query_race_ob().query_humanoid():
                if self.driver.environment(thing) == self.driver.environment():
                    return "someone"
            return "something"
        if not hasattr(thing, "query_determinate"):
            return "one of the unknown objects"
        self._event_info.where = self if self.driver.environment(thing) != self.driver.environment() else self.driver.environment()
        article = thing.query_determinate(self)
        its_plural = self.get_pretty_plural(thing, dark)
        if not article or article in ["a ", "an "]:
            if self.some_more(its_plural):
                return f"one of the {its_plural}"
            return f"the {self.get_pretty_short(thing, dark)}"
        return f"{article}{self.get_pretty_short(thing, dark)}"

    def my_poss_short(self, thing, arg, dark):
        """
        Returns a possessive short description.
        
        @param thing the object
        @param arg fallback argument
        @param dark visibility condition
        @return formatted description
        """
        if dark and self.driver.environment(thing) != self:
            if self.driver.living(thing) and thing.query_race_ob() and thing.query_race_ob().query_humanoid():
                if self.driver.environment(thing) == self.driver.environment():
                    return "someone"
            return "something"
        if not hasattr(thing, "query_determinate"):
            return "an unknown object"
        if self.driver.living(thing):
            if thing == self:
                return "your"
            of_whom = self.get_pretty_short(thing, dark)
            return f"{of_whom}'" if of_whom.endswith("s") else f"{of_whom}'s"
        
        self._event_info.where = self.driver.environment(thing)
        if not self._event_info.where or (not self.driver.living(self._event_info.where) and not self._event_info.where.query_corpse()):
            return self.my_a_short(thing, arg, dark)
        
        if self._event_info.where == self:
            of_whom = "your "
        elif self._event_info.where in self._event_info.had_shorts:
            of_whom = f"{self._event_info.where.query_possessive()} "
        else:
            of_whom = self.my_the_short(self._event_info.where, arg, dark)
            of_whom = f"{of_whom}' " if of_whom.endswith("s") else f"{of_whom}'s "
        
        its_plural = self.get_pretty_plural(thing, dark)
        if self.some_more(its_plural):
            return f"one of {of_whom}{its_plural}"
        return f"{of_whom}{self.get_pretty_short(thing, dark)}"

    def my_the_poss_short(self, thing, arg, dark):
        """
        Returns a "the" possessive short description.
        
        @param thing the object
        @param arg fallback argument
        @param dark visibility condition
        @return formatted description
        """
        if dark and self.driver.environment(thing) != self:
            return "someone's" if self.driver.living(thing) else "something's"
        if not hasattr(thing, "query_determinate"):
            return "an unknown object's"
        
        article = thing.query_determinate(self)
        if not article or article in ["a ", "an "]:
            article = "the "
        
        if self.driver.living(thing):
            if thing == self:
                return "your"
            of_whom = self.get_pretty_short(thing, dark)
            of_whom = f"{of_whom}'" if of_whom.endswith("s") else f"{of_whom}'s"
            return f"{article}{of_whom}"
        
        self._event_info.where = self.driver.environment(thing)
        if not self._event_info.where or (not self.driver.living(self._event_info.where) and not self._event_info.where.query_corpse()):
            return self.my_the_short(thing, arg, dark)
        
        if self._event_info.where == self:
            of_whom = "your "
        elif self._event_info.where in self._event_info.had_shorts:
            of_whom = f"{self._event_info.where.query_possessive()} "
        else:
            of_whom = self.my_the_short(self._event_info.where, arg, dark)
            of_whom = f"{of_whom}' " if of_whom.endswith("s") else f"{of_whom}'s "
        
        its_plural = self.get_pretty_plural(thing, dark)
        if self.some_more(its_plural):
            return f"one of {article}{of_whom}{its_plural}"
        return f"{of_whom}{article}{self.get_pretty_short(thing, dark)}"

    def clear_event_info_had_shorts(self):
        """
        Clears the list of previously seen short descriptions.
        """
        self._event_info.had_shorts = []

    def calc_shorts(self, short_list, exact=False):
        """
        Calculates a formatted list of short descriptions.
        
        @param short_list list of short descriptions
        @param exact if True, uses exact numbering
        @return formatted string
        """
        descs_str = []
        descs_ob = []
        dark = self.check_dark(self.driver.environment().query_light()) if self.driver.environment() else 0
        number = lambda x: self.query_num(x) if exact else self.query_num(x, 20)
        
        if not self._event_info.had_shorts:
            self.clear_event_info_had_shorts()
        
        for str_ in short_list:
            parts = str_.split(":")
            if len(parts) >= 2:
                ob = self.driver.find_object(f"/home/archaon/mud/lib/{parts[1]}") if len(parts) == 2 else self.driver.find_object(f"/home/archaon/mud/lib/{':'.join(parts[1:])}")
            else:
                ob = None
                parts.append("")
            
            if ob:
                self._event_info.had_shorts.insert(0, ob)
            
            if ob == self:
                desc = "your" if parts[0] in ["my_poss_short", "my_the_poss_short"] else "you"
            elif len(parts) >= 2:
                desc = {
                    "my_mirror_short": self.my_mirror_short,
                    "my_a_short": self.my_a_short,
                    "my_the_short": self.my_the_short,
                    "my_one_short": self.my_one_short,
                    "my_poss_short": self.my_poss_short,
                    "my_the_poss_short": self.my_the_poss_short
                }[parts[0]](ob, parts[1], dark)
            else:
                desc = parts[0] or "something"
            
            i = descs_str.index(desc) if desc in descs_str else -1
            if i == -1:
                descs_str.append(desc)
                descs_ob.append([ob])
            else:
                descs_ob[i].append(ob)
        
        you_idx = descs_str.index("you") if "you" in descs_str else -1
        if you_idx != -1 and you_idx != len(descs_str) - 1:
            descs_str = descs_str[:you_idx] + descs_str[you_idx + 1:] + ["you"]
            descs_ob = descs_ob[:you_idx] + descs_ob[you_idx + 1:] + [descs_ob[you_idx]]
        
        result = []
        for i, (desc, things) in enumerate(zip(descs_str, descs_ob)):
            things = [t for t in things if t]
            if len(things) == 1:
                result.append(f"one {things[0].short()}" if exact and things[0] else desc)
            else:
                if things:
                    result.append(f"{number(len(things))} {self.get_pretty_plural(things[0], dark)}")
                else:
                    result.append(f"{number(len(things))} unknown objects")
            if i < len(descs_str) - 1:
                result.append(" and " if i == len(descs_str) - 2 else ", ")
        
        return "".join(result)

    def indent_column(self, column, width, pad):
        """
        Indents a column of text.
        
        @param column the text column
        @param width maximum width
        @param pad padding flag
        @return indented string
        """
        if not column.startswith("$I$"):
            column = f"$I$0=$C${column}"
        
        parts = column.split("$I$")
        ret = []
        left = 0
        right = 0
        space = False
        
        for part in parts[1:]:
            stuff, part = part.split("=", 1)
            if stuff.startswith(" "):
                space = not space
            stuff = stuff.split(",")
            
            if stuff[0]:
                if stuff[0].startswith("+"):
                    if space and left > 0 and part:
                        part = self.SPACES[:left] + part
                    left += int(stuff[0][1:])
                elif stuff[0].startswith("-"):
                    left = max(0, left - int(stuff[0][1:]))
                    if space and left > 0 and part:
                        part = self.SPACES[:left] + part
                else:
                    left = int(stuff[0])
            
            if len(stuff) > 1:
                if stuff[1].startswith("+"):
                    right += int(stuff[1][1:])
                elif stuff[1].startswith("-"):
                    right = max(0, right - int(stuff[1][1:]))
                else:
                    right = int(stuff[1])
            
            ret.append(self.fix_string(part, width - right, left if left > 0 else 0, pad))
        
        return "".join(ret)

    def fit_message(self, message):
        """
        Fits a message into columns if specified.
        
        @param message the message text
        @return formatted message
        """
        if len(message) < 6:
            return message
        
        columns = message.split("$COLUMN$")
        if len(columns) > 1:
            stuff = [[] for _ in columns]
            width = self.cols
            for i in range(len(columns) - 1):
                if "=" in columns[i]:
                    num, columns[i] = columns[i].split("=", 1)
                    size = int(num)
                else:
                    size = 10
                    columns[i] += "\nMust specify a column size.\n"
                width -= size
                stuff[i] = [size] + self.indent_column(columns[i], size, 1).split("\n")
            stuff[-1] = [width] + self.indent_column(columns[-1], width, 0).split("\n")
            
            ret = []
            j = 1
            while True:
                ok = False
                line = []
                for i, col in enumerate(stuff):
                    if len(col) > j:
                        line.append(col[j])
                        if len(col) > j + 1:
                            ok = True
                    elif i < len(stuff) - 1:
                        line.append(" " * (col[0] - 1))
                if not line:
                    break
                ret.append("".join(line))
                j += 1
                ret.append("\n")
                if not ok:
                    break
            return self.fix_string("".join(ret))
        return self.indent_column(columns[0], self.cols, 0)

    def fix_for_mxp(self, input_):
        """
        Escapes a string for MXP compatibility.
        
        @param input_ the input string
        @return MXP-safe string
        """
        replacements = {
            "&": "&amp;", "<": "&lt;", ">": "&gt;",
            "\n": f"{self.driver.mxp_next_secure(self)}<BR>",
            "MXP&lt;": "<", "MXP&gt;": ">"
        }
        for old, new in replacements.items():
            input_ = input_.replace(old, new)
        return input_

    def show_message(self, message):
        """
        Displays a message to the player.
        
        @param message the message to show
        """
        if "$P$" in message:
            bit, message = message.split("$P$", 2)[1:3]
            self.more_string(self.fit_message(message), bit, 1)
        else:
            formatted = self.fit_message(message)
            if self.driver.mxp_enabled():
                self.driver.tell_object(self, self.fix_for_mxp(formatted))
            else:
                self.driver.tell_object(self, formatted)
            if self.driver.screenreader_mode():
                self.driver.screenreader_output({"type": "message", "text": formatted})

    def evaluate_message(self, stuff):
        """
        Evaluates a message with object substitutions.
        
        @param stuff tuple of (message, things)
        @return evaluated message
        """
        message, things = stuff
        self.clear_event_info_had_shorts()
        
        for i, item in enumerate(things):
            message = message.replace(f"${i}$", self.calc_shorts(item))
            while f"$V${i}=" in message:
                start, rest = message.split(f"$V${i}=", 1)
                verb_sing, rest = rest.split(",", 1)
                verb_plur, finish = rest.split("$V$", 1)
                if (len(item) == 1 and self._event_info.had_shorts and 
                        hasattr(self._event_info.had_shorts[0], "query_property")):
                    obj = self._event_info.had_shorts[0]
                    if obj.query_property("group object") or obj.group_object():
                        message = f"{start}{verb_plur}{finish}"
                    else:
                        message = f"{start}{verb_sing}{finish}"
                else:
                    message = f"{start}{verb_plur}{finish}"
        
        return message

    def print_messages(self):
        """
        Prints all queued messages.
        """
        messages = self._event_info.eemessages
        self._event_info.eemessages = []
        for i in range(0, len(messages), 2):
            message = messages[i]
            if messages[i + 1]:
                message = self.evaluate_message([message, messages[i + 1]])
            self.show_message(message)
        self._event_info.where = None

    def convert_message(self, message):
        """
        Converts a message without queuing.
        
        @param message the message text
        @return converted message
        """
        if message:
            message = self.evaluate_message(self.reform_message(message, []))
        self._event_info.where = None
        return message

    def event_inform(self, _, mess, which, thing):
        """
        Handles inform events for the player.
        
        @param _ unused object parameter
        @param mess the message or function
        @param which the inform type
        @param thing the related object
        """
        on = self.inform_types if self.inform_types else []
        if self.query_property("inform repressed") or not on:
            return
        if thing and thing.query_creator() and not thing.query_visible(self):
            return
        
        if which == "logon" and self.is_friend(thing.query_name()) and "friend" in on:
            which = "friend"
        elif (which in ["logon", "link-death"] and 
              self.driver.find_object("/home/archaon/mud/lib/secure/playerinfo_handler.py").query_alerts_for(thing.query_name()) and 
              "alert" in on):
            which = "alert"
        elif which not in on:
            return
        
        inform_col = self.colour_event(which, self.INFORM_COLOURS.get(which, self.INFORM_COLOURS["default"]))
        
        if which == "friend":
            add_friend_later = False
            if not mess:
                mess = f" -- {self.query_friend_tag(thing.query_name())}"
            elif isinstance(mess, str):
                mess += f" -- {self.query_friend_tag(thing.query_name())}"
            else:
                add_friend_later = True
            if "friend" in self.INFORM_COLOURS:
                inform_col = self.colour_event(which, self.INFORM_COLOURS["friend"])
        
        if callable(mess):
            mess = mess(self)
            if isinstance(mess, str) and add_friend_later:
                mess += f"%^RESET%^%^{inform_col}%^ -- {self.query_friend_tag(thing.query_name())}"
        
        if which == "logon" and self.query_lord() and not self.check_earmuffs("verbose-logon", self) and "enters" in mess:
            mess += f" %^RESET%^%^{inform_col}%^{self.driver.query_ip_name(thing)}"
        
        self.add_message(f"[%^{inform_col}%^{mess}%^RESET%^]\n", [])

    def enter_exit_mess(self, mess, thing, going):
        """
        Formats enter/exit messages.
        
        @param mess the message template
        @param thing the moving object
        @param going 1 for exit, 0 for enter
        """
        mess = mess.replace("$N", "$0$")
        words = mess.split()
        for i in range(len(words) - 1, -1, -1):
            if "s" in words[i]:
                verb, part = words[i].split("s", 1)
                if not part.islower():

    def event_player_emote_all(self, ob, mess):
        """
        Handles an emote broadcast to all players.
        
        @param ob the object performing the emote
        @param mess the emote message
        """
        if ob == self:
            return
        if self.driver.master().query_lord(self.query_name()):
            self.add_message("$0$ emotes to all:\n", ([f"my_the_short:/home/archaon/mud/lib/{self.driver.file_name(ob)}"]))
        mess = f"{self.colour_event('emoteall')} {mess} %^RESET%^"
        self.add_message(f"$I$5=$C${mess.replace('$N', '$0$')}", ([f"my_the_short:/home/archaon/mud/lib/{self.driver.file_name(ob)}"]))

    def event_player_echo(self, ob, mess):
        """
        Handles an echo message from a player.
        
        @param ob the object sending the echo
        @param mess the echo message
        """
        if ob == self:
            return
        if self.driver.master().query_lord(self.query_name()):
            self.add_message("$0$ echos:\n", ([f"my_the_short:/home/archaon/mud/lib/{self.driver.file_name(ob)}"]))
        self.add_message(mess, [])

    def receive_snoop(self, mess):
        """
        Displays a snoop message to the player.
        
        @param mess the snoop message
        """
        self.driver.tell_object(self, f"] {mess}")

    def terminal_type(self, type_):
        """
        Sets the terminal type based on negotiation.
        
        @param type_ the terminal type received
        """
        IAC, SB, TELOPT_TTYPE, TELQUAL_SEND, SE = 255, 250, 24, 1, 240
        if self.set_network_terminal_type(type_):
            self.driver.tell_object(self, f"Setting your network terminal type to \"{type_}\".\n")
        elif self.term_name == "network":
            if not self._event_info.last_term or self._event_info.last_term != type_:
                self._event_info.last_term = type_
                self.driver.write(bytes([IAC, SB, TELOPT_TTYPE, TELQUAL_SEND, IAC, SE]))
            else:
                self.driver.tell_object(self, f"Unknown terminal type \"{type_}\".\n")

    def window_size(self, width, height):
        """
        Adjusts terminal size based on client report.
        
        @param width the terminal width
        @param height the terminal height
        """
        if self.term_name == "network":
            if 10 < width < 256:
                self.set_cols(width)
            if 5 < height < 256:
                self.set_rows(height)
            self.driver.tell_object(self, f"Your machine told our machine that your terminal has {height} rows and {width} columns.\n")

    def mxp_enable(self):
        """
        Enables MXP for the player with setup instructions.
        """
        IAC, SB, TELOPT_MXP, SE = 255, 250, 102, 240
        setup = self.driver.read_file("/home/archaon/mud/lib/doc/login/mxp_setup").replace("\n", "")
        self.driver.tell_object(self, bytes([IAC, SB, TELOPT_MXP, IAC, SE, 0]) + b"\x1b[1z" + setup.encode() + b"\n")                    