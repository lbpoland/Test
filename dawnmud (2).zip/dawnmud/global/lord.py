# File: /home/archaon/mud/lib/global/lord.py
# Purpose: Provides lord-specific functionality and commands.
# Linked Files: /home/archaon/mud/lib/global/wiz_file_comm.py, /home/archaon/mud/lib/global/auto_mailer.py
# Updated Features: None identified from live Discworld MUD updates as of 2025-03-20; lord system consistent per dwwiki.mooo.com.
# Translated by: Archaon

from home.archaon.mud.lib.global.wiz_file_comm import WizFileComm

class Lord(WizFileComm):
    """
    Extends creator functionality with lord-specific privileges and commands.
    """

    CREATOR_DOC = "/home/archaon/mud/lib/doc/creator/concepts/creator_doc.txt"
    DIR_LORD_CMDS = "/home/archaon/mud/lib/cmds/lord"
    DIR_SECURE_LORD_CMDS = "/home/archaon/mud/lib/secure/cmds/lord"

    def __init__(self, driver):
        super().__init__(driver)
        self.driver = driver
        self.create()

    def create(self):
        """
        Initializes lord-specific settings.
        """
        pass

    def move_player_to_start(self, bong, bing, c_name, ident, go_invis):
        """
        Moves a lord to their starting location with additional messaging.
        
        @param bong unused parameter
        @param bing new player flag
        @param c_name creator name
        @param ident identifier
        @param go_invis invisibility flag
        """
        super().move_player_to_start(bong, bing, c_name, ident, go_invis)
        self.driver.cat("/home/archaon/mud/lib/doc/CREATORNEWS")
        self.driver.cat("/home/archaon/mud/lib/doc/DIRECTORNEWS")
        
        invis = self.query_invis()
        messages = {
            3: "===> You are currently Trustee invisible! <===\n",
            2: "===> You are currently Director invisible! <===\n",
            1: "===> You are currently invisible! <===\n"
        }
        if invis in messages:
            self.driver.tell_object(self, messages[invis])
        
        self.driver.add_command("qsnoop", self, "<indirect:player>", lambda _, args: self.do_qsnoop(args[0]))
        self.driver.add_command("qsnoop", self, "", lambda: self.do_qsnoop([]))
        self.driver.add_command("employ", self, "<word>", lambda _, args: self.employ(args[0]))
        self.driver.add_command("dismiss", self, "<word> <string>", lambda _, args: self.do_dismiss(args[0], args[1]))
        self.driver.add_command("new_domain", self, "<word> <word>", lambda _, args: self.new_domain(args[0], args[1]))
        self.driver.add_command("heart_beat", self, "", lambda: self.do_heart_beat())
        self.driver.add_command("bulk_delete", self, "{a|b|c|d|e|f|g|h|i|j|k|l|m|n|o|p|q|r|s|t|u|v|w|x|y|z}", 
                                lambda _, args: self.bulk_delete(args[0]))
        self.driver.add_command("clean_up_files", self, "<word>", lambda _, args: self.clean_up_files(args[0]))
        self.AddSearchPath([self.DIR_LORD_CMDS, self.DIR_SECURE_LORD_CMDS])

    def process_input(self, input_):
        """
        Processes lord-specific input commands.
        
        @param input_ the input string
        @return processed result or delegated to parent
        """
        if input_ == "end_it_all":
            self.driver.shutdown(0)
            return True
        if input_.startswith("hexec"):
            return self.do_hexec(input_[5:].strip())
        return super().process_input(input_)

    def end_it_all(self):
        """
        Shuts down the game (lord privilege).
        
        @return True
        """
        self.driver.shutdown(0)
        return True

    def do_heart_beat(self):
        """
        Triggers a manual heartbeat.
        
        @return True
        """
        self.driver.heart_beat()
        return True

    def query_creator(self):
        """
        Identifies as a creator.
        
        @return True
        """
        return True

    def query_director(self):
        """
        Identifies as a director.
        
        @return True
        """
        return True

    def query_lord(self):
        """
        Identifies as a lord.
        
        @return True
        """
        return True

    def employ(self, str_):
        """
        Employs a new creator.
        
        @param str_ the creator name
        @return True if successful, False otherwise
        """
        from home.archaon.mud.lib.global.auto_mailer import AutoMailer
        auto_mailer = self.driver.find_object("/home/archaon/mud/lib/global/auto_mailer.py")
        
        if self.GetForced():
            return False
        result = self.driver.master().employ_creator(str_.lower())
        if result in [1, 2]:
            if result == 2 and self.driver.file_size(self.CREATOR_DOC) > 0:
                doc = self.driver.read_file(self.CREATOR_DOC)
                auto_mailer.auto_mail(str_.lower(), self.driver.this_player().query_name(),
                                      "Documents for new creators", "", doc, 0, 0)
            return True
        return False

    def do_dismiss(self, str_, reason):
        """
        Dismisses a creator with a reason.
        
        @param str_ the creator name
        @param reason the dismissal reason
        @return True if successful, False otherwise
        """
        if self.GetForced():
            return False
        return self.driver.master().dismiss_creator(f"{str_} {reason}")

    def new_domain(self, dom, director):
        """
        Creates a new domain with a director.
        
        @param dom the domain name
        @param director the director name
        @return True if successful, False otherwise
        """
        if self.GetForced():
            return False
        return self.driver.master().create_domain(dom, director)

    def query_object_type(self, _=None):
        """
        Returns the lord's object type.
        
        @param _ unused parameter
        @return 'T' for trustee, 'D' for director
        """
        return "T" if self.driver.master().query_trustee(self.driver.geteuid(self)) else "D"

    def event_enter(self, me, s1, from_):
        """
        Handles enter events with lord-specific messaging.
        
        @param me the entering object
        @param s1 the enter message
        @param from_ the source location
        """
        if not s1 and self.driver.interactive(me):
            env = self.driver.environment()
            if env == self.driver.environment(me):
                self.event_inform(me, f"{me.query_cap_name()} invisibly enters the room", "enter")
            else:
                self.event_inform(me, f"{me.query_cap_name()} invisibly enters your inventory", "enter")
        super().event_enter(me, s1, from_)

    def event_exit(self, me, s1, from_):
        """
        Handles exit events with lord-specific messaging.
        
        @param me the exiting object
        @param s1 the exit message
        @param from_ the destination
        """
        if not s1 and self.driver.interactive(me):
            env = self.driver.environment()
            if env == self.driver.environment(me):
                self.event_inform(me, f"{me.query_cap_name()} invisibly exits the room", "enter")
            else:
                self.event_inform(me, f"{me.query_cap_name()} invisibly exits your inventory", "enter")
        super().event_exit(me, s1, from_)

    def do_hexec(self, junk):
        """
        Executes arbitrary code in a temporary file (lord privilege).
        
        @param junk the code to execute
        @return True if executed, False if forced
        """
        if self.GetForced():
            return False
        fname = f"/home/archaon/mud/lib/w/{self.query_name()}/exec_thing.py"
        self.driver.write_file(fname, f"def create():\n    {junk}\n")
        try:
            self.driver.call_other(fname, "bingle")
        except:
            pass
        self.driver.destruct(self.driver.find_object(fname))
        self.driver.rm(fname)
        return True

    def adjust_xp(self, number, shared=None):
        """
        Adjusts XP with lord-specific logging.
        
        @param number the XP amount
        @param shared unused parameter
        @return adjusted XP result
        """
        prev_obj = self.driver.previous_object()
        if hasattr(prev_obj, "query_name"):
            self.event_inform(prev_obj, f"{prev_obj.query_name()} ({self.driver.file_name(prev_obj)}) gives you {number} xp", "xp")
        return super().adjust_xp(number, shared)

    def bulk_delete(self, word):
        """
        Performs a bulk deletion of files.
        
        @param word the file prefix letter
        @return True if successful, False if forced
        """
        if self.GetForced():
            return False
        return self.driver.find_object("/home/archaon/mud/lib/secure/bulk_delete.py").delete_files(word.lower())

    def clean_up_files(self, word):
        """
        Cleans up files based on a prefix.
        
        @param word the file prefix
        @return True if successful, False if forced
        """
        if self.GetForced():
            return False
        return self.driver.find_object("/home/archaon/mud/lib/secure/bulk_delete.py").clean_up_files(word)

    def do_qsnoop(self, obs):
        """
        Quick snoops a player or cancels snooping.
        
        @param obs list of player objects to snoop
        @return True if successful, False on failure
        """
        if self.GetForced():
            return False
        if not obs or not len(obs):
            self.driver.snoop(self, None)
            self.driver.write("Ok, qsnoop cancelled.\n")
            return True
        targ = obs[0]
        if not self.driver.snoop(self, targ):
            self.driver.notify_fail(f"You fail to qsnoop {targ.query_cap_name()}.\n")
            return False
        self.driver.write(f"Ok, qsnooping {targ.query_cap_name()}.\n")
        return True