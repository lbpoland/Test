# File: /home/archaon/mud/lib/global/friends.py
# Purpose: Manages a player's friend list and tags.
# Linked Files: /home/archaon/mud/lib/secure/player_handler.py, /home/archaon/mud/lib/cmds/player/friends.py
# Updated Features: None identified from live Discworld MUD updates as of 2025-03-20; friend system consistent.
# Translated by: Archaon

class Friends:
    """
    Manages friend relationships and associated tags for a player.
    """

    FRIENDS_CMD = "/home/archaon/mud/lib/cmds/player/friends.py"
    PLAYER_MAX_FRIEND_TAG_LEN = 20  # Assumed constant from LPC

    def __init__(self, driver):
        self.driver = driver
        self._friends = {}

    def create(self):
        """
        Initializes the friends mapping.
        """
        self._friends = {}

    def is_friend(self, person):
        """
        Checks if a person is a friend.
        
        @param person the name of the person
        @return True if a friend, False otherwise
        """
        if not self._friends:
            self._friends = {}
        return person in self._friends and isinstance(self._friends[person], str)

    def query_friend_tag(self, person):
        """
        Retrieves the tag for a friend, with security check.
        
        @param person the friend's name
        @return tag string or empty string if unauthorized
        """
        prev_obj = self.driver.previous_object()
        if not self.driver.interactive(prev_obj):
            return self._friends.get(person, "")
        caller = prev_obj.query_name() if hasattr(prev_obj, "query_name") else self.driver.file_name(prev_obj)
        self.driver.log_file("CHEAT", f"{self.driver.ctime(self.driver.time())} query_friend_tag called on {self.query_name()} by {caller}\n")
        return ""

    def add_friend(self, person, tag):
        """
        Adds a friend with a tag.
        
        @param person the friend's name
        @param tag the associated tag
        """
        from home.archaon.mud.lib.secure.player_handler import PlayerHandler
        player_handler = self.driver.find_object("/home/archaon/mud/lib/secure/player_handler.py")
        
        if len(tag) > self.PLAYER_MAX_FRIEND_TAG_LEN or not player_handler.test_user(person):
            return
        self._friends[person] = tag

    def remove_friend(self, person):
        """
        Removes a friend from the list.
        
        @param person the friend's name
        """
        if person in self._friends:
            del self._friends[person]

    def query_friends(self):
        """
        Returns the list of friends, with security check.
        
        @return list of friend names or empty list if unauthorized
        """
        prev_obj = self.driver.previous_object()
        if self.driver.file_name(prev_obj) == self.FRIENDS_CMD:
            return list(self._friends.keys())
        caller = prev_obj.query_name() if hasattr(prev_obj, "query_name") else self.driver.file_name(prev_obj)
        self.driver.log_file("CHEAT", f"{self.driver.ctime(self.driver.time())} query_friends called on {self.query_name()} by {caller}\n")
        return []