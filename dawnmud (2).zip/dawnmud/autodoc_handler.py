# /obj/handlers/autodoc_handler.py
# This handler extracts documentation from LPC source files and generates nroff and HTML documentation.
# It maintains an index for the help system and processes files in /doc/autodoc and /www/autodoc directories.

import asyncio
import os
from pathlib import Path
import re

# Constants from autodoc.h (assumed)
SAVE_DIR = "/save/autodoc/"
NROFF_DOC_DIR = "/doc/autodoc/"
NROFF_DOC_SINGLE = "/doc/autodoc/single/"
HTML_DOC_DIR = "/www/autodoc/"
SAVE_FILE = SAVE_DIR + "main_rubbish"
SAVE_INDEX_DELAY = 3600  # Assumed delay in seconds
MAIN_FILE = 0
INDEX_FILE = 1

class AutodocHandler:
    """
    This class manages the autodoc system, processing LPC files to generate documentation.
    @author Pinkfish
    @started Tue Oct 28 13:25:09 EST 1997
    @index autodoc
    @see /obj/handlers/autodoc/autodoc_file
    @see /obj/handlers/autodoc/autodoc_nroff
    @see /obj/handlers/autodoc/autodoc_html
    """

    def __init__(self, driver):
        """
        Initializes the autodoc handler.
        @param driver The driver object providing efuns
        """
        self.driver = driver
        self.files = []
        self.file_pos = 0
        self.something_changed = False
        self.last_created_index = 0
        self.filters = [
            lambda ob, type_: self.create_nroff_file(ob, type_),
            lambda ob, type_: self.create_html_file(ob, type_)
        ]
        self.call_id = None
        self.summary_map = {}
        self.extra_indexes = []
        self.help_map = {}
        self.create()

    def create(self):
        """
        Sets up the autodoc handler and starts processing.
        """
        self.driver.seteuid(self.driver.getuid())
        self.load()
        asyncio.create_task(self.do_parse_next_file())
        # Uncomment for testing: asyncio.create_task(self.create_index())

    async def create_nroff_file(self, ob, type_):
        """
        Creates an nroff documentation file.
        @param ob The parsed file object or index data
        @param type_ The type of file to create (MAIN_FILE or INDEX_FILE)
        """
        if type_ == MAIN_FILE:
            fname = ob.query_file_name().replace("/", ".")
            if fname.startswith("."):
                fname = fname[1:]
            self.driver.rm(NROFF_DOC_DIR + fname)
            self.driver.find_object("/obj/handlers/autodoc_nroff").create_nroff_file(ob, NROFF_DOC_DIR + fname)
        elif type_ == INDEX_FILE:
            index_stuff = ob
            stuff = [(name.split("/")[-1], name) for name in self.query_files()]
            stuff = self.unique_array(index_stuff + stuff, lambda x: x[0][0].lower())
            for group in stuff:
                fname = f"{NROFF_DOC_DIR}index_{group[0][0][0].lower()}"
                self.driver.find_object("/obj/handlers/autodoc_nroff").create_nroff_index_file(group, fname)

    async def create_html_file(self, ob, type_):
        """
        Creates an HTML documentation file.
        @param ob The parsed file object or index data
        @param type_ The type of file to create (MAIN_FILE or INDEX_FILE)
        """
        if type_ == MAIN_FILE:
            fname = ob.query_file_name().replace("/", ".")[1:] + ".html" if ob.query_file_name().startswith("/") else ob.query_file_name().replace("/", ".") + ".html"
            self.driver.rm(HTML_DOC_DIR + fname)
            self.driver.find_object("/obj/handlers/autodoc_html").create_html_file(ob, HTML_DOC_DIR + fname)
        elif type_ == INDEX_FILE:
            index_stuff = ob
            stuff = [(name.split("/")[-1], name, "", self.summary_map.get(name, "")) for name in self.query_files()]
            stuff = self.unique_array(index_stuff + stuff, lambda x: x[0][0].lower())
            chars = {}
            for group in stuff:
                fname = f"index_{group[0][0][0].lower()}.html"
                self.driver.rm(HTML_DOC_DIR + fname)
                self.driver.find_object("/obj/handlers/autodoc_html").create_html_index_file(
                    group, group[0][0][0].lower(), HTML_DOC_DIR + fname
                )
                self.driver.reset_eval_cost()
                chars[group[0][0][0].upper()] = fname
            self.driver.find_object("/obj/handlers/autodoc_html").create_main_index(chars, HTML_DOC_DIR)

    async def after_thingy(self, no_index):
        """
        Handles post-processing of a file.
        @param no_index Whether to skip index creation
        """
        prev_ob = self.driver.previous_object()
        if no_index:
            self.driver.printf(f"Finished recreating the documentation for {prev_ob.query_file_name()}\n")
        if prev_ob.query_changed():
            self.something_changed = True
        if prev_ob.query_num_failed_tries() > 1:
            self.remove_file(self.files[self.file_pos - 1])
        elif prev_ob.query_changed() or no_index:
            for filter_func in self.filters:
                asyncio.create_task(filter_func(prev_ob, MAIN_FILE))
        asyncio.create_task(asyncio.sleep(20, lambda: prev_ob.dest_me()))
        self.save()

    async def do_parse_next_file(self):
        """
        Processes the next file in the queue.
        """
        self.call_id = asyncio.create_task(asyncio.sleep(60, self.start_processing))
        if self.file_pos >= len(self.files):
            self.file_pos = 0
        ob = self.driver.new("/obj/handlers/autodoc_file")
        ob.parse_file(self.files[self.file_pos], lambda: self.after_thingy(0))
        self.file_pos += 1

    async def start_processing(self):
        """
        Manages the processing loop.
        """
        if not self.files:
            return
        if self.last_created_index + SAVE_INDEX_DELAY < self.driver.time() and self.something_changed:
            asyncio.create_task(asyncio.sleep(2, self.create_index))
            self.something_changed = False
            self.save()
        self.call_id = asyncio.create_task(asyncio.sleep(360, self.do_parse_next_file))

    def query_short_args_def(self, args):
        """
        Generates a short argument definition string.
        @param args List of argument types and names
        @return String representation of arguments
        """
        ret = ", ".join(" ".join(args[i:i+2]) for i in range(0, len(args), 2))
        return f"({ret})"

    def process_stuff(self, name, fname, fn, docs):
        """
        Processes documentation data for indexing.
        @param name The item name (function, class, etc.)
        @param fname The file name
        @param fn The nroff file name
        @param docs The documentation mapping
        @return Processed data list
        """
        if name not in ["create", "setup", "init"]:
            self.help_map[name] = self.help_map.get(name, []) + [fn]
        if name in docs:
            if isinstance(docs[name], list):
                fluff = docs[name][1]  # AUTO_DOCS assumed as index 1
                ret = [name, fname, self.query_short_args_def(docs[name][0])]  # AUTO_ARGS assumed as index 0
            else:
                ret = [name, fname, ""]
                fluff = docs[name]
        else:
            ret = [name, fname, ""]
            fluff = docs if isinstance(docs, dict) else {}
        
        blue = "\n".join(fluff.get("main", [])) if fluff.get("main") else ""
        end = len(blue)
        for char in [".", "!", "?"]:
            i = blue.find(char)
            if 0 < i < end:
                end = i
        ret.append(blue[:end] if blue else "")
        
        if "index" in fluff:
            for blue in fluff["index"]:
                blue = blue.replace(" ", "").replace("\n", "")
                self.help_map[blue] = self.help_map.get(blue, []) + [fn]
                self.extra_indexes.append([blue, fname, "", ret[3]])
        
        return ret

    async def create_index(self):
        """
        Creates the documentation index.
        """
        index_stuff = []
        self.help_map = {}
        self.extra_indexes = []
        self.summary_map = {}
        parse = self.driver.clone_object("/obj/handlers/autodoc_file")
        for fname in self.files:
            parse.parse_file(fname, None, True)
            if parse.query_file_name():
                fn = NROFF_DOC_DIR + parse.query_file_name().replace("/", ".")[1:]
                bits = parse.query_file_name()[:-2].split("/")
                rabbit = self.process_stuff(bits[-1], "", fn, parse.query_main_docs())
                if rabbit[3]:
                    self.summary_map[fname] = rabbit[3]
                else:
                    self.summary_map.pop(fname, None)
                index_stuff.extend(self.process_stuff(k, fname, fn, parse.query_public_functions())
                                  for k in parse.query_public_functions().keys())
                index_stuff.extend(self.process_stuff(k, fname, fn, parse.query_protected_functions())
                                  for k in parse.query_protected_functions().keys())
                index_stuff.extend(self.process_stuff(k, fname, fn, parse.query_class_docs())
                                  for k in parse.query_class_docs().keys())
                if fname.endswith(".h"):
                    index_stuff.extend(self.process_stuff(k, fname, fn, parse.query_define_docs())
                                      for k in parse.query_define_docs().keys())
            self.driver.reset_eval_cost()
        
        index_stuff.extend(self.extra_indexes)
        self.extra_indexes = []
        for filter_func in self.filters:
            self.driver.reset_eval_cost()
            try:
                await filter_func(index_stuff, INDEX_FILE)
            except:
                pass
        self.summary_map = {}
        self.last_created_index = self.driver.time()
        self.save()

    def recreate_documentation(self, fname):
        """
        Recreates documentation for a single file.
        @param fname The file name to update
        @return 1 if successful, 0 otherwise
        """
        if fname in self.files:
            ob = self.driver.clone_object("/obj/handlers/autodoc_file")
            ob.parse_file(fname, lambda: self.after_thingy(True))
            return 1
        return 0

    def recreate_indexes(self):
        """
        Regenerates the index files.
        """
        self.driver.unguarded(lambda: asyncio.create_task(self.create_index()))

    def add_file(self, fname):
        """
        Adds a file to the autodoc processing list.
        @param fname The file name to add
        @return 1 if successful, 0 otherwise
        @see recreate_documentation()
        """
        fname = "/" + "/".join([x for x in fname.split("/") if x])
        if fname not in self.files and self.driver.unguarded(lambda: self.driver.stat(fname)):
            self.files.append(fname)
            self.save()
            if len(self.files) == 1:
                self.start_processing()
            else:
                asyncio.create_task(asyncio.sleep(random.randint(0, 59), lambda: self.recreate_documentation(fname)))
            return 1
        return 0

    def remove_file(self, fname):
        """
        Removes a file from the autodoc processing list.
        @param fname The file name to remove
        @return 1 if successful, 0 otherwise
        """
        if fname in self.files:
            self.files.remove(fname)
            self.file_pos = 0
            fn = HTML_DOC_DIR + fname.replace("/", ".")
            self.driver.unguarded(lambda: self.driver.rm(fn))
            fn = NROFF_DOC_DIR + fname.replace("/", ".")
            self.driver.unguarded(lambda: self.driver.rm(fn))
            fn = NROFF_DOC_SINGLE + fname[:-2] + "/"
            our_files = self.driver.get_dir(fn)
            for dfn in our_files:
                self.driver.unguarded(lambda: self.driver.rm(fn + dfn))
            if self.driver.file_size(fn[:-1]) != -1:
                self.driver.unguarded(lambda: self.driver.rm(fn[:-1]))
            self.save()
            if not self.files and self.call_id:
                self.call_id.cancel()
            return 1
        return 0

    def load(self):
        """
        Loads the saved state.
        """
        self.driver.unguarded(lambda: self.driver.restore_object(SAVE_FILE))

    def save(self):
        """
        Saves the current state.
        """
        self.driver.unguarded(lambda: self.driver.save_object(SAVE_FILE))

    def query_files(self):
        """
        Returns the list of files being processed.
        @return Array of file names
        """
        return self.files

    def query_help_map(self):
        """
        Returns the help mapping of functions to files.
        @return Mapping of function names to file arrays
        """
        return self.help_map

    def query_help_on(self, file, func):
        """
        Returns the help file path for a function in a file.
        @param file The file name
        @param func The function name
        @return Full path to help file or None
        """
        file = file[1:] if file.startswith("/") else file
        if file.endswith(".c"):
            file = file[:-2]
        file = f"{NROFF_DOC_SINGLE}{file}/{func}"
        return file if self.driver.file_size(file) > 0 else None

    def query_summary_map(self):
        """
        Returns the summary mapping during index creation.
        @return Mapping of file names to summaries
        """
        return self.summary_map

    def is_autodoc_file(self, name):
        """
        Checks if a file is in the autodoc set.
        @param name The file name
        @return 1 if found, 0 otherwise
        """
        return name in self.files

    def unique_array(self, arr, key_func):
        """
        Groups array elements by a key function.
        @param arr The array to group
        @param key_func Function to determine grouping key
        @return List of grouped arrays
        """
        groups = {}
        for item in arr:
            key = key_func(item)
            groups[key] = groups.get(key, []) + [item]
        return list(groups.values())