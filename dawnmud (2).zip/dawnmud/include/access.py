# File: /home/archaon/mud/lib/include/access.py
# Purpose: Defines constants and structures for access control in the MUD system.
# Linked Files: Potentially used by security or permission systems (e.g., /secure/master.py).
# Updated Features: No specific updates from live MUD detected for this file as of 2025-03-20; basic translation with Pythonic constants.
# Changes: LPC #defines converted to Python constants, added tuple for permission names.
# Translated by: Archaon
# @updated: 2025-03-21 - Initial translation from LPC to Python - No live MUD updates applied

# Access level constants
ERROR = 0
ACCESS = 1
NO_NEW = 2
NO_ACCESS = 3
AUTH_NEW = 4
DEFAULT = ACCESS

# Indices for access-related data
ACCESS_LEVEL = 0
ACCESS_REASON = 1
ACCESS_TIMEOUT = 2

# Indices for multi-level access data
MULTI_LEVEL = 0
MULTI_TIMEOUT = 1

# Indices for suspension data
SUSPEND_TIME = 0
SUSPEND_REASON = 1

# Permission names as a tuple for easy reference
PERM_NAMES = (
    "error",
    "normal access",
    "no new characters",
    "no access",
    "new requires authorisation"
)