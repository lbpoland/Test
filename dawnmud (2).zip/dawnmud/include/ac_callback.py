# File: /home/archaon/mud/lib/include/ac_callback.py
# Purpose: Defines the structure for callback data used in asynchronous operations.
# Linked Files: None explicitly linked, but likely used by systems requiring callbacks (e.g., combat, events).
# Updated Features: None identified from live MUD updates as of 2025-03-20; basic struct translation.
# Translated by: Archaon

class ACCallbackData:
    """
    Structure for holding callback data in asynchronous operations.
    
    Attributes:
        ob (object): The object associated with the callback.
        id (int): Unique identifier for the callback.
        func (callable): Function to be executed as the callback.
        priority (int): Priority level of the callback.
        extra (any): Additional data associated with the callback.
    """
    def __init__(self, ob=None, id=0, func=None, priority=0, extra=None):
        self.ob = ob
        self.id = id
        self.func = func
        self.priority = priority
        self.extra = extra