# File: /home/archaon/mud/lib/std/key.py
# Purpose: Manages a key object with engraving support and customizable properties for locking mechanisms.
# Related Files: /home/archaon/mud/lib/std/object.py, /home/archaon/mud/lib/include/shops/engrave.py
# Updated Features: No significant updates identified from Discworld MUD as of March 20, 2025; core functionality from 2003 mudlib preserved.
# Translated by: Archaon

from home.archaon.mud.lib.std.object import Object
from home.archaon.mud.lib.include.shops.engrave import ENGRAVE_PROP

class Key(Object):
    def __init__(self, driver):
        super().__init__(driver)
        self.set_name("key")
        self.set_long("A key. Wonder where it fits?.\n")
        self.add_plural("keys")
        self.set_short("key")
        self.add_property(ENGRAVE_PROP, 1)
        self.setup()

    def set_key(self, str_, prop):
        """Set the key's description and property for locking.

        @param str_: Descriptive prefix for the key (e.g., "brass")
        @param prop: Property identifying the lock it fits
        """
        self.set_short(f"{str_} key")
        self.set_main_plural(f"{str_} keys")
        self.set_name("key")
        self.add_plural("keys")
        bits = str_.split()
        for bit in bits:
            self.add_adjective(bit)
        self.add_property(prop, 1)
        self.set_value(0)
        self.set_weight(1)

    def query_static_auto_load(self):
        """Prepare static auto-load data if this is the base key object.

        @return: Static auto-load data or empty dict
        """
        if f"{self.driver.base_name(self)}.c" == "/home/archaon/mud/lib/std/key.c":
            return self.int_query_static_auto_load()
        return {}