# File: /home/archaon/mud/lib/std/held.py
# Purpose: Manages an object that can be held by another object, tracking its holder and handling movement.
# Related Files: /home/archaon/mud/lib/std/object.py
# Updated Features: No significant updates identified from Discworld MUD as of March 20, 2025; core functionality preserved.
# Translated by: Archaon

from home.archaon.mud.lib.std.object import Object

class Held(Object):
    def __init__(self, driver):
        super().__init__(driver)
        self.holder = None  # Object holding this item

    def query_holdable(self):
        """Check if the object can be held.

        @return: 1 (True) indicating it is holdable
        """
        return 1

    def set_holder(self, ob):
        """Set the holder of this object.

        @param ob: Object that will hold this item
        @return: 1 if successful
        """
        self.holder = ob
        return 1

    def query_holder(self):
        """Get the current holder of this object.

        @return: Holder object or None if not held
        """
        return self.holder

    def drop(self, dest):
        """Drop the object, clearing the holder.

        @param dest: Destination to drop to
        @return: Result of the drop operation
        """
        self.holder = None
        return super().drop(dest)

    def move(self, dest, arrive=None, leave=None):
        """Move the object, notifying the holder if necessary.

        @param dest: Destination to move to
        @param arrive: Arrival message (optional)
        @param leave: Leaving message (optional)
        @return: Result of the move operation
        """
        if self.holder and dest != self.holder:
            self.holder.unhold_ob(self)
            self.holder = None
        return super().move(dest, arrive, leave)