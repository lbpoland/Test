# File: /home/archaon/mud/lib/std/delivery.py
# Purpose: Manages a delivery system for items with delays, messaging, and persistence across logins.
# Related Files: /home/archaon/mud/lib/global/auto_load.py, /home/archaon/mud/lib/include/player_handler.py, /home/archaon/mud/lib/include/login.py, /home/archaon/mud/lib/include/move_failures.py
# Updated Features: No significant updates identified from Discworld MUD as of March 20, 2025; core functionality preserved.
# Translated by: Archaon

from home.archaon.mud.lib.global.auto_load import AutoLoad
from home.archaon.mud.lib.include.player_handler import PLAYER_HANDLER
from home.archaon.mud.lib.include.login import LOGIN_HANDLER, LOGIN, RECONNECT
from home.archaon.mud.lib.include.move_failures import MOVE_OK
import time
import random

class DeliveryItem:
    def __init__(self, delivery_ob, sent_by, submit_time, delay_time):
        self.delivery_ob = delivery_ob
        self.sent_by = sent_by
        self.submit_time = submit_time
        self.delay_time = delay_time

class Delivery(AutoLoad):
    def __init__(self, driver):
        super().__init__(driver)
        self._delivery = {}
        self._item_save = None
        self._save_file = ""
        self._cont = self.driver.clone_object("/home/archaon/mud/lib/std/container")
        self._delivery_mess = (
            "\nA small womble wearing a bright green hat strides up to you confidently and hands you $N. "
            "She mutters something about \"delivery\" and \"$S\", before scurrying away.\n"
        )
        self._burdened_mess = (
            "\nA small womble wearing a bright purple hat strides up to you, and places \"$N\" on the ground. "
            "She mutters something about a gift from \"$S\", and then runs off.\n"
        )
        self._delivery_delay = 5
        self.driver.call_out(self.tidy_up, 30 + random.randint(0, 30))

    def setup_delivery(self):
        """Set up login hooks for delivery checks."""
        LOGIN_HANDLER.add_static_login_call("all", "check_delivery", self.driver.base_name(self))

    def query_save_file(self):
        """Get the save file path.

        @return: Save file path string
        """
        return self._save_file

    def set_save_file(self, str_):
        """Set the save file path and load existing data.

        @param str_: Save file path
        """
        self._save_file = str_
        self.load_file()

    def clear_delivery(self):
        """Clear all delivery data."""
        self._delivery = {}
        self.save_file()

    def set_delivery(self, x):
        """Set the delivery mapping.

        @param x: Mapping of deliveries
        """
        self._delivery = x
        self.save_file()

    def add_delivery(self, who, sender, item, delay):
        """Add a delivery item.

        @param who: Recipient (object or string)
        @param sender: Sender (object or string)
        @param item: Item to deliver
        @param delay: Delivery delay in seconds
        """
        name = who.query_name() if hasattr(who, "query_name") else who
        from_ = sender.query_cap_name() if hasattr(sender, "query_cap_name") else sender
        parcel = DeliveryItem(item, from_, int(time.time()), delay)
        self._delivery.setdefault(name, []).append(parcel)
        prev_ob = self.driver.previous_object()
        self.driver.log_file("/home/archaon/mud/lib/DELIVERY",
                             f"{prev_ob.short()} added a new delivery item for {name}, {item.short()} sent by {from_}.\n")
        item.move(self._cont)
        self.save_file()

    def valid_delivery(self, delivery, person):
        """Check if a delivery is valid and schedule it if ready.

        @param delivery: DeliveryItem instance
        @param person: Recipient name
        @return: 1 if not ready, 0 if delivered
        """
        if delivery.submit_time + delivery.delay_time > int(time.time()):
            return 1
        if not isinstance(delivery.delivery_ob, object):
            return 0
        self.driver.call_out(lambda: self.deliver_item(person, delivery.delivery_ob, delivery.sent_by), self._delivery_delay)
        return 0

    def check_delivery(self, person, type_):
        """Check deliveries for a person upon login.

        @param person: Player name
        @param type_: Login type (LOGIN or RECONNECT)
        """
        if type_ not in [LOGIN, RECONNECT]:
            return
        if person not in self._delivery:
            return
        self._delivery[person] = [d for d in self._delivery[person] if self.valid_delivery(d, person)]
        if not self._delivery[person]:
            del self._delivery[person]
        self.save_file()

    def deliver_item(self, who, ob, sent_by):
        """Deliver an item to a player.

        @param who: Recipient name
        @param ob: Item to deliver
        @param sent_by: Sender name
        """
        player = self.driver.find_player(who)
        if not player:
            ob.move("/home/archaon/mud/lib/room/rubbish")
            return
        if ob.move(player) != MOVE_OK:
            env = player.environment()
            if env:
                new_mess = self._burdened_mess.replace("$S", sent_by).replace("$N", "$0$")
                player.add_message(new_mess, [{"my_a_short:" + self.driver.file_name(ob)}])
                ob.move(env)
            else:
                ob.move("/home/archaon/mud/lib/room/rubbish", "$N appear$s in a puff of smoke.")
                self.driver.log_file("/home/archaon/mud/lib/DELIVERY",
                                     f"{time.ctime()}: {ob.short()} sent to the rubbish room, {player.short()} has no environment.\n")
        else:
            new_mess = self._delivery_mess.replace("$S", sent_by).replace("$N", "$0$")
            player.add_message(new_mess, [{"my_a_short:" + self.driver.file_name(ob)}])
            self.driver.log_file("/home/archaon/mud/lib/DELIVERY",
                                 f"{time.ctime()}: {ob.short()} delivered to {who}.\n")

    def query_theft_command(self):
        """Indicate no theft command support.

        @return: -1 (no theft command)
        """
        return -1

    def clean_delivery_mapping(self):
        """Remove invalid delivery entries."""
        self._delivery = {k: [d for d in v if isinstance(d.delivery_ob, object)] for k, v in self._delivery.items()}
        self._delivery = {k: v for k, v in self._delivery.items() if v}

    def save_file(self):
        """Save delivery data to file."""
        if not self._save_file:
            return
        self._item_save = []
        self.clean_delivery_mapping()
        for player, values in self._delivery.items():
            tmp = [v.delivery_ob for v in values if isinstance(v.delivery_ob, object)]
            if tmp:
                self._item_save.extend([player, self.create_auto_load(tmp, 0)])
        self.driver.tell_creator("ceres", f"Saving: {self._save_file}\n")
        self.driver.save_object(self._save_file)
        self._item_save = None

    def load_file(self):
        """Load delivery data from file."""
        if not self._save_file or self.driver.file_size(self._save_file + ".o") <= -1:
            return
        self.driver.log_file("/home/archaon/mud/lib/DELIVERY",
                             f"Attempting to load save file at {time.ctime()}.\n")
        self.driver.tell_creator("ceres", f"Loading: {self._save_file}\n")
        self.driver.restore_object(self._save_file)
        if not self._cont:
            self._cont = self.driver.clone_object("/home/archaon/mud/lib/std/container")
        for obj in self._cont.all_inventory():
            obj.move("/home/archaon/mud/lib/room/rubbish")
        for i in range(0, len(self._item_save), 2):
            who = self._item_save[i]
            items = self._item_save[i + 1]
            if who in self._delivery:
                tmp = self.load_auto_load_to_array(items, self.driver.this_player())
                size = len(tmp)
                for j in range(size):
                    self._delivery[who][j].delivery_ob = tmp[size - j - 1]
                    tmp[j].move(self._cont)
        self._item_save = None

    def query_delivery_mess(self):
        """Get the delivery message.

        @return: Delivery message string
        """
        return self._delivery_mess

    def query_delivery_delay(self):
        """Get the delivery delay.

        @return: Delay in seconds
        """
        return self._delivery_delay

    def set_delivery_delay(self, new_time):
        """Set the delivery delay.

        @param new_time: Delay in seconds
        """
        self._delivery_delay = new_time

    def set_delivery_mess(self, s):
        """Set the delivery message.

        @param s: New message string
        """
        self._delivery_mess = s

    def set_burdened_mess(self, s):
        """Set the burdened delivery message.

        @param s: New message string
        """
        self._burdened_mess = s

    def query_burdened_mess(self):
        """Get the burdened delivery message.

        @return: Burdened message string
        """
        return self._burdened_mess

    def query_delivery(self, person=None):
        """Query delivery data.

        @param person: Specific player name (optional)
        @return: Delivery data for person or entire mapping
        """
        if person is None or person not in self._delivery:
            return dict(self._delivery)
        return list(self._delivery[person])

    def dest_me(self):
        """Clean up delivery object."""
        if self._cont:
            self._cont.dest_me()

    def query_cont(self):
        """Get the container object.

        @return: Container object
        """
        return self._cont

    def tidy_up(self):
        """Remove deliveries for inactive players."""
        for person in list(self._delivery.keys()):
            if not PLAYER_HANDLER.test_user(person) or not PLAYER_HANDLER.test_active(person):
                self.driver.log_file("/home/archaon/mud/lib/DELIVERY",
                                     f"{self.query_short()} Removing delivery for {person} (inactive).\n")
                del self._delivery[person]
        self.save_file()

    def stats(self):
        """Get delivery statistics.

        @return: List of stat tuples
        """
        return [
            ("delivery mess", self._delivery_mess.replace("\n", "")),
            ("burdened mess", self._burdened_mess.replace("\n", "")),
            ("delivery delay", self._delivery_delay),
            ("delivery save file", self._save_file),
            ("undelivered items", len(self._cont.all_inventory()) if self._cont else 0)
        ]