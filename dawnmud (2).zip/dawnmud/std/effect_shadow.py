# File: /home/archaon/mud/lib/std/effect_shadow.py
# Purpose: Provides a shadow object to attach effects to a player, managing effect arguments and removal.
# Related Files: None directly inherited or included in original; interacts with player objects.
# Updated Features: No significant updates identified from Discworld MUD as of March 20, 2025; core functionality preserved.
# Translated by: Archaon

import time

class EffectShadow:
    def __init__(self, driver):
        self.driver = driver
        self.player = None
        self.id = None

    def attach_to_player(self, p, i):
        """Attach the shadow to a player with a specific effect ID.

        @param p: Player object to attach to
        @param i: Effect ID
        @return: Shadowed player object
        """
        self.player = p
        self.id = i
        return self.driver.shadow(self.player, self, 1)  # Shadowing mechanism delegated to driver

    def remove_effect_shadow(self, i):
        """Remove the shadow if the effect ID matches.

        @param i: Effect ID to check
        """
        if i == self.id:
            if self.driver.this_object():
                self.driver.destruct(self.driver.this_object())
            return
        self.player.remove_effect_shadow(i)

    def arg(self):
        """Get the argument of the attached effect.

        @return: Effect argument or None if effect not found
        """
        enum = self.player.sid_to_enum(self.id)
        if enum == -1:
            # Log debug info if effect is missing
            self.driver.log_file("/home/archaon/mud/lib/DEBUG/EFFECTS",
                                 f"{int(time.time())}: no effect for {self.driver.file_name(self)}\n"
                                 f"           on {self.driver.file_name(self.player)}\n")
            self.driver.destruct(self.driver.this_object())
            return None
        return self.player.arg_of(enum)

    def set_arg(self, newarg):
        """Set the argument of the attached effect.

        @param newarg: New argument value
        """
        enum = self.player.sid_to_enum(self.id)
        if enum != -1:
            self.player.set_arg_of(enum, newarg)

    def remove_this_effect(self):
        """Remove the effect from the player."""
        enum = self.player.sid_to_enum(self.id)
        if enum != -1:
            self.player.delete_effect(enum)