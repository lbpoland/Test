# File: /home/archaon/mud/lib/std/book.py
# Purpose: Manages a book object with pages that can be opened, turned, torn, and read.
# Related Files: /home/archaon/mud/lib/std/object.py, /home/archaon/mud/lib/include/move_failures.py, /home/archaon/mud/lib/include/player.py
# Updated Features: No significant updates identified from Discworld MUD as of March 20, 2025; core functionality preserved.
# Translated by: Archaon

from home.archaon.mud.lib.std.object import Object
from home.archaon.mud.lib.include.move_failures import MOVE_OK
from home.archaon.mud.lib.include.player import PLAYER_RECEIPT

class Book(Object):
    def __init__(self, driver):
        super().__init__(driver)
        self._pages = []
        self._default_page_object = "/obj/misc/paper"
        self._def_p_obj = self.driver.load_object(self._default_page_object)
        self._open_page = 0
        self._book_num = 0
        self._ignore_open_page = 0
        self._ignore_saved_pages = 0
        self._player = None
        self._num_torn_out = -1
        self.add_help_file("book")

    def query_book(self):
        return 1

    def query_weight(self):
        """Calculate total weight including pages."""
        if not self._def_p_obj:
            self._def_p_obj = self.driver.load_object(self._default_page_object)
        return super().query_weight() + len([p for p in self._pages if isinstance(p, object)]) * self._def_p_obj.query_weight()

    def init(self):
        """Initialize book commands."""
        self.add_command("open", "<direct:object>", lambda: self.do_open(1))
        self.add_command("open", "<direct:object> to [page] <number>", lambda args: self.do_open(args[4][1]))
        self.add_command("tear", "page from <direct:object>", lambda: self.do_tear(1))
        self.add_command("tear", "[all] pages from <direct:object>", lambda: self.do_tear(0))
        self.add_command("tear", "<number> [of] pages from <direct:object>", lambda args: self.do_tear(args[4][0]))
        self.add_command("rip", "page from <direct:object>", lambda: self.do_tear(1))
        self.add_command("rip", "<number> [of] pages from <direct:object>", lambda args: self.do_tear(args[4][0]))
        self.add_command("rip", "[all] pages from <direct:object>", lambda: self.do_tear(0))
        self.add_command("turn", "[a|1] page of <direct:object>", lambda: self.do_turn(1))
        self.add_command("turn", "<number> pages of <direct:object>", lambda args: self.do_turn(args[4][0]))
        self.add_command("turn", "<direct:object> to [page] <number>", lambda args: self.do_open(args[4][1]))
        self.add_command("turn", "to page <number> of <direct:object>", lambda args: self.do_open(args[4][0]))
        self.add_command("close", "<direct:object>", self.do_close)

    def add_weight(self, number):
        """Adjust weight of the book."""
        self.adjust_weight(number)
        return 1

    def test_add(self, ob, flag):
        """Check if an object can be added to the book."""
        return ob.query_property("my book") == self

    def test_remove(self, ob, flag, dest):
        """Check if an object can be removed from the book."""
        return ob.query_property("my book") != self

    def set_no_pages(self, no):
        """Set the number of pages in the book."""
        siz = len(self._pages)
        if no < siz:
            self._pages = self._pages[:no]
            if self._open_page >= no:
                self._open_page = no
        else:
            self._pages.extend([[] for _ in range(no - siz)])
            if self._open_page > len(self._pages):
                self._open_page = len(self._pages)

    def query_pages(self):
        return self._pages

    def set_open_page(self, i):
        """Set the currently open page."""
        if i < 0 or i == self._open_page:
            return
        if not self._open_page and i:
            self.add_alias("page")
            self.add_plural("pages")
        if i > len(self._pages):
            self._open_page = len(self._pages)
        else:
            self._open_page = i
        if not self._open_page:
            self.remove_alias("page")
            self.remove_plural("pages")

    def query_open_page(self):
        return self._open_page

    def is_current_page_torn_out(self):
        """Check if the current page is torn out."""
        return self._open_page and self._pages and not self._pages[self._open_page - 1]

    def is_page_torn_out(self, page):
        """Check if a specific page is torn out."""
        if page < 1 or page > len(self._pages):
            return 0
        return not self._pages[page - 1]

    def query_current_page(self):
        """Get the current page object."""
        if not self._open_page:
            return self
        for i in range(self._open_page - 1, len(self._pages)):
            if self._pages[i]:
                if not self._def_p_obj:
                    self._def_p_obj = self.driver.load_object(self._default_page_object)
                return self._def_p_obj
        return None

    def query_current_page_clone(self):
        return self

    def tear_current_page_out(self, dest):
        """Tear out the current page."""
        if self.is_current_page_torn_out():
            return None
        page = None
        if self._pages[self._open_page - 1]:
            page = self.driver.clone_object(self._default_page_object)
            page.add_alias("page")
            page.add_plural("pages")
            if self._pages[self._open_page - 1] != 1:
                page.set_read_mess(self._pages[self._open_page - 1])
        if page and page.move(dest) == MOVE_OK:
            self._pages[self._open_page - 1] = None
            return page
        return None

    def add_page_after(self, page, after):
        """Add a page after a specific position."""
        if after < 0 or after > len(self._pages) + 1 or not isinstance(page, object):
            return 0
        self._pages = self._pages[:after] + page.query_read_mess() + self._pages[after:]
        page.move("/room/rubbish")
        return 1

    def replace_page_with(self, page, num):
        """Replace a page with new content."""
        if num < 1 or num > len(self._pages) or not isinstance(page, object):
            return 0
        self._pages[num - 1] = page.query_read_mess()
        page.move("/room/rubbish")
        return 1

    def make_page_blank(self, num):
        """Make a page blank."""
        if num < 1 or num > len(self._pages):
            return 0
        self._pages[num - 1] = 1
        return 1

    def short(self, flags=0):
        """Get the short description with open/closed state."""
        if not flags or self._ignore_open_page:
            return super().short(flags)
        return f"{'open' if self._open_page else 'closed'} {super().short(flags)}"

    def parse_command_adjectiv_id_list(self):
        """Add open/closed adjective to command parsing."""
        base = super().parse_command_adjectiv_id_list()
        return base + ["open"] if self._open_page else base + ["closed"]

    def long(self, str=None, dark=0):
        """Get the long description with page details."""
        if not self._open_page:
            return super().long(str, dark) + "It is closed.\n"
        ret = super().long(str, dark) + f"It is open at page {self._open_page}.\n"
        for i in range(self._open_page - 1, len(self._pages)):
            if not self._pages[i]:
                ret += f"Page {i + 1} has been torn out.\n"
            else:
                if i != self._open_page - 1:
                    ret += f"You can see page {i + 1} however.\n"
                if str and "page" in str:
                    ret += self._default_page_object.long(str, dark)
                break
        else:
            ret += "All the rest of the pages have been torn out!\n"
        return ret

    def do_open(self, page):
        """Open the book to a specific page.

        @param page: Page number to open to
        @return: 1 if successful, 0 if failed
        """
        if page <= 0:
            self.driver.write("Oddly enough, the first page is page 1.\n")
            page = 1
        elif page > len(self._pages):
            self.driver.write(f"There {'is only' if len(self._pages) == 1 else 'are only'} {self.query_num(len(self._pages))} "
                              f"{'page' if len(self._pages) == 1 else 'pages'} in {self.the_short()}.\n")
            page = len(self._pages)
        if self._open_page == page:
            self.add_failed_mess(f"The $D is already open at page {page}.\n")
            return 0
        if self._open_page > 0 and self.is_page_torn_out(page):
            self.add_failed_mess(f"The page {page} in $D is torn out.\n")
            return 0
        self._ignore_open_page = 1
        self.driver.call_out(lambda: setattr(self, '_ignore_open_page', 0), 4)
        self.set_open_page(page)
        self.add_succeeded_mess(f"$N $V $D to page {page}.\n", [])
        return 1

    def do_turn(self, number):
        """Turn pages in the book.

        @param number: Number of pages to turn
        @return: 1 if successful, 0 if failed
        """
        tmp = self._open_page
        if tmp + number > len(self._pages):
            self.set_open_page(0)
            self.add_succeeded_mess("$N close$s $D.\n")
        else:
            self.set_open_page(tmp + number)
            if tmp == 0:
                self.add_succeeded_mess(f"$N turn$s $D to page {number}.\n")
            else:
                self.add_succeeded_mess(f"$N turn$s {number} {'pages' if number > 1 else 'page'} of $D.\n")
        if tmp == self._open_page:
            self.add_failed_mess("Unable to turn page of $D.\n", [])
            return 0
        self._ignore_open_page = 1
        self.driver.call_out(lambda: setattr(self, '_ignore_open_page', 0), 4)
        return 1

    def do_close(self):
        """Close the book.

        @return: 1 if successful, 0 if already closed
        """
        if not self._open_page:
            self.driver.this_player().add_failed_mess(self, "$D is already closed.\n", [])
            return 0
        self._ignore_open_page = 1
        self.driver.call_out(lambda: setattr(self, '_ignore_open_page', 0), 4)
        self.set_open_page(0)
        return 1

    def do_tear(self, number):
        """Tear pages from the book.

        @param number: Number of pages to tear (0 for all)
        @return: 1 if successful, 0 if failed
        """
        if self._ignore_saved_pages:
            self.add_failed_mess("For some reason you cannot seem to tear any pages from $D.\n")
            return 0
        if not self._open_page:
            self.driver.this_player().add_failed_mess(self, "$D is closed!\n", [])
            return 0
        if number == 0:
            self._open_page = 1
            number = len(self._pages)
        i = 0
        while i < number:
            if not self.tear_current_page_out(self.driver.this_player()):
                break
            if self._open_page != len(self._pages):
                self._open_page += 1
            i += 1
        if i:
            self.add_succeeded_mess(f"$N $V {'a page' if i == 1 else f'{i} pages'} from $D.\n")
            return 1
        return 0

    def set_read_mess(self, str_=None, lang=None, size=None):
        """Set the read message for the current page."""
        if self._open_page:
            if isinstance(str_, list):
                self._pages[self._open_page - 1] = str_
            elif str_:
                self._pages[self._open_page - 1] = [[str_, 0, lang, size]]
            else:
                self._pages[self._open_page - 1] = 1
        else:
            super().set_read_mess(str_, lang, size)

    def add_read_mess(self, str_, type_, lang, size):
        """Add a read message to the current page."""
        if self._open_page:
            if not isinstance(self._pages[self._open_page - 1], list):
                self._pages[self._open_page - 1] = []
            self._pages[self._open_page - 1].append([str_, type_, lang, size])
        else:
            super().add_read_mess(str_, type_, lang, size)

    def query_read_mess(self):
        """Get the read message for the current page."""
        if self._open_page:
            return self._pages[self._open_page - 1] or []
        return super().query_read_mess()

    def stats(self):
        """Get book statistics."""
        return [
            ("num pages", len(self._pages)),
            ("ignore saved pages", self._ignore_saved_pages),
            ("default page ob", self._default_page_object),
            ("open page", self._open_page),
            ("book number", self._book_num)
        ] + super().stats()

    def dest_me(self):
        """Clean up book and its pages upon destruction."""
        for page in self._pages:
            if isinstance(page, object):
                page.dest_me()
        super().dest_me()

    def query_dynamic_auto_load(self):
        """Prepare data for dynamic auto-loading."""
        bing = {
            "::": super().query_dynamic_auto_load(),
            "default page object": self._default_page_object,
            "open page": self._open_page,
            "book num": self._book_num
        }
        if not self._ignore_saved_pages:
            bing["pages"] = self._pages
        return bing

    def init_dynamic_arg(self, map_, player=None):
        """Initialize book with dynamic auto-load data."""
        if not player:
            player = self._player or self.driver.this_player()
        if "::" in map_:
            super().init_dynamic_arg(map_["::"])
        if "default page object" in map_:
            self._default_page_object = map_["default page object"]
            self._def_p_obj = self.driver.load_object(self._default_page_object)
        if "pages" in map_ and not self._ignore_saved_pages:
            if map_["pages"] and len(map_["pages"][0]) == 3:
                for i, page_data in enumerate(map_["pages"]):
                    tmp = player.load_auto_load_to_array(page_data, self, player)
                    if tmp.query_read_mess():
                        self._pages[i] = tmp.query_read_mess()[0]
                    tmp.move("/room/rubbish")
            else:
                self._pages = map_["pages"]
        self._book_num = map_.get("book num", 0)
        self.set_open_page(map_.get("open page", 0))

    def set_default_page_object(self, obj):
        """Set the default page object."""
        self._default_page_object = obj
        self._def_p_obj = self.driver.load_object(obj)

    def query_default_page_object(self):
        return self._default_page_object

    def create_default_page_object(self):
        return self.driver.clone_object(self._default_page_object)

    def query_num_pages(self):
        return len(self._pages)

    def query_book_num(self):
        return self._book_num

    def set_book_num(self, num):
        self._book_num = num

    def query_ignore_saved_pages(self):
        return self._ignore_saved_pages

    def set_ignore_saved_pages(self, saved):
        self._ignore_saved_pages = saved

    def set_player(self, player):
        self._player = player

    def query_player(self):
        return self._player

    def query_read_short(self, player, ignore_labels=0):
        """Get the readable short description."""
        base = super().query_read_short(player, 0)
        if not base:
            return None
        return f"the cover of {base}" if not self._open_page else f"page {self.query_num(self._open_page)} of {base}"

    def query_readable_message(self, player, ignore_labels=0):
        return super().query_readable_message(player, self._open_page != 0)