# File: /home/archaon/mud/lib/std/book_dir.py
# Purpose: Extends Book to manage a directory-based book with dynamically loaded pages.
# Related Files: /home/archaon/mud/lib/std/book.py, /home/archaon/mud/lib/include/nroff.py
# Updated Features: No significant updates identified from Discworld MUD as of March 20, 2025; core functionality preserved.
# Translated by: Archaon

from home.archaon.mud.lib.std.book import Book
from home.archaon.mud.lib.include.nroff import Nroff  # Assuming nroff.h provides constants or utilities

class BookDir(Book):
    def __init__(self, driver):
        super().__init__(driver)
        self.language = None

    def set_book_language(self, lang):
        """Set the language for the book's content.

        @param lang: Language string
        """
        self.language = lang

    def query_language(self):
        """Get the book's language.

        @return: Language string or None
        """
        return self.language

    def set_book_dir(self, dir_):
        """Load pages from a directory structure.

        @param dir_: Directory path to load pages from
        """
        self.set_no_pages(10)
        self.set_ignore_saved_pages(1)
        max_pages = 10
        i = 1
        self.set_default_page_object("/home/archaon/mud/lib/obj/misc/nroff_paper")
        self.set_open_page(0)
        while self.driver.file_size(f"{dir_}{i}") > 0:
            self.set_open_page(i)
            self.set_read_mess(f"$${dir_}{i}$$", self.language, 0)
            i += 1
            if i >= max_pages:
                max_pages += 10
                self.set_no_pages(max_pages)
        self.set_no_pages(i - 1)
        self.set_open_page(0)