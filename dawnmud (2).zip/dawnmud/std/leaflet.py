# File: /home/archaon/mud/lib/std/leaflet.py
# Purpose: Manages a leaflet object with multiple pages that can be turned and read.
# Related Files: /home/archaon/mud/lib/std/object.py
# Updated Features: No significant updates identified from Discworld MUD as of March 20, 2025; core functionality from 2003 mudlib preserved.
# Translated by: Archaon

from home.archaon.mud.lib.std.object import Object

class Leaflet(Object):
    def __init__(self, driver):
        super().__init__(driver)
        self.page = 0
        self.pages = [[]]  # Initialize with one empty page
        self.setup()
        self.add_help_file("leaflet")

    def query_leaflet(self):
        """Check if this is a leaflet object.

        @return: 1 (True) indicating it is a leaflet
        """
        return 1

    def query_page(self):
        """Get the current page number (0-based).

        @return: Current page number
        """
        return self.page

    def query_pages(self):
        """Get a copy of all pages.

        @return: List of pages
        """
        return list(self.pages)

    def init(self):
        """Initialize leaflet commands."""
        self.add_command("turn", "[a] page of <direct:object>", self.do_turn)
        self.add_command("open", "<direct:object> to [page] <number>", lambda args: self.do_open(args[4][1]))

    def set_no_pages(self, number):
        """Set the number of pages in the leaflet.

        @param number: Number of pages (minimum 1)
        """
        if number < 1:
            number = 1
        self.pages = [[] for _ in range(number)]

    def set_read_mess(self, mess=None, lang=None, size=None):
        """Set the read message for the current page.

        @param mess: Message content (string or list)
        @param lang: Language (optional)
        @param size: Size (optional)
        """
        super().set_read_mess(mess, lang, size)
        self.pages[self.page] = self.query_read_mess()

    def add_read_mess(self, mess, type_, lang, size):
        """Add a read message to the current page.

        @param mess: Message content
        @param type_: Message type
        @param lang: Language
        @param size: Size
        @return: Added message
        """
        ret = super().add_read_mess(mess, type_, lang, size)
        self.pages[self.page] = self.query_read_mess()
        return ret

    def query_open_page(self):
        """Get the current page number (1-based).

        @return: Current page number plus 1
        """
        return self.page + 1

    def set_open_page(self, number):
        """Set the current page.

        @param number: Page number (1-based)
        """
        if number < 1 or number > len(self.pages):
            number = 1
        self.page = number - 1
        self.set_read_mess(self.pages[self.page])

    def do_turn(self):
        """Turn to the next page.

        @return: 1 if successful
        """
        self.set_open_page(self.page + 2)
        return 1

    def do_open(self, page_no):
        """Open the leaflet to a specific page.

        @param page_no: Page number (1-based)
        @return: 1 if successful, 0 if failed
        """
        if page_no < 1 or page_no > len(self.pages):
            self.add_failed_mess(f"The page no {page_no} does not exist.\n")
            return 0
        self.set_open_page(page_no)
        return 1

    def query_static_auto_load(self):
        """Prepare static auto-load data if this is the base leaflet object.

        @return: Static auto-load data or empty dict
        """
        fname_parts = self.driver.file_name(self).split('#')
        if fname_parts[0] == "/home/archaon/mud/lib/std/leaflet":
            return self.int_query_static_auto_load()
        return {}

    def query_dynamic_auto_load(self):
        """Prepare dynamic auto-load data.

        @return: Mapping of dynamic data
        """
        return {
            "::": super().query_dynamic_auto_load(),
            "page": self.page,
            "pages": list(self.pages)
        }

    def init_dynamic_arg(self, map_):
        """Initialize with dynamic auto-load data.

        @param map_: Mapping of dynamic data
        """
        if not isinstance(map_, dict):
            return
        if "::" in map_:
            super().init_dynamic_arg(map_["::"])
        self.page = map_.get("page", 0)
        if "pages" in map_ and isinstance(map_["pages"], list):
            self.pages = map_["pages"]
            self.set_open_page(self.page + 1)

    def query_read_short(self, player, ignore_labels=0):
        """Get the readable short description.

        @param player: Player object
        @param ignore_labels: Ignore labels flag
        @return: Readable short string or None
        """
        ret = super().query_read_short(player, 1 if self.page == 0 else 0)
        if not ret:
            return None
        return f"page {self.query_num(self.page)} of {ret}"