# File: /home/archaon.mud/lib/std/container.py
# Purpose: Manages a container object with weight and item limits, ownership, and inventory tracking.
# Related Files: /home/archaon/mud/lib/std/object.py, /home/archaon/mud/lib/include/move_failures.py, /home/archaon/mud/lib/include/player.py, /home/archaon/mud/lib/include/player_handler.py
# Updated Features: No significant updates identified from Discworld MUD as of March 20, 2025; core functionality preserved.
# Translated by: Archaon

from home.archaon.mud.lib.std.object import Object
from home.archaon.mud.lib.std.basic.cute_look import CuteLook
from home.archaon.mud.lib.std.basic.export_inventory import ExportInventory
from home.archaon.mud.lib.global.auto_load import AutoLoad
from home.archaon.mud.lib.include.move_failures import MOVE_OK, MOVE_INVALID_DEST
from home.archaon.mud.lib.include.player import PLAYER_RECEIPT
from home.archaon.mud.lib.include.player_handler import PLAYER_HANDLER
import math

class Container(Object, CuteLook, ExportInventory, AutoLoad):
    def __init__(self, driver):
        super().__init__(driver)
        ExportInventory.__init__(self)
        self._max_weight = 0
        self._loc_weight = 0
        self._max_items = 0
        self._prevent_insert = 0
        self._ownership = None
        self._player = None
        self._n_tracked_items = 0
        self._tracking = 1
        self.registered_containers = []

    def query_max_items(self):
        """Get the maximum number of items the container can hold.

        @return: Max items or calculated value
        """
        if self._max_items:
            return self._max_items
        if self._max_weight:
            return int(4 * math.sqrt(self._max_weight))
        return -1

    def set_max_items(self, number):
        """Set the maximum number of items."""
        self._max_items = number

    def query_max_weight(self):
        return self._max_weight

    def set_max_weight(self, number):
        self._max_weight = number

    def query_loc_weight(self):
        return self._loc_weight

    def update_loc_weight(self):
        """Update the local weight based on inventory."""
        self._loc_weight = sum(obj.query_complete_weight() for obj in self.all_inventory())

    def query_complete_weight(self):
        return super().query_complete_weight() + self._loc_weight

    def add_weight(self, n):
        """Add weight to the container.

        @param n: Weight to add
        @return: 1 if successful, 0 if exceeds limit
        """
        if not self._max_weight:
            self._loc_weight += n
            return 1
        if n + self._loc_weight > self._max_weight:
            return 0
        env = self.environment()
        if not env:
            self._loc_weight += n
            return 1
        if not env.add_weight(n):
            return 0
        self._loc_weight += n
        return 1

    def query_ownership(self):
        return self._ownership

    def set_ownership(self, word):
        """Set the ownership of the container."""
        self._ownership = word.lower() if word else None

    def test_remove(self, thing, flag, dest):
        """Check if an item can be removed based on ownership.

        @param thing: Object to remove
        @param flag: Unused flag
        @param dest: Destination
        @return: 1 if allowed, 0 if not
        """
        if not self._ownership or not self.driver.this_player():
            return 1
        dest_path = dest if isinstance(dest, str) else self.driver.file_name(dest)
        if dest_path in ["/home/archaon/mud/lib/room/rubbish", "/home/archaon/mud/lib/room/vault"]:
            return 1
        player = self.driver.this_player()
        log_str = (f"Item {self.driver.file_name(self)} accessed by {player.query_short()} "
                   f"which belongs to $C${self._ownership}")
        if player.query_name() == self._ownership:
            log_str += ". Taking items, no theft event."
            self.driver.log_file("/home/archaon/mud/w/trilogy/CONTAINER", log_str + "\n")
            return 1
        player_exists = PLAYER_HANDLER.test_user(self._ownership)
        if player_exists:
            log_str += ", who is a player. "
            if not self.pk_check(player, self._ownership, 1) and player.environment():
                log_str += "PK check succeeded: Taking items, theft event triggered."
                player.zap_harry_shadow()
                self.driver.event(player.environment(), "theft", player, self, [thing])
                self.driver.log_file("/home/archaon/mud/w/trilogy/CONTAINER", log_str + "\n")
                return 1
            else:
                log_str += "PK check failed: Cannot take items."
                self.driver.write("An unseen force stays your hand.\n")
                self.driver.log_file("/home/archaon/mud/w/trilogy/CONTAINER", log_str + "\n")
                return 0
        log_str += ", which is not a player. Taking items, theft event triggered."
        player.zap_harry_shadow()
        self.driver.event(player.environment(), "theft", player, self, [thing])
        self.driver.log_file("/home/archaon/mud/w/trilogy/CONTAINER", log_str + "\n")
        return 1

    def test_add(self, ob, flag):
        """Check if an item can be added to the container."""
        if not self._max_weight and not self._max_items:
            return 1
        if ob.query_max_weight() > self._max_weight - self._loc_weight:
            return 0
        if self.query_length() > 1 and self.query_length() < ob.query_length():
            return 0
        if self.query_width() > 1 and self.query_width() < ob.query_width():
            return 0
        deep_inv = self.deep_inventory()
        deep_ob = ob.deep_inventory()
        if ob.query_max_weight():
            return len(deep_inv) + len(deep_ob) < self.query_max_items()
        return len(deep_inv) < self.query_max_items()

    def set_prevent_insert(self):
        self._prevent_insert = 1

    def reset_prevent_insert(self):
        self._prevent_insert = 0

    def query_prevent_insert(self):
        return self._prevent_insert

    def move(self, dest, messin=None, messout=None):
        """Move the container, respecting insert prevention."""
        if self._prevent_insert and self._loc_weight and not self.driver.living(dest) and self.driver.environment(dest):
            return MOVE_INVALID_DEST
        return super().move(dest, messin, messout)

    def find_inv_match(self, words, looker):
        """Find visible inventory matches."""
        things = self.all_inventory()
        return [t for t in things if t.short(0) and (not looker or t.query_visible(looker))]

    def do_restore_inventory_error(self, ob, move_flag):
        """Handle inventory restoration errors."""
        receipt = self.driver.clone_object(PLAYER_RECEIPT)
        receipt.setup_receipt(ob)
        receipt.set_weight(0)
        ret = receipt.move(self)
        if ret != MOVE_OK:
            receipt.dest_me()
        else:
            move_flag = MOVE_OK
            ob.move("/home/archaon/mud/lib/room/rubbish")
        return move_flag

    def handle_restore_inventory(self, ob):
        """Restore inventory item."""
        ob.disable_item_tracking()
        move_flag = ob.move(self)
        ob.enable_item_tracking()
        if move_flag != MOVE_OK:
            move_flag = self.do_restore_inventory_error(ob, move_flag)
        return move_flag

    def stats(self):
        return super().stats() + [
            ("loc_weight", self.query_loc_weight()),
            ("max_weight", self.query_max_weight()),
            ("max_items", self.query_max_items()),
            ("export invent", self.query_can_export_inventory())
        ]

    def int_query_static_auto_load(self):
        tmp = super().int_query_static_auto_load()
        return {
            "::": tmp,
            "max weight": self._max_weight,
            "prevent insert": self._prevent_insert,
            "can export inventory": self.query_can_export_inventory()
        }

    def query_dynamic_auto_load(self):
        inventory = self.create_auto_load(self.all_inventory(), 0)
        return {
            "::": super().query_dynamic_auto_load(),
            "inv": inventory
        }

    def set_player(self, thing):
        super().set_player(thing)
        self._player = thing

    def query_player(self):
        return self._player

    def enable_item_tracking(self):
        self._tracking = 1

    def disable_item_tracking(self):
        self._tracking = 0

    def event_container_move(self, mover, from_, to):
        if self._n_tracked_items:
            for item in self.all_inventory():
                item.event_container_move(mover, from_, to)

    def event_move_object(self, from_, to):
        if self._n_tracked_items and self._tracking and not self.interactive():
            for item in self.all_inventory():
                item.event_container_move(self, from_, to)
            if isinstance(from_, object):
                from_.remove_tracked_items(self._n_tracked_items)
            if isinstance(to, object):
                to.add_tracked_items(self._n_tracked_items)

    def set_tracked_item_status_reason(self, reason):
        if self._n_tracked_items:
            for item in self.all_inventory():
                item.set_tracked_item_status(reason)

    def add_tracked_items(self, n_items):
        self._n_tracked_items += n_items
        env = self.environment()
        if env:
            env.add_tracked_items(n_items)

    def remove_tracked_items(self, n_items):
        self._n_tracked_items -= n_items
        env = self.environment()
        if env:
            env.remove_tracked_items(n_items)

    def query_tracked_items(self):
        return self._n_tracked_items

    def can_find_match_recurse_into(self, looker):
        """Check if recursive matching is allowed."""
        env = self.environment()
        while env and not self.driver.living(env) and env != looker and env != looker.environment():
            env = env.environment()
        return env in [looker, looker.environment()]

    def can_find_match_reference_inside_object(self, thing, looker):
        return 1

    def init_dynamic_arg(self, bing, obj=None):
        if "::" in bing:
            super().init_dynamic_arg(bing["::])
        if "inv" in bing:
            if not self._player:
                self._player = self.driver.this_player()
            load_func = lambda x: self.handle_restore_inventory(x)
            self.load_auto_load_to_inventory(bing["inv"], self, self._player or self.driver.this_player(), load_func)

    def init_static_arg(self, bing):
        if "::" in bing:
            super().init_static_arg(bing["::])
        if "max weight" in bing:
            self._max_weight = bing["max weight"]
        if "prevent insert" in bing:
            self._prevent_insert = bing["prevent insert"]
        if bing.get("can export inventory"):
            self.set_can_export_inventory()
        else:
            self.reset_can_export_inventory()

    def dest_me(self):
        """Clean up container and its contents."""
        for ob in self.all_inventory():
            ob.dest_me()
        super().dest_me()