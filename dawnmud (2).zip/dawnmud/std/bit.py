# File: /home/archaon/mud/lib/std/bit.py
# Purpose: Manages individual corpse bits with decay, edibility, and sub-bit mechanics for a MUD environment.
# Related Files: /home/archaon/mud/lib/std/object.py, /home/archaon/mud/lib/include/bit.py, /home/archaon/mud/lib/include/corpse.py
# Updated Features: No significant updates identified from Discworld MUD as of March 20, 2025; core functionality preserved.
# Translated by: Archaon

from home.archaon.mud.lib.std.object import Object
from home.archaon.mud.lib.include.bit import BIT_CONTROLLER, BIT_NAME, BIT_ALIAS, BIT_EXTRA, EXTRA_VALUE, EXTRA_WEIGHT, DECAY_TIME, STD_CORPSE_WEIGHT
import random

class Bit(Object):
    def __init__(self, driver):
        super().__init__(driver)
        self.bit_data = None
        self.bits = []
        self.race_ob = None
        self.corpse_weight = STD_CORPSE_WEIGHT
        self.race_name = None
        self.bits_gone = []
        self.decay = 0
        self.cured = 0
        self.set_short("anonymous bit")
        self.set_long("This is an unknown bit of some creature.\n")
        self.set_weight(5)
        self.set_name("bit")
        self.add_property("corpse bit", 1)
        self.add_property("cureable", 1)

    def init(self):
        """Initialize commands for the bit object."""
        self.add_command("eat", "<direct:object>", self.do_eat)

    def query_edible(self):
        """Check if the bit is edible based on race-specific rules.

        @return: 1 if edible, 0 if not
        """
        if not self.race_ob or not self.bit_data:
            return 0
        bit = self.bit_data[BIT_NAME]
        if not self.race_ob.query_eat(bit):
            return 0
        for poss_bit in self.query_possible_bits(None) - self.bits_gone:
            if not self.race_ob.query_eat(poss_bit):
                return 0
        return 1

    def do_eat(self):
        """Handle the eat command for the bit.

        @return: 1 if successful, 0 if not edible
        """
        if not self.query_edible():
            return 0
        self.move("/room/rubbish")
        return 1

    def no_decay(self):
        """Check if the bit is immune to decay.

        @return: True if unrottable, False otherwise
        """
        return self.race_ob and self.bit_data and self.race_ob.query_unrottable(self.bit_data[BIT_NAME])

    def set_race_ob(self, s):
        """Set the race object for the bit."""
        self.race_ob = s

    def set_race_name(self, s):
        """Set the race name for the bit."""
        self.race_name = s

    def setup_long(self):
        """Update the long description based on decay state and curing."""
        if not self.bit_data:
            return
        base_desc = ""
        if self.no_decay():
            base_desc = f"This is the {self.bit_data[BIT_NAME]} of " + (
                f"{self.add_a(self.race_name)}.\n" if self.race_name else "an unknown creature.\n")
        elif self.decay > 80:
            base_desc = f"This is a fresh {self.bit_data[BIT_NAME]} severed from the corpse of " + (
                f"{self.add_a(self.race_name)}.\n" if self.race_name else "an unknown creature.\n")
        elif self.decay > 50:
            base_desc = f"This is {self.add_a(self.bit_data[BIT_NAME])} severed from the corpse of " + (
                f"{self.add_a(self.race_name)}.\n" if self.race_name else "an unknown creature.\n")
        elif self.decay > 30:
            base_desc = f"This is the partially decayed remains of {self.add_a(self.bit_data[BIT_NAME])} severed from the corpse of " + (
                f"{self.add_a(self.race_name)}.\n" if self.race_name else "an unknown creature.\n")
        else:
            base_desc = f"This is the almost unrecognizable remains of {self.add_a(self.bit_data[BIT_NAME])} severed from the corpse of " + (
                f"{self.add_a(self.race_name)}.\n" if self.race_name else "an unknown creature.\n")
        self.set_short(self.race_name + " " + self.bit_data[BIT_NAME] if self.race_name else self.bit_data[BIT_NAME])
        self.set_main_plural(self.race_name + " " + self.pluralize(self.bit_data[BIT_NAME]) if self.race_name else self.pluralize(self.bit_data[BIT_NAME]))
        self.set_long(base_desc + (self.extra_look() if self.bits_gone else ""))
        if self.cured:
            self.set_long(self.query_long() + "It seems to have been pickled.\n")

    def extra_look(self):
        """Generate additional description for missing bits.

        @return: String describing missing bits
        """
        if self.bits_gone:
            return f"It appears to be missing the {self.query_multiple_short(self.bits_gone)}.\n"
        return ""

    def set_corpse_weight(self, i):
        """Set the corpse weight for weight calculations."""
        self.corpse_weight = i

    def set_bit(self, s, dec):
        """Initialize the bit with specific data and decay state.

        @param s: Bit name
        @param dec: Initial decay value
        """
        self.bit_data = self.race_ob.query_bit(s) if self.race_ob else None
        if not self.bit_data or not len(self.bit_data):
            return
        self.add_adjective(self.race_name if self.race_name else "unknown")
        self.add_adjective(s.split())
        if isinstance(self.bit_data[BIT_EXTRA][EXTRA_VALUE], list) and len(self.bit_data[BIT_EXTRA][EXTRA_VALUE]) > 3:
            self.set_value(self.bit_data[BIT_EXTRA][EXTRA_VALUE][3])
        self.add_alias(self.bit_data[BIT_NAME])
        self.add_plural(self.pluralize(self.bit_data[BIT_NAME]))
        if self.bit_data[BIT_ALIAS] and len(self.bit_data[BIT_ALIAS]):
            self.add_alias(self.bit_data[BIT_ALIAS])
            self.add_plural(self.pluralize(self.bit_data[BIT_ALIAS]))
        temp = self.bit_data[BIT_EXTRA][EXTRA_WEIGHT] * self.corpse_weight // STD_CORPSE_WEIGHT
        self.set_weight(temp if temp > 0 else 1)
        self.decay = dec if dec else 100
        if not self.no_decay():
            BIT_CONTROLLER.add_bit(self)
        self.setup_long()
        self.set_bits()

    def do_decay(self):
        """Handle the decay process for the bit.

        @return: 1 if still decaying, 0 if fully decayed
        """
        if not self.environment():
            self.move("/room/rubbish")
            return 0
        rate = 5 + (self.environment().query_property("decay rate") or 0)
        if rate > 0:
            self.decay -= rate
        if self.decay < 0:
            self.driver.tell_object(self.environment(), f"{self.the_short().capitalize()} decays to dust.\n")
            self.move("/room/rubbish")
            return 0
        if self.decay in [80, 50, 30]:
            self.setup_long()
        return 1

    def query_race_ob(self):
        return self.race_ob

    def query_race_name(self):
        return self.race_name

    def query_bit_data(self):
        return self.bit_data

    def query_decay(self):
        return self.decay

    def dest_me(self):
        """Clean up the bit object upon destruction."""
        BIT_CONTROLLER.remove_bit(self)
        super().dest_me()

    def query_dynamic_auto_load(self):
        """Prepare data for dynamic auto-loading.

        @return: Tuple of dynamic attributes
        """
        return (self.bit_data, self.race_ob, self.corpse_weight, self.race_name,
                self.decay, self.cured, self.bits_gone, super().query_dynamic_auto_load())

    def init_dynamic_arg(self, arg, obj=None):
        """Initialize the bit with dynamic auto-load data.

        @param arg: Tuple of dynamic attributes
        @param obj: Unused object parameter
        """
        if isinstance(arg, dict):
            super().init_dynamic_arg(arg)
            return
        self.bit_data, self.race_ob, self.corpse_weight, self.race_name, self.decay, self.cured, self.bits_gone = arg[:-1]
        super().init_dynamic_arg(arg[-1])
        if not self.cured and not self.no_decay():
            BIT_CONTROLLER.add_bit(self)
        self.setup_long()
        if self.bit_data:
            self.set_bits()

    def do_cure(self):
        """Cure the bit to prevent decay."""
        if self.cured:
            return
        self.cured = 1
        BIT_CONTROLLER.remove_bit(self)
        self.set_long(self.query_long() + "It seems to have been pickled.\n")
        self.set_short(f"cured {self.query_short()}")
        self.set_main_plural(f"cured {self.query_main_plural()}")
        self.add_adjective("cured")

    def query_cured(self):
        return self.cured

    def query_vect(self):
        return self.bit_data[BIT_EXTRA][EXTRA_VALUE] if self.bit_data else None

    def query_possible_bits(self, word):
        """Get possible sub-bits for the bit.

        @param word: Specific bit to filter (optional)
        @return: List of possible bits
        """
        possibles = []
        for i in range(len(self.bits) - 3, -1, -3):
            if (self.bits[i] == word or self.bits[i + 1] == word or not word):
                if isinstance(self.bits[i + 2][2], list):
                    possibles.extend([self.bits[i]] * self.bits[i + 2][2][1])
                else:
                    possibles.append(self.bits[i])
        return possibles

    def query_possible_plural_bits(self, word):
        """Get possible plural sub-bits.

        @param word: Specific plural bit to filter (optional)
        @return: List of possible plural bits
        """
        possibles = []
        for i in range(len(self.bits) - 3, -1, -3):
            if ((self.bits[i] and self.pluralize(self.bits[i]) == word) or
                (self.bits[i + 1] and self.pluralize(self.bits[i + 1]) == word) or not word):
                if isinstance(self.bits[i + 2][2], list):
                    possibles.extend([self.bits[i]] * self.bits[i + 2][2][1])
                else:
                    possibles.append(self.bits[i])
        return possibles

    def query_bit_left(self, s):
        """Get the first available bit not gone.

        @param s: Bit name to check
        @return: First available bit or None
        """
        poss_bits = self.query_possible_bits(s)
        if not poss_bits:
            return None
        poss_bits = [b for b in poss_bits if b not in self.bits_gone]
        return poss_bits[0] if poss_bits else None

    def query_bit_left_pl(self, s):
        """Get available plural bits not gone.

        @param s: Plural bit name to check
        @return: List of available bits or None
        """
        poss_bits = self.query_possible_plural_bits(s)
        if not poss_bits:
            return None
        poss_bits = [b for b in poss_bits if b not in self.bits_gone]
        return poss_bits if poss_bits else None

    def find_inv_match(self, s, looker):
        """Find inventory matches for cutting or plucking bits.

        @param s: Bit name to match
        @param looker: Player attempting the action
        @return: List of matched bit objects
        """
        bit = self.query_bit_left(s)
        bit_pl = self.query_bit_left_pl(s)
        if not bit and not bit_pl:
            return self.all_inventory()
        cut = 0
        weap = looker.query_weapons() if looker else []
        for wep in weap:
            if wep.id("dagger") or wep.id("knife"):
                cut = 1
                break
        if bit:
            if cut or self.race_ob.query_pluckable(bit):
                return [self.make_bit(bit)]
            self.driver.tell_object(looker, f"You can only cut things from {self.a_short()} with a knife or dagger.\n" if weap else
                                    f"You can't cut bits from {self.a_short()} with your bare hands.\n")
            return []
        if bit_pl:
            if cut:
                return self.make_bits(bit_pl[:5] if len(bit_pl) > 5 else bit_pl)
            bit_pl = [b for b in bit_pl if self.race_ob.query_pluckable(b)]
            if bit_pl:
                return self.make_bits(bit_pl[:5] if len(bit_pl) > 5 else bit_pl)
            self.driver.tell_object(looker, f"You can only cut things from {self.a_short()} with a knife or dagger.\n" if weap else
                                    f"You can't cut bits from {self.a_short()} with your bare hands.\n")
            return []
        return []

    def make_bit(self, which_bit):
        """Create a new bit object from the current bit.

        @param which_bit: Name of the bit to create
        @return: New bit object
        """
        bit = self.race_ob.query_bit(which_bit)
        if isinstance(bit[2][2], list) and isinstance(bit[2][2][1], str):
            bitobj = self.driver.clone_object(bit[2][2])
        elif bit[2][2] == 0:
            bitobj = self.driver.clone_object("/std/bit")
        else:
            bitobj = self.driver.clone_object("/std/bit")
        bitobj.set_race_ob(self.race_ob)
        bitobj.set_race_name(self.race_name if self.race_name else self.race_ob.query_name())
        bitobj.set_corpse_weight(self.query_weight())
        decay_val = 0 if not self.race_ob.query_eat(bit[BIT_NAME]) else (self.decay * 2) // 3
        bitobj.set_bit(bit[0], decay_val)
        for gone_bit in self.bits_gone:
            if gone_bit in bit[BIT_EXTRA]:
                bitobj.add_bit_gone(gone_bit)
        self.bits_gone.extend([bit[BIT_NAME]] + bit[BIT_EXTRA][3:])
        if self.environment():
            bitobj.move(self.environment())
        return bitobj

    def make_bits(self, what_bits):
        """Create multiple bit objects.

        @param what_bits: List of bit names to create
        @return: List of new bit objects
        """
        return [self.make_bit(bit) for bit in what_bits]

    def query_bits_gone(self):
        return self.bits_gone

    def add_bit_gone(self, bit):
        """Mark a bit as gone and update sub-bits.

        @param bit: Bit name to mark as gone
        @return: Bit details or None
        """
        poss_bits = [b for b in self.query_possible_bits(bit) if b not in self.bits_gone]
        if not poss_bits:
            return None
        bit_details = self.race_ob.query_bit(poss_bits[0])
        self.bits_gone.append(bit_details[BIT_NAME])
        for tempbit in bit_details[BIT_EXTRA][3:]:
            temp_bit_data = self.race_ob.query_bit(tempbit)
            if isinstance(temp_bit_data[2][2], list) and isinstance(temp_bit_data[2][2][1], int):
                self.bits_gone.extend([tempbit] * temp_bit_data[2][2][1])
        return bit_details

    def set_bits_gone(self, bits):
        """Set the list of gone bits.

        @param bits: List of bit names to mark as gone
        """
        self.bits_gone = []
        for bit in bits:
            self.add_bit_gone(bit)

    def query_bits_left(self):
        """Get the list of remaining bits.

        @return: List of bits not gone
        """
        all_bits = []
        bit_pl = self.race_ob.query_bits()
        for i in range(0, len(bit_pl), 3):
            if isinstance(bit_pl[i + 2][2], list):
                all_bits.extend([bit_pl[i]] * bit_pl[i + 2][2][1])
            else:
                all_bits.append(bit_pl[i])
        return [b for b in all_bits if b not in self.bits_gone]

    def set_bits(self):
        """Initialize the bits list based on bit data."""
        self.bits = []
        these_bits = self.bit_data
        all_bits = self.race_ob.query_bits()
        for i in range(3, len(these_bits[2])):
            for j in range(0, len(all_bits), 3):
                if these_bits[0] == all_bits[j + 2][0] and these_bits[2][i] == all_bits[j]:
                    self.bits.extend(all_bits[j:j + 3])
                    del all_bits[j:j + 2]
                    break

    def query_determinate(self, caller):
        """Get the determinate article for the bit.

        @param caller: Object requesting the determinate
        @return: Determinate string
        """
        return self.race_ob.query_determinate(caller) if self.race_ob else ""

    def query_medium_alias(self):
        """Generate a medium alias for the bit.

        @return: Medium alias string
        """
        if not self.bit_data:
            return ""
        temp = self.bit_data[0]
        temp2 = [t.capitalize() for t in temp.split()]
        return "".join(temp2) + "Of" + self.race_ob.query_name().capitalize()

    def query_collective(self):
        """Check if the bit behaves collectively for get/take commands.

        @return: 1 if collective, 0 otherwise
        """
        verb = self.driver.query_verb()
        return 1 if verb in ["get", "take"] else 0