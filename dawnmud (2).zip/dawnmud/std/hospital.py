# File: /home/archaon/mud/lib/std/hospital.py
# Purpose: Manages a hospital room with NPC generation, inventory caching, and data-driven population control.
# Related Files: /home/archaon/mud/lib/std/room.py, /home/archaon/mud/lib/include/armoury.py, /home/archaon/mud/lib/include/data.py, /home/archaon/mud/lib/include/weather.py, /home/archaon/mud/lib/include/hospital.py
# Updated Features: No significant updates identified from Discworld MUD as of March 20, 2025; core functionality preserved with assumptions for missing includes.
# Translated by: Archaon

from home.archaon.mud.lib.std.room import Room
from home.archaon.mud.lib.include.armoury import ARMOURY
from home.archaon.mud.lib.include.data import DATA_HANDLER
from home.archaon.mud.lib.include.weather import WEATHER
from home.archaon.mud.lib.include.hospital import HOSPITAL_ALIGNMENT_INHERIT, DEFAULT_MAX_CACHE, REGEN_TIME, MINIMUM_DEATH_REGEN, POPULATION_UPDATE_TIME, DEFAULT_LOG_DIRECTORY
import random
import time

class Hospital(Room, HOSPITAL_ALIGNMENT_INHERIT):
    def __init__(self, driver):
        super().__init__(driver)
        HOSPITAL_ALIGNMENT_INHERIT.__init__(self)
        self.driver.seteuid(self.driver.master().creator_file(self.driver.file_name(self)))
        self._save_file = ""
        self._hospital_type = ""
        self._regenerated_npcs = []
        self._hospital_call_id = 0
        self._log_file_info = {}
        self._hospital_log_directory = ""
        self._data_directory = ""
        self._npc_path = ""
        self._domain = ""
        self._max_cache = DEFAULT_MAX_CACHE
        self._disable_npc_generation = 0
        self._unique_npcs = {}
        self._hospital_npcs = {}
        self._cache_inventory = {}
        self._last_npc_check = 0
        self._zone_npcs = 0
        self._group_info = {}
        self._npc_info = {}
        self._zone_info = {}
        self._path_to_npc = {}
        self._file_modified_time = {}
        self.set_short("Un-configured Hospital")
        self.set_long("This is an unconfigured hospital. Find the right one.\n")
        self.add_property("determinate", "the ")
        self.set_light(60)
        self.setup()

    def ok_to_clone(self):
        """Indicate if cloning is allowed.

        @return: 1 (True)
        """
        return 1

    def query_deities(self):
        """Get the list of deities supported by the hospital.

        @return: List of deity names
        """
        return ["fish", "pishe", "sek", "hat", "gapp", "gufnork", "sandelfon"]

    def get_item(self, destination, items):
        """Request an item from the armoury for the destination.

        @param destination: Object to receive the item
        @param items: List of item names to choose from
        @return: 1 if successful, 0 if failed
        """
        if not isinstance(destination, object):
            return 0
        item = None
        while not item and items:
            i = random.randint(0, len(items) - 1)
            item = ARMOURY.request_item(items[i], 80 + random.randint(0, 20), self._domain)
            if not item:
                item = ARMOURY.request_item(items[i], 80 + random.randint(0, 20))
                if not item:
                    items = items[:i] + items[i + 1:]
                    continue
        if not items:
            self.hospital_log_file("BROKEN_ITEMS",
                                   "Unable to select any items for %s in the Ankh-Morpork hospital.\n",
                                   self.driver.previous_object().short())
            return 0
        if item:
            item.move(destination)
            return 1
        return 0

    def load_file(self):
        """Load hospital data from the save file."""
        if self.driver.file_size(self._save_file + ".o") > -1:
            self.driver.restore_object(self._save_file)
            self._group_info = self._group_info or {}
            for name in self._group_info:
                self._group_info[name].storage = None
            self._npc_info = self._npc_info or {}
            for name in self._npc_info:
                self._npc_info[name].population = []
            self._zone_info = self._zone_info or {}
            self._path_to_npc = self._path_to_npc or {}
            self._file_modified_time = self._file_modified_time or {}
            self._unique_npcs = self._unique_npcs or {}

    def save_file(self):
        """Save hospital data to the save file."""
        self.driver.save_object(self._save_file)

    def set_save_file(self, new_save):
        """Set the save file path and load data.

        @param new_save: New save file path
        """
        self._save_file = new_save
        self.load_file()

    def query_save_file(self):
        """Get the save file path.

        @return: Save file path
        """
        return self._save_file

    def set_data_directory(self, dir_):
        """Set the data directory and schedule a scan.

        @param dir_: Data directory path
        """
        self._data_directory = dir_
        self.driver.call_out(self.scan_for_new_data, 2)

    def query_data_directory(self):
        """Get the data directory.

        @return: Data directory path
        """
        return self._data_directory

    def set_npc_path(self, path):
        """Set the NPC path prefix.

        @param path: NPC path prefix
        """
        self._npc_path = path

    def set_domain(self, domain):
        """Set the domain for item requests.

        @param domain: Domain string
        """
        self._domain = domain

    def set_max_cache(self, num):
        """Set the maximum cache size.

        @param num: Maximum cache size
        """
        self._max_cache = num

    def set_disable_npc_generation(self, value):
        """Enable or disable NPC generation.

        @param value: 1 to disable, 0 to enable
        """
        self._disable_npc_generation = value

    def query_disable_npc_generation(self):
        """Check if NPC generation is disabled.

        @return: 1 if disabled, 0 if enabled
        """
        return self._disable_npc_generation

    def make_unique(self, who):
        """Mark an NPC as unique and schedule regeneration.

        @param who: NPC name or object
        @return: 1 if successful, 0 if not
        """
        name = who.query_name() if isinstance(who, object) else who
        if name not in self._unique_npcs:
            self._unique_npcs[name] = type('UniqueNPC', (), {'next_regen_time': 0})()
        if self._unique_npcs[name].next_regen_time > time.time():
            return 0
        delay = self._npc_info[name].delay if name in self._npc_info and self._npc_info[name].delay else REGEN_TIME
        self._unique_npcs[name].next_regen_time = int(time.time()) + delay
        self.save_file()
        return 1

    def reset_unique(self, who):
        """Reset the unique NPC regeneration timer.

        @param who: NPC name
        """
        if who in self._unique_npcs:
            self._unique_npcs[who].next_regen_time = 0

    def regen_after_death(self, dead_npc):
        """Regenerate NPCs after death if conditions are met.

        @param dead_npc: Dead NPC object
        """
        if not dead_npc:
            return
        new_npc = type('RegeneratedNPC', (), {
            'type': dead_npc.query_property("monster_type"),
            'load_position': self.driver.previous_object().query_property("start location")
        })()
        self._regenerated_npcs.append(new_npc)
        if not self.ok_to_clone(self._hospital_type) or len(self._regenerated_npcs) < MINIMUM_DEATH_REGEN:
            return
        new_npc = self._regenerated_npcs.pop(0)
        if not hasattr(new_npc, 'load_position') or not new_npc.type:
            return
        max_ = random.randint(0, 4)
        for _ in range(max_):
            destination = self.driver.find_object(new_npc.load_position)
            if not destination:
                return
            monsters = self.get_monster(new_npc.type)
            destination.replace_monster(self.driver.previous_object(), monsters)
            self.driver.call_out(lambda d, m: d.announce_entry(m), 8 + random.randint(0, 5), destination, monsters)

    def npc_path(self, str_):
        """Construct full NPC path.

        @param str_: NPC path suffix
        @return: Full NPC path
        """
        return f"{self._npc_path}/{str_}"

    def hospital_log_file(self, file, format_, *args):
        """Log a message to a hospital log file.

        @param file: Log file name
        @param format_: Format string
        @param args: Format arguments
        """
        if file.startswith('/'):
            file = file[file.rfind('/') + 1:]
        self.driver.log_file(f"{self._hospital_log_directory}/{file}", f"{time.ctime()}: {format_}", *args)

    def set_log_directory(self, new_dir):
        """Set the log directory.

        @param new_dir: New log directory path
        """
        if self.driver.file_size(new_dir) != -2:
            self.driver.debug_printf(f"{self.driver.file_name(self)}: Invalid log directory -- defaulting to {DEFAULT_LOG_DIRECTORY}.\n")
            new_dir = DEFAULT_LOG_DIRECTORY
        self._hospital_log_directory = new_dir

    def parse_zone(self, fname, data):
        """Parse zone data from a file.

        @param fname: File name
        @param data: Zone data mapping
        """
        if "name" not in data:
            self.driver.debug_printf(f"No name for zone {data}\n")
            self.hospital_log_file("COMPILE_ERROR", "No name for zone %O\n", data)
            return
        name = data["name"]
        data["group"] = [data["group"]] if "group" in data and not isinstance(data["group"], list) else data.get("group", [])
        data["npc"] = [data["npc"]] if "npc" in data and not isinstance(data["npc"], list) else data.get("npc", [])
        data["zone"] = [data["zone"]] if "zone" in data and not isinstance(data["zone"], list) else data.get("zone", [])
        info = type('ZoneInfo', (), {
            'npcs': {}, 'groups': {}, 'zones': {},
            'npc_chance': 0, 'group_chance': 0, 'zone_chance': 0, 'busy': data.get("busy")
        })()
        for bing in data["npc"]:
            if not isinstance(bing, dict) or "name" not in bing or not isinstance(bing["chance"], int):
                self.driver.debug_printf(f"Invalid data for zone ({name}) {bing}\n")
                self.hospital_log_file("COMPILE_ERROR", "Invalid data for zone (%s) %O\n", name, bing)
            else:
                info.npcs[bing["name"]] = bing["chance"]
                info.npc_chance += bing["chance"]
        for bing in data["group"]:
            if not isinstance(bing, dict) or "name" not in bing or not isinstance(bing["chance"], int):
                self.driver.debug_printf(f"Invalid data for zone ({name}) {bing}\n")
                self.hospital_log_file("COMPILE_ERROR", "Invalid data for zone (%s) %O\n", name, bing)
            else:
                info.groups[bing["name"]] = bing["chance"]
                info.group_chance += bing["chance"]
        for bing in data["zone"]:
            if not isinstance(bing, dict) or "name" not in bing or not isinstance(bing["chance"], int):
                self.driver.debug_printf(f"Invalid data for zone ({name}) {bing}\n")
                self.hospital_log_file("COMPILE_ERROR", "Invalid data for zone (%s) %O\n", name, bing)
            else:
                info.zones[bing["name"]] = bing["chance"]
                info.zone_chance += bing["chance"]
        unknown_keys = [k for k in data if k not in {"zone", "group", "npc", "name", "busy"}]
        if unknown_keys:
            self.driver.debug_printf(f"Unknown keys {self.query_multiple_short(unknown_keys)} in zone {name}\n")
            self.hospital_log_file("COMPILE_ERROR", "Unknown keys %s in %s\n",
                                   self.query_multiple_short(unknown_keys), name)
        self._zone_info[name] = info
        self.save_file()

    def parse_npc(self, fname, data):
        """Parse NPC data from a file.

        @param fname: File name
        @param data: NPC data mapping
        """
        if "name" not in data:
            self.driver.debug_printf(f"No name for npc {data}\n")
            self.hospital_log_file("COMPILE_ERROR", "No name for npc %O\n", data)
            return
        name = data["name"]
        if "path" not in data:
            self.hospital_log_file("COMPILE_ERROR", "Required path field not present for npc %s\n", name)
            return
        if self.driver.file_size(f"{self.npc_path(data['path'])}.c") < 0:
            self.hospital_log_file("BAD_NPC_PATH", "Bad path for npc %s (%s)\n", name, data["path"])
        data["command"] = [data["command"]] if "command" in data and not isinstance(data["command"], list) else data.get("command", [])
        data["move_zone"] = [data["move_zone"]] if "move_zone" in data and not isinstance(data["move_zone"], list) else data.get("move_zone", [])
        info = type('NPCInfo', (), {
            'move_zones': data["move_zone"], 'commands': data["command"],
            'unique': data.get("unique", 0), 'path': data["path"], 'delay': data.get("delay"),
            'max_population': data.get("population"), 'transient': data.get("transient", 0),
            'nocturnal': data.get("nocturnal", 0), 'diurnal': data.get("diurnal", 0),
            'seasonal': [data["seasonal"]] if data.get("seasonal") and not isinstance(data["seasonal"], list) else data.get("seasonal", []),
            'population': [], 'no_created': 0, 'no_reused': 0, 'no_deaths': 0
        })()
        unknown_keys = [k for k in data if k not in {"unique", "path", "move_zone", "population", "name", "delay", "transient", "nocturnal", "diurnal", "seasonal"}]
        if unknown_keys:
            self.driver.debug_printf(f"Unknown keys {self.query_multiple_short(unknown_keys)} in npc {name}\n")
            self.hospital_log_file("COMPILE_ERROR", "Unknown keys %s in npc %s\n",
                                   self.query_multiple_short(unknown_keys), name)
        if info.path in self._path_to_npc and self._path_to_npc[info.path] != name:
            self.hospital_log_file("NPC_NAME_CLASH", "NPC path %s is used by %s and %s.\n",
                                   info.path, name, self._path_to_npc[info.path])
        self._path_to_npc[info.path] = name
        if name in self._npc_info:
            info.population = self._npc_info[name].population
            info.no_created = self._npc_info[name].no_created
            info.no_reused = self._npc_info[name].no_reused
            info.no_deaths = self._npc_info[name].no_deaths
        self._npc_info[name] = info
        self.save_file()

    def parse_group(self, fname, data):
        """Parse group data from a file.

        @param fname: File name
        @param data: Group data mapping
        """
        if "name" not in data:
            self.driver.debug_printf(f"No name for group {data}\n")
            self.hospital_log_file("COMPILE_ERROR", "No name for group %O\n", data)
            return
        name = data["name"]
        data["npc"] = [data["npc"]] if "npc" in data and not isinstance(data["npc"], list) else data.get("npc", [])
        info = type('GroupInfo', (), {
            'npcs': {}, 'move_zones': data.get("move_zone", []), 'npc_commands': {},
            'max_population': data.get("population"), 'protect': data.get("protect", 0),
            'defend': data.get("defend", 0), 'transient': data.get("transient", 0),
            'storage': None, 'next_update': 0
        })()
        for bing in data["npc"]:
            if not isinstance(bing, dict) or "name" not in bing or not (isinstance(bing["quantity"], int) or hasattr(bing["quantity"], "number")):
                self.driver.debug_printf(f"Invalid data for group ({name}) {bing}\n")
                self.hospital_log_file("COMPILE_ERROR", "Invalid data for group (%s) %O\n", name, bing)
            else:
                info.npcs[bing["name"]] = bing["quantity"]
                if "command" in bing:
                    info.npc_commands[bing["name"]] = bing["command"] if isinstance(bing["command"], list) else [bing["command"]]
        unknown_keys = [k for k in data if k not in {"npc", "name", "population", "move_zone", "protect", "defend", "transient"}]
        if unknown_keys:
            self.driver.debug_printf(f"Unknown keys {self.query_multiple_short(unknown_keys)} in group {name}\n")
            self.hospital_log_file("COMPILE_ERROR", "Unknown keys %s in group %s\n",
                                   self.query_multiple_short(unknown_keys), name)
        if name in self._group_info:
            info.storage = self._group_info[name].storage
        self._group_info[name] = info

    def finish_compiling(self, fname, data):
        """Finish compiling data from a file.

        @param fname: File name
        @param data: Data mapping
        """
        for name, bits in data.items():
            if name == "zone":
                for thing in bits:
                    self.parse_zone(fname, thing)
            elif name == "npc":
                for thing in bits:
                    self.parse_npc(fname, thing)
            elif name == "group":
                for thing in bits:
                    self.parse_group(fname, thing)
            else:
                self.driver.debug_printf(f"Unknown data area {name} in {fname}\n")
                self.hospital_log_file("COMPILE_ERROR", "Unknown data area %s in %s\n", name, fname)
        self._file_modified_time[fname] = self.driver.stat(fname)[1]
        self.save_file()

    def scan_for_new_data(self, force=0):
        """Scan for new data files.

        @param force: Force recompilation if 1
        @return: 1 if successful
        """
        self.driver.debug_printf("Scan for new data.")
        current_file_time = self.driver.stat(__file__)[1]
        if current_file_time != self._file_modified_time.get(__file__):
            self._file_modified_time = {}
        if force:
            self._npc_info = {}
            self._zone_info = {}
            self._group_info = {}
        files = [self._data_directory]
        while files:
            fname = files.pop(0)
            if self.driver.file_size(fname) == -2:
                bits = self.driver.get_dir(f"{fname}/")
                if bits:
                    bits = [b for b in bits if b not in ["RCS", ".", ".."] and b[0] != '.']
                    files.extend(f"{fname}/{b}" for b in bits)
            elif self._file_modified_time.get(fname) != self.driver.stat(fname)[1] or force:
                self.driver.debug_printf(f"Compiling {fname}")
                DATA_HANDLER.compile_file(fname, self.finish_compiling)
        self._file_modified_time[__file__] = current_file_time
        return 1

    def roll_dice(self, die):
        """Roll dice for quantity calculations.

        @param die: Integer or dice object (with number, die, modifier)
        @return: Rolled value
        """
        if isinstance(die, int):
            return die
        if hasattr(die, "number"):
            result = sum(random.randint(1, die.die) for _ in range(die.number)) + die.modifier
            return result
        return 0

    def query_npc_max_population(self, npc):
        """Get the maximum population for an NPC.

        @param npc: NPC name
        @return: Max population or -1 if not found
        """
        return self._npc_info[npc].max_population if npc in self._npc_info else -1

    def query_npc_current_population(self, npc, clean=0):
        """Get the current population of an NPC.

        @param npc: NPC name
        @param clean: Force cleanup if 1
        @return: Current population or -1 if not found
        """
        if npc not in self._npc_info:
            return -1
        data = self._npc_info[npc]
        if not data.population or data.next_update < time.time() or clean:
            data.population = self.driver.children(self.npc_path(data.path))
            data.next_update = int(time.time()) + POPULATION_UPDATE_TIME
        if clean or data.next_update < time.time():
            data.population = [p for p in data.population if isinstance(p, object)]
            data.next_update = int(time.time()) + POPULATION_UPDATE_TIME
        return len(data.population)

    def is_npc_under_max_population(self, name):
        """Check if an NPC is under its max population.

        @param name: NPC name
        @return: 1 if under max, 0 if not
        """
        info = self._npc_info.get(name)
        if not info:
            return 0
        if info.transient:
            return 1
        if info.max_population:
            return self.query_npc_current_population(name, 1) < info.max_population
        return 1

    def is_group_under_max_population(self, name):
        """Check if a group is under its max population.

        @param name: Group name
        @return: 1 if under max, 0 if not
        """
        group = self._group_info.get(name)
        if not group:
            return 0
        if not group.max_population or group.transient:
            return 1
        if not group.storage:
            group.storage = []
        elif group.next_update < time.time():
            group.storage = [s for s in group.storage if any(isinstance(o, object) for o in s)]
            group.next_update = int(time.time()) + POPULATION_UPDATE_TIME
        return len(group.storage) < group.max_population

    def load_npc_object(self, npc_name):
        """Load an NPC object.

        @param npc_name: NPC name
        @return: NPC object or None
        """
        if npc_name not in self._npc_info:
            self.driver.debug_printf(f"Unable to find npc {npc_name}")
            return None
        info = self._npc_info[npc_name]
        if info.diurnal and not WEATHER.query_day(self.driver.previous_object()):
            return None
        if info.nocturnal and WEATHER.query_day(self.driver.previous_object()):
            return None
        if info.seasonal and WEATHER.query_season() not in info.seasonal:
            return None
        if not isinstance(info.path, str):
            self.driver.debug_printf(f"Broken npc data {info.path}")
            return None
        npc = None
        if info.unique:
            npc = self.driver.find_object(self.npc_path(info.path))
            if (not npc or not npc.environment()) and self.make_unique(npc_name):
                try:
                    npc = self.driver.load_object(self.npc_path(info.path))
                except Exception:
                    self.hospital_log_file("BAD_NPC_PATH", "Error loading %s (%s)\n", npc_name, info.path)
                    return None
                if not npc:
                    self.hospital_log_file("BAD_NPC_PATH", "Failed to load %s (%s)\n", npc_name, info.path)
                    return None
                if npc.environment():
                    self.driver.debug_printf(f"NPC unique and already exists {npc_name}")
                    return None
        elif info.transient:
            self._cache_inventory = self._cache_inventory or {}
            if npc_name in self._cache_inventory:
                self._cache_inventory[npc_name] = [n for n in self._cache_inventory[npc_name] if n]
            if self._cache_inventory.get(npc_name):
                npc = self._cache_inventory[npc_name].pop(0)
                info.no_reused += 1
            else:
                npc = self.driver.clone_object(self.npc_path(info.path))
                if npc:
                    npc.add_property("transient", 1)
                    npc.add_property("npc_id", npc_name)
                    npc.add_property("hospital", self.driver.base_name(self))
                    info.no_created += 1
                else:
                    self.driver.debug_printf(f"Failed to clone {self.npc_path(info.path)}")
        elif self.is_npc_under_max_population(npc_name):
            npc = self.driver.clone_object(self.npc_path(info.path))
            info.no_created += 1
            if not npc:
                self.driver.debug_printf(f"Npc path does not exist {npc} ({self.npc_path(info.path)})")
        if npc and not info.transient:
            info.population = info.population or []
            info.population.append(npc)
            npc.add_property("npc_id", npc_name)
            for zone in info.move_zones:
                npc.add_move_zone(zone)
            for cmd in info.commands:
                npc.init_command(cmd, 2)
        return npc

    def load_group_npcs(self, group_name):
        """Load a group of NPCs.

        @param group_name: Group name
        @return: List of NPC objects or None
        """
        if group_name not in self._group_info or not self.is_group_under_max_population(group_name):
            return None
        group = self._group_info[group_name]
        npcs = []
        for npc_name, quantity in group.npcs.items():
            qty = self.roll_dice(quantity)
            for _ in range(qty):
                ob = self.load_npc_object(npc_name)
                if not ob:
                    for n in npcs:
                        n.move("/home/archaon/mud/lib/room/rubbish")
                    return []
                npcs.append(ob)
                if npc_name in group.npc_commands:
                    for cmd in group.npc_commands[npc_name]:
                        ob.init_command(cmd, 2)
        group.storage = group.storage or []
        group.storage.append(npcs)
        for ob in npcs:
            ob.add_property("group_id", group_name)
        for ob in npcs:
            for ob_bing in npcs:
                if ob != ob_bing:
                    ob.add_follower(ob_bing)
                    if group.defend:
                        ob.add_defender(ob_bing)
                    if group.protect:
                        ob.add_protector(ob_bing)
        return npcs

    def query_npc_info(self, npc):
        """Get NPC info.

        @param npc: NPC name
        @return: NPC info object or None
        """
        return self._npc_info.get(npc)

    def query_debug_npc_info(self):
        """Get debug NPC info.

        @return: NPC info mapping
        """
        return self._npc_info

    def query_group_info(self, group):
        """Get group info.

        @param group: Group name
        @return: Group info object or None
        """
        return self._group_info.get(group)

    def npc_died(self, ob):
        """Handle NPC death.

        @param ob: Dead NPC object
        """
        npc_id = ob.query_property("npc_id")
        if npc_id and npc_id in self._npc_info:
            info = self._npc_info[npc_id]
            info.population = [p for p in info.population if p != ob]
            info.no_deaths += 1
        group_id = ob.query_property("group_id")
        if group_id in self._group_info:
            stuff = self._group_info[group_id].storage
            if stuff:
                for i in range(len(stuff)):
                    stuff[i] = [s for s in stuff[i] if s != ob]
                self._group_info[group_id].storage = [s for s in stuff if s]

    def query_all_npc_info(self):
        """Get all NPC info.

        @return: NPC info mapping
        """
        return self._npc_info

    def query_all_group_info(self):
        """Get all group info.

        @return: Group info mapping
        """
        return self._group_info

    def query_all_zone_info(self):
        """Get all zone info.

        @return: Zone info mapping
        """
        return self._zone_info

    def count_chances_in_zone(self, zone):
        """Count total chances in a zone.

        @param zone: Zone name
        @return: Total chance value
        """
        info = self._zone_info.get(zone)
        if not info:
            return 0
        return info.npc_chance + info.group_chance + info.zone_chance

    def create_npcs_in_zone(self, zone, pos):
        """Create NPCs in a zone based on chance.

        @param zone: Zone name
        @param pos: Chance position
        @return: List of NPC objects
        """
        info = self._zone_info.get(zone)
        if not info:
            return []
        if pos < info.npc_chance:
            for npc, chance in info.npcs.items():
                if pos < chance:
                    ob = self.load_npc_object(npc)
                    if ob:
                        self.driver.debug_printf(f"{'Reused' if ob.environment() == self else 'Created'} {npc} in {zone}")
                        return [ob]
                pos -= chance
        pos -= info.npc_chance
        if pos < info.group_chance:
            for npc, chance in info.groups.items():
                if pos < chance:
                    obs = self.load_group_npcs(npc)
                    if obs:
                        return obs
                pos -= chance
        pos -= info.group_chance
        for extra, chance in info.zones.items():
            if pos < chance:
                return self.load_random_npc(extra, -1, -1)
        return []

    def load_random_npc(self, zone, wealth, busy):
        """Load a random NPC for a zone.

        @param zone: Zone name
        @param wealth: Wealth level (-1 for default)
        @param busy: Busy level (-1 for default)
        @return: List of NPC objects
        """
        if self._disable_npc_generation:
            return []
        zone_key = f"{zone}-w{wealth}-b{busy}" if f"{zone}-w{wealth}-b{busy}" in self._zone_info else (
            f"{zone}-w{wealth}" if f"{zone}-w{wealth}" in self._zone_info else (
                f"{zone}-b{busy}" if f"{zone}-b{busy}" in self._zone_info else zone
            )
        )
        if zone_key not in self._zone_info:
            return []
        info = self._zone_info[zone_key]
        if info.busy and info.busy < random.randint(0, random.randint(0, 99)):
            return []
        chance = self.count_chances_in_zone(zone_key)
        if not chance:
            return []
        pos = random.randint(0, chance - 1)
        return self.create_npcs_in_zone(zone_key, pos)

    def do_report(self):
        """Generate a report of NPC and group status.

        @return: 1 if successful
        """
        txt = "%^WHITE%^NPCs%^RESET%^\n"
        total = 0
        max_ = 0
        for name, npc in self._npc_info.items():
            self.driver.reset_eval_cost()
            pop = self.query_npc_current_population(name, 0) if isinstance(npc.path, str) and self.driver.file_size(f"{self.npc_path(npc.path)}.c") > 0 else 0
            if npc.transient:
                txt += f"$I$5=Name: {name}. ({npc.path if isinstance(npc.path, str) else 'Broken!'}) (Transient) Reused {npc.no_reused} Created {npc.no_created} Died {npc.no_deaths}\n"
            else:
                txt += f"$I$5=Name: {name}. ({npc.path if isinstance(npc.path, str) else 'Broken!'}) Population: ({pop}/{npc.max_population}) Created {npc.no_created} Died {npc.no_deaths}\n"
                total += pop
                max_ += npc.max_population
        txt += "$I$0=%^WHITE%^Groups%^RESET%^\n"
        for name, group in self._group_info.items():
            if group.transient:
                txt += f"$I$5=Name: {name}. ({self.query_multiple_short(list(group.npcs.keys()))}) (Transient)\n"
            else:
                txt += f"$I$5=Name: {name}. ({self.query_multiple_short(list(group.npcs.keys()))}) Population: ({len(group.storage)}/{group.max_population})\n"
        txt += "$I$0=%^WHITE%^Cache%^RESET%^\n"
        for name in self._cache_inventory:
            self._cache_inventory[name] = [n for n in self._cache_inventory[name] if n]
        for name, group in self._cache_inventory.items():
            txt += f"$I$5=Name: {name} {len(group)}\n"
        txt += f"\nTotal NPCs in hospital: {total}/{max_}.\n"
        self.driver.write(f"$P$Report$P${txt}")
        return 1

    def init(self):
        """Initialize commands and handle NPC caching."""
        ob = self.driver.this_player()
        self.add_command("report", "", self.do_report)
        self.add_command("scan", "", self.scan_for_new_data)
        if (ob.query_property("npc_id") and ob.query_property("hospital") and
                ob.query_property("hospital") == self.driver.base_name(self)):
            self._cache_inventory.setdefault(ob.query_property("npc_id"), []).append(ob)
            if len(self._cache_inventory[ob.query_property("npc_id")]) > self._max_cache:
                ob.move("/home/archaon/mud/lib/room/rubbish")
        elif self.driver.base_name(ob) == "/home/archaon/mud/lib/obj/corpse":
            ob.move("/home/archaon/mud/lib/room/rubbish")

    def no_attack(self):
        """Prevent attacks in the hospital.

        @return: 1 (True)
        """
        return 1

    def query_dynamic_auto_load(self):
        """Prepare dynamic auto-load data.

        @return: Mapping of dynamic data
        """
        tmp = {group_name: data.storage for group_name, data in self._group_info.items()}
        tmp2 = {npc: data.population for npc, data in self._npc_info.items()}
        return {self.driver.file_name(self): tmp, "npcs": tmp2}

    def init_dynamic_arg(self, tmp):
        """Initialize with dynamic auto-load data.

        @param tmp: Mapping of dynamic data
        """
        if self.driver.file_name(self) in tmp:
            for group_name, npcs in tmp[self.driver.file_name(self)].items():
                if group_name in self._group_info:
                    self._group_info[group_name].storage = npcs
            for npc_name, npcs in tmp["npcs"].items():
                if npc_name in self._npc_info:
                    self._npc_info[npc_name].population = npcs

    def query_all_npcs(self):
        """Get all NPCs in groups.

        @return: List of NPC lists
        """
        return [g.storage for g in self._group_info.values()]

    def query_inventory_cache(self):
        """Get the inventory cache.

        @return: Cache mapping
        """
        return dict(self._cache_inventory)

    def query_registered_npcs(self):
        """Get registered NPC names.

        @return: List of NPC names
        """
        return list(self._npc_info.keys())