# File: /home/archaon/mud/lib/std/bit_set.py
# Purpose: Extends Bit to handle sets of corpse bits with collective descriptions.
# Related Files: /home/archaon/mud/lib/std/bit.py, /home/archaon/mud/lib/include/corpse.py, /home/archaon/mud/lib/include/bit.py
# Updated Features: No significant updates identified from Discworld MUD as of March 20, 2025; core functionality preserved.
# Translated by: Archaon

from home.archaon.mud.lib.std.bit import Bit
from home.archaon.mud.lib.include.corpse import STD_CORPSE_WEIGHT

class BitSet(Bit):
    def __init__(self, driver):
        super().__init__(driver)
        self.set_short("anonymous set of bits")
        self.set_long("This is an unknown set of bits of some creature.\n")
        self.corpse_weight = STD_CORPSE_WEIGHT
        self.set_weight(5)
        self.set_name("bit")
        self.add_property("corpse bit", 1)
        self.add_property("cureable", 1)

    def setup_long(self):
        """Update the long description for a set of bits based on decay and curing."""
        if not self.bit_data:
            return
        base_desc = ""
        if self.no_decay():
            base_desc = f"This is a set of {self.bit_data[BIT_NAME]} from " + (
                f"{self.add_a(self.race_name)}.\n" if self.race_name else "an unknown creature.\n")
        elif self.decay > 80:
            base_desc = f"This is a fresh set of {self.bit_data[BIT_NAME]} severed from the corpse of " + (
                f"{self.add_a(self.race_name)}.\n" if self.race_name else "an unknown creature.\n")
        elif self.decay > 50:
            base_desc = f"This is a set of {self.bit_data[BIT_NAME]} severed from the corpse of " + (
                f"{self.add_a(self.race_name)}.\n" if self.race_name else "an unknown creature.\n")
        elif self.decay > 30:
            base_desc = f"This is the partially decayed remains of a set of {self.bit_data[BIT_NAME]} severed from the corpse of " + (
                f"{self.add_a(self.race_name)}.\n" if self.race_name else "an unknown creature.\n")
        else:
            base_desc = f"This is the almost unrecognizable remains of a set of {self.bit_data[BIT_NAME]} severed from the corpse of " + (
                f"{self.add_a(self.race_name)}.\n" if self.race_name else "an unknown creature.\n")
        self.set_short(f"set of {self.race_name + ' ' if self.race_name else ''}{self.bit_data[BIT_NAME]}")
        self.set_main_plural(f"sets of {self.race_name + ' ' if self.race_name else ''}{self.bit_data[BIT_NAME]}")
        self.set_long(base_desc + ("It seems to have been pickled.\n" if self.cured else ""))