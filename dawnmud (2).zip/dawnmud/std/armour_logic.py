# File: /home/archaon/mud/lib/std/armour_logic.py
# Purpose: Manages armour class logic, including adding, removing, and querying armour class values for different types and zones.
# Related Files: /home/archaon/mud/lib/std/weapon_old.py (assumed translation of weapon_old.h)
# Updated Features: None identified from live Discworld MUD as of March 20, 2025, for this specific file; base functionality preserved.
# Translated by: Archaon

from home.archaon.mud.lib.std.weapon_old import A_ARRAY_SIZE, A_AC, A_TYPE, F_FIXED, F_RAND, F_NUM, F_DIE
import random

class ArmourLogic:
    def __init__(self, driver):
        self.driver = driver
        self.ac = {}
        self.armour_types = []

    def add_ac(self, name, type_, a_c):
        """Add an armour class entry for a given name and type.

        @param name: The name of the armour class entry
        @param type_: The type of armour (e.g., "slash", "pierce")
        @param a_c: The armour class value (integer or array)
        @return: 1 if successful, 0 if failed
        """
        if not isinstance(type_, str):
            return 0
        if not self.ac:
            self.ac = {}
        if name in self.ac:
            return 0
        self.ac[name] = [a_c, type_]
        i = self.armour_types.index(type_) if type_ in self.armour_types else -1
        if i == -1:
            self.armour_types.extend([type_, [name]])
        else:
            self.armour_types[i + 1].append(name)
        return 1

    def remove_ac(self, name):
        """Remove an armour class entry by name.

        @param name: The name of the armour class entry to remove
        @return: 1 if successful, 0 if not found
        """
        if name not in self.ac:
            return 0
        type_ = self.ac[name][1]
        j = self.armour_types.index(type_)
        k = self.armour_types[j + 1].index(name)
        del self.armour_types[j + 1][k]
        if not self.armour_types[j + 1]:
            del self.armour_types[j:j + 2]
        del self.ac[name]
        return 1

    def calc_value(self, arr):
        """Calculate the effective armour class value from an integer or array.

        @param arr: Integer or array representing armour class
        @return: Calculated value
        """
        if isinstance(arr, int):
            return random.randint(0, arr - 1) if not random.randint(0, 9) else arr
        if not isinstance(arr, list):
            return 0
        if len(arr) == 1:
            return arr[F_FIXED]
        if len(arr) == 2:
            return arr[F_FIXED] + random.randint(0, arr[F_RAND])
        val = 0
        for _ in range(arr[F_NUM]):
            val += random.randint(0, arr[F_DIE] - 1)
        return val + arr[F_FIXED]

    def query_ac(self, type_, dam=None, zone=None):
        """Query the total armour class for a given type.

        @param type_: The armour type to query
        @param dam: Damage amount (unused in base logic)
        @param zone: Specific zone (unused in base logic)
        @return: Total adjusted armour class value
        """
        if not self.armour_types:
            return 0
        val = 0
        i = self.armour_types.index(type_) if type_ in self.armour_types else -1
        if i != -1:
            for j in range(len(self.armour_types[i + 1])):
                name = self.armour_types[i + 1][j]
                if name in self.ac and len(self.ac[name]) == A_ARRAY_SIZE:
                    val += self.calc_value(self.ac[name][A_AC])
        val -= val // 4  # Adjust value as per original logic
        return val

    def query_armour_class(self):
        """Return the full armour class mapping.

        @return: Dictionary of armour class entries
        """
        return self.ac

    def calc_string(self, b):
        """Convert an armour class value to a string representation.

        @param b: Integer or array representing armour class
        @return: String representation of the value
        """
        if isinstance(b, int):
            return f"rand({b})"
        if not isinstance(b, list):
            return "Dead"
        if len(b) == 1:
            return str(b[0])
        if len(b) == 2:
            return f"{b[0]}+rand({b[1]})"
        if len(b) == 3:
            return f"{b[0]}+{b[1]}d{b[2]}"
        return "Oh hell"

    def stats(self):
        """Return statistics about the armour class entries.

        @return: List of tuples with armour class details
        """
        ret = []
        stuff = list(self.ac.keys())
        for i, name in enumerate(stuff):
            ret.extend([
                (f"ARM{i} name", name),
                ("     type", self.ac[name][A_TYPE]),
                ("    class", self.calc_string(self.ac[name][A_AC]))
            ])
        return ret

    def set_ac(self, bing):
        """Set multiple armour class entries from a flat list.

        @param bing: List of alternating names and [value, type] pairs
        """
        for i in range(0, len(bing), A_ARRAY_SIZE):
            self.add_ac(bing[i], bing[i + 1][A_TYPE], bing[i + 1][A_AC])