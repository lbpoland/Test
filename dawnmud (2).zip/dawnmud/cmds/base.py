# File: /home/archaon/mud/lib/cmds/base.py
# Purpose: Base class for command handling in Aethoria, providing lifecycle and cleanup methods.
# Linked Files: None directly, serves as a base for other command files (e.g., /home/archaon/mud/lib/cmds/player/accept.py).
# Updated Features: None from live MUD as this is a foundational file with no specific updates noted.
# Translated by: Archaon

class Base:
    def __init__(self, driver):
        self.driver = driver  # Reference to the driver at /home/archaon/mud/driver.py

    def create(self):
        """Initialize the command object with appropriate user ID."""
        self.driver.seteuid(self.driver.getuid(self))  # Set effective UID to object's UID

    def dest_me(self):
        """Destroy the command object if it exists."""
        if self.driver.this_object():
            self.driver.destruct(self)  # Destroy the current object

    def clean_up(self):
        """Perform cleanup by destroying the object."""
        self.dest_me()
        return 1  # Indicate successful cleanup

    def reset(self):
        """Reset the object by destroying it."""
        self.dest_me()