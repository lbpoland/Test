# File: /home/archaon/mud/lib/cmds/position_base.py
# Purpose: Base class for position-related commands (e.g., sit, stand), managing player positioning.
# Linked Files: Inherits from /home/archaon/mud/lib/cmds/base.py; uses /home/archaon/mud/lib/include/position.py.
# Updated Features: None from live MUD as of March 20, 2025; core positioning logic preserved.
# Translated by: Archaon

from home.archaon.mud.lib.cmds.base import Base
from home.archaon.mud.lib.include.position import AT_TYPE, BESIDE_TYPE, ON_TYPE, CAN_POSITION_PROPERTY, MULTIPLE_POSITION_PROPERTY

class PositionBase(Base):
    def __init__(self, driver):
        super().__init__(driver)
        self.position = ""
        self.up_down = ""
        self.position_type = ""

    def query_position_command(self):
        """Indicate this is a position command."""
        return 1

    def query_up_down(self):
        """Get the up/down descriptor."""
        return self.up_down

    def query_position(self):
        """Get the position verb."""
        return self.position

    def query_position_type(self):
        """Get the position type."""
        return self.position_type

    def setup_position(self, pos, up, type_):
        """Set up position parameters."""
        self.position = pos
        self.up_down = up
        self.position_type = type_

    def position(self, person, silent):
        """Handle positioning without an object."""
        if person.query_position() == self.position_type:
            if person == self.driver.this_player():
                self.driver.add_failed_mess(f"You are already {self.position_type}.\n")
            return 0
        env = self.driver.environment(person)
        if not env or not env.is_allowed_position(self.position_type):
            if person == self.driver.this_player():
                self.driver.add_failed_mess(f"You cannot {self.position} {self.up_down} here.\n")
            return 0
        if not silent:
            pos_type = person.query_position_type()
            if self.up_down:
                if person.query_position_on():
                    msg = f"You {self.position} {self.up_down} {pos_type} {person.query_position_on_short()}.\n"
                    self.driver.tell_object(person, msg)
                    self.driver.tell_room(env, 
                                          f"{person.one_short()} {self.position}s {self.up_down} {pos_type} {person.query_position_on_short()}.\n", 
                                          [person])
                else:
                    self.driver.tell_object(person, f"You {self.position} {self.up_down}.\n")
                    self.driver.tell_room(env, 
                                          f"{person.one_short()} {self.position}s {self.up_down}.\n", 
                                          [person])
            else:
                if person.query_position_on():
                    self.driver.tell_object(person, f"You {self.position} {pos_type} {person.query_position_on_short()}.\n")
                    self.driver.tell_room(env, 
                                          f"{person.one_short()} {self.position}s {pos_type} {person.query_position_on_short()}.\n", 
                                          [person])
                else:
                    self.driver.tell_object(person, f"You {self.position}.\n")
                    self.driver.tell_room(env, f"{person.one_short()} {self.position}s.\n", [person])
        person.set_position(self.position_type)
        return 1

    def position_floor(self, person, silent):
        """Handle positioning on the floor."""
        env = self.driver.environment(person)
        if not env or not env.is_allowed_position(self.position_type):
            if person == self.driver.this_player():
                self.driver.add_failed_mess(f"You cannot {self.position} {self.up_down} here.\n")
            return 0
        if person.query_position_on():
            if not silent:
                if self.up_down:
                    self.driver.tell_object(person, f"You get off {person.query_position_on_short()} and {self.position} {self.up_down}.\n")
                    self.driver.tell_room(env, 
                                          f"{person.one_short()} gets off {person.query_position_on_short()} and {self.position}s {self.up_down}.\n", 
                                          [person])
                else:
                    self.driver.tell_object(person, f"You get off {person.query_position_on_short()} and {self.position}.\n")
                    self.driver.tell_room(env, 
                                          f"{person.one_short()} gets off {person.query_position_on_short()} and {self.position}s.\n", 
                                          [person])
            person.set_position(self.position_type)
            person.set_position_on(None)
            person.set_position_type(None)
            person.set_position_multiple(0)
            return 1
        return self.position(person, 0)

    def query_position_strings(self, person):
        """Determine position transition strings."""
        pos_type = person.query_position_type()
        if pos_type in [AT_TYPE, BESIDE_TYPE]:
            return ["move away from", "moves away from"]
        return ["get off", "gets off"]  # Default for ON_TYPE or others

    def position_object(self, obs, pos_type, person):
        """Handle positioning on or near an object."""
        env = self.driver.environment(person)
        if not env or not env.is_allowed_position(self.position_type):
            if person == self.driver.this_player():
                self.driver.add_failed_mess(f"You cannot {self.position} {self.up_down} here.\n")
            return 0
        pos_strings = self.query_position_strings(person)
        for ob in obs:
            if ob.query_property(CAN_POSITION_PROPERTY):
                mult = ob.query_property(MULTIPLE_POSITION_PROPERTY)
                if person.query_position_on():
                    if person.query_position_on() == ob and person.query_position_type() == pos_type:
                        if person.query_position() != self.position_type:
                            return self.position(person, 0)
                        if person == self.driver.this_player():
                            self.driver.add_failed_mess(f"You are already {self.position_type} {pos_type} $I.\n", [ob])
                        return 0
                    self.driver.tell_object(person, f"You {pos_strings[0]} {person.query_position_on_short()} and {self.position} {pos_type} {ob.a_short()}.\n")
                    self.driver.tell_room(env, 
                                          f"{person.one_short()} {pos_strings[1]} {person.query_position_on_short()} and {self.position}s {pos_type} {ob.a_short()}.\n", 
                                          [person])
                    person.set_position(self.position_type)
                    person.set_position_on(ob)
                    person.set_position_type(pos_type)
                    person.set_position_multiple(mult)
                    return 1
                self.driver.tell_object(person, f"You {self.position} {pos_type} {ob.a_short()}.\n")
                self.driver.tell_room(env, 
                                      f"{person.one_short()} {self.position}s {pos_type} {ob.a_short()}.\n", 
                                      [person])
                person.set_position(self.position_type)
                person.set_position_on(ob)
                person.set_position_type(pos_type)
                person.set_position_multiple(mult)
                return 1
            else:
                rabbit = ob.query_position_string(self.position_type)
                if rabbit:
                    mult = ob.query_position_multiple(self.position_type)
                    if person.query_position_on():
                        if person.query_position_on() == rabbit and person.query_position_type() == pos_type:
                            if person.query_position() != self.position_type:
                                return self.position(person, 0)
                            self.driver.add_failed_mess(f"You are already {self.position_type} {pos_type} $I.\n", [ob])
                            return 0
                        self.driver.tell_object(person, f"You {pos_strings[0]} {person.query_position_on_short()} and {self.position} {pos_type} {rabbit}.\n")
                        self.driver.tell_room(env, 
                                              f"{person.one_short()} {pos_strings[1]} {person.query_position_on_short()} and {self.position}s {pos_type} {rabbit}.\n", 
                                              [person])
                        person.set_position(self.position_type)
                        person.set_position_on(rabbit)
                        person.set_position_type(pos_type)
                        person.set_position_multiple(mult)
                        return 1
                    self.driver.tell_object(person, f"You {self.position} {pos_type} {rabbit}.\n")
                    self.driver.tell_room(env, 
                                          f"{person.one_short()} {self.position}s {pos_type} {rabbit}.\n", 
                                          [person])
                    person.set_position(self.position_type)
                    person.set_position_on(rabbit)
                    person.set_position_type(pos_type)
                    person.set_position_multiple(mult)
                    return 1
        return 0

    def query_patterns(self):
        """Define command patterns for parsing."""
        return [
            ("", lambda: self.position(self.driver.this_player(), 0)),
            ("on [the] floor", lambda: self.position_floor(self.driver.this_player(), 0)),
            ("{on|at|in|beside} <indirect:object>", 
             lambda: self.position_object(self.driver.args[1], self.driver.args[0][0], self.driver.this_player()))
        ]