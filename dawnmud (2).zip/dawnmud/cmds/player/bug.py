# File: /home/archaon/mud/lib/cmds/player/bug.py
# Purpose: Player command to report bugs, inheriting from report_base.
# Linked Files: Inherits from /home/archaon/mud/lib/cmds/report_base.py.
# Updated Features: None from live MUD as of March 20, 2025; core functionality preserved from 2003 base.
# Translated by: Archaon

from home.archaon.mud.lib.cmds.report_base import ReportBase

class Bug(ReportBase):
    def __init__(self, driver):
        super().__init__(driver)

    def create(self):
        """Initialize the bug reporting command with specific settings."""
        super().create()  # Call parent create method
        self.set_error_type("BUG")  # Set report type to BUG
        self.set_use_last_error(1)  # Enable use of last error trace