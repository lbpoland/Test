# File: /home/archaon/mud/lib/cmds/player/bury.py
# Purpose: Allows players to bury items, with effects like XP distribution for corpses.
# Linked Files: Inherits from /home/archaon/mud/lib/cmds/base.py; uses /home/archaon/mud/lib/include/move_failures.py, /home/archaon/mud/lib/include/cmds/bury.py, /home/archaon/mud/lib/include/playtesters.py.
# Updated Features: Verified against live MUD sources as of March 20, 2025; no significant updates noted in wiki, announcements, or blogs beyond 2003 functionality. Playtester check (PT) retained but assumed optional in Aethoria.
# Translated by: Archaon

from home.archaon.mud.lib.cmds.base import Base
from home.archaon.mud.lib.include.move_failures import MOVE_OK, MOVE_TOO_HEAVY
from home.archaon.mud.lib.include.cmds.bury import BURY_EFFECT
from home.archaon.mud.lib.include.playtesters import PLAYTESTER_HAND

GP_INCREMENT = 10
MAX_BURY_NUMBER = 20

class Bury(Base):
    def __init__(self, driver):
        super().__init__(driver)
        self.TP = self.driver.this_player()  # Shortcut for this_player()

    def cmd(self, obs):
        """Bury specified objects with gameplay effects.
        
        @param obs list of objects to bury
        @return 1 on success, 0 on failure
        """
        # Optional playtester check (commented out but retained for reference)
        # if not (PLAYTESTER_HAND.query_playtester(self.TP.query_name()) or self.TP.query_creator()):
        #     self.driver.add_failed_mess("This command is in play testing at the moment.\n")
        #     return 0
        
        sobs, fobs, too_many, gp = [], [], [], 0
        if self.TP.query_property("dead"):
            self.driver.add_failed_mess("You are a disembodied spirit, how do you expect to bury anything at all?\n")
            return 0
        if any(a for a in self.TP.query_attacker_list() if self.driver.environment(a) == self.driver.environment(self.TP)):
            self.driver.add_failed_mess("You cannot bury items while in combat.\n")
            return 0
        env = self.driver.environment(self.TP)
        if env.query_property("no burial"):
            self.driver.add_failed_mess("You cannot bury things here.\n")
            return 0
        
        for ob in obs:
            if len(sobs) >= MAX_BURY_NUMBER:
                too_many.append(ob)
            elif (ob.query_owner() == self.TP.query_cap_name() or 
                  ob.get() in (MOVE_OK, MOVE_TOO_HEAVY)) and \
                 ob.query_property("no burial") != 1 and \
                 not ob.ok_to_bury(self.TP):
                if ob.query_property("player") != 1 or ob.query_owner() == self.TP.query_name():
                    effs = ob.effects_matching("mudlib.owned.weapon")
                    if effs:
                        person = ob.arg_of(effs[0])
                        self.driver.log_file("BURIAL", f"{self.driver.ctime(self.driver.time())}: {person}'s {ob.query_short()} buried by {self.TP.query_name()}\n")
                    env.add_effect(BURY_EFFECT, ob)
                    sobs.append(ob)
                    if ob.query_property("corpse bit") or ob.query_property("money"):
                        gp -= 1
                    elif self.driver.base_name(ob) == "/home/archaon/mud/lib/obj/corpse" and not ob.query_property("already buried"):
                        gp += GP_INCREMENT
                        ob.add_property("already buried", 1)
                        xp = ob.query_property("XP")
                        if xp and len(xp) == 2:
                            for tmp in xp[0]:
                                if tmp:
                                    tmp.adjust_xp(xp[1], 1)
                        ob.remove_property("XP")
                else:
                    fobs.append(ob)
            else:
                fobs.append(ob)
        
        if not sobs:
            if fobs:
                if self.TP not in fobs:
                    self.driver.add_failed_mess(f"You cannot bury {self.driver.query_multiple_short(fobs)}.\n")
                else:
                    self.driver.add_failed_mess(f"You cannot bury {self.driver.query_multiple_short([f for f in fobs if f != self.TP] + ['yourself'])}.\n")
            else:
                self.driver.add_failed_mess("You cannot find anything here to bury!\n")
            return 0
        
        if too_many:
            self.driver.write(f"You can only bury up to {MAX_BURY_NUMBER} items at a time, not burying {self.driver.query_multiple_short(too_many)}.\n")
        
        messages = env.query_burial_message()
        if messages:
            self.driver.write(messages[0].replace("$objs$", self.driver.query_multiple_short(sobs)))
            self.driver.say(messages[1].replace("$N", self.TP.the_short()).replace("$objs$", self.driver.query_multiple_short(sobs)))
        elif env.query_property("location") != "outside":
            self.driver.write(f"You tidy up the place, clearing away {self.driver.query_multiple_short(sobs)}.\n")
            self.driver.say(f"{self.TP.one_short()} tidies up the place, clearing away {self.driver.query_multiple_short(sobs)}.\n")
        else:
            self.driver.write(f"You bury {self.driver.query_multiple_short(sobs)} deep within the earth.\n")
            self.driver.say(f"{self.TP.one_short()} buries {self.driver.query_multiple_short(sobs)} deep within the ground.\n")
        
        self.TP.adjust_gp(gp)
        return 1

    def query_patterns(self):
        """Define command patterns for parsing.
        
        @return list of pattern tuples
        """
        return [
            ("<indirect:object:here>", lambda: self.cmd(self.driver.args[0])),
            ("", lambda: self.cmd(self.driver.match_objects_for_existence("corpse", self.driver.environment(self.TP))))
        ]