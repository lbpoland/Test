# File: /home/archaon/mud/lib/cmds/player/countries.py
# Purpose: Displays a list of countries represented by currently logged-in players.
# Linked Files: Inherits from /home/archaon/mud/lib/cmds/base.py.
# Updated Features: Verified against live MUD sources as of March 20, 2025; no significant updates noted in wiki, announcements, or blogs beyond 2003 functionality. Country list preserved as-is.
# Translated by: Archaon

from home.archaon.mud.lib.cmds.base import Base

COUNTRIES_NO_SHOW_PROP = "don't show on countries list"

COMMON_COUNTRIES = {
    "N/A": [0, "An unresolved address"],
    "com": [0, "Commercial"],
    "edu": [0, "Educational"],
    "net": [0, "Network"],
    "uk": [0, "United Kingdom"],
    "au": [0, "Australia"]
}

ALL_COUNTRIES = {
    "ad": [0, "Andorra"], "ae": [0, "United Arab Emirates"], "af": [0, "Afghanistan"],
    "ag": [0, "Antigua and Barbuda"], "ai": [0, "Anguila"], "al": [0, "Albania"],
    "am": [0, "Armenia"], "an": [0, "Netherlands Antilles"], "ao": [0, "Angola"],
    "aq": [0, "Antarctica"], "ar": [0, "Argentina"], "as": [0, "American Samoa"],
    "at": [0, "Austria"], "au": [0, "Australia"], "aw": [0, "Aruba"],
    "az": [0, "Azerbaijan"], "ba": [0, "Bosnia and Herzegovina"], "bb": [0, "Barbados"],
    "bd": [0, "Bangladesh"], "be": [0, "Belgium"], "bf": [0, "Burkina Faso"],
    "bg": [0, "Bulgaria"], "bh": [0, "Bahrain"], "bi": [0, "Burundi"],
    "bj": [0, "Benin"], "bm": [0, "Bermuda"], "bn": [0, "Brunei Darussalam"],
    "bo": [0, "Bolivia"], "br": [0, "Brazil"], "bs": [0, "Bahamas"],
    "bt": [0, "Bhutan"], "bv": [0, "Bouvet Island"], "bw": [0, "Botswana"],
    "by": [0, "Belarus"], "bz": [0, "Belize"], "ca": [0, "Canada"],
    "cc": [0, "Cocos (Keeling) Islands"], "cf": [0, "Central African Republic"],
    "cg": [0, "Congo"], "ch": [0, "Switzerland"], "ci": [0, "Cote D'Ivoire (Ivory Coast)"],
    "ck": [0, "Cook Island"], "cl": [0, "Chile"], "cm": [0, "Cameroon"],
    "cn": [0, "China"], "co": [0, "Colombia"], "cr": [0, "Costa Rica"],
    "cs": [0, "Czechoslovakia (former)"], "cu": [0, "Cuba"], "cv": [0, "Cape Verde"],
    "cx": [0, "Christmas Island"], "cy": [0, "Cyprus"], "cz": [0, "Czech Republic"],
    "de": [0, "Germany"], "dk": [0, "Denmark"], "dm": [0, "Dominica"],
    "do": [0, "Dominican Republic"], "dz": [0, "Algeria"], "ec": [0, "Ecuador"],
    "ee": [0, "Estonia"], "eg": [0, "Egypt"], "eh": [0, "Western Sahara"],
    "er": [0, "Eritrea"], "es": [0, "Spain"], "et": [0, "Ethiopia"],
    "fi": [0, "Finland"], "fj": [0, "Fiji"], "fk": [0, "Falkland Islands (Malvinas)"],
    "fm": [0, "Micronesia"], "fo": [0, "Faroe Islands"], "fr": [0, "France"],
    "fx": [0, "France, Metropolitan"], "ga": [0, "Gabon"], "gd": [0, "Grenada"],
    "ge": [0, "Georgia"], "gf": [0, "French Guiana"], "gh": [0, "Ghana"],
    "gi": [0, "Gibraltar"], "gl": [0, "Greenland"], "gm": [0, "Gambia"],
    "gn": [0, "Guinea"], "gp": [0, "Guadeloupe"], "gq": [0, "Equatorial Guinea"],
    "gr": [0, "Greece"], "gs": [0, "S. Georgia and S. Sandwich Isls."],
    "gt": [0, "Guatemala"], "gu": [0, "Guam"], "gw": [0, "Guinea-Bissau"],
    "gy": [0, "Guyana"], "hk": [0, "Hong Kong"], "hm": [0, "Heard and McDonald Islands"],
    "hn": [0, "Honduras"], "hr": [0, "Croatia (Hrvatska)"], "ht": [0, "Haiti"],
    "hu": [0, "Hungary"], "id": [0, "Indonesia"], "ie": [0, "Ireland"],
    "il": [0, "Israel"], "in": [0, "India"], "io": [0, "British Indian Ocean Territory"],
    "iq": [0, "Iraq"], "ir": [0, "Iran"], "is": [0, "Iceland"],
    "it": [0, "Italy"], "jm": [0, "Jamaica"], "jo": [0, "Jordan"],
    "jp": [0, "Japan"], "ke": [0, "Kenya"], "kg": [0, "Kyrgyzstan"],
    "kh": [0, "Cambodia"], "ki": [0, "Kiribati"], "km": [0, "Comoros"],
    "kn": [0, "Saint Kitts and Nevis"], "kp": [0, "Korea (North)"],
    "kr": [0, "Korea (South)"], "kw": [0, "Kuwait"], "ky": [0, "Cayman Islands"],
    "kz": [0, "Kazakhstan"], "la": [0, "Laos"], "lb": [0, "Lebanon"],
    "lc": [0, "Saint Lucia"], "li": [0, "Liechtenstein"], "lk": [0, "Sri Lanka"],
    "lr": [0, "Liberia"], "ls": [0, "Lesotho"], "lt": [0, "Lithuania"],
    "lu": [0, "Luxembourg"], "lv": [0, "Latvia"], "ly": [0, "Libya"],
    "ma": [0, "Morocco"], "mc": [0, "Monaco"], "md": [0, "Moldovia"],
    "mg": [0, "Madagascar"], "mh": [0, "Marshall Islands"], "mk": [0, "Macedonia"],
    "ml": [0, "Mali"], "mm": [0, "Myanmar"], "mn": [0, "Mongolia"],
    "mo": [0, "Macau"], "mp": [0, "Northern Mariana Islands"], "mq": [0, "Martinique"],
    "mr": [0, "Mauritania"], "ms": [0, "Montserrat"], "mt": [0, "Malta"],
    "mu": [0, "Mauritius"], "mv": [0, "Maldives"], "mw": [0, "Malawi"],
    "mx": [0, "Mexico"], "my": [0, "Malaysia"], "mz": [0, "Mozambique"],
    "na": [0, "Namibia"], "nc": [0, "New Caledonia"], "ne": [0, "Niger"],
    "nf": [0, "Norfolk Islands"], "ng": [0, "Nigeria"], "ni": [0, "Nicaragua"],
    "nl": [0, "Netherlands"], "no": [0, "Norway"], "np": [0, "Nepal"],
    "nr": [0, "Nauru"], "nt": [0, "Neutral Zone"], "nu": [0, "Niue"],
    "nz": [0, "New Zealand (Aotearoa)"], "om": [0, "Oman"], "pa": [0, "Panama"],
    "pe": [0, "Peru"], "pf": [0, "French Polynesia"], "pg": [0, "Papua New Guinea"],
    "ph": [0, "Philippines"], "pk": [0, "Pakistan"], "pl": [0, "Poland"],
    "pm": [0, "St. Pierre and Miquelon"], "pn": [0, "Pitcairn"], "pr": [0, "Puerto Rico"],
    "pt": [0, "Portugal"], "pw": [0, "Palau"], "py": [0, "Paraguay"],
    "qa": [0, "Qatar"], "re": [0, "Reunion"], "ro": [0, "Romania"],
    "ru": [0, "Russian Federation"], "rw": [0, "Rwanda"], "sa": [0, "Saudi Arabia"],
    "sb": [0, "Solomon Islands"], "sc": [0, "Seychelles"], "sd": [0, "Sudan"],
    "se": [0, "Sweden"], "sg": [0, "Singapore"], "sh": [0, "St. Helena"],
    "si": [0, "Slovenia"], "sj": [0, "Svalbard and Jan Mayen Islands"],
    "sk": [0, "Slovak Republic"], "sl": [0, "Sierra Leone"], "sm": [0, "San Marino"],
    "sn": [0, "Senegal"], "so": [0, "Somalia"], "sr": [0, "Suriname"],
    "st": [0, "Sao Tome and Principe"], "su": [0, "USSR (former)"],
    "sv": [0, "El Salvador"], "sy": [0, "Syria"], "sz": [0, "Swaziland"],
    "tc": [0, "Turks and Caicos Islands"], "td": [0, "Chad"],
    "tf": [0, "French Southern Territories"], "tg": [0, "Togo"],
    "th": [0, "Thailand"], "tj": [0, "Tajikistan"], "tk": [0, "Tokelau"],
    "tm": [0, "Turkmenistan"], "tn": [0, "Tunisia"], "to": [0, "Tonga"],
    "tp": [0, "East Timor"], "tr": [0, "Turkey"], "tt": [0, "Trinidad and Tobago"],
    "tv": [0, "Tuvalu"], "tw": [0, "Taiwan"], "tz": [0, "Tanzania"],
    "ua": [0, "Ukraine"], "ug": [0, "Uganda"], "uk": [0, "United Kingdom"],
    "um": [0, "US Minor Outlying Islands"], "us": [0, "United States"],
    "uy": [0, "Uruguay"], "uz": [0, "Uzbekistan"], "va": [0, "Vatican City State (Holy See)"],
    "vc": [0, "Saint Vincent and the Grenadines"], "ve": [0, "Venezuela"],
    "vg": [0, "Virgin Islands (British)"], "vi": [0, "Virgin Islands (U.S.)"],
    "vn": [0, "Viet Nam"], "vu": [0, "Vanuatu"], "wf": [0, "Wallis and Futuna Islands"],
    "ws": [0, "Samoa"], "ye": [0, "Yemen"], "yt": [0, "Mayotte"],
    "yu": [0, "Yugoslavia"], "za": [0, "South Africa"], "zm": [0, "Zambia"],
    "zr": [0, "Zaire"], "zw": [0, "Zimbabwe"], "com": [0, "Commercial"],
    "edu": [0, "Educational"], "gov": [0, "US Government"], "int": [0, "International"],
    "mil": [0, "US Military"], "net": [0, "Network"], "org": [0, "Non-Profit Organization"],
    "arpa": [0, "Old Style Arpanet"], "nato": [0, "NATO Field"]
}

class Countries(Base):
    def __init__(self, driver):
        super().__init__(driver)

    def cmd(self):
        """Display countries of logged-in players.
        
        @return 1 on success, 0 on failure
        """
        player = self.driver.this_player()
        countries = {k: [v[0], v[1]] for k, v in COMMON_COUNTRIES.items()}
        users = [u for u in self.driver.users() 
                 if u.query_visible(player) and not u.query_property(COUNTRIES_NO_SHOW_PROP)]
        if not users:
            return self.driver.notify_fail("No visible players.\n")
        
        for person in users:
            suffix = self.resolve_domain_suffix(person)
            if suffix not in countries:
                if suffix not in ALL_COUNTRIES:
                    countries["N/A"][0] += 1
                    continue
                countries[suffix] = ALL_COUNTRIES[suffix].copy()
                COMMON_COUNTRIES[suffix] = ALL_COUNTRIES[suffix].copy()
            countries[suffix][0] += 1
        
        size = len(users) - countries["N/A"][0]
        del countries["N/A"]
        unsorted = []
        for country, data in list(countries.items()):
            if not data[0]:
                del COMMON_COUNTRIES[country]
                continue
            data[1] += f" (%^BOLD%^ {country.upper()}%^RESET%^)"
            unsorted.append(data)
        
        sorted_data = sorted(unsorted, key=lambda x: x[0], reverse=True)
        message = (f"\nA total of %^BOLD%^ {self.driver.query_num(size)} %^RESET%^ visible "
                   f"{'users' if size != 1 else 'user'} with resolvable addresses logged on:\n")
        left = (player.query_cols() // 3) * 2 - 3
        right = player.query_cols() - left
        for data in sorted_data:
            percentage = int(data[0] * 100.0 / size + 0.5)
            message += f"   {data[1]:.<{left}}{'  ' + str(percentage) + '%':->{right}}\n"
        
        player.more_string(message)
        return 1

    def resolve_domain_suffix(self, player):
        """Get the domain suffix from a player's IP.
        
        @param player the player object
        @return suffix string or None
        """
        addy = self.driver.query_ip_name(player)
        if not addy:
            return None
        host = addy.lower().split(".")
        return host[-1]

    def handle_no_show(self, hide):
        """Toggle visibility on the countries list.
        
        @param hide 1 to hide, 0 to show
        @return 1 on success, 0 on failure
        """
        player = self.driver.this_player()
        if hide == 1:
            if player.query_property(COUNTRIES_NO_SHOW_PROP):
                self.driver.tell_object(player, "You are already hidden on the countries list.\n")
                return 1
            player.add_property(COUNTRIES_NO_SHOW_PROP, 1)
            self.driver.tell_object(player, "You will no longer be included in the countries list.\n")
            return 1
        if hide == 0:
            if not player.query_property(COUNTRIES_NO_SHOW_PROP):
                self.driver.tell_object(player, "You are already visible on the countries list.\n")
                return 1
            player.remove_property(COUNTRIES_NO_SHOW_PROP)
            self.driver.tell_object(player, "You will now be shown on the countries list.\n")
            return 1
        return self.driver.notify_fail("This shouldn't happen.\n")

    def query_patterns(self):
        """Define command patterns for parsing.
        
        @return list of pattern tuples
        """
        return [
            ("", lambda: self.cmd()),
            ("hide", lambda: self.handle_no_show(1)),
            ("show", lambda: self.handle_no_show(0))
        ]