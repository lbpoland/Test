# File: /home/archaon/mud/lib/cmds/player/arguments.py
# Purpose: Lists theological arguments known by the player.
# Linked Files: Inherits from /home/archaon/mud/lib/cmds/base.py; uses /home/archaon/mud/lib/include/philosophies.py.
# Updated Features: None from live MUD as of March 20, 2025; core functionality preserved from 2003 base.
# Translated by: Archaon

from home.archaon.mud.lib.cmds.base import Base
from home.archaon.mud.lib.include.philosophies import PHILOSOPHY_HANDLER

class Arguments(Base):
    def __init__(self, driver):
        super().__init__(driver)

    def cmd(self):
        """List all theological arguments known by the player.
        
        @return 1 on success
        """
        args = PHILOSOPHY_HANDLER.query_all_known(self.driver.this_player().query_name())
        if not args:
            self.driver.write("You do not know any theological arguments.\n")
        else:
            self.driver.write(f"You know the following theological arguments:\n{self.driver.query_multiple_short(args)}.\n")
        return 1

    def query_patterns(self):
        """Define command patterns for parsing.
        
        @return list of pattern tuples
        """
        return [("", lambda: self.cmd())]