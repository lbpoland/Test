# File: /home/archaon/mud/lib/cmds/player/chfn.py
# Purpose: Allows players to change their finger information (real name, location, birthday, email, homepage).
# Linked Files: Inherits from /home/archaon/mud/lib/cmds/base.py.
# Updated Features: Verified against live MUD sources as of March 20, 2025; no significant updates noted in wiki, announcements, or blogs beyond 2003 functionality.
# Translated by: Archaon

from home.archaon.mud.lib.cmds.base import Base

MAX_EMAIL_LEN = 50  # Maximum length for email, real name, and location

class Chfn(Base):
    def __init__(self, driver):
        super().__init__(driver)
        self.TP = self.driver.this_player()  # Shortcut for this_player()

    def cmd(self, str_):
        """Initiate changing finger information.
        
        @param str_ unused parameter (kept for compatibility)
        @return 1 on success
        """
        self.driver.write("Change finger information.\n")
        self.driver.write("Pressing return at the prompts will take the default. The default "
                         "is the option in []'s.\n")
        self.driver.write(f"What real name do you wish to use [{self.TP.query_real_name()}] ? ")
        self.driver.input_to(self.real_name)
        return 1

    def real_name(self, str_):
        """Set player's real name.
        
        @param str_ the input string for real name
        @return 1 on success
        """
        str_ = self.driver.strip_colours(str_)
        real_name = self.TP.query_real_name()
        if str_ and str_ != "":
            real_name = None if str_ == "none" else str_
        if real_name and len(real_name) > MAX_EMAIL_LEN:
            self.driver.write(f"Real name is too long, a maximum of {MAX_EMAIL_LEN} characters is allowed.\n")
            self.driver.write(f"What real name do you wish to use [{self.TP.query_real_name()}] ? ")
            self.driver.input_to(self.real_name)
            return 1
        if real_name and real_name != "":
            self.driver.write(f"Ok real name set to {real_name}.\n")
        else:
            self.driver.write("Real name cleared.\n")
        self.TP.set_real_name(real_name)
        self.driver.write(f"Enter your location (ie Perth, oz, whatever) [{self.TP.query_where()}]\n(none for none) : ")
        self.driver.input_to(self.get_where)
        return 1

    def get_where(self, str_):
        """Set player's location.
        
        @param str_ the input string for location
        @return 1 on success
        """
        str_ = self.driver.strip_colours(str_)
        where = self.TP.query_where()
        if str_ and str_ != "":
            where = None if str_ == "none" else str_
        if where and where != "":
            self.driver.write(f"Ok location set to {where}.\n")
        else:
            self.driver.write("Location cleared.\n")
        if where and len(where) > MAX_EMAIL_LEN:
            self.driver.write(f"Your location is too long, maximum of {MAX_EMAIL_LEN} characters allowed.\n")
            self.driver.write(f"Enter your location (ie Perth, oz, whatever) [{self.TP.query_where()}]\n(none for none) : ")
            self.driver.input_to(self.get_where)
            return 1
        self.TP.set_where(where)
        if self.TP.query_birthday() == "Unknown":
            self.driver.write(f"Enter your birthday (ddmm) [{self.TP.query_birthday()}]\n(none for none) : ")
            self.driver.input_to(self.birthday)
        else:
            self.driver.write("What email address do you wish to use. Set to none to clear.\n")
            self.driver.write("Putting a : in front of it means that only the creators can read it.\n")
            self.driver.write(f"[{self.TP.query_email()}] : ")
            self.driver.input_to(self.get_email)
        return 1

    def convert_birthday(self, str_):
        """Convert ddmm format to a readable birthday string.
        
        @param str_ the ddmm birthday string
        @return formatted string
        """
        MONTHS = ["January", "February", "March", "April", "May", "June",
                  "July", "August", "September", "October", "November", "December"]
        tot = int(str_)
        day = tot // 100
        month = tot % 100
        if day in (11, 12, 13):
            suffix = "th"
        else:
            suffix = {1: "st", 2: "nd", 3: "rd"}.get(day % 10, "th")
        return f"{day}{suffix} of {MONTHS[month - 1]}"

    def valid_birthday(self, str_):
        """Validate a ddmm birthday string.
        
        @param str_ the ddmm birthday string
        @return 1 if valid, 0 if not
        """
        LENGTHS = [0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
        if len(str_) != 4:
            return 0
        try:
            tot = int(str_)
        except ValueError:
            return 0
        month = tot % 100
        day = tot // 100
        if not (1 <= month <= 12 and 1 <= day <= LENGTHS[month]):
            return 0
        return 1

    def birthday(self, str_):
        """Set player's birthday.
        
        @param str_ the input string for birthday
        """
        birth_day = self.TP.query_birthday()
        if str_ == "":
            self.driver.write(f"Birthday unchanged from {birth_day}.\n" if birth_day else "Birthday left as blank.\n")
        else:
            if birth_day != "Unknown":
                self.driver.write("You can't change when you were born! Please ask a Creator or a Lord to change it if you made an error.\n")
            elif not self.valid_birthday(str_):
                self.driver.write("Invalid Birthday. Birthday cleared.\n")
                birth_day = None
            else:
                birth_day = self.convert_birthday(str_)
                self.driver.write(f"Birthday set to {birth_day}.\n")
                self.TP.birthday_gifts()  # Assuming this triggers any birthday-related effects
        self.TP.set_birthday(birth_day)
        self.driver.write("What email address do you wish to use. Set to none to clear.\n")
        self.driver.write("Putting a : in front of it means that only the creators and lords can read it.\n")
        self.driver.write(f"[{self.TP.query_email()}] : ")
        self.driver.input_to(self.get_email)

    def get_email(self, str_):
        """Set player's email address.
        
        @param str_ the input string for email
        """
        email = self.TP.query_email()
        str_ = self.driver.strip_colours(str_)
        if str_ == "":
            self.driver.write("Email address left blank.\n" if not email or email == "" else f"Email address left as {email}.\n")
        elif str_ == "none":
            email = None
            self.driver.write("Email address cleared.\n")
        else:
            email = str_
            self.driver.write(f"Email address set to {email}.\n")
        if email and len(email) > MAX_EMAIL_LEN:
            self.driver.write(f"Your email address is too long, maximum of {MAX_EMAIL_LEN} characters allowed.\n")
            self.driver.write("What email address do you wish to use. Set to none to clear.\n")
            self.driver.write("Putting a : in front of it means that only the creators and lords can read it.\n")
            self.driver.write(f"[{self.TP.query_email()}] : ")
            self.driver.input_to(self.get_email)
            return
        self.TP.set_email(email)
        self.driver.write("Please enter your home page (World Wide Web page address), type 'none' to clear it.\n")
        homepage = self.TP.query_homepage()
        self.driver.write("[none] : " if not homepage else f"[{homepage}] : ")
        self.driver.input_to(self.get_home_page)

    def get_home_page(self, str_):
        """Set player's homepage (incomplete in original; stubbed here).
        
        @param str_ the input string for homepage
        """
        str_ = self.driver.strip_colours(str_)
        homepage = self.TP.query_homepage()
        if str_ == "":
            self.driver.write("Home page left blank.\n" if not homepage else f"Home page left as {homepage}.\n")
        elif str_ == "none":
            homepage = None
            self.driver.write("Home page cleared.\n")
        else:
            homepage = str_
            self.driver.write(f"Home page set to {homepage}.\n")
        self.TP.set_homepage(homepage)
        # Original truncated here; assuming process ends
        self.driver.write("Finger information update complete.\n")

    def query_patterns(self):
        """Define command patterns for parsing.
        
        @return list of pattern tuples
        """
        return [("", lambda: self.cmd(None))]