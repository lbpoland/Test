# File: /home/archaon/mud/lib/cmds/player/components.py
# Purpose: Displays components required or consumed by a player's spell.
# Linked Files: Inherits from /home/archaon/mud/lib/cmds/base.py.
# Updated Features: Verified against live MUD sources as of March 20, 2025; no significant updates noted in wiki, announcements, or blogs beyond 2003 functionality.
# Translated by: Archaon

from home.archaon.mud.lib.cmds.base import Base

OBJ = 0  # Constant for spell object index

class Components(Base):
    def __init__(self, driver):
        super().__init__(driver)

    def cmd(self, spell_name):
        """Show components required or consumed by a specified spell.
        
        @param spell_name the name of the spell to check
        @return 1 on success, 0 on failure
        """
        player = self.driver.this_player()
        spells = player.query_spells_nocase()
        if not spells:
            self.driver.add_failed_mess("You don't know any magic spells.\n")
            return 0
        spell_name = player.expand_nickname(spell_name).capitalize()
        if spell_name.lower() not in spells:
            self.driver.add_failed_mess(f"You don't know a spell named {spell_name}.\n")
            return 0
        spell_ob = spells[spell_name.lower()][OBJ]
        consumed = spell_ob.query_consumables()
        needed = spell_ob.query_needed()
        if not consumed and not needed:
            mess = f"You don't need anything to cast {spell_name}"
        elif consumed:
            mess = f"{spell_name} will consume {self.driver.query_multiple_short(consumed)}"
            if needed:
                mess += f". It also requires {self.driver.query_multiple_short(needed)} but will not consume {'them' if len(needed) > 1 else 'it'}"
        else:
            mess = f"{spell_name} requires {self.driver.query_multiple_short(needed)} but will not consume {'them' if len(needed) > 1 else 'it'}"
        self.driver.add_succeeded_mess([mess + ".\n", ""])
        return 1

    def query_patterns(self):
        """Define command patterns for parsing.
        
        @return list of pattern tuples
        """
        return [("[for] <string'spell'>", lambda: self.cmd(self.driver.args[0]))]