# File: /home/archaon/mud/lib/cmds/player/coverage.py
# Purpose: Displays body coverage by worn or potential armor/clothing items.
# Linked Files: Inherits from /home/archaon/mud/lib/cmds/base.py; uses /home/archaon/mud/lib/obj/handlers/clothing_handler.py.
# Updated Features: None from live MUD as of March 20, 2025; core functionality preserved from 2003 base.
# Translated by: Archaon

from home.archaon.mud.lib.cmds.base import Base

CLOTHING_HANDLER = "/home/archaon/mud/lib/obj/handlers/clothing_handler"

class Coverage(Base):
    def __init__(self, driver):
        super().__init__(driver)
        self._zone_patterns = None  # Not used in Python version but kept for reference

    def cmd(self, items, inverse, bits):
        """Display body coverage by armor/clothing items.
        
        @param items list of items to check (empty for all worn)
        @param inverse flag to show unprotected areas (1) or covered (0)
        @param bits specific body parts to check (string or None)
        @return 1 on success, 0 on failure
        """
        player = self.driver.this_player()
        clothing_handler = self.driver.find_object(CLOTHING_HANDLER)
        all_zones = list(clothing_handler.query_all_clothing_zones().keys())
        covered = {zone: [] for zone in all_zones}
        pot_covered = {zone: [] for zone in all_zones}
        
        armors = player.query_armours() if not items else items
        fail = [a for a in armors if not (a.query_armour() or a.query_clothing())]
        armors = [a for a in armors if a not in fail]
        wearing = player.query_wearing()
        
        if bits:
            bits = bits.replace(" ", ",").replace(",and,", ",")
            zones = [z for z in bits.split(",") if z]
            parts = [z for z in zones if z in all_zones]
            if not parts:
                self.driver.write(f"Please choose some combination of {self.driver.query_multiple_short(all_zones)}.\n")
                return 1
        
        for armor in armors:
            types = armor.query_type() if not isinstance(armor.query_type(), list) else armor.query_type()
            zones = []
            for type_ in types:
                equiv_type = clothing_handler.query_equivilant_type(type_)
                zones.extend(clothing_handler.query_zone_names(equiv_type or type_))
            if zones:
                target = covered if armor in wearing else pot_covered
                for zone in zones:
                    target[zone].append(armor)
            else:
                fail.append(armor)
        
        if bits:
            covered = {k: v for k, v in covered.items() if k in parts}
            pot_covered = {k: v for k, v in pot_covered.items() if k in parts}
        
        if inverse:
            unprotected = [z for z in all_zones if not covered[z]]
            if unprotected:
                verb = " are" if len(unprotected) > 1 or unprotected[0] in ("arms", "hands", "legs", "feet") else " is"
                self.driver.write(f"Your {self.driver.query_multiple_short(unprotected)}{verb} unprotected.\n")
            else:
                self.driver.write("You are covered from head to foot.\n")
            return 1
        
        zones = sorted(set(covered.keys()) | set(pot_covered.keys()))
        for zone in zones:
            verb = " are" if zone in ("arms", "hands", "legs", "feet") else " is"
            if covering := covered.get(zone, []):
                mess = (f"Your {zone}{verb} protected by {covering[0].one_short()}" 
                        if len(covering) == 1 
                        else f"Your {zone}{verb} protected by {self.driver.query_num(len(covering))} things, {self.driver.query_multiple_short(covering, 'one')}")
                if pot_covered.get(zone):
                    mess += f" and could be protected by {self.driver.query_multiple_short(pot_covered[zone], 'one')}.\n"
                    pot_covered[zone] = []
                else:
                    mess += ".\n"
                self.driver.write(mess)
            elif covering := pot_covered.get(zone, []):
                self.driver.write(f"Your {zone} could be protected by {self.driver.query_multiple_short(covering, 'one')}.\n")
            elif bits:
                self.driver.write(f"Your {zone}{verb} unprotected.\n")
        
        if fail and items:
            if len(fail) == 1 and fail[0] == player:
                self.driver.write("You don't offer any protection. Perhaps you should invest in some sonkies?\n")
            else:
                self.driver.write(f"{self.driver.query_multiple_short(fail, 'the')} {'doesn\\'t' if len(fail) == 1 else 'don\\'t'} offer any protection.\n")
        elif not (set(armors) - set(fail)):
            self.driver.write("You are completely unprotected. Good luck!\n")
        return 1

    def query_patterns(self):
        """Define command patterns for parsing.
        
        @return list of pattern tuples
        """
        return [
            ("", lambda: self.cmd([], 0, None)),
            ("[by] <indirect:object'armour/clothing'>", lambda: self.cmd(self.driver.args[0], 0, None)),
            ("unprotected", lambda: self.cmd([], 1, None)),
            ("of <string'body part(s)'>", lambda: self.cmd([], 0, self.driver.args[0]))
        ]