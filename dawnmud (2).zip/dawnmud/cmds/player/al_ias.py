# File: /home/archaon/mud/lib/cmds/player/al_ias.py
# Purpose: Manages player aliases, including listing, adding, and modifying alias definitions.
# Linked Files: Inherits from /home/archaon/mud/lib/cmds/base.py; uses /home/archaon/mud/lib/include/alias.py.
# Updated Features: None from live MUD as of March 20, 2025; core functionality preserved from 2003 base with updated alias constants.
# Translated by: Archaon

from home.archaon.mud.lib.cmds.base import Base
from home.archaon.mud.lib.include.alias import NEW_LINE, ALL_ARGS, ONE_ARG, TO_ARG, FROM_ARG, ALL_ARG, ARG_THING, ELSE_THING, ALL_IFARG, IFARG_THING, CURR_LOC, END_IF, ALIAS_MASK
import re

class Alias(Base):
    def __init__(self, driver):
        super().__init__(driver)
        self.gfilter = None  # Global filter for alias listing

    def alias_string(self, al):
        """Convert an alias array to its string representation.
        
        @param al the alias array to convert
        @return the string representation
        """
        str_ = ""
        i = 0
        while i < len(al):
            if isinstance(al[i], str):
                str_ += al[i].replace(";", "\\;")
            else:
                num = al[i] & ALIAS_MASK
                code = al[i] - num
                if code == NEW_LINE:
                    str_ += ";"
                elif code == ALL_ARGS:
                    str_ += "$*$"
                elif code == ONE_ARG:
                    str_ += f"${num}$"
                elif code == TO_ARG:
                    str_ += f"$*{num}$"
                elif code == FROM_ARG:
                    str_ += f"${num}*$"
                elif code == ALL_ARG:
                    i += 1
                    str_ += f"$arg:{al[i]}$"
                elif code == ARG_THING:
                    i += 1
                    str_ += f"$arg{num}:{al[i]}$"
                elif code == ELSE_THING:
                    str_ += "$else$"
                elif code == ALL_IFARG:
                    str_ += "$ifarg:"
                elif code == IFARG_THING:
                    str_ += f"$ifarg{num}:"
                elif code == CURR_LOC:
                    str_ += "$!$"
                elif code == END_IF:
                    str_ += "$endif$"
            i += 1
        return str_

    def print_aliases(self, filter_, sorted_):
        """Display the player's aliases with optional filtering and sorting.
        
        @param filter_ the filter pattern (regex) or None
        @param sorted_ flag to sort aliases (1) or not (0)
        @return 1 on success, 0 on failure
        """
        player = self.driver.this_player()
        aliases = player.query_aliases()
        if not aliases:
            self.driver.notify_fail("None defined.\n")
            return 0
        tmp = list(aliases.keys())
        if filter_:
            if re.search(r"[\[\]\(\)\*\?\+]{2,}", filter_):
                self.driver.add_failed_mess("Bad pattern to alias.\n")
                return 0
            if filter_[0] in ('*', '+'):
                self.driver.add_failed_mess("Cannot start a regular expression with a '*' or '+', try: '.*' or '.+'.\n")
                return 0
            self.gfilter = f"^{filter_}"
            try:
                tmp = [t for t in tmp if t and re.match(self.gfilter, t)]
            except re.error:
                self.driver.add_failed_mess("Bad pattern to alias (mismatched brackets?).\n")
                return 0
        tmp.sort() if sorted_ else None
        ret = "You currently have the following aliases:\n"
        str1, str2 = "", ""
        for key in tmp:
            if not key:
                del aliases[None]
                continue
            bing = self.alias_string(aliases[key]) or "Error in the alias!"
            key_display = "icky" if not key else key
            if "%^" in bing:
                bing = bing.replace("%^", "% ^")
                key_display += " (colour replace)"
            str_ = f"{key_display}: {bing}"
            cols = player.query_cols()
            if len(str_) > 39 or sorted_:
                len_ = max(cols - len(key_display) - 2, 10)
                ret += f"{key_display}: {bing:<{len_}}\n"
            elif len(str_) > 19:
                str1 += str_ + "\n"
            else:
                str2 += str_ + "\n"
        if str1:
            ret += f"{str1:<#{cols}}\n"
        if str2:
            ret += f"{str2:<#{cols}}\n"
        ret += f"A total of {len(tmp)} aliases.\n"
        player.more_string(ret)
        return 1

    def compile_alias(self, str_):
        """Compile an alias string into an alias array.
        
        @param str_ the alias string to compile
        @return the compiled alias array
        """
        str_ = str_.replace("\\;", "$escaped$").replace(";", "$new_line$").replace(" ", " ")
        str_ = str_.replace("$escaped$", ";")
        ending_dollar = str_.endswith('$')
        frog = f"&{str_}&".split('$')
        frog[0] = frog[0][1:] if frog[0] == "&" else frog[0]
        frog[-1] = frog[-1][:-1] if frog[-1] == "&" else frog[-1]
        ret = [frog[0]]
        ifargs = []
        nodollar, gumby, space = 1, 0, 0
        i = 1
        while i < len(frog):
            token = frog[i]
            if token == "new_line":
                ret.append(NEW_LINE)
                nodollar = 1
            elif token == "*":
                ret.append(ALL_ARGS)
                gumby = 1
                nodollar = 1
            elif token == "!" and self.driver.this_object().query_creator():
                ret.append(CURR_LOC)
                nodollar = 1
            elif token == "else" and ifargs:
                ret[ifargs[-1]] = len(ret) - ifargs[-1] + 1
                ret.extend([ELSE_THING, 0, ""])
                ifargs[-1] = len(ret) - 2
                nodollar = 1
            elif token in ("~", "endif") and ifargs:
                ret.append(END_IF)
                ret[ifargs[-1]] = len(ret) - ifargs[-1]
                ifargs.pop()
                nodollar = 1
                space = 1
            elif token.startswith("ifarg"):
                if match := re.match(r"ifarg(\d+):(.*)", token):
                    tmp, s1 = int(match.group(1)), match.group(2)
                    tmp = max(0, min(tmp, ALIAS_MASK))
                    ret.extend([IFARG_THING + tmp, 0, ""])
                    frog[i] = s1
                    i -= 1
                    nodollar = 1
                    ifargs.append(len(ret) - 2)
                    space = 0
                    gumby = 1
                elif token.startswith("ifarg:"):
                    ret.extend([ALL_IFARG, 0, ""])
                    frog[i] = token[6:]
                    i -= 1
                    nodollar = 1
                    ifargs.append(len(ret) - 2)
                    space = 0
                    gumby = 1
                else:
                    self._append_token(ret, token, nodollar, space)
            elif token.startswith("arg"):
                if match := re.match(r"arg(\d+):(.*)", token):
                    tmp, s1 = int(match.group(1)), match.group(2)
                    tmp = max(0, min(tmp, ALIAS_MASK))
                    ret.extend([ARG_THING + tmp, s1, ""])
                    nodollar = 1
                    gumby = 1
                elif token.startswith("arg:"):
                    ret.extend([ALL_ARG, token[4:], ""])
                    nodollar = 1
                    gumby = 1
                else:
                    self._append_token(ret, token, nodollar, space)
            elif token.endswith('*') and re.match(r"(\d+)\*$", token):
                tmp = int(token[:-1])
                tmp = max(0, min(tmp, ALIAS_MASK))
                ret.append(FROM_ARG + tmp)
                gumby = 1
                nodollar = 1
            elif token.startswith('*') and re.match(r"\*(\d+)$", token):
                tmp = int(token[1:])
                tmp = max(0, min(tmp, ALIAS_MASK))
                ret.append(TO_ARG + tmp)
                gumby = 1
                nodollar = 1
            elif match := re.match(r"(\d+)$", token) and (i < len(frog) - 1 or ending_dollar):
                tmp = int(token)
                tmp = max(0, min(tmp, ALIAS_MASK))
                ret.append(ONE_ARG + tmp)
                gumby = 1
                nodollar = 1
            else:
                self._handle_complex_token(ret, token, ifargs, nodollar, space)
            i += 1
        while ifargs:
            ret.append(END_IF)
            ret[ifargs[-1]] = len(ret) - ifargs[-1]
            ifargs.pop()
        if not gumby and ret:
            if isinstance(ret[-1], str) and not space:
                ret[-1] += " "
            ret.append(ALL_ARGS)
        return ret

    def _append_token(self, ret, token, nodollar, space):
        """Helper to append a token to the alias array.
        
        @param ret the alias array
        @param token the token to append
        @param nodollar flag indicating if dollar sign is needed
        @param space flag indicating spacing
        """
        if nodollar:
            ret.append(token)
        else:
            ret.append(f"${token}")
        return 0, 0  # Reset nodollar and space

    def _handle_complex_token(self, ret, token, ifargs, nodollar, space):
        """Handle complex tokens with conditional logic.
        
        @param ret the alias array
        @param token the token to process
        @param ifargs list of ifarg positions
        @param nodollar flag indicating if dollar sign is needed
        @param space flag indicating spacing
        @return updated nodollar and space
        """
        if not nodollar:
            token = f"${token}"
        nodollar = 0
        if token.endswith('~') and ifargs:
            token = token[:-1] if len(token) > 1 else ""
            ret.append(END_IF)
            ret[ifargs[-1]] = len(ret) - ifargs[-1]
            ifargs.pop()
            nodollar = 1
            space = 1
        if ret and isinstance(ret[-1], str) and space != 2:
            ret[-1] += token
        else:
            ret.append(token)
        space = 2 if space else space
        return nodollar, space

    def print_some_aliases(self, str_, every):
        """Display specific aliases or filtered list.
        
        @param str_ the alias name or filter
        @param every flag to show all matching (1) or single (0)
        @return 1 on success, 0 on failure
        """
        player = self.driver.this_player()
        if player.is_alias(str_) and not every:
            alias_str = self.alias_string(player.query_player_alias(str_))
            self.driver.printf("%s: %-*s\n", str_, player.query_cols() - len(str_) - 2, alias_str)
            return 1
        return self.print_aliases(str_, 0)

    def alias(self, name, value):
        """Add or modify an alias.
        
        @param name the alias name
        @param value the alias definition
        @return 1 on success, 0 on failure
        """
        player = self.driver.this_player()
        if "END_ALIAS" in value:
            self.driver.add_failed_mess("You cannot use 'END_ALIAS' in an alias.\n")
            return 0
        name = "".join(name.split())
        if name in ("unalias", "alias", "ealias"):
            self.driver.add_failed_mess(f"You can't alias the '{name}' command, because otherwise, there would be Problems.\n")
            return 0
        compiled = self.compile_alias(value)
        if not player.is_alias(name):
            player.add_player_alias(name, compiled)
            self.driver.write(f"Added alias '{name}'.\n")
        else:
            player.add_player_alias(name, compiled)
            self.driver.write(f"Changed alias '{name}'.\n")
        return 1

    def query_patterns(self):
        """Define command patterns for parsing.
        
        @return list of pattern tuples
        """
        return [
            ("", lambda: self.print_aliases("", 0)),
            ("sorted", lambda: self.print_aliases("", 1)),
            ("every <word'alias'>", lambda: self.print_some_aliases(self.driver.args[0], 1)),
            ("<word'alias'>", lambda: self.print_some_aliases(self.driver.args[0], 0)),
            ("<word'alias'> <string>", lambda: self.alias(self.driver.args[0], self.driver.args[1]))
        ]