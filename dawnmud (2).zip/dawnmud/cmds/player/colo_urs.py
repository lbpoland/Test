# File: /home/archaon/mud/lib/cmds/player/colo_urs.py
# Purpose: Manages color settings for various player events, informs, and clubs.
# Linked Files: Inherits from /home/archaon/mud/lib/cmds/base.py; uses /home/archaon/mud/lib/include/colour.py, /home/archaon/mud/lib/include/clubs.py, /home/archaon/mud/lib/include/creator.py, /home/archaon/mud/lib/include/newbiehelpers.py.
# Updated Features: Verified against live MUD sources as of March 20, 2025; no significant updates noted in wiki, announcements, or blogs beyond 2003 functionality. Color codes and club handling preserved.
# Translated by: Archaon

from home.archaon.mud.lib.cmds.base import Base
from home.archaon.mud.lib.include.colour import USER_COLOUR_LIST
from home.archaon.mud.lib.include.clubs import CLUB_HANDLER
from home.archaon.mud.lib.include.newbiehelpers import NEWBIEHELPERS_HANDLER

class Colours(Base):
    def __init__(self, driver):
        super().__init__(driver)
        self._colours = [
            "BOLD", "FLASH", "BLACK", "RED", "BLUE", "CYAN", "MAGENTA", "ORANGE",
            "YELLOW", "GREEN", "WHITE", "B_RED", "B_ORANGE", "B_YELLOW", "B_BLACK",
            "B_CYAN", "B_WHITE", "B_GREEN", "B_MAGENTA"
        ]

    def create(self):
        """Initialize the colours command."""
        pass  # No additional initialization needed beyond base class

    def is_valid_colour(self, name):
        """Check if a color code is valid.
        
        @param name the color code to check
        @return 1 if valid, 0 if not
        """
        return name in self._colours

    def show_allowed_colours(self):
        """Display all allowed color codes.
        
        @return 1 on success
        """
        self.driver.write(f"The allowed colour codes are "
                         f"{self.driver.query_multiple_short([c.lower() for c in self._colours], 0, 0, 1)}.\n")
        return 1

    def query_colour_list(self, inform):
        """Get the list of colorable events based on inform type.
        
        @param inform 0 for events, 1 for informs, 2 for clubs
        @return list of event types
        """
        player = self.driver.this_player()
        if inform == 0:
            colour_list = USER_COLOUR_LIST.copy()
            if NEWBIEHELPERS_HANDLER.query_can_chat(player):
                colour_list.append("newbiehelpers")
            if player.query_creator():
                colour_list.extend(player.channel_list())
        elif inform == 1:
            colour_list = player.query_inform_types()
        else:  # inform == 2
            clubs = player.query_player_clubs()
            invalid_clubs = [c for c in clubs if not CLUB_HANDLER.is_club(c)]
            for bing in invalid_clubs:
                player.remove_player_club(bing)
            colour_list = [f"club_{c}" for c in player.query_player_clubs()]
        return colour_list

    def set_colours(self, inform, event_type, colour, force):
        """Set color for a specific event type.
        
        @param inform 0 for events, 1 for informs, 2 for clubs
        @param event_type the event type to color
        @param colour the color code(s) to set
        @param force flag to bypass validation (1 to force, 0 to validate)
        @return 1 on success, 0 on failure
        """
        player = self.driver.this_player()
        colour_list = self.query_colour_list(inform)
        name = (CLUB_HANDLER.query_club_name(event_type) if inform == 2 else event_type.lower())
        event_type = f"club_{event_type}" if inform == 2 else event_type
        
        if event_type not in colour_list:
            return self.driver.notify_fail("No such type.\n")
        
        my_colours = player.query_my_colours()
        if colour in ("default", "none"):
            player.set_my_colours(event_type, colour)
            self.driver.write(f"{name} colour set to {colour}.\n")
        else:
            colour_list = [c.upper() for c in colour.split()]
            bad = [c for c in colour_list if not self.is_valid_colour(c)]
            if bad and not force:
                self.driver.add_failed_mess(f"The colour{'s' if len(bad) > 1 else ''} "
                                           f"{self.driver.query_multiple_short(bad)} "
                                           f"{'are' if len(bad) > 1 else 'is'} not valid, valid colours are: "
                                           f"{self.driver.query_multiple_short(self._colours)}.\n")
                return 0
            tmp = "%^" + " %^".join(colour_list) + "%^"
            player.set_my_colours(event_type, tmp)
            self.driver.write(f"{name} colour set to {tmp}[{colour}]%^RESET%^.\n")
        return 1

    def show_colours(self, inform):
        """Display current color settings for specified inform type.
        
        @param inform 0 for events, 1 for informs, 2 for clubs
        @return 1 on success
        """
        player = self.driver.this_player()
        colour_list = self.query_colour_list(inform)
        my_colours = player.query_my_colours()
        
        if not inform:
            self.driver.write(f"{'Clubs':<20} <list>\n{'Inform':<20} <list>\n")
        
        for event in colour_list:
            name = CLUB_HANDLER.query_club_name(event[5:]) if inform == 2 else event
            display = (f"{my_colours[event]}[{my_colours[event].replace('%^', '')}]%^RESET%^" 
                       if my_colours.get(event) and my_colours[event] != "" 
                       else "[none]" if my_colours.get(event) == "" else "[default]")
            self.driver.write(f"{name:<20} {display}\n")
        return 1

    def query_patterns(self):
        """Define command patterns for parsing.
        
        @return list of pattern tuples
        """
        return [
            ("<word'event type'> <string'colour'>", lambda: self.set_colours(0, self.driver.args[0], self.driver.args[1], 0)),
            ("force <word'event type'> <string'colour'>", lambda: self.set_colours(0, self.driver.args[0], self.driver.args[1], 1)),
            ("", lambda: self.show_colours(0)),
            ("inform <word'inform type'> <string'colour'>", lambda: self.set_colours(1, self.driver.args[0], self.driver.args[1], 0)),
            ("inform force <word'inform type'> <string'colour'>", lambda: self.set_colours(1, self.driver.args[0], self.driver.args[1], 1)),
            ("club <string:quoted'club name'> <string'colour'>", lambda: self.set_colours(2, self.driver.args[0], self.driver.args[1], 0)),
            ("club force <string:quoted'club name'> <string'colour'>", lambda: self.set_colours(2, self.driver.args[0], self.driver.args[1], 1)),
            ("inform", lambda: self.show_colours(1)),
            ("allowed", lambda: self.show_allowed_colours()),
            ("clubs", lambda: self.show_colours(2))
        ]