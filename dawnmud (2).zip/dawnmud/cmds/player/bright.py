# File: /home/archaon/mud/lib/cmds/player/bright.py
# Purpose: Displays brightness levels of the environment or specified objects.
# Linked Files: Inherits from /home/archaon/mud/lib/cmds/base.py; uses /home/archaon/mud/lib/include/dirs.py.
# Updated Features: Verified against live MUD sources as of March 20, 2025; no significant updates noted in wiki, announcements, or blogs beyond 2003 functionality.
# Translated by: Archaon

from home.archaon.mud.lib.cmds.base import Base
from home.archaon.mud.lib.include.dirs import LENGTHEN

THRESHOLDS = [10, 30, 200, 300]  # Light level thresholds

class Bright(Base):
    def __init__(self, driver):
        super().__init__(driver)

    def illumination(self, number):
        """Describe the illumination level based on light value.
        
        @param number the light level
        @return descriptive string
        """
        if number < 0:
            return "in the darkness that lies beyond darkness"
        if number < THRESHOLDS[0]:
            return "in pitch darkness"
        if number < THRESHOLDS[1]:
            return "in near darkness"
        if number > THRESHOLDS[3]:
            return "too brightly lit to see"
        if number > THRESHOLDS[2]:
            return "too brightly lit to see clearly"
        number = (100 * (number - THRESHOLDS[1])) // (THRESHOLDS[2] - THRESHOLDS[1])
        if 0 <= number <= 5:
            return "very poorly lit"
        if 6 <= number <= 10:
            return "poorly lit"
        if 11 <= number <= 20:
            return "dimly lit"
        if 21 <= number <= 30:
            return "quite well lit"
        if 31 <= number <= 40:
            return "well lit"
        if 41 <= number <= 50:
            return "brightly lit"
        return "very brightly lit"

    def intensity(self, number, thing):
        """Describe the light intensity of an object.
        
        @param number the light level
        @param thing the object emitting light
        @return descriptive string
        """
        flag = thing == self.driver.this_player()
        if number < 0:
            return f"{'are' if flag else 'is'} dark beyond darkness"
        if number < THRESHOLDS[0]:
            return f"produce{'s' if not flag else ''} a faint light"
        if number < THRESHOLDS[1]:
            return f"produce{'s' if not flag else ''} a bit of light"
        if number > THRESHOLDS[3]:
            return f"{'are' if flag else 'is'} so bright you can't bear to look"
        if number > THRESHOLDS[2]:
            return f"{'are' if flag else 'is'} so bright it hurts to look"
        number = (100 * (number - THRESHOLDS[1])) // (THRESHOLDS[2] - THRESHOLDS[1])
        if 0 <= number <= 24:
            return f"produce{'s' if not flag else ''} quite a bit of light"
        if 25 <= number <= 49:
            return f"{'are' if flag else 'is'} very bright"
        return f"{'are' if flag else 'is'} extremely bright"

    def check_exists(self, file):
        """Check if a file or object exists.
        
        @param file the file path to check
        @return 1 if exists, 0 if not
        """
        if self.driver.find_object(file):
            return 1
        return 1 if self.driver.file_size(file + ".c") > 0 else 0

    def cmd(self, things):
        """Display brightness of environment or objects.
        
        @param things list of objects to check (None for environment)
        @return 1 on success
        """
        player = self.driver.this_player()
        env = self.driver.environment(player)
        results = (f"Wherever you are, it's " if env.query_light() < THRESHOLDS[0] 
                  else f"$C${env.the_short(1)} is ") + self.illumination(env.query_light()) + ".\n"
        if not things:
            self.driver.write(results)
            return 1
        no_light_results = ""
        no_light = []
        result_light = False
        for thing in things:
            its_light = thing.query_light()
            if its_light:
                results += f"$C${thing.the_short(1)} {self.intensity(its_light, thing)}.\n"
                result_light = True
            else:
                no_light.append(thing)
        if no_light and not result_light:
            self.driver.write(f"$C${self.driver.query_multiple_short(no_light, 'one', 0, 1)} "
                             f"{'produces' if len(no_light) == 1 and no_light[0] != player else 'produce'} no light at all.\n")
        self.driver.write(results)
        return 1

    def cmd_exit(self, arg):
        """Display brightness of an exit's destination.
        
        @param arg the exit name
        @return 1 on success, 0 on failure
        """
        player = self.driver.this_player()
        room = self.driver.environment(player)
        if room.query_mirror_room():
            room = room.query_mirror_room()
        arg = LENGTHEN.get(arg, arg)
        if not room.query_exit(arg):
            arg = player.find_abs(arg)
        if room.query_exit(arg):
            other = room.query_destination(arg)
            if self.check_exists(other):
                door = room.query_door_control(arg)
                if room.query_door_open(arg) or (door and door.query_transparent()):
                    self.driver.write(f"{other.the_short(1)} is {self.illumination(other.query_light())}.\n")
                    return 1
                self.driver.add_failed_mess(f"The exit {arg} is not open.\n")
                return 0
            self.driver.add_failed_mess(f"The exit {arg} does not exist.\n")
            return 0
        self.driver.add_failed_mess(f"Unable to find the exit {arg}.\n")
        return 0

    def query_patterns(self):
        """Define command patterns for parsing.
        
        @return list of pattern tuples
        """
        return [
            ("<indirect:object>", lambda: self.cmd(self.driver.args[0])),
            ("exit <string'exit name'>", lambda: self.cmd_exit(self.driver.args[0])),
            ("", lambda: self.cmd(None))
        ]