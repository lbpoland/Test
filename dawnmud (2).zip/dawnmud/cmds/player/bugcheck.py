# File: /home/archaon/mud/lib/cmds/player/bugcheck.py
# Purpose: Helps players determine how to report bugs for specific objects or rooms.
# Linked Files: Inherits from /home/archaon/mud/lib/cmds/base.py.
# Updated Features: None from live MUD as of March 20, 2025; core functionality preserved from 2003 base.
# Translated by: Archaon

from home.archaon.mud.lib.cmds.base import Base

WEIRD_OBJECT_LOG = "/home/archaon/mud/lib/log/secure/playtesters/bugcheck-weird-objects"

class Bugcheck(Base):
    def __init__(self, driver):
        super().__init__(driver)

    def cmd(self, obs):
        """Check how to bug report specific objects.
        
        @param obs list of objects to check
        @return 1 on success
        """
        for ob in obs:
            s = (ob.query_property("virtual name").split('/') 
                 if isinstance(ob.query_property("virtual name"), str) 
                 else self.driver.base_name(ob).split('/'))
            match s[0]:
                case "d":
                    self.driver.write(f"{ob.the_short().capitalize()} is a domain thing. It's probably safe to bugrep it directly.\n")
                case "w":
                    self.driver.write(f"{ob.the_short().capitalize()}... why do you have a creator item?\n")
                    self.driver.log_file("ILLEGAL_OBJECT", 
                                        f"{self.driver.ctime(self.driver.time())}: {self.driver.this_player().query_name()} tried to bugcheck {self.driver.base_name(ob)}.\n\n")
                case "std":
                    self.driver.write(f"{ob.the_short().capitalize()} is a weird MUD library thing. If you bugrep it, the response might be slow. It may be a better idea to bugrep the room that the object was found in.\n")
                case "obj":
                    if s[1] in ("weapons", "armours", "clothes", "food", "jewellery"):
                        self.driver.write(f"{ob.the_short().capitalize()} is a Disc-wide item, but belongs to a directory that is checked regularly. Best to make the bugrep directly on the item.\n")
                    else:
                        self.driver.write(f"{ob.the_short().capitalize()} is a fairly general Disc-wide object. If you bugrep it, the response might be slow. It would most likely be a better idea to bugrep the room in which the object was found.\n")
                case "global":
                    if s[1] in ("player", "lord", "playtester"):
                        txt = "are" if ob == self.driver.this_player() else "is"
                        self.driver.write(f"{ob.the_short().capitalize()} {txt} the general {s[1]} object... if your bugrep is on this, then bugrep this object. If your bugrep is along the frivolous lines of '{ob.the_short()} {txt} overpowered!', then don't bugreport it... be sure and raise the issue on the nearest bulletin board.\n")
                case _:
                    self.driver.write(f"I've got no idea about {ob.the_short()}. Sorry it didn't work out.\n")
                    self.driver.log_file(WEIRD_OBJECT_LOG, "/".join(s) + "\n")
        return 1

    def cmd_room(self):
        """Provide guidance on bug reporting the room.
        
        @return 1 on success
        """
        self.driver.write("Bug report the room for anything that seems to be odd in the room, descriptions being wrong, items you look at being wrong. Anything odd you see that does not seem to fit anywhere else should also be reported to the room.\n")
        return 1

    def query_patterns(self):
        """Define command patterns for parsing.
        
        @return list of pattern tuples
        """
        return [
            ("<indirect:object:'thing'>", lambda: self.cmd(self.driver.args[0])),
            ("here", lambda: self.cmd_room())
        ]