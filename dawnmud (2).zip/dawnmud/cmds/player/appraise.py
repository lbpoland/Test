# File: /home/archaon/mud/lib/cmds/player/appraise.py
# Purpose: Allows players to appraise items for details like dimensions, appearance, and type.
# Linked Files: Inherits from /home/archaon/mud/lib/cmds/base.py; uses /home/archaon/mud/lib/include/volumes.py.
# Updated Features: None from live MUD as of March 20, 2025; core functionality preserved from 2003 base.
# Translated by: Archaon

from home.archaon.mud.lib.cmds.base import Base
from home.archaon.mud.lib.include.volumes import VOLUME_GALLON, VOLUME_QUART, VOLUME_PINT, VOLUME_GILL, VOLUME_SHOT

class Appraise(Base):
    def __init__(self, driver):
        super().__init__(driver)

    def query_length_mess(self, number):
        """Convert a length in units to a descriptive string.
        
        @param number the length in units
        @return descriptive string
        """
        if number == 0:
            return "not very"
        elif number == 1:
            return "an inch"
        elif number == 2:
            return "a couple of inches"
        elif number == 3:
            return "three inches"
        elif number == 4:
            return "four inches"
        elif 5 <= number <= 7:
            return "about six inches"
        elif 8 <= number <= 10:
            return "about nine inches"
        elif 11 <= number <= 14:
            return "about a foot"
        elif 15 <= number <= 21:
            return "about a foot and a half"
        elif 22 <= number <= 27:
            return "about two feet"
        elif 28 <= number <= 33:
            return "about two and a half feet"
        else:
            half_feet = (number + 3) // 6
            if half_feet % 2:
                return f"about {self.driver.query_num(half_feet // 2)} and a half feet"
            return f"about {self.driver.query_num(half_feet // 2)} feet"

    def query_dimensions_mess(self, thing):
        """Get dimensions message for an object.
        
        @param thing the object to describe
        @return dimensions string
        """
        return f"is {self.query_length_mess(thing.query_length())} long and {self.query_length_mess(thing.query_width())} wide."

    def query_appearance_mess(self, thing):
        """Get appearance message for an object.
        
        @param thing the object to describe
        @return appearance string
        """
        materials = thing.query_materials()
        material_mess = "some unidentifiable material" if not materials else self.driver.query_multiple_short(materials)
        if thing.query_colour():
            return f"is {thing.query_colour()} and is made of {material_mess}"
        return f"is made of {material_mess}"

    def query_type_mess(self, thing):
        """Get type message for an object.
        
        @param thing the object to describe
        @return type string or 0 if none
        """
        if thing.query_plant():
            return "appears to be some sort of plant"
        if thing.query_food_object():
            return "looks drinkable" if thing.query_liquid() else "looks edible"
        if thing.query_furniture():
            return "could be placed as furniture"
        if thing.query_property("shop type") == "jewellers":
            return "appears to be a piece of jewellery"
        if thing.query_weapon():
            return "could be used as a weapon"
        if thing.query_armour() and thing.query_wearable():
            return "could be worn as armour"
        if thing.query_wearable():
            return "looks like you could wear it"
        if thing.query_no_limbs() > 0:
            return "looks like you could hold it"
        return 0

    def query_container_mess(self, thing):
        """Get container capacity message for an object.
        
        @param thing the object to describe
        @return capacity string or 0 if none
        """
        volume = thing.query_max_volume()
        size = thing.query_max_size() if thing.query_container() else 0
        if size or volume:
            str_ = ""
            if size:
                str_ += f"can hold about {size // 9} pounds"
            if volume:
                if size:
                    str_ += " and "
                str_ += "can hold about "
                if volume > VOLUME_GALLON:
                    str_ += f"{(volume + VOLUME_GALLON // 2) // VOLUME_GALLON} gallons"
                elif volume >= VOLUME_QUART:
                    str_ += f"{(volume + VOLUME_QUART // 2) // VOLUME_QUART} quarts"
                elif volume >= VOLUME_PINT:
                    str_ += f"{(volume + VOLUME_PINT // 2) // VOLUME_PINT} pints"
                elif volume >= VOLUME_GILL:
                    str_ += f"{(volume + VOLUME_GILL // 2) // VOLUME_GILL} gills"
                elif volume >= VOLUME_SHOT:
                    str_ += f"{(volume + VOLUME_SHOT // 2) // VOLUME_SHOT} shots"
                else:
                    str_ += "nothing"
            return str_
        return 0

    def cmd(self, things):
        """Appraise the specified objects.
        
        @param things list of objects to appraise
        @return 1 on success, 0 on failure
        """
        if not things:
            self.driver.add_failed_mess("For some reason, you have nothing to appraise. Please bugrep this.\n", [])
            return 0
        if len(things) > 1:
            self.driver.add_failed_mess("You cannot appraise more than one object at once.\n", [])
            return 0
        thing = things[0]
        player = self.driver.this_player()
        if thing == player:
            if player.query_name() == "penguin":
                self.driver.write("Is that a tuxedo you are wearing? No, probably not.\n")
            else:
                import random
                self.driver.write(f"You appraise yourself. {random.randint(1, 10)} out of 10.\n")
            return 0
        if self.driver.environment(thing) != player:
            self.driver.add_failed_mess("You cannot appraise objects you are not carrying.\n", [])
            return 0
        if thing.query_living():
            self.driver.write(f"You appraise {thing.the_short()} and mmmm, very sexy.\n")
            return 1
        if thing.query_worn_by():
            self.driver.add_failed_mess("You cannot appraise $I while you are wearing it.\n", [thing])
            return 0
        mess = (f"{thing.the_short()} {self.query_dimensions_mess(thing)}  " 
                if not thing.query_clothing() else "")
        tmp = self.query_type_mess(thing)
        mess += f"It {self.query_appearance_mess(thing)}{' and ' + tmp if tmp else ''}."
        if tmp := self.query_container_mess(thing):
            mess += f"  It {tmp}."
        mess += f"  {thing.cond_string()}" if thing.cond_string() and thing.cond_string() != "" else "\n"
        self.driver.write(f"$P$Appraise$P${mess}")
        self.driver.add_succeeded_mess("")
        return 1

    def query_patterns(self):
        """Define command patterns for parsing.
        
        @return list of pattern tuples
        """
        return [("<indirect:object:me-here'item'>", lambda: self.cmd(self.driver.args[0]))]