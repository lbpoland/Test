# File: /home/archaon/mud/lib/cmds/player/accept.py
# Purpose: Handles player acceptance of surrender, club invites, and family relationships.
# Linked Files: Inherits from /home/archaon/mud/lib/cmds/base.py; uses /home/archaon/mud/lib/include/clubs.py, /home/archaon/mud/lib/include/broadcaster.py.
# Updated Features: None from live MUD as of March 20, 2025; functionality preserved from 2003 base.
# Translated by: Archaon

from home.archaon.mud.lib.cmds.base import Base
from home.archaon.mud.lib.include.clubs import CLUB_HANDLER, CLUB_RESPOND_TYPE, CLUB_FAMILY_RESPOND_TYPE
from home.archaon.mud.lib.include.broadcaster import BROADCASTER

class Accept(Base):
    def __init__(self, driver):
        super().__init__(driver)

    def do_surrender(self, player):
        """Accept a surrender offer from another player."""
        victims = self.driver.this_player().query_surrenderers()
        if not victims or player not in victims:
            self.driver.add_failed_mess("Sorry, but $I has not offered to surrender to you.\n", [player])
            return 0
        self.driver.this_player().remove_surrenderer(player)
        player.accepted_surrender(self.driver.this_player())
        self.driver.write("Good show!\n")
        return 1

    def do_club(self, club_name, players):
        """Accept a club invitation from specified players."""
        ok = 0
        for ob in players:
            club = self.driver.this_player().query_respond_command(CLUB_RESPOND_TYPE, ob)
            if club:
                if club.lower() == club_name.lower():
                    if CLUB_HANDLER.is_member_of(club_name, self.driver.this_player().query_name()):
                        self.driver.add_failed_mess("You are already a member of '" + 
                                                    CLUB_HANDLER.query_club_name(club_name) + "'.\n")
                    else:
                        CLUB_HANDLER.add_member(club_name, self.driver.this_player().query_name())
                        self.driver.add_succeeded_mess("$N join$s '" + 
                                                       CLUB_HANDLER.query_club_name(club_name) + 
                                                       "' with an invite from $I.\n", [ob])
                        ob.remove_respond_command(CLUB_RESPOND_TYPE, ob)
                        ok += 1
                        for item in self.driver.this_player().all_inventory():
                            item.event_joined_club(self.driver.this_player(), club_name)
                else:
                    self.driver.add_failed_mess("$I is inviting you to join '" + 
                                                CLUB_HANDLER.query_club_name(club) + 
                                                "' not '" + club_name + "'.\n", [ob])
            else:
                self.driver.add_failed_mess("$I is not inviting you to join any clubs.\n", [ob])
        return ok

    def do_family(self, family, relationship, players):
        """Accept a family relationship invitation."""
        ok = 0
        curr_family = self.driver.this_player().query_family_name()
        if curr_family:
            curr_family = CLUB_HANDLER.query_club_name(curr_family)
        relationship = CLUB_HANDLER.query_ungendered_relationship(relationship)
        if not relationship:
            self.driver.add_failed_mess("Could not figure out the relationship.\n")
            return 0
        for ob in players:
            frog = self.driver.this_player().query_respond_command(CLUB_FAMILY_RESPOND_TYPE, ob)
            if not family and frog:
                family = frog.family
            if frog and frog.family:
                if frog.family.lower() == family.lower():
                    if frog.relationship.lower() != relationship.lower():
                        self.driver.add_failed_mess("You were asked to have the relationship of '" +
                                                    CLUB_HANDLER.query_relationship_gender(frog.relationship,
                                                    self.driver.this_player().query_female()) + 
                                                    "', not '" +
                                                    CLUB_HANDLER.query_relationship_gender(relationship,
                                                    self.driver.this_player().query_female()) + 
                                                    "' in the family '" +
                                                    CLUB_HANDLER.query_club_name(frog.family) + "'.\n")
                    elif (CLUB_HANDLER.is_relationship(frog.family, self.driver.this_player().query_name(),
                                                       ob.query_name(), relationship) and 
                          frog.family == curr_family):
                        self.driver.add_failed_mess("You have already setup a relationship of '" +
                                                    CLUB_HANDLER.query_relationship_gender(relationship,
                                                    self.driver.this_player().query_female()) + 
                                                    "' with $I.\n", [ob])
                    else:
                        if not CLUB_HANDLER.is_member_of(frog.family, self.driver.this_player().query_name()):
                            if frog.family != curr_family and curr_family:
                                if not CLUB_HANDLER.move_family_member(curr_family, 
                                                                       self.driver.this_player().query_name(), 
                                                                       frog.family):
                                    self.driver.add_failed_mess("Unable to move you into the family " +
                                                                frog.family + " for some reason.\n")
                                    continue
                            else:
                                if not CLUB_HANDLER.add_member(frog.family, 
                                                               self.driver.this_player().query_name()):
                                    self.driver.add_failed_mess("Unable to add you into the family " +
                                                                frog.family + " for some reason.\n")
                                    continue
                            self.driver.this_player().set_family_name(frog.family)
                        if not CLUB_HANDLER.is_relationship(frog.family, self.driver.this_player().query_name(),
                                                            ob.query_name(), relationship):
                            if not CLUB_HANDLER.add_relationship(ob.query_family_name(), ob.query_name(),
                                                                 frog.family, self.driver.this_player().query_name(),
                                                                 relationship):
                                self.driver.add_failed_mess("Unable to add the relationship to $I for some reason.\n")
                            else:
                                self.driver.add_succeeded_mess("$N set$s up a relationship with $I in '" +
                                                               CLUB_HANDLER.query_club_name(frog.family) + 
                                                               "'.\n", [ob])
                                ok += 1
                        else:
                            self.driver.add_succeeded_mess("$N set$s up a relationship with $I in '" +
                                                           CLUB_HANDLER.query_club_name(frog.family) + 
                                                           "'.\n", [ob])
                            ok += 1
                        ob.remove_respond_command(CLUB_FAMILY_RESPOND_TYPE, ob)
                else:
                    self.driver.add_failed_mess("$I is inviting you to a relationship in '" +
                                                CLUB_HANDLER.query_club_name(frog.family) + 
                                                "' not '" + family + "'.\n", [ob])
            else:
                self.driver.add_failed_mess("$I is not inviting you to setup any relationships.\n", [ob])
        return ok

    def query_patterns(self):
        """Define command patterns for parsing."""
        return [
            ("<indirect:living:here>", lambda: self.do_surrender(self.driver.args[0][0])),
            ("invite from <indirect:living:here> to <string'club name'>", 
             lambda: self.do_club(self.driver.args[1], self.driver.args[0])),
            ("relationship from <indirect:living:here> to <string'family'> as <string'relationship'>", 
             lambda: self.do_family(self.driver.args[1], self.driver.args[2], self.driver.args[0])),
            ("relationship from <indirect:living:here> as <string'relationship'>", 
             lambda: self.do_family(self.driver.this_player().query_family_name(), self.driver.args[1], self.driver.args[0]))
        ]