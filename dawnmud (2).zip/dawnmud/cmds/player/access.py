# File: /home/archaon/mud/lib/cmds/player/access.py
# Purpose: Manages player IP access control for login restrictions.
# Linked Files: Inherits from /home/archaon/mud/lib/cmds/base.py; uses /home/archaon/mud/lib/include/drinks.py, /home/archaon/mud/lib/include/language.py, /home/archaon/mud/lib/include/player.py, /home/archaon/mud/lib/include/player_handler.py.
# Updated Features: None from live MUD as of March 20, 2025; core functionality preserved.
# Translated by: Archaon

from home.archaon.mud.lib.cmds.base import Base
from home.archaon.mud.lib.include.player_handler import PLAYER_HANDLER

class Access(Base):
    def __init__(self, driver):
        super().__init__(driver)
        self.TP = self.driver.this_player()  # Shortcut for this_player()

    def cmd_list(self):
        """List allowed IP addresses for login."""
        ips = self.TP.query_rhosts() or []
        if not ips:
            self.driver.write("You are allowed to login from anywhere.\n")
        else:
            ips.sort()
            self.driver.write(f"You are currently allowed to login from: {', '.join(ips)}.\n")
        return 1

    def enable(self, address):
        """Add an IP address to the allowed login list."""
        if self.TP.query_property("access_restricted"):
            return self.driver.notify_fail("Sorry, you are not allowed to change your access list.\n")
        ips = self.TP.query_rhosts() or []
        if address not in ips:
            ips.append(address)
            self.TP.set_rhosts(ips)
        else:
            self.driver.write(f"You are already allowed to login from {address}.\n")
        self.driver.write(f"You are now allowed to login from {address}.\n")
        return 1

    def disable(self, address):
        """Remove an IP address from the allowed login list."""
        if self.TP.query_property("access_restricted"):
            return self.driver.notify_fail("Sorry, you are not allowed to change your access list.\n")
        ips = self.TP.query_rhosts() or []
        if address in ips:
            ips.remove(address)
            self.TP.set_rhosts(ips if ips else None)
        else:
            self.driver.write(f"You are already not allowed to login from {address}.\n")
        if not ips:
            self.driver.write("You are now allowed to login from anywhere.\n")
        else:
            self.driver.write(f"You are not now allowed to login from {address}.\n")
        return 1

    def authorise_for(self, name, address):
        """Admin command to modify a player's IP access list."""
        if not self.TP.query_lord():
            return self.driver.notify_fail("You may not do this.\n")
        if self.driver.find_player(name):
            return self.driver.notify_fail("This player is online.\n")
        if not PLAYER_HANDLER.test_user(name):
            return self.driver.notify_fail("No such player.\n")
        
        self.driver.seteuid("Root")
        fname = f"/save/players/{name[0]}/{name}"
        self.driver.uncompress_file(f"{fname}.o.gz")
        file_content = self.driver.unguarded(lambda: self.driver.read_file(f"{fname}.o"))
        if not file_content:
            return self.driver.notify_fail("Error reading file.\n")

        bits = file_content.split("\n")
        var_name = "player_info "
        info = {}
        found = False
        for i, line in enumerate(bits):
            if line.startswith(var_name):
                info = self.driver.restore_variable(line[len(var_name):])
                found = True
                break
        
        if not found:
            return self.driver.notify_fail("Cannot find mapping.\n")
        
        if address == "reset":
            info["allowed_ips"] = []
        elif "allowed_ips" in info and info["allowed_ips"]:
            if address not in info["allowed_ips"]:
                info["allowed_ips"].append(address)
        else:
            info["allowed_ips"] = [address]

        if i < len(bits):
            bits[i] = var_name + self.driver.save_variable(info)
        else:
            bits.append(var_name + self.driver.save_variable(info))

        self.driver.unguarded(lambda: self.driver.rm(f"{fname}.old"))
        self.driver.unguarded(lambda: self.driver.rename(f"{fname}.o", f"{fname}.old"))
        self.driver.unguarded(lambda: self.driver.write_file(f"{fname}.o", "\n".join(bits) + "\n"))
        self.driver.compress_file(f"{fname}.o")
        self.driver.unguarded(lambda: self.driver.rm(f"{fname}.o"))
        PLAYER_HANDLER.remove_cache_entry(name)
        self.driver.tell_object(self.TP, f"Access for {name} changed.\n")
        return 1

    def query_patterns(self):
        """Define command patterns for parsing."""
        return [
            ("enable <string'address'>", lambda: self.enable(self.driver.args[0])),
            ("disable <string'address'>", lambda: self.disable(self.driver.args[0])),
            ("for <string'name'> <string'address'>", lambda: self.authorise_for(self.driver.args[0], self.driver.args[1])),
            ("reset for <string'name'>", lambda: self.authorise_for(self.driver.args[0], "reset")),
            ("", lambda: self.cmd_list())
        ]