# File: /home/archaon/mud/lib/cmds/player/birthdays.py
# Purpose: Displays players whose birthday is today.
# Linked Files: Inherits from /home/archaon/mud/lib/cmds/base.py.
# Updated Features: None from live MUD as of March 20, 2025; core functionality preserved from 2003 base.
# Translated by: Archaon

from home.archaon.mud.lib.cmds.base import Base

class Birthdays(Base):
    def __init__(self, driver):
        super().__init__(driver)

    def cmd(self):
        """Show players with a birthday today.
        
        @return 1 on success, 0 on failure
        """
        peeps = [p for p in self.driver.users() 
                 if p.query_visible(self.driver.this_player()) and p.query_is_birthday_today()]
        if not peeps:
            return self.driver.notify_fail("No one has a birthday today.\n")
        if len(peeps) == 1:
            self.driver.printf("%s has a birthday today.\n", peeps[0].short())
        else:
            self.driver.write(f"{self.driver.query_multiple_short(peeps)} have a birthday today.\n")
        return 1

    def query_patterns(self):
        """Define command patterns for parsing.
        
        @return list of pattern tuples
        """
        return [("", lambda: self.cmd())]