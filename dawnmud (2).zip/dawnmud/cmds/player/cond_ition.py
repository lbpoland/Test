# File: /home/archaon/mud/lib/cmds/player/cond_ition.py
# Purpose: Displays the condition of specified items, with sorting options.
# Linked Files: Inherits from /home/archaon/mud/lib/cmds/base.py.
# Updated Features: Verified against live MUD sources as of March 20, 2025; no significant updates noted in wiki, announcements, or blogs beyond 2003 functionality.
# Translated by: Archaon

from home.archaon.mud.lib.cmds.base import Base

class CondInfo:
    def __init__(self):
        self.cond_item = None  # Object being checked
        self.cond_string = ""  # Condition description
        self.cond_percent = 0  # Condition percentage

class Condition(Base):
    def __init__(self, driver):
        super().__init__(driver)

    def cond_colour(self, percent):
        """Determine color code based on condition percentage.
        
        @param percent the condition percentage
        @return color code string
        """
        damage = 100 - percent
        if 0 <= damage <= 50:
            return ""
        if 51 <= damage <= 60:
            return "%^CYAN%^"
        if 61 <= damage <= 70:
            return "%^GREEN%^"
        if 71 <= damage <= 80:
            return "%^YELLOW%^"
        if 81 <= damage <= 90:
            return "%^RED%^"
        return "%^BOLD%^%^RED%^"

    def is_valid_environment(self, ob):
        """Check if an object is in a valid environment (player's inventory or ground).
        
        @param ob the object to check
        @return 1 if valid, 0 if not
        """
        env = self.driver.environment(ob)
        player = self.driver.this_player()
        if env == self.driver.environment(player):
            return 1
        while env:
            if env == player:
                return 1
            env = self.driver.environment(env)
        return 0

    def cmd(self, things, dir_, no_excellent):
        """Display condition of specified items.
        
        @param things list of items to check
        @param dir_ sorting direction (1 for up, -1 for down, 0 for none)
        @param no_excellent flag to exclude excellent condition items (1 to exclude, 0 to include)
        @return 1 on success, 0 on failure
        """
        player = self.driver.this_player()
        dark = 0 if player.query_property("dead") else player.check_dark(self.driver.environment(player).query_light())
        if dark == 2:
            self.driver.add_failed_mess("It is way too bright to see anything at all.\n")
            return 0
        if dark == -2:
            self.driver.add_failed_mess("It is way too dark to see anything at all.\n")
            return 0
        
        things = [t for t in things if self.is_valid_environment(t)]
        if not things:
            self.driver.add_failed_mess("Can only check the condition of things you have in your inventory or on the ground.\n")
            return 0
        
        if len(things) == 1:
            list_ = things[0].cond_string()
            if not list_ or list_ == "":
                list_ = " has no condition.\n"
            else:
                list_ = list_[4:] if things[0].query_is_pair() else list_[2:]
            self.driver.write(f"$C${things[0].the_short()}{list_}")
            return 1
        
        info = []
        for thing in things:
            list_ = thing.cond_string()
            if list_ and list_ != "":
                list_ = list_[4:] if thing.query_is_pair() else list_[2:]
                info.append(CondInfo())
                info[-1].cond_item = thing
                info[-1].cond_string = list_
                info[-1].cond_percent = (thing.query_cond() * 100) // thing.query_max_cond()
        
        if not info:
            self.driver.add_failed_mess("None of those things has a condition.\n")
            return 0
        
        if len(info) == 1:
            self.driver.write(f"$C${info[0].cond_item.the_short()}{info[0].cond_string}")
        else:
            if dir_:
                info.sort(key=lambda x: x.cond_percent, reverse=(dir_ == -1))
            i = 0
            for new_info in info:
                if not no_excellent or new_info.cond_percent <= 90:
                    self.driver.write(f"{self.cond_colour(new_info.cond_percent)}$C${new_info.cond_item.the_short()} ({i + 1})"
                                     f"{new_info.cond_string}%^RESET%^")
                    i += 1
            if i == 0 and no_excellent:
                self.driver.write("Everything is in excellent condition.\n")
        return 1

    def query_patterns(self):
        """Define command patterns for parsing.
        
        @return list of pattern tuples
        """
        return [
            ("<indirect:object'item(s)'> sorting {up|down}", 
             lambda: self.cmd(self.driver.args[0], 1 if self.driver.args[1] == "up" else -1, 0)),
            ("<indirect:object'item(s)'>", lambda: self.cmd(self.driver.args[0], 0, 0)),
            ("<indirect:object'item(s)'> damaged", lambda: self.cmd(self.driver.args[0], 0, 1)),
            ("<indirect:object'item(s)'> damaged sorting {up|down}", 
             lambda: self.cmd(self.driver.args[0], 1 if self.driver.args[1] == "up" else -1, 1))
        ]