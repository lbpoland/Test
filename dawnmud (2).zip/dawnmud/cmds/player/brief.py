# File: /home/archaon/mud/lib/cmds/player/brief.py
# Purpose: Sets or displays brief/verbose settings for player output types.
# Linked Files: Inherits from /home/archaon/mud/lib/cmds/base.py.
# Updated Features: None from live MUD as of March 20, 2025; core functionality preserved from 2003 base.
# Translated by: Archaon

from home.archaon.mud.lib.cmds.base import Base

class Brief(Base):
    def __init__(self, driver):
        super().__init__(driver)
        self.TP = self.driver.this_player()  # Shortcut for this_player()

    def cmd(self, which, type_):
        """Set or display brief/verbose settings.
        
        @param which 'brief' or 'verbose' to set the mode
        @param type_ the specific type to set or None to display all
        @return 1 on success
        """
        if not type_:
            disp = "Your settings are: "
            for t in self.TP.query_verbose_types():
                disp += f"{t} ({'verbose' if self.TP.query_verbose(t) else 'brief'}) "
            self.driver.write(disp + "\n")
        elif type_ == "all":
            for t in self.TP.query_verbose_types():
                self.TP.set_verbose(t, which == "verbose")
            self.driver.write("Ok\n")
        elif type_ in self.TP.query_verbose_types():
            self.TP.set_verbose(type_, which == "verbose")
            self.driver.write("Ok\n")
        else:
            self.driver.write("No such option.\n")
        return 1

    def query_patterns(self):
        """Define command patterns for parsing.
        
        @return list of pattern tuples
        """
        return [
            ("<word'type'>", lambda: self.cmd("brief", self.driver.args[0])),
            ("", lambda: self.cmd("brief", None))
        ]