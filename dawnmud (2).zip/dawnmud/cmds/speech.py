# File: /home/archaon/mud/lib/cmds/speech.py
# Purpose: Handles player speech commands (e.g., say, shout), including language and emote processing.
# Linked Files: Uses /home/archaon/mud/lib/include/language.py, /home/archaon/mud/lib/include/player.py, /home/archaon/mud/lib/include/drinks.py, /home/archaon/mud/lib/include/cmds/options.py.
# Updated Features: Language handling updated per Aethoria skill tree (March 20, 2025); no specific live MUD updates beyond skill tree noted.
# Translated by: Archaon

from home.archaon.mud.lib.include.language import LANGUAGE_HAND, LANGUAGES
from home.archaon.mud.lib.include.player import SHORTHAND_PROP
from home.archaon.mud.lib.include.drinks import D_ALCOHOL
import random

BEEP = chr(7)
CTRL = chr(13)
REPLACEMENTS = {
    "ne1": "anyone", "u": "you", "r": "are", "NE1": "anyone", "U": "you",
    "R": "are", "ur": "you are", "teh": "the", "some1": "someone"
}

class Message:
    def __init__(self):
        self.text = ""
        self.emote = ""
        self.language = ""
        self.type = ""
        self.notify_mess = ""
        self.status = 0

# Status constants
NO_MESSAGE = 0
NOT_SPOKEN = 1
NOT_KNOWN = 2
NOT_DISTANCE = 3
MESSAGE_OK = 4

class Speech:
    def __init__(self, driver):
        self.driver = driver
        self.TP = self.driver.this_player()  # Shortcut for this_player()

    def query_word_type(self, str_, def_=None):
        """Determine the type of speech based on punctuation.
        
        @param str_ the input string to analyze
        @param def_ default type if no specific punctuation found
        @return the determined speech type
        """
        if not str_ or len(str_.strip()) < 1:
            return ""
        i = len(str_.rstrip()) - 1
        if i < 0:
            return "discombobulate"
        if str_[i] == '!':
            return "exclaim"
        elif str_[i] == '?':
            return "ask"
        return def_ or "say"

    def mangle_tell(self, mess, dest):
        """Modify tell messages based on environment properties.
        
        @param mess the message to mangle
        @param dest the destination object
        @return the mangled message
        """
        if not self.TP or not self.driver.environment(self.TP):
            return mess
        env = self.driver.environment(self.TP)
        if (env.query_property("reverse_tell") and 
            not dest.query_creator() and 
            not self.TP.query_creator()):
            return mess[::-1]  # Reverse the string
        return mess

    def drunk_speech(self, str_):
        """Alter speech when drunk.
        
        @param str_ the input string to modify
        @return the modified drunk speech string
        """
        replacements = {"S": "sh", "r": "rr", "ing": "in'", "x": "xsh", "R": "RR"}
        for old, new in replacements.items():
            str_ = str_.replace(old, new)
        return str_

    def de_eight(self, arg):
        """Replace 'eight' or '8' for wizards guild members.
        
        @param arg the input string to modify
        @return the modified string
        """
        g = self.TP.query_guild_ob()
        if g and g.query_name() == "wizards" and not self.TP.query_creator():
            arg = f"@ {arg} @"
            replace_num = [" seven plus one", " nine minus one", 
                          " two to the power of three", " four times two"]
            replace_exp = ["(7+1)", "(9-1)", "(2^3)", "(4*2)"]
            choice = random.randint(0, 3)
            arg = arg.replace(" eight", replace_num[choice]).replace("8", replace_exp[choice])
            return arg[2:-2]
        return arg

    def fix_shorthand(self, mess):
        """Expand shorthand notations in speech.
        
        @param mess the input message to expand
        @return the expanded message
        """
        bits = mess.split()
        for name, value in REPLACEMENTS.items():
            for i, bit in enumerate(bits):
                if name in bit:
                    bits[i] = bit.replace(name, value)
        return " ".join(bits)

    def my_mess(self, fish, erk):
        """Display a formatted message to the player.
        
        @param fish the prefix message
        @param erk the main message content
        """
        if not self.TP.query_interactive():
            return
        bing = min(len(fish), 15)
        self.driver.tell_object(self.TP, self.TP.fix_string(f"{fish}{erk}\n", self.TP.query_cols(), bing))

    def build_message(self, arg, target, word_type):
        """Construct a message object with language and emote handling.
        
        @param arg the input argument string
        @param target the target of the message (if any)
        @param word_type the type of speech (e.g., say, tell)
        @return a Message object
        """
        mess = Message()
        if not arg or arg.strip() in ("", " "):
            mess.status = NO_MESSAGE
            return mess
        lang, emotion = None, ""
        done = False
        while not done and (not lang or not emotion):
            if not arg:
                done = True
                break
            if arg[0] == '#' and word_type != "tell":
                if arg.startswith("#'") and "' " in arg:
                    lang, arg = arg[2:].split("' ", 1)
                elif " " in arg:
                    lang, arg = arg[1:].split(" ", 1)
                    langs = LANGUAGE_HAND.query_languages()
                    if lang not in langs:
                        for l in langs:
                            spoken_skill = LANGUAGE_HAND.query_language_spoken_skill(l)
                            written_skill = LANGUAGE_HAND.query_language_written_skill(l)
                            if (self.TP.query_skill(spoken_skill) > 1 or 
                                self.TP.query_skill(written_skill) > 1):
                                if l.startswith(lang):
                                    lang = l
                                    break
                else:
                    done = True
            elif arg[0] == '@' and " " in arg:
                emotion, arg = arg[1:].split(" ", 1)
                emotion += " "
            else:
                done = True
        mess.emote = emotion or ""
        if lang == "general" and self.TP.query_interactive() and not self.TP.query_creator():
            mess.status = NOT_KNOWN
            return mess
        mess.language = lang or self.TP.query_current_language()
        if not LANGUAGE_HAND.query_language_spoken(mess.language):
            mess.status = NOT_SPOKEN
            return mess
        if word_type == "shout" and not LANGUAGE_HAND.query_language_distance(mess.language):
            mess.status = NOT_DISTANCE
            return mess
        spoken_skill = LANGUAGE_HAND.query_language_spoken_skill(mess.language)
        if (word_type != "tell" and 
            not self.TP.query_skill(spoken_skill) and 
            not LANGUAGE_HAND.query_language_always_spoken(mess.language)):
            mess.status = NOT_KNOWN
            return mess
        if not self.TP.query_interactive():
            arg = self.TP.convert_message(arg)
            arg = self.TP.fit_message(arg)
        arg = arg.replace(BEEP, "").replace(CTRL, "").replace("[A", "").replace("[B", "").replace("[C", "").replace("[D", "").replace("%^", " ")
        if self.TP.query_property(SHORTHAND_PROP):
            arg = self.fix_shorthand(arg)
        if word_type != "tell":
            if self.TP.query_volume(D_ALCOHOL):
                arg = self.drunk_speech(arg)
            s1 = self.TP.mangle_speech(arg)
            if isinstance(s1, str):
                arg = s1
            env = self.driver.environment(self.TP)
            if env and hasattr(env, "mangle_speech"):
                arg = env.mangle_speech(word_type, arg, target)
            arg = self.de_eight(arg)
        mess.type = self.query_word_type(arg, word_type)
        mess.text = arg
        mess.status = MESSAGE_OK
        target_str = f" $target$: " if target else ": "
        mess.notify_mess = f"$one_short:{self.driver.file_name(self.TP)}$ {mess.emote}$V$0={mess.type}s,{mess.type}$V${target_str}"
        return mess

    def say_it(self, mess):
        """Execute a general speech action (e.g., say, shout).
        
        @param mess the Message object to process
        @return success indicator
        """
        if not self.driver.environment(self.TP):
            self.driver.write("You are in limbo, noone can hear you.\n")
        if mess.status == NO_MESSAGE:
            return self.driver.notify_fail(f"Syntax: {self.driver.query_verb()} <something>\n")
        elif mess.status == NOT_SPOKEN:
            return self.driver.notify_fail(f"{mess.language.capitalize()} is not a spoken language.\n")
        elif mess.status == NOT_KNOWN:
            return self.driver.notify_fail(f"You cannot speak {mess.language.capitalize()}.\n")
        self.TP.remove_hide_invis("hiding")
        accent = self.TP.query_nationality_accent_ob()
        self.TP.comm_event(self.driver.environment(self.TP), "person_say", 
                          mess.notify_mess, mess.text, mess.language, accent)
        lang_str = f" in {mess.language.capitalize()}" if mess.language not in (self.TP.query_default_language(), "general") else ""
        self.my_mess(f"You {mess.emote}{mess.type}{lang_str}: ", mess.text)
        self.TP.adjust_time_left(-5)
        return 1

    def say_it_to(self, mess, targets, priv, event):
        """Execute a directed speech action (e.g., tell, whisper).
        
        @param mess the Message object to process
        @param targets list of target objects
        @param priv privacy level (0=public, 1=exclude targets, 2=private)
        @param event the event type to trigger
        @return success indicator
        """
        if not self.driver.environment(self.TP):
            self.driver.write("You are in limbo, noone can hear you.\n")
        if mess.status == NO_MESSAGE:
            return self.driver.notify_fail(f"Syntax: {self.driver.query_verb()} <something>\n")
        elif mess.status == NOT_SPOKEN:
            return self.driver.notify_fail(f"{mess.language.capitalize()} is not a spoken language.\n")
        elif mess.status == NOT_KNOWN:
            return self.driver.notify_fail(f"You cannot speak {mess.language.capitalize()}.\n")
        if not targets:
            return 0
        targets = [t for t in targets if t != self.TP]
        self.TP.remove_hide_invis("hiding")
        self.TP.adjust_time_left(-5)
        accent = self.TP.query_nationality_accent_ob()
        extra = "to " if mess.type in ("exclaim", "whisper", "say") else ""
        if priv == 0:
            self.TP.comm_event(self.driver.environment(self.TP), event,
                              f"$one_short:{self.driver.file_name(self.TP)}$ {mess.emote}$V$0={mess.type}s,{mess.type}$V$ {extra}{self.driver.query_multiple_short(targets, 'the')}: ",
                              mess.text, mess.language, accent)
        elif priv == 1:
            self.TP.comm_event_to(self.driver.environment(self.TP), event,
                                 f"{self.TP.one_short(1)} {mess.emote}{mess.type}s {extra}",
                                 mess.text, targets, mess.language, self.TP, accent)
        lang_str = f" in {LANGUAGES.cap_words(mess.language)}" if mess.language not in (self.TP.query_default_language(), "general") else ""
        self.driver.write(f"You {mess.emote}{mess.type} {extra}{self.driver.query_multiple_short(targets, 'the')}{lang_str}: {mess.text}\n")
        return 1