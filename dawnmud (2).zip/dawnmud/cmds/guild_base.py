# File: /home/archaon/mud/lib/cmds/guild_base.py
# Purpose: Base class for guild-related commands, handling teaching and help functionality.
# Linked Files: Inherits from /home/archaon/mud/lib/cmds/base.py; uses /home/archaon/mud/lib/include/nroff.py.
# Updated Features: None from live MUD as of March 20, 2025; foundational guild command logic preserved.
# Translated by: Archaon

from home.archaon.mud.lib.cmds.base import Base
from home.archaon.mud.lib.include.nroff import NROFF_HAND, NROFF_DIR, NROFF_SOURCE

class TeachSkill:
    def __init__(self):
        self.skill = ""
        self.teach = 0
        self.learn = 0

class GuildBase(Base):
    def __init__(self, driver):
        super().__init__(driver)
        self._teach_skills = []  # List of TeachSkill objects
        self._nroff_fname = None
        self._command_name = None
        self._teach_guild = None

    def create(self):
        """Initialize guild command with empty teach skills list."""
        self._teach_skills = []

    def set_nroff_file(self, fname):
        """Set the nroff help file path."""
        self._nroff_fname = fname

    def query_nroff_file(self):
        """Get the nroff help file path."""
        return self._nroff_fname

    def nroff_file(self, name, html=False):
        """Retrieve or generate nroff help content."""
        if not name.startswith('/'):
            name = NROFF_SOURCE + name
        nroff_fn = NROFF_DIR + name.replace('/', '.')
        if html:
            content = NROFF_HAND.html_file(nroff_fn, 1)
        else:
            content = NROFF_HAND.cat_file(nroff_fn, 1)
        if not content:
            NROFF_HAND.create_nroff(name, nroff_fn)
            content = NROFF_HAND.html_file(nroff_fn, 0) if html else NROFF_HAND.cat_file(nroff_fn, 0)
        return content

    def help_function(self):
        """Return a function to retrieve help content if nroff file is set."""
        if self._nroff_fname:
            return lambda: self.nroff_file(self._nroff_fname, 0)
        return None

    def help(self):
        """Return help content as a string."""
        if self._nroff_fname:
            return self.nroff_file(self._nroff_fname, 0)
        return None

    def query_www_help(self):
        """Return HTML help content for web clients."""
        if self._nroff_fname:
            return self.nroff_file(self._nroff_fname, 1)
        return None

    def add_teach_skill(self, skill, teach, learn):
        """Add a teachable skill with required levels."""
        bing = TeachSkill()
        bing.skill = skill
        bing.teach = teach
        bing.learn = learn
        self._teach_skills.append(bing)

    def query_teach_skills(self):
        """Get the list of teachable skills."""
        return self._teach_skills

    def set_command_name(self, name):
        """Set the command name for teaching."""
        self._command_name = name

    def query_command_name(self):
        """Get the command name."""
        return self._command_name

    def set_teach_guild(self, guild):
        """Set the guild restriction for teaching."""
        self._teach_guild = guild

    def query_teach_guild(self):
        """Get the guild restriction."""
        return self._teach_guild

    def can_teach_command(self, teacher, student):
        """Check if teacher can teach the command to student."""
        if not self._teach_skills or not self._command_name:
            return 0
        for bing in self._teach_skills:
            if teacher.query_skill(bing.skill) < bing.teach:
                return -1  # Teacher lacks required skill level
            if student.query_skill(bing.skill) < bing.learn:
                return -2  # Student lacks required skill level
        if self._teach_guild and student.query_guild_ob() != self._teach_guild:
            return -3  # Student not in required guild
        return 1  # All conditions met

    def teach_command(self, teacher, student):
        """Teach the command to the student if conditions are met."""
        ret = self.can_teach_command(teacher, student)
        if ret == 1:
            student.add_known_command(self._command_name)
        return ret