# File: /home/archaon/mud/lib/cmds/report_base.py
# Purpose: Base class for reporting bugs, ideas, and typos, with specific handling for various game elements.
# Linked Files: Inherits from /home/archaon/mud/lib/cmds/base.py and /home/archaon/mud/lib/cmds/bug_replies.py; uses /home/archaon/mud/lib/include/creator.py, /home/archaon/mud/lib/include/log.py, /home/archaon/mud/lib/include/command.py, /home/archaon/mud/lib/include/spells.py, /home/archaon/mud/lib/include/user_parser.py, /home/archaon/mud/lib/include/soul.py, /home/archaon/mud/lib/include/error_handler.py.
# Updated Features: None from live MUD as of March 20, 2025; core functionality preserved from 2003 base with inherited bug_replies functionality.
# Translated by: Archaon

from home.archaon.mud.lib.cmds.base import Base
from home.archaon.mud.lib.cmds.bug_replies import BugReplies
from home.archaon.mud.lib.include.creator import CMD_D
from home.archaon.mud.lib.include.log import SMART_LOG
from home.archaon.mud.lib.include.command import Command
from home.archaon.mud.lib.include.spells import S_OBJECT
from home.archaon.mud.lib.include.user_parser import SOUL_OBJECT
from home.archaon.mud.lib.include.error_handler import ERROR_HANDLER

SYNONYMS = "/home/archaon/mud/lib/doc/SYNONYMS"

class Errors:
    def __init__(self):
        self.type = 0      # Type of error (e.g., ROOM_BUG)
        self.file = ""     # File path related to the error
        self.error = ""    # Error description
        self.extra = ""    # Additional info

# Error type constants
ROOM_BUG = 1
OBJECT_BUG = 2
RITUAL_BUG = 3
SPELL_BUG = 4
HELP_BUG = 5
COMMAND_BUG = 6
GENERAL_BUG = 7
WEB_BUG = 8

class ReportBase(Base, BugReplies):
    def __init__(self, driver):
        Base.__init__(self, driver)
        BugReplies.__init__(self, driver)
        self._globals = {}         # Mapping of players to Errors objects
        self._error_type = ""      # Type of report (e.g., BUG, IDEA)
        self._use_last_error = 0   # Flag to include last error trace

    def create(self):
        """Initialize report base and bug replies."""
        BugReplies.create(self)
        self._globals = {}

    def set_error_type(self, type_):
        """Set the type of error report.
        
        @param type_ the error type string (e.g., BUG, IDEA)
        """
        self._error_type = type_

    def set_use_last_error(self, error):
        """Set whether to use the last error trace.
        
        @param error flag (1 to use, 0 to not use)
        """
        self._use_last_error = error

    def query_use_last_error(self):
        """Get the use last error flag.
        
        @return the flag value
        """
        return self._use_last_error

    def bug_room(self):
        """Report a room-related issue."""
        player = self.driver.this_player()
        env = self.driver.environment(player)
        file_path = self.driver.file_name(env) if env else "/home/archaon/mud/lib/d/mudlib/void"
        self._globals[player] = Errors()
        self._globals[player].type = ROOM_BUG
        self._globals[player].error = f"ROOM {self._error_type}"
        self._globals[player].file = file_path
        player.do_edit(None, lambda body: self.end_of_edit(body))
        return 1

    def bug_special(self, which):
        """Report a special area issue.
        
        @param which the special area identifier
        """
        player = self.driver.this_player()
        self._globals[player] = Errors()
        self._globals[player].type = GENERAL_BUG
        self._globals[player].error = f"GENERAL {self._error_type}"
        self._globals[player].file = f"/home/archaon/mud/lib/d/special/{which}/BugReports"
        player.do_edit(None, lambda body: self.end_of_edit(body))
        return 1

    def bug_misc(self, which):
        """Report a miscellaneous object issue.
        
        @param which the object identifier
        """
        player = self.driver.this_player()
        self._globals[player] = Errors()
        self._globals[player].type = GENERAL_BUG
        self._globals[player].error = f"GENERAL {self._error_type}"
        self._globals[player].file = f"/home/archaon/mud/lib/obj/{which}/BugReports"
        player.do_edit(None, lambda body: self.end_of_edit(body))
        return 1

    def bug_general(self):
        """Report a general issue."""
        player = self.driver.this_player()
        env = self.driver.environment(player)
        dir = self.driver.file_name(env) if env else "/home/archaon/mud/lib/d/am/fluff"
        bits = dir.split('/')
        file_path = '/'.join(bits[:2]) + "/general" if bits[0] == "d" else dir
        self._globals[player] = Errors()
        self._globals[player].type = GENERAL_BUG
        self._globals[player].error = f"GENERAL {self._error_type}"
        self._globals[player].file = file_path
        player.do_edit(None, lambda body: self.end_of_edit(body))
        return 1

    def bug_command(self, str_):
        """Report a command-related issue.
        
        @param str_ the command name
        """
        player = self.driver.this_player()
        bing = Errors()
        actions = self.driver.actions_defined(player, 0, 12)
        coms = [actions[i:i+2] for i in range(0, len(actions), 2) if actions[i] == str_]
        if len(coms) > 1:
            return self.driver.notify_fail(f"More than one commands with the name \"{str_}\" found. Please be more specific.\n")
        if coms:
            bing.file = self.driver.function_exists(coms[0][1][0], coms[0][1][1])
            if not bing.file:
                bing.file = self.driver.base_name(coms[0][1][1])
                str_ += " (protected method, so it might not be in this file)"
        else:
            cmd = Command(verb=str_)
            paths = CMD_D.GetPaths(cmd.verb) if CMD_D.HandleStars(cmd) else []
            search_paths = player.GetSearchPath()
            coms = [p for p in paths if p in search_paths]
            if coms:
                bing.file = f"{coms[0]}/{cmd.verb}"
            else:
                cmd_class = player.query_parse_command(str_)
                if cmd_class:
                    temp = cmd_class.patterns
                    cmd_data = temp[list(temp.keys())[0]]
                    bing.file = self.driver.base_name(cmd_data.calls[0])
                elif SOUL_OBJECT.query_soul_command(str_):
                    bing.file = f"/home/archaon/mud/lib/soul/{str_[0]}/{str_}"
                elif self._error_type == "IDEA":
                    dir = self.driver.file_name(self.driver.environment(player))
                    bits = dir.split('/')
                    bing.file = '/'.join(bits[:2]) + "/general" if bits[0] == "d" else dir
                else:
                    return self.driver.notify_fail(f"Command {str_} not found.\n")
        bing.error = f"COMMAND {self._error_type} {str_}"
        bing.type = COMMAND_BUG
        self._globals[player] = bing
        player.do_edit(None, lambda body: self.end_of_edit(body))
        return 1

    def bug_help(self, str_):
        """Report a help file issue.
        
        @param str_ the help subject
        """
        player = self.driver.this_player()
        bing = Errors()
        help_cmd = self.driver.find_object("/home/archaon/mud/lib/cmds/player/help")
        tmp = help_cmd.query_synonym(str_) if str_ else ""
        str_ = tmp if tmp else str_
        stuff = help_cmd.query_help_on(str_) if str_ else []
        if not stuff:
            if not SOUL_OBJECT.query_soul_command(str_):
                return self.driver.notify_fail(f"Could not find the help file '{str_}'. If you wish to suggest a new command use 'idea help'\n")
            bing.file = f"/home/archaon/mud/lib/soul/{str_}"
        else:
            bing.file = stuff[0][0].split(' (')[1][:-1]  # Extract file from "(file)" format
        bing.error = f"HELP {self._error_type} {str_}"
        bing.type = HELP_BUG
        self._globals[player] = bing
        player.do_edit(None, lambda body: self.end_of_edit(body))
        return 1

    def bug_soul(self, str_):
        """Report a soul command issue.
        
        @param str_ the soul command name
        """
        player = self.driver.this_player()
        bing = Errors()
        if str_:
            tmp = f"/home/archaon/mud/lib/soul/{str_[0]}/{str_}.s"
            if self.driver.file_size(tmp) < 1:
                return self.driver.notify_fail(f"No such soul command \"{str_}\".\n")
            return self.bug_command(str_)
        bing.file = "/home/archaon/mud/lib/soul/ideas"
        bing.error = f"COMMAND {self._error_type} {str_}"
        bing.type = COMMAND_BUG
        self._globals[player] = bing
        player.do_edit(None, lambda body: self.end_of_edit(body))
        return 1

    def bug_ritual(self, str_):
        """Report a ritual-related issue.
        
        @param str_ the ritual name
        """
        player = self.driver.this_player()
        bing = Errors()
        str_ = player.expand_nickname(str_)
        junk = player.query_spells()
        file = None
        for sname, data in junk.items():
            if sname.lower() == str_.lower():
                file = data[S_OBJECT] if len(data) > S_OBJECT else self.driver.file_name(self.driver.environment(player))
                break
        if not file:
            del self._globals[player]
            return self.driver.notify_fail(f"Ritual {str_} not found.\n")
        bing.file = file
        bing.error = f"RITUAL {self._error_type} {str_}"
        bing.type = RITUAL_BUG
        self._globals[player] = bing
        player.do_edit(None, lambda body: self.end_of_edit(body))
        return 1

    def bug_web(self, url):
        """Report a web-related issue.
        
        @param url the URL related to the issue
        """
        player = self.driver.this_player()
        bing = Errors()
        bing.file = "/home/archaon/mud/lib/www/fluff"
        bing.error = f"OBJECT {self._error_type} {url}"
        bing.type = WEB_BUG
        self._globals[player] = bing
        player.do_edit(f"Url: {url}\n\n", lambda body: self.end_of_edit(body))
        return 1

    def bug_spell_file(self, file, name):
        """Report a spell file issue.
        
        @param file the spell file path
        @param name the spell name
        """
        player = self.driver.this_player()
        bing = Errors()
        bing.file = file
        bing.error = f"SPELL {self._error_type} {name}"
        bing.type = SPELL_BUG
        self._globals[player] = bing
        player.do_edit(None, lambda body: self.end_of_edit(body))
        return 1

    def bug_spell(self, str_):
        """Report a spell-related issue.
        
        @param str_ the spell name
        """
        player = self.driver.this_player()
        if str_ in ("wizards", "witches"):
            return self.bug_spell_file(f"/home/archaon/mud/lib/obj/spells/{str_}", str_)
        str_ = player.expand_nickname(str_)
        junk = player.query_spells()
        file = None
        for sname, data in junk.items():
            if sname.lower() == str_.lower() and isinstance(data, list):
                file = data[S_OBJECT]
                break
        if not file:
            del self._globals[player]
            return self.driver.notify_fail(f"Spell {str_} not found.\n")
        return self.bug_spell_file(file, str_)

    def bug_object_new(self, name):
        """Report a new object issue.
        
        @param name the object name
        """
        player = self.driver.this_player()
        bing = Errors()
        bing.file = self.driver.base_name(self.driver.environment(player))
        bing.error = f"OBJECT {self._error_type} {name}"
        bing.type = OBJECT_BUG
        self._globals[player] = bing
        player.do_edit(None, lambda body: self.end_of_edit(body))
        return 1

    def bug_object(self, obj, str_):
        """Report an object-related issue.
        
        @param obj list of objects (expected single object)
        @param str_ the object identifier
        """
        player = self.driver.this_player()
        if len(obj) > 1:
            del self._globals[player]
            return self.driver.notify_fail(f"More than one object can be identified with the name {str_}\n")
        bing = Errors()
        bing.file = self.driver.base_name(obj[0])
        info = ""
        if bing.file == "/home/archaon/mud/lib/std/room/basic/item":
            bing.file = self.driver.base_name(self.driver.environment(player))
            info = f"Room item {str_}.\n\n"
        elif bing.file == "/home/archaon/mud/lib/std/bit":
            bing.file = "/home/archaon/mud/lib/std/races/happy_bit"
        elif bing.file in ("/home/archaon/mud/lib/std/book", "/home/archaon/mud/lib/obj/armour", 
                          "/home/archaon/mud/lib/obj/baggage", "/home/archaon/mud/lib/obj/clothing", 
                          "/home/archaon/mud/lib/obj/container", "/home/archaon/mud/lib/obj/food", 
                          "/home/archaon/mud/lib/obj/monster", "/home/archaon/mud/lib/obj/weapon", 
                          "/home/archaon/mud/lib/std/object"):
            if obj[0].query_property("virtual name"):
                bing.file = obj[0].query_property("virtual name")
                info = f"VObject: {bing.file}, Object: {self.driver.base_name(obj[0])}\nName: {obj[0].query_name()}, Short: {obj[0].query_short()}\n\n"
            else:
                bing.file = self.driver.base_name(self.driver.environment(player))
        else:
            bits = bing.file.split('/')
            name = bits[1] if len(bits) > 1 else bits[0]
            if name in ("obj", "std") and (len(bits) == 2 or bits[2] not in ("food", "armours", "weapons", 
                                                                            "amulets", "monster", "music", 
                                                                            "plants", "rings", "furnitures", 
                                                                            "jewellery", "wands")):
                bing.file = self.driver.base_name(self.driver.environment(player))
            name = obj[0].query_name()[0] if isinstance(obj[0].query_name(), list) else obj[0].query_name() or "<Bad name>"
            short = obj[0].query_short() or "<Bad short>"
            info = f"Name: {name}, Short: {short}\n\n"
        bing.error = f"OBJECT {self._error_type} {str_}"
        bing.type = OBJECT_BUG
        bing.extra = info
        self._globals[player] = bing
        player.do_edit(None, lambda body: self.end_of_edit(body))
        return 1

    def end_of_edit(self, body):
        """Finalize and log the report.
        
        @param body the report content
        """
        player = self.driver.this_player()
        if body and body.strip():
            bing = self._globals[player]
            if bing.extra:
                body = bing.extra + body
            if body[-1] != '\n':
                body += "\n"
            env = self.driver.environment(player)
            if env:
                body += f"\nEnvironment: {self.driver.file_name(env)} ({env.short()})\n"
            trace = ""
            if self._use_last_error:
                last_error = player.get_last_error()
                if isinstance(last_error, dict):
                    trace = self.driver.master().standard_trace(last_error, 1)
                    player.set_last_error(None)
            name = player.query_name()
            SMART_LOG.smart_log(bing.error, name, body, trace, bing.file)
            self.driver.printf("Thank you for your %s report.\n", self._error_type.lower())
        else:
            self.driver.printf("Not saving %s report, aborting.\n", self._error_type.lower())
        del self._globals[player]

    def clean_up(self):
        """Override cleanup to prevent destruction.
        
        @return 0 to indicate no cleanup
        """
        return 0

    def reset(self):
        """Override reset to do nothing."""
        pass

    def query_patterns(self):
        """Define command patterns for parsing.
        
        @return list of pattern tuples
        """
        special_dirs = [d for d in self.driver.get_dir("/home/archaon/mud/lib/d/special/") 
                       if self.driver.file_size(f"/home/archaon/mud/lib/d/special/{d}/BugReports") >= 0]
        misc_dirs = [d for d in self.driver.get_dir("/home/archaon/mud/lib/obj/") 
                    if self.driver.file_size(f"/home/archaon/mud/lib/obj/{d}/BugReports") >= 0]
        return [
            ("command <string'name'>", lambda: self.bug_command(self.driver.args[0])),
            ("replies", lambda: self.bug_replies(0)),
            ("replies new", lambda: self.bug_replies(1)),
            ("web <string'url'>", lambda: self.bug_web(self.driver.args[0])),
            ("spell <string'name'>", lambda: self.bug_spell(self.driver.args[0])),
            ("spell {generic|wizards|witches}", 
             lambda: self.bug_spell_file(f"/home/archaon/mud/lib/obj/spells/{self.driver.args[0]}", self.driver.args[0])),
            ("spell new", lambda: self.bug_spell_file("/home/archaon/mud/lib/obj/spells/generic", "generic")),
            ("object new", lambda: self.bug_object_new("new")),
            ("object name <string'name'>", lambda: self.bug_object_new(self.driver.args[0])),
            ("object <indirect:object:me-here'name of NPC or item'>", 
             lambda: self.bug_object(self.driver.args[0], self.driver.args[1])),
            ("ritual <string'name'>", lambda: self.bug_ritual(self.driver.args[0])),
            ("ritual generic", lambda: self.bug_spell_file("/home/archaon/mud/lib/obj/rituals/generic", "generic")),
            ("ritual new", lambda: self.bug_spell_file("/home/archaon/mud/lib/obj/rituals/generic", "generic")),
            ("help <string'subject'>", lambda: self.bug_help(self.driver.args[0])),
            ("help", lambda: self.bug_help("")),
            ("soul <string'soul command'>", lambda: self.bug_soul(self.driver.args[0])),
            ("soul new", lambda: self.bug_soul(None)),
            ("room", lambda: self.bug_room()),
            (f"special {{{'|'.join(special_dirs)}}}", lambda: self.bug_special(self.driver.args[0])),
            (f"misc {{{'|'.join(misc_dirs)}}}", lambda: self.bug_misc(self.driver.args[0]))
        ]