# File: /home/archaon/mud/lib/cmds/bug_replies.py
# Purpose: Handles bug reply management for players, including listing, reading, deleting, and replying to bug reports.
# Linked Files: Uses /home/archaon/mud/lib/include/error_handler.py, /home/archaon/mud/lib/include/db.py, /home/archaon/mud/lib/include/nroff.py.
# Updated Features: None from live MUD as of March 20, 2025; core functionality preserved from 2003 base.
# Translated by: Archaon

from home.archaon.mud.lib.include.error_handler import ERROR_HANDLER
from home.archaon.mud.lib.include.db import DB_SUCCESS
from home.archaon.mud.lib.include.nroff import NROFF_HAND

HELP_FILE = "/home/archaon/mud/lib/doc/helpdir/bug_replies"

class PlayerData:
    def __init__(self):
        self.position = 0  # Current selected position in reply list
        self.date = 0      # Timestamp of reply retrieval
        self.replys = []   # List of ErrorReplies objects

class ErrorReplies:
    def __init__(self):
        self.id = 0        # Unique identifier for the reply
        self.status = ""   # Status (e.g., NEW, READ, DELETED)
        self.sender = ""   # Sender of the reply
        self.subject = ""  # Subject line
        self.message = ""  # Reply message content
        self.senddate = 0  # Timestamp of sending

class BugReplies:
    def __init__(self, driver):
        self.driver = driver
        self._player_replies = {}  # Mapping of player objects to PlayerData

    def create(self):
        """Initialize the bug replies mapping."""
        self._player_replies = {}

    def print_bug_replies(self, player):
        """Display a list of bug replies for the player.
        
        @param player the player object to display replies for
        """
        replies = self._player_replies[player].replys
        if not replies:
            self.driver.tell_object(player, "No bug replies.\n")
            return
        pos = self._player_replies[player].position
        str_ = ""
        for i, reply in enumerate(replies):
            prefix = ">" if i == pos else " "
            status_char = "N" if reply.status == "NEW" else "D" if reply.status == "DELETED" else " "
            str_ += f"{prefix}{status_char}{i + 1}) {reply.sender} Sub: {reply.subject}\n"
        player.set_finish_func(lambda: self.finish_more_replies(), self)
        self.driver.tell_object(player, f"$P$Bug replies$P${str_}")

    def finish_more_replies(self):
        """Callback after displaying replies to prompt for input."""
        self.print_menu_input()

    def print_menu(self, player):
        """Display the command menu for bug replies.
        
        @param player the player object to display menu for
        """
        len_ = len(self._player_replies[player].replys)
        prompt = f"[1-{len_}] QDRULH?<num>: " if len_ else "[None] QDRULH?<num>: "
        self.driver.tell_object(player, prompt)

    def delete_message(self, start_pos, end_pos):
        """Mark messages as deleted.
        
        @param start_pos starting position of messages to delete
        @param end_pos ending position of messages to delete
        """
        player = self.driver.this_player()
        for pos in range(start_pos - 1, end_pos):
            ERROR_HANDLER.do_status_error_reply(self._player_replies[player].replys[pos].id, "DELETED", lambda: 1)
            self._player_replies[player].replys[pos].status = "DELETED"
        msg = (f"Delete error reply {start_pos} from {end_pos}.\n" if start_pos != end_pos 
               else f"Delete error reply {end_pos}.\n")
        self.driver.write(msg)

    def undelete_message(self, start_pos, end_pos):
        """Mark messages as read (undelete).
        
        @param start_pos starting position of messages to undelete
        @param end_pos ending position of messages to undelete
        """
        player = self.driver.this_player()
        for pos in range(start_pos - 1, end_pos):
            ERROR_HANDLER.do_status_error_reply(self._player_replies[player].replys[pos].id, "READ", lambda: 1)
            self._player_replies[player].replys[pos].status = "READ"
        msg = (f"Undelete error reply {start_pos} from {end_pos}.\n" if start_pos != end_pos 
               else f"Undelete error reply {end_pos}.\n")
        self.driver.write(msg)

    def valid_message(self, pos):
        """Check if a message position is valid.
        
        @param pos the position to validate
        @return 1 if valid, 0 if not
        """
        pos -= 1
        player = self.driver.this_player()
        return 0 <= pos < len(self._player_replies[player].replys)

    def print_menu_input(self):
        """Prompt for menu input."""
        self.print_menu(self.driver.this_player())
        self.driver.input_to(self.bug_replies_menu)

    def read_message(self, pos):
        """Display a specific message.
        
        @param pos the position of the message to read
        """
        pos -= 1
        player = self.driver.this_player()
        reply = self._player_replies[player].replys[pos]
        player.set_finish_func(lambda: self.print_menu_input(), self)
        player.more_string(f"Date Sent: {self.driver.ctime(reply.senddate)}\n"
                          f"From: {reply.sender}\n"
                          f"Subject: {reply.subject}\n\n{reply.message}\n")
        if reply.status == "NEW":
            ERROR_HANDLER.do_status_error_reply(reply.id, "READ", lambda: 1)
            reply.status = "READ"

    def read_next_new(self):
        """Read the next unread message.
        
        @return 1 if a new message was read, 0 if none found
        """
        player = self.driver.this_player()
        replies = self._player_replies[player].replys
        for i, reply in enumerate(replies):
            if reply.status == "NEW":
                self.read_message(i + 1)
                return 1
        self.driver.write("No new unread error replies.\n")
        return 0

    def finish_editing_message(self, mess, pos):
        """Handle completion of reply editing.
        
        @param mess the edited message content
        @param pos the position of the original message
        """
        player = self.driver.this_player()
        if not mess or not mess.strip():
            self.driver.write("Aborting send of message.\n")
        else:
            reply = self._player_replies[player].replys[pos]
            ERROR_HANDLER.do_add_error_reply(reply.id, player.query_name(), reply.sender, 
                                            f"Re: {reply.subject}", mess)
            self.driver.write(f"Sent message to {reply.sender}\n")
        self.print_menu(player)
        self.driver.input_to(self.bug_replies_menu)

    def reply_message(self, pos):
        """Initiate replying to a message.
        
        @param pos the position of the message to reply to
        @return 1 on success
        """
        self.driver.write("Replying to message:\n")
        pos -= 1
        self.driver.this_player().do_edit("", lambda mess: self.finish_editing_message(mess, pos), self, 0)
        return 1

    def help_command(self):
        """Display help for bug replies."""
        nroff_fn = f"{HELP_FILE}.o"
        str_ = NROFF_HAND.cat_file(nroff_fn, 1)
        if not str_:
            NROFF_HAND.create_nroff(HELP_FILE, nroff_fn)
            str_ = NROFF_HAND.cat_file(nroff_fn, 0)
        self.driver.this_player().set_finish_func(lambda: self.print_menu_input(), self)
        self.driver.this_player().more_string(str_)

    def bug_replies_menu(self, inp):
        """Handle menu input for bug replies.
        
        @param inp the user's input string
        """
        inp = inp.strip()
        player = self.driver.this_player()
        if not inp:
            if self.read_next_new():
                return
        elif inp[0].isdigit():
            pos = int(''.join(c for c in inp if c.isdigit()))
            if self.valid_message(pos):
                self.read_message(pos)
                return
            self.driver.write(f"Message {pos} is invalid.\n")
        else:
            pos, end_pos = -1, -1
            digits = ''.join(c for c in inp if c.isdigit() or c == '-')
            if digits:
                if '-' in digits:
                    pos, end_pos = map(int, digits.split('-', 1))
                else:
                    pos = int(digits)
            cmd = inp[0].lower()
            if cmd == 'q':
                self.driver.write("Exiting the system.\n")
                del self._player_replies[player]
                return
            elif cmd == 'r' and self.valid_message(pos):
                if self.reply_message(pos):
                    return
                self.driver.write(f"Message {pos} is invalid.\n")
            elif cmd == 'd':
                end_pos = pos if end_pos == -1 else end_pos
                if self.valid_message(pos) and self.valid_message(end_pos):
                    if end_pos >= pos:
                        self.delete_message(pos, end_pos)
                    else:
                        self.driver.write(f"Your end position ({end_pos}) must be higher than the start position ({pos}).\n")
                else:
                    self.driver.write(f"Message {pos if not self.valid_message(pos) else end_pos} is invalid.\n")
            elif cmd == 'u':
                end_pos = pos if end_pos == -1 else end_pos
                if self.valid_message(pos) and self.valid_message(end_pos):
                    if end_pos >= pos:
                        self.undelete_message(pos, end_pos)
                    else:
                        self.driver.write(f"Your end position ({end_pos}) must be higher than the start position ({pos}).\n")
                else:
                    self.driver.write(f"Message {pos if not self.valid_message(pos) else end_pos} is invalid.\n")
            elif cmd in ('h', '?'):
                self.help_command()
                return
            elif cmd == 'l':
                self.print_bug_replies(player)
                return
        self.print_menu(player)
        self.driver.input_to(self.bug_replies_menu)

    def bug_replies_result(self, type_, data, player):
        """Handle result of fetching bug replies.
        
        @param type_ the result type (e.g., DB_SUCCESS)
        @param data the retrieved reply data
        @param player the player object
        """
        if type_ != DB_SUCCESS:
            self.driver.tell_object(player, "Error retrieving replies.\n")
        else:
            self._player_replies[player] = PlayerData()
            self._player_replies[player].date = self.driver.time()
            self._player_replies[player].replys = data
            self.print_bug_replies(player)

    def bug_replies(self, only_new):
        """Initiate bug replies retrieval.
        
        @param only_new flag to fetch only new replies
        @return 1 on success, 0 on failure
        """
        player = self.driver.this_player()
        self._player_replies[player] = PlayerData()
        self._player_replies[player].date = self.driver.time()
        self._player_replies[player].replys = []
        if ERROR_HANDLER.do_error_replies(player.query_name(), only_new, 
                                         lambda t, d: self.bug_replies_result(t, d, player)):
            self.driver.input_to(self.bug_replies_menu)
            return 1
        self.driver.add_failed_mess("Unable to find the bug replies.\n")
        return 0