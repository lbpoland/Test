# File: /home/archaon/mud/lib/cmds/theft_base.py
# Purpose: Base class for theft-related commands (e.g., steal, snatch), managing theft mechanics.
# Linked Files: Inherits from /home/archaon/mud/lib/cmds/guild_base.py; uses /home/archaon/mud/lib/include/thief.py, /home/archaon/mud/lib/include/obj_parser.py, /home/archaon/mud/lib/include/player.py.
# Updated Features: None from live MUD as of March 20, 2025; core theft logic preserved with updated skill references.
# Translated by: Archaon

from home.archaon.mud.lib.cmds.guild_base import GuildBase
from home.archaon.mud.lib.include.thief import THEFT_INSURANCE, QUOTA
from home.archaon.mud.lib.include.obj_parser import match_objects_in_environments, OBJ_PARSER_SUCCESS
from home.archaon.mud.lib.include.player import PLAYER_MULTIPLAYER_HANDLER

SKILL = "covert.manipulation.stealing"  # Updated skill per Aethoria skill tree
PERCEPTION = "other.perception"  # Assuming this aligns with adventuring.perception

class TheftBase(GuildBase):
    def __init__(self, driver):
        super().__init__(driver)

    def query_theft_command(self):
        """Indicate this is a theft command."""
        return 1

    def victim_checks(self, thief, victim):
        """Perform checks on the thief and victim before theft."""
        if thief == victim:
            return self.driver.notify_fail("Be serious!\n")
        if thief.query_property("dead"):
            return self.driver.notify_fail("Be serious, you're dead!\n")
        if thief.query_auto_loading():
            return self.driver.notify_fail("You don't have all your equipment yet..\n")
        if victim.query_auto_loading():
            return self.driver.notify_fail(f"Be sporting; {victim.the_short()} doesn't have {victim.query_possessive()} equipment yet.\n")
        if victim.query_user() and not victim.query_interactive():
            return self.driver.notify_fail(f"You can't {self.driver.query_verb()} from a net dead statue.\n")
        if victim.query_property("nosteal"):
            return self.driver.notify_fail(f"You cannot {self.driver.query_verb()} from {victim.the_short()}.\n")
        if victim.query_sanctuary():
            return self.driver.notify_fail("You can't snatch from someone who is protected.\n")
        if self.driver.pk_check(thief, victim):
            return self.driver.notify_fail(f"You feel it would be wrong to {self.driver.query_verb()} from {victim.short()}.\n")
        if victim.query_creator() and not thief.query_creator():
            self.driver.notify_fail("Stop trying to steal from creators.\n")
            thief.adjust_tmp_dex(-10)
            return 0
        return 1

    def get_item(self, thief, location, str_):
        """Retrieve the item to steal."""
        result = match_objects_in_environments(str_, location, 0, thief)
        if result.result != OBJ_PARSER_SUCCESS:
            return self.driver.notify_fail("Pssst, they don't have one of those.\n")
        result.objects = [obj for obj in result.objects if self.driver.environment(obj) == location]
        if not result.objects:
            return self.driver.notify_fail("Pssst, they don't have one of those.\n")
        if len(result.objects) != 1:
            return self.driver.notify_fail(f"You can only {self.driver.query_verb()} one thing at a time.\n")
        return result.objects[0]

    def combat_checks(self, thief, victim):
        """Check combat conditions affecting theft."""
        if thief.query_fighting():
            self.driver.notify_fail(f"You can't attempt to {self.driver.query_verb()} while in battle.\n")
            return 2
        if thief in victim.query_attacker_list():
            self.driver.notify_fail(f"You cannot attempt to {self.driver.query_verb()} from someone that is fighting you.\n")
            return 1
        return 0

    def item_checks(self, victim, item, wielded_ok, worn_ok):
        """Validate the item can be stolen."""
        if item.query_liquid() and item.query_food_object():
            return self.driver.notify_fail(f"You cannot {self.driver.query_verb()} liquids!\n")
        if (item.query_property("nosteal") or 
            (not wielded_ok and item.query_wielded() == victim) or 
            (not worn_ok and item.query_worn_by() == victim)):
            return self.driver.notify_fail(f"You cannot {self.driver.query_verb()} {item.the_short()} from {victim.the_short()}.\n")
        # Assuming QUOTA_CHECK is optional or handled elsewhere in Aethoria; omitted for now
        return 1

    def calc_value(self, ob):
        """Calculate the total value of an object and its contents."""
        value = 0
        name = self.driver.file_name(ob).split('#')[0]
        if name != "/obj/package":
            value = ob.query_value()
        for tmp in ob.deep_inventory():
            value += tmp.query_value()
        return value

    def check_player_quota(self, victim, ob):
        """Check if stealing exceeds victim's theft quota."""
        things = [ob] + ob.deep_inventory()
        value = sum(t.query_value_in("Ankh-Morpork") if t.query_property("money") else t.query_value() for t in things)
        quota = QUOTA.query_player_quota(victim.query_name())
        reported = QUOTA.query_player_reported(victim.query_name())
        valid = QUOTA.query_player_valid(victim.query_name())
        return (quota - (reported + valid)) >= value

    def steal_item(self, thief, victim, item):
        """Perform the theft action."""
        if item.move(thief):
            return self.driver.notify_fail(f"You cannot {self.driver.query_verb()} {item.the_short()} from {victim.the_short()}.\n")
        stolen = [item] + item.deep_inventory()
        self.driver.tell_object(thief, f"You steal {self.driver.query_multiple_short(stolen, 'the')} from {victim.the_short()}.\n")
        env = self.driver.environment(thief)
        if env.query_theft_handler() and "/d/am/" in env.query_theft_handler() and thief.query_name() == "wobin":
            stolen = THEFT_INSURANCE.check_items(stolen, victim, thief)
        self.driver.event(env, "theft", thief, victim, stolen)
        for s in stolen:
            self.driver.event(s, "theft", thief, victim)
        item.event_ward(thief, victim)
        if (thief.query_property("player") and 
            self.driver.query_ip_number(thief) == self.driver.query_ip_number(victim) and 
            PLAYER_MULTIPLAYER_HANDLER.check_allowed(thief, [victim])):
            sh = f"{thief.query_name().capitalize()} stole {self.driver.query_multiple_short(stolen)} from {victim.query_name()} while logged in from the same IP address."
            self.driver.user_event("inform", sh, "multiplayer")
            sh = victim.convert_message(sh)
            self.driver.log_file("MULTIPLAYERS", f"{self.driver.ctime(self.driver.time())}: {sh}\n")
        return 1