# /secure/command.py
# Translated from /secure/command.c (2003 Discworld MUD library)
# Purpose: Manages command parsing and execution
# Last modified in original: Unknown

import asyncio

# Constants from command.h
DIR_PLAYER_CMDS = "/cmds/player"
DIR_CREATOR_CMDS = "/cmds/creator"
DIR_SECURE_CREATOR_CMDS = "/secure/cmds/creator"
DIR_LORD_CMDS = "/secure/cmds/lord"
DIR_LIVING_CMDS = "/cmds/living"
DIR_GUILD_CMDS = "/cmds/guild"
DIR_PLAYTESTER_CMDS = "/cmds/playtester"

class Command:
    def __init__(self, driver):
        self.driver = driver
        self.driver.seteuid(self.driver.getuid())
        self.Commands = {}
        self.Cache = {}
        self.Paths = []
        self.GRCommands = []
        self.last_verb = None
        self.last_args = None
        self.found_cmd = None
        self.found_args = None
        self.event_rehash([DIR_PLAYER_CMDS, DIR_CREATOR_CMDS, DIR_SECURE_CREATOR_CMDS,
                           DIR_LORD_CMDS, DIR_LIVING_CMDS, DIR_GUILD_CMDS,
                           DIR_PLAYTESTER_CMDS])

    async def init(self, driver):
        pass  # No additional init needed beyond create()

    def event_guild_race_rehash(self):
        """Rehashes guild and race commands."""
        paths = [DIR_GUILD_CMDS]
        guild_dirs = [d for d in self.driver.unguarded(lambda: self.driver.get_dir(f"{DIR_GUILD_CMDS}/", -1))
                      if d[1] == -2]
        paths.extend([f"{DIR_GUILD_CMDS}/{d[0]}" for d in guild_dirs])
        self.GRCommands = []
        for path in paths:
            files = [f[:-2] for f in self.driver.unguarded(lambda: self.driver.get_dir(f"{path}/*.c"))]
            for cmd in files:
                self.GRCommands.append(cmd)
                self.Commands[cmd] = self.Commands.get(cmd, []) + [path]

    def event_rehash(self, paths):
        """Rehashes command paths."""
        self.Cache = {}
        if isinstance(paths, str):
            paths = [paths]
        elif not isinstance(paths, list):
            return
        for path in paths:
            if path.endswith("/"):
                continue
            if self.driver.file_size(path) != -2:
                continue
            if path == DIR_GUILD_CMDS:
                self.event_guild_race_rehash()
                continue
            files = [f[:-2] for f in self.driver.unguarded(lambda: self.driver.get_dir(f"{path}/*.c"))]
            for file in files:
                self.Commands[file] = self.Commands.get(file, []) + [path]
            if path not in self.Paths:
                self.Paths.append(path)

    def handle_command_line(self, cmd):
        """Splits command into verb and args."""
        args = cmd.args
        i = args.find(" ")
        if i != -1:
            cmd.verb = args[:i]
            cmd.args = args[i + 1:]
        else:
            cmd.verb = args
            cmd.args = None

    def strncmp(self, s1, s2, length):
        """Compares strings up to a length."""
        return s1[:length] == s2[:length]

    def handle_stars(self, cmd):
        """Handles command aliases with underscores."""
        if cmd.verb == "END_ALIAS":
            return False
        if self.last_verb == cmd.verb and self.last_args == cmd.args:
            cmd.verb = self.found_cmd
            if self.found_args is not None:
                cmd.args = self.found_args
            return True
        if cmd.verb in self.Cache:
            if self.Cache[cmd.verb][1] is not None:
                cmd.args = self.Cache[cmd.verb][1]
            cmd.verb = self.Cache[cmd.verb][0]
            return True
        if cmd.verb in self.Commands:
            return True
        files = [f for f in self.Commands.keys() if f[0] == cmd.verb[0]]
        for file in files:
            i = file.find("_")
            if i == -1:
                continue
            tmpfile = file[:i] + file[i + 1:]
            len_file = len(tmpfile)
            if i == len_file:
                tmpargs = cmd.verb[i:] + ("" if cmd.args is None or len(cmd.verb) == i else " ") + (cmd.args or "")
                tmpverb = cmd.verb[:i]
                if not self.strncmp(tmpfile, tmpverb, len_file):
                    continue
                no_cache = True
            else:
                length = len(cmd.verb)
                if length > len_file or length < i:
                    continue
                if not self.strncmp(cmd.verb, tmpfile, length):
                    continue
                tmpargs = None
                no_cache = False
            if not no_cache:
                self.Cache[cmd.verb] = [file, tmpargs]
            self.last_verb = cmd.verb
            self.last_args = cmd.args
            cmd.verb = file
            if tmpargs is not None:
                cmd.args = tmpargs
            self.found_cmd = cmd.verb
            self.found_args = tmpargs
            return True
        return False

    def get_command(self, cmd, path):
        """Finds and sets up a command for execution."""
        if not isinstance(cmd.args, str):
            return False
        tmp = [p for p in path if p in self.Paths]
        new_paths = [p for p in path if p not in tmp]
        if new_paths:
            self.event_rehash(new_paths)
        self.handle_command_line(cmd)
        if self.handle_stars(cmd) and cmd.verb in self.Commands:
            tmp = [p for p in path if p in self.Commands[cmd.verb]]
            if tmp:
                cmd.file = f"{tmp[0]}/{cmd.verb}"
                cmd.filepart = cmd.verb
                i = cmd.verb.find("_")
                if i != -1:
                    cmd.verb = cmd.verb[:i] + cmd.verb[i + 1:]
                if cmd.args == "":
                    cmd.args = None
                if self.driver.find_object(cmd.file).query_patterns():
                    return False
                return True
        return False

    def return_patterns(self, cmd, path):
        """Returns command patterns for parsing."""
        tmp = [p for p in path if p in self.Paths]
        new_paths = [p for p in path if p not in tmp]
        if new_paths:
            self.event_rehash(new_paths)
        if self.handle_stars(cmd) and cmd.verb in self.Commands:
            tmp = [p for p in path if p in self.Commands[cmd.verb]]
            if tmp:
                ret_patterns = []
                for fname in tmp:
                    cmd.file = f"{fname}/{cmd.verb}"
                    q_patterns = self.driver.find_object(cmd.file).query_patterns()
                    if not q_patterns:
                        return None
                    r_patterns = []
                    for i in range(0, len(q_patterns), 2):
                        if q_patterns[i + 1] and not callable(q_patterns[i + 1]):
                            continue
                        stuff = self.driver.pattern_ob().query_pattern(q_patterns[i])
                        j = 0
                        while j < len(r_patterns) and r_patterns[j][0] >= stuff[0]:
                            j += 1
                        r_patterns = r_patterns[:j] + [[stuff[0], q_patterns[i], 0, 
                                                        self.driver.find_object(cmd.file), 
                                                        q_patterns[i + 1]]] + r_patterns[j:]
                    ret_patterns.extend(r_patterns)
                return ret_patterns
        return None

    def get_command_patterns(self, cmd_name, path):
        """Gets patterns for a specific command."""
        cmd = type('Command', (), {'verb': cmd_name, 'args': None, 'file': None, 'filepart': None})()
        return self.return_patterns(cmd, path)

    def get_commands(self, path=None):
        """Returns available commands."""
        if not path:
            return list(self.Commands.keys())
        return [cmd for cmd, paths in self.Commands.items() if path in paths]

    def get_paths(self, cmd=None):
        """Returns paths for a command or all paths."""
        if cmd:
            if cmd in self.Commands:
                return self.Commands[cmd]
            tmp = type('Command', (), {'verb': cmd, 'args': None, 'file': None, 'filepart': None})()
            if self.handle_stars(tmp):
                return self.Commands.get(tmp.verb, [])
            return None
        return self.Paths.copy()

    def is_gr_command(self, cmd):
        """Checks if a command is guild/race related."""
        if cmd in self.GRCommands:
            return True
        tmp = type('Command', (), {'verb': cmd, 'args': None, 'file': None, 'filepart': None})()
        if self.handle_stars(tmp):
            return tmp.verb in self.GRCommands
        return False