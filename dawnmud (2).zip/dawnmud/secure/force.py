# /secure/force.py
# Translated from /secure/force.c (2003 Discworld MUD library)
# Purpose: Handles forcing commands on other objects
# Last modified in original: Unknown

FORCE_COST = 1
ILLEGAL_FORCE = ["alias", "unalias", "mv", "mkdir", "call", "rm", "force", "kill",
                 "gauge", "exec", "promote", "new_domain", "rmdir", "cd", "history",
                 "echoall", "shout"]

class Force:
    def __init__(self, driver):
        self.driver = driver
        self.fname = self.driver.file_name(self).split("#")[0]
        self.no_force_me = False
        self.force_commands()

    async def init(self, driver):
        pass  # No additional init needed

    def force_commands(self):
        """Sets up force-related commands."""
        ob = self.driver.this_object()
        if not ob.query_property("npc") and (ob.query_property("force") or self.fname == "/global/lord"):
            ob.add_action("do_force", "force", self.do_force)
        if self.fname == "/global/lord":
            ob.add_action("no_force", "noforce", self.no_force)

    def no_force(self, str):
        """Toggles forcing permission."""
        if self.fname != "/global/lord":
            return False
        if str == "on":
            self.no_force_me = True
            self.driver.write("Ok.\n")
            return True
        if str == "off":
            self.no_force_me = False
            self.driver.write("Ok.\n")
            return True
        self.driver.write(f"Forcing you is currently {'disabled' if self.no_force_me else 'enabled'}.\n")
        return True

    def do_force(self, str):
        """Forces a command on another object."""
        tp = self.driver.this_player()
        if self.fname == "/global/player" and not tp.query_property("force"):
            self.driver.notify_fail("You do not have the ability to do that yet.\n")
            return False
        if not str or len(parts := str.split(" ", 1)) != 2:
            self.driver.notify_fail("Usage : force <person> <command>\n")
            return False
        who, what = parts
        if tp.adjust_social_points(-FORCE_COST) < 0:
            self.driver.notify_fail("Insufficient social points.\n")
            return False
        who = tp.expand_nickname(who).lower()
        omatch = self.driver.match_objects_in_environments(who, self.driver.environment(self.driver.this_object()))
        if omatch.result != "OBJ_PARSER_SUCCESS":
            self.driver.notify_fail(self.driver.match_objects_failed_mess(omatch))
            return False
        obs = omatch.objects
        if not obs:
            ob = self.driver.find_living(who)
            if not ob:
                self.driver.notify_fail("No such living thing.\n")
                return False
            obs.append(ob)
        for ob in obs:
            if not ob.do_force_on_me(what):
                self.driver.write(f"{who.capitalize()} didn't want to do that.\n")
        self.driver.write("Ok.\n")
        return True

    def do_force_on_me(self, str):
        """Handles being forced to execute a command."""
        forcer = self.driver.this_player(1) or self.driver.previous_object()
        ob = self.driver.this_object()
        if not ob.query_property("npc"):
            self.driver.log_file("FORCE", f"{datetime.now()} {forcer.query_name()} {ob.query_name()} : {str}")
        self.driver.tell_object(ob, f"{forcer.query_cap_name()} tries to force you to {str}\n")
        if self.no_force_me or ob.query_name() == "pinkfish":
            self.driver.log_file("FORCE", " (failed)\n")
            return False
        parts = str.split(" ", 1)
        temp1 = parts[0]
        if len(parts) > 1 and temp1 in ILLEGAL_FORCE and not self.driver.get_master().high_programmer(self.driver.geteuid(forcer)):
            self.driver.log_file("FORCE", " (failed)\n")
            return False
        self.driver.command(str)
        self.driver.log_file("FORCE", " (succeeded)\n")
        return True