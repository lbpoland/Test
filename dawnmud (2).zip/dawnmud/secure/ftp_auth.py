# /secure/ftp_auth.py
# Translated from /secure/ftp_auth.c (2003 Discworld MUD library)
# Purpose: Manages FTP authentication server
# Last modified in original: Unknown

import asyncio
import random
import crypt

PORT_FTPAUTH = 2121  # Assumed, adjust as needed
MAX_LIFE = 36000  # 10 hours
BASTARDS = "/secure/bastards"
STREAM = "STREAM"  # Assumed network.h constant

class FtpSession:
    def __init__(self, fd=None, token=None, timestamp=None, user=None):
        self.fd = fd
        self.token = token
        self.timestamp = timestamp
        self.user = user

class FtpAuth:
    def __init__(self, driver):
        self.driver = driver
        self.Sockets = {}
        self.setup()

    async def init(self, driver):
        asyncio.create_task(self.clean_sockets())

    def setup(self):
        """Sets up the FTP auth server."""
        self.driver.set_socket_type(STREAM)
        self.driver.set_destruct_on_close(True)
        asyncio.create_task(self.event_create_socket(PORT_FTPAUTH))

    async def event_create_socket(self, port):
        """Creates the FTP server socket."""
        if await self.driver.event_create_socket(port) < 0:
            self.driver.destruct(self)

    async def event_new_connection(self, fd):
        """Handles new FTP connections."""
        address = self.driver.socket_address(fd)
        parts = address.split(" ")
        if len(parts) < 2 or parts[0] != "127.0.0.1":
            await self.driver.event_write(fd, "", True)
            return
        sess = FtpSession(fd=fd)
        self.Sockets[fd] = sess

    def get_path(self, path):
        """Normalizes file paths."""
        if path == "/":
            return "/"
        array = [x for x in path.split("/") if x]
        array1 = []
        for part in array:
            if part == "..":
                if array1:
                    array1.pop()
            elif part != ".":
                array1.append(part)
        return "/" + ("/".join(array1) if array1 else "")

    async def event_read(self, fd, str):
        """Handles FTP read events."""
        sess = self.Sockets.get(fd)
        if not sess:
            await self.driver.event_write(fd, "DENIED\n", True)
            return
        if str == "mudname":
            await self.driver.event_write(fd, f"OKAY: {self.driver.mud_name()}\n")
            return
        parts = str.split(" ", 1)
        if len(parts) != 2:
            await self.driver.event_write(fd, "Syntax error\n", True)
            return
        name, rest = parts
        name = name.lower()
        ph = self.driver.player_handler()
        pth = self.driver.playtester_handler()
        bastards = self.driver.find_object(BASTARDS)
        
        if rest in ["request login", "request login playtester"]:
            anon = name == "ftp"
            if rest == "request login":
                if not (anon or ph.test_creator(name)):
                    await self.driver.event_write(fd, "DENIED\n")
                    return
            else:
                if not anon and not pth.query_playtester(name) and not ph.test_creator(name):
                    await self.driver.event_write(fd, "DENIED invalid\n")
                    return
            if bastards.query_suspended(name):
                await self.driver.event_write(fd, "DENIED suspended\n")
                return
            timestamp = self.driver.time()
            token = crypt.crypt(str(timestamp), str(random.randint(0, 12000)))
            sess.token = token
            sess.timestamp = timestamp
            sess.user = name
            ret = f"OKAY: {token} * /pub\n" if anon else \
                  f"OKAY: {token} {ph.get_password(name)} /w/{name}\n"
            await self.driver.event_write(fd, ret)
            return
        
        subparts = rest.split(" ", 2)
        if len(subparts) != 3:
            await self.driver.event_write(fd, "Syntax error\n", True)
            return
        token, type_, path = subparts
        if token != sess.token or (self.driver.time() - sess.timestamp) > MAX_LIFE:
            await self.driver.event_write(fd, "DENIED\n")
            return
        path = self.get_path(path)
        if type_ == "read":
            if self.driver.file_size(path) == -2:
                path += "/"
            size = self.driver.file_size(path)
            if size >= 0:
                await self.driver.event_write(fd, f"OKAY: {size}\n")
            else:
                await self.driver.event_write(fd, "DENIED\n")
        else:
            await self.driver.event_write(fd, "Syntax error\n", True)

    async def event_socket_closed(self, fd):
        """Handles socket closure."""
        if fd in self.Sockets:
            del self.Sockets[fd]

    async def clean_sockets(self):
        """Cleans up expired sockets."""
        current_time = self.driver.time()
        for sess in list(self.Sockets.values()):
            if not sess.timestamp:
                sess.timestamp = current_time
                continue
            if current_time - sess.timestamp > MAX_LIFE:
                await self.driver.event_write(sess.fd, "Timeout\n", True)
        await asyncio.sleep(3600)
        asyncio.create_task(self.clean_sockets())

    def query_connections(self):
        """Returns current FTP connections."""
        return [sess.user.capitalize() if sess.user else "login" for sess in self.Sockets.values()]