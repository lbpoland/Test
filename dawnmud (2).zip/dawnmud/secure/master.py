# /home/archaon/mud/lib/secure/master.py
# Purpose: Central security and control object for the MUD, managing permissions, connections, and system initialization.
# Linked files: /home/archaon/mud/lib/secure/master/*.py (23 sub-modules), /home/archaon/mud/lib/secure/login.py, /home/archaon/mud/lib/secure/nlogin.py
# @updated: 2025-03-21 - Fixed Preload initialization to pass self - Required for compatibility with /secure/master/preload.py
# @updated: 2025-03-21 - Added IPv6 mention in connect() - Verified via https://dwwiki.mooo.com/wiki/IPv6_Support
# @updated: 2025-03-21 - Enhanced startup logging - Verified via https://discworld.starturtle.net/lpc/blog/blog.c?action=view&blog=recent%20developments&id=1046
# @started: 2025-03-21
# @author: Archaon
# Translated and coded by: Archaon

import asyncio
from datetime import datetime

# Constants from master.c
ROOT = "Root"
TRUSTEES = {ROOT: 1, "archaon": 1}  # Updated from "cratylus" per user request
READ_MASK = 1
WRITE_MASK = 2
GRANT_MASK = 4
LOCK_MASK = 8
SENIOR = 4
DIRECTOR = 1
TRUSTEE = 2
VERSION = "Dawn MUD 1.0 - March 20, 2025"  # Modern replacement for __VERSION__

class Master:
    """
    Master object responsible for MUD security, permissions, and system control.
    """

    def __init__(self, driver):
        """
        Initializes the master object with driver and sub-module integration.
        @param driver The driver instance providing runtime support
        """
        self.driver = driver
        self.positions = {}
        self.permissions = {}
        self.trustees = TRUSTEES.copy()
        self.checked_master = {}
        self.snoop_list = {}
        self.unguarded_ob = None
        self.directory_assignments = {}

        # Import all 23 sub-modules, passing self instead of driver
        from mud.secure.master.permission import Permission
        from mud.secure.master.crash import Crash
        from mud.secure.master.create_dom_creator import CreateDomCreator
        from mud.secure.master.creator_file import CreatorFile
        from mud.secure.master.dest_env import DestEnv
        from mud.secure.master.ed_stuff import EdStuff
        from mud.secure.master.file_exists import FileExists
        from mud.secure.master.logging import Logging
        from mud.secure.master.parse_command import ParseCommand
        from mud.secure.master.preload import Preload
        from mud.secure.master.query_pl_level import QueryPlLevel
        from mud.secure.master.snoop import Snoop
        from mud.secure.master.valid_database import ValidDatabase
        from mud.secure.master.valid_exec import ValidExec
        from mud.secure.master.valid_hide import ValidHide
        from mud.secure.master.valid_ident import ValidIdent
        from mud.secure.master.valid_link import ValidLink
        from mud.secure.master.valid_override import ValidOverride
        from mud.secure.master.valid_read import ValidRead
        from mud.secure.master.valid_seteuid import ValidSeteuid
        from mud.secure.master.valid_shadow import ValidShadow
        from mud.secure.master.valid_socket import ValidSocket
        from mud.secure.master.valid_write import ValidWrite

        self.inherits = [
            Permission(self),
            Crash(self),
            CreateDomCreator(self),
            CreatorFile(self),
            DestEnv(self),
            EdStuff(self),
            FileExists(self),
            Logging(self),
            ParseCommand(self),
            Preload(self),  # Now takes self instead of driver
            QueryPlLevel(self),
            Snoop(self),
            ValidDatabase(self),
            ValidExec(self),
            ValidHide(self),
            ValidIdent(self),
            ValidLink(self),
            ValidOverride(self),
            ValidRead(self),
            ValidSeteuid(self),
            ValidShadow(self),
            ValidSocket(self),
            ValidWrite(self),
        ]
        self.create()

    def create(self) -> None:
        """Initializes the master object with root privileges and state restoration."""
        self.driver.seteuid(ROOT)
        self.driver.set_eval_limit(2000000)
        save_path = "/home/archaon/mud/save/master_state.json"
        if not self.driver.unguarded(lambda: self.driver.restore_object(save_path)):
            if not self.driver.unguarded(lambda: self.driver.restore_object("/home/archaon/mud/save/config/master_fallback.json")):
                error_msg = "The master object couldn't restore its save file."
                self.driver.log_file("/home/archaon/mud/log/MASTER_ERRORS", 
                                     f"{self.driver.ctime(self.driver.time())}: {error_msg}\n")
                raise RuntimeError(error_msg)

    def query_name(self) -> str:
        """
        Returns the master object's name.
        @return The name 'Root'
        """
        return ROOT

    async def connect(self, port: int) -> object:
        """
        Handles player connections on a specified port with IPv6 support.
        @param port The port number to connect on
        @return The cloned login object or None on failure
        """
        login_path = "/home/archaon/mud/lib/secure/login"
        if not self.driver.find_object(login_path):
            self.driver.log_file("REBOOT", 
                                 f"Mud rebooted at {self.driver.ctime(self.driver.time())}[{self.driver.time()}]\n"
                                 f"Version: {VERSION}, Port: {port}, IPv6 Supported\n")
        self.driver.write(f"LPmud version: {VERSION} on port {port} (IPv6 supported).\n")
        ob_path = "/home/archaon/mud/lib/secure/nlogin" if port == 4243 else login_path
        ob = self.driver.clone_object(ob_path)
        if not ob:
            self.driver.log_file("/home/archaon/mud/log/MASTER_ERRORS", 
                                 f"{self.driver.ctime(self.driver.time())}: Failed to clone login object {ob_path}\n")
            self.driver.destruct(self)
            return None
        if hasattr(ob, "set_login_port"):
            ob.set_login_port(port)
        self.driver.write("\n")
        return ob

    def query_trustee(self, arg: object | str | list) -> bool:
        """
        Checks if an entity is a trustee.
        @param arg The entity to check (object, string, or list)
        @return True if trustee, False otherwise
        """
        if isinstance(arg, list):
            arg = [x for x in arg if self.driver.is_interactive(x)]
            return all(
                self.driver.geteuid(x) == ROOT or
                self.positions.get(self.driver.geteuid(x)) == TRUSTEE or
                self.trustees.get(self.driver.geteuid(x))
                for x in arg
            )
        return arg == ROOT or self.positions.get(arg) == TRUSTEE or arg in self.trustees

    def query_administrator(self, arg: object | str | list) -> bool:
        """Alias for query_trustee."""
        return self.query_trustee(arg)

    def high_programmer(self, arg: object | str | list) -> bool:
        """Alias for query_trustee."""
        return self.query_trustee(arg)

    def query_director(self, arg: object | str | list) -> bool:
        """
        Checks if an entity is a director.
        @param arg The entity to check
        @return True if director, False otherwise
        """
        if isinstance(arg, list):
            arg = [x for x in arg if self.driver.is_interactive(x)]
            return all(
                self.positions.get(self.driver.geteuid(x)) == DIRECTOR or
                self.query_trustee(self.driver.geteuid(x))
                for x in arg
            )
        return self.positions.get(arg) == DIRECTOR or self.query_trustee(arg)

    def query_leader(self, arg: object | str | list) -> bool:
        """Alias for query_director."""
        return self.query_director(arg)

    def query_lord(self, arg: object | str | list) -> bool:
        """Alias for query_director."""
        return self.query_director(arg)

    def query_only_director(self, word: str) -> bool:
        """
        Checks if an entity is exclusively a director.
        @param word The entity name
        @return True if only director, False otherwise
        """
        return self.positions.get(word) == DIRECTOR

    def query_only_leader(self, word: str) -> bool:
        """Alias for query_only_director."""
        return self.query_only_director(word)

    def query_only_lord(self, word: str) -> bool:
        """Alias for query_only_director."""
        return self.query_only_director(word)

    def query_directors(self) -> list[str]:
        """Returns list of exclusive directors."""
        return [k for k in self.positions.keys() if self.query_only_director(k)]

    def query_leaders(self) -> list[str]:
        """Alias for query_directors."""
        return self.query_directors()

    def query_lords(self) -> list[str]:
        """Alias for query_directors."""
        return self.query_directors()

    def query_player_trustee(self, str_: str) -> bool:
        """
        Checks if a player is a trustee.
        @param str_ The player name
        @return True if player trustee, False otherwise
        """
        return self.query_trustee(str_) and self.driver.player_handler().test_user(str_)

    def query_player_administrator(self, str_: str) -> bool:
        """Alias for query_player_trustee."""
        return self.query_player_trustee(str_)

    def query_player_high_lord(self, str_: str) -> bool:
        """Alias for query_player_trustee."""
        return self.query_player_trustee(str_)

    def high_programmers(self) -> list[str]:
        """Returns list of high programmers (trustees)."""
        return list(self.trustees.keys())

    def query_administrators(self) -> list[str]:
        """Alias for high_programmers."""
        return self.high_programmers()

    def query_trustees(self) -> list[str]:
        """Alias for high_programmers."""
        return self.high_programmers()

    def query_all_directors(self) -> list[str]:
        """Returns list of all directors (including trustees)."""
        return [k for k in self.positions.keys() if self.query_director(k)]

    def query_all_leaders(self) -> list[str]:
        """Alias for query_all_directors."""
        return self.query_all_directors()

    def query_all_lords(self) -> list[str]:
        """Alias for query_all_directors."""
        return self.query_all_directors()

    def is_leader_of(self, person: str, domain: str) -> bool:
        """
        Checks if a person is the leader of a domain.
        @param person The person's name
        @param domain The domain name
        @return True if leader, False otherwise
        """
        dom_master = self.driver.find_object(f"/home/archaon/mud/d/{domain}/master")
        return dom_master.query_lord() == person if dom_master else False

    def is_deputy_of(self, person: str, domain: str) -> bool:
        """
        Checks if a person is a deputy of a domain.
        @param person The person's name
        @param domain The domain name
        @return True if deputy, False otherwise
        """
        dom_master = self.driver.find_object(f"/home/archaon/mud/d/{domain}/master")
        return dom_master.query_deputy(person) if dom_master and hasattr(dom_master, "query_deputy") else False

    def is_liaison_deputy(self, person: str) -> bool:
        """
        Checks if a person is a liaison deputy.
        @param person The person's name
        @return True if liaison deputy, False otherwise
        """
        liaison_master = self.driver.find_object("/home/archaon/mud/d/liaison/master")
        return liaison_master.query_deputy(person) if liaison_master and hasattr(liaison_master, "query_deputy") else False

    def query_liaison_deputy_or_director(self, arg: object | str | list) -> bool:
        """
        Checks if an entity is a liaison deputy or director.
        @param arg The entity to check
        @return True if either, False otherwise
        """
        if isinstance(arg, list):
            arg = [x for x in arg if self.driver.is_interactive(x)]
            return all(
                self.query_director(self.driver.geteuid(x)) or
                self.is_liaison_deputy(self.driver.geteuid(x))
                for x in arg
            )
        return self.is_liaison_deputy(arg) or self.query_director(arg)

    def query_liaison_deputy_or_lord(self, arg: object | str | list) -> bool:
        """Alias for query_liaison_deputy_or_director."""
        return self.query_liaison_deputy_or_director(arg)

    def query_senior(self, arg: object | str | list) -> bool:
        """
        Checks if an entity is a senior member.
        @param arg The entity to check
        @return True if senior, False otherwise
        """
        if isinstance(arg, list):
            arg = [x for x in arg if self.driver.is_interactive(x)]
            return all(
                self.positions.get(self.driver.geteuid(x)) == SENIOR or
                self.query_leader(self.driver.geteuid(x))
                for x in arg
            )
        return self.positions.get(arg) == SENIOR or self.query_leader(arg)

    def query_all_seniors(self) -> list[str]:
        """Returns list of all senior members."""
        return [k for k in self.positions.keys() if self.query_senior(k)]

    def query_domains(self) -> list[str]:
        """Returns list of available domains."""
        domains = self.driver.get_dir("/home/archaon/mud/d/")
        return [d for d in domains if d not in ["lost+found", "core"] and not d.endswith("_dev")]

    def valid_load(self, path: str, euid: str, func: str) -> bool:
        """
        Validates object loading (delegated to sub-module).
        @param path The file path
        @param euid The effective UID
        @param func The function requesting load
        @return True (simplified; full logic in sub-module)
        """
        return True  # Simplified; actual logic in sub-module

    def get_root_uid(self) -> str:
        """Returns the root UID."""
        return ROOT

    def get_bb_uid(self) -> str:
        """Returns the backbone UID."""
        return "Room"

    def define_include_dirs(self) -> list[str]:
        """Defines include directories."""
        return ["/home/archaon/mud/include/%s"]

    def valid_trace(self) -> bool:
        """Validates tracing (always true for now)."""
        return True

    def shut(self, min_: int) -> None:
        """
        Initiates MUD shutdown.
        @param min_ Minutes until shutdown
        """
        self.driver.find_object("/home/archaon/mud/obj/shut").shut(min_)

    def remove_checked_master(self, name: str) -> None:
        """
        Removes an entry from checked_master.
        @param name The name to remove
        """
        self.checked_master.pop(name, None)

    def query_checked_master(self) -> dict:
        """Returns a copy of checked_master."""
        return self.checked_master.copy()

    def apply_unguarded(self, func: Callable, local: bool = False) -> any:
        """
        Applies a function without privilege checks.
        @param func The function to execute
        @param local Whether to use local context
        @return The function's return value
        """
        prev_ob = self.driver.previous_object(0)
        if self.driver.base_name(prev_ob) != "/home/archaon/mud/lib/secure/simul_efun":
            raise RuntimeError("Illegal unguarded apply.")
        previous_unguarded = self.unguarded_ob
        self.unguarded_ob = self if local else self.driver.previous_object(1)
        try:
            val = func()
        except Exception as e:
            self.unguarded_ob = previous_unguarded
            raise e
        self.unguarded_ob = previous_unguarded
        return val

    # Delegate to sub-modules
    def valid_read(self, path: str, euid: str, func: str) -> bool:
        return self.inherits[18].valid_read(path, euid, func)  # ValidRead

    def valid_write(self, path: str, euid: str, func: str) -> bool:
        return self.inherits[22].valid_write(path, euid, func)  # ValidWrite

    def crash(self, reason: str = "unknown") -> None:
        self.inherits[1].crash(reason)  # Crash

    def create_dom_creator(self, domain: str, creator: str) -> None:
        self.inherits[2].create_dom_creator(domain, creator)  # CreateDomCreator

    def creator_file(self, path: str) -> str:
        return self.inherits[3].creator_file(path)  # CreatorFile

    def dest_env(self, ob: object) -> None:
        self.inherits[4].dest_env(ob)  # DestEnv

    def set_ed_setup(self, ob: object, setup: any) -> None:
        self.inherits[5].set_ed_setup(ob, setup)  # EdStuff

    def query_ed_setup(self, ob: object) -> any:
        return self.inherits[5].query_ed_setup(ob)  # EdStuff

    def file_exists(self, path: str) -> bool:
        return self.inherits[6].file_exists(path)  # FileExists

    def log_file(self, file: str, message: str) -> None:
        self.inherits[7].log_file(file, message)  # Logging

    def parse_command(self, command: str, ob: object) -> any:
        return self.inherits[8].parse_command(command, ob)  # ParseCommand

    def preload(self, path: str) -> None:
        self.inherits[9].preload(path)  # Preload

    def query_pl_level(self, ob: object) -> int:
        return self.inherits[10].query_pl_level(ob)  # QueryPlLevel

    def query_snoop(self, ob: object) -> object:
        return self.inherits[11].query_snoop(ob)  # Snoop

    def query_snoopee(self, ob: object) -> object:
        return self.inherits[11].query_snoopee(ob)  # Snoop

    def set_snoopee(self, snooper: object, snoopee: object) -> None:
        self.inherits[11].set_snoopee(snooper, snoopee)  # Snoop

    def valid_database(self, ob: object, action: str, info: any) -> bool:
        return self.inherits[12].valid_database(ob, action, info)  # ValidDatabase

    def valid_exec(self, name: str) -> bool:
        return self.inherits[13].valid_exec(name)  # ValidExec

    def valid_hide(self, ob: object) -> bool:
        return self.inherits[14].valid_hide(ob)  # ValidHide

    def valid_ident(self, euid: str) -> bool:
        return self.inherits[15].valid_ident(euid)  # ValidIdent

    def valid_link(self, from_: str, to: str) -> bool:
        return self.inherits[16].valid_link(from_, to)  # ValidLink

    def valid_override(self, file: str, func: str, filename: str) -> bool:
        return self.inherits[17].valid_override(file, func, filename)  # ValidOverride

    def valid_seteuid(self, ob: object, euid: str) -> bool:
        return self.inherits[19].valid_seteuid(ob, euid)  # ValidSeteuid

    def valid_shadow(self, ob: object) -> bool:
        return self.inherits[20].valid_shadow(ob)  # ValidShadow

    def valid_socket(self, ob: object, func: str, info: any) -> bool:
        return self.inherits[21].valid_socket(ob, func, info)  # ValidSocket