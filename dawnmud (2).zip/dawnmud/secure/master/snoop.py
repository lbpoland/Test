# /lib/secure/master/snoop.py
# Manages snoop permissions and logging.

class Snoop:
    def __init__(self, driver):
        self.driver = driver
        self.snoop_list = {}

    def valid_snoop(self, snooper, snoopee, pobj):
        """
        Validates and initiates a snoop action.
        @param snooper The snooping object
        @param snoopee The target object (optional)
        @param pobj The calling object
        @return 1 if valid, 0 otherwise
        """
        master = self.driver.get_master()
        verb = self.driver.this_player().query_current_verb()
        if snooper == snoopee:
            self.driver.tell_object(snooper, "You can't snoop yourself.\n")
            return 0
        if snoopee and self.driver.query_snoop(snoopee):
            self.driver.tell_object(snooper, f"{snoopee.query_cap_name()} is already being snooped.\n")
            return 0
        if current_snoopee := snooper.query_snoopee():
            self.driver.user_event(f"{snooper.query_cap_name()} stops {verb}ing {current_snoopee.query_name()}", "snoop")
            if not snooper.query_property("quiet snoop"):
                self.driver.tell_object(current_snoopee, f"{snooper.query_cap_name()} stops snooping you.\n")
            else:
                snooper.remove_property("quiet snoop")
            snooper.set_snoopee(None)
        if not snoopee:
            return 1
        if not snooper.query_creator():
            return 0
        if pobj == self.driver.this_object():
            self.driver.user_event(f"{snooper.query_cap_name()} starts qsnooping {snoopee.query_name()}", "snoop")
            return 1
        if verb == "qsnoop" and master.query_lord(self.driver.geteuid(snooper)) and not master.query_lord(self.driver.geteuid(snoopee)):
            self.driver.tell_object(snooper, f"You are quiet snooping {snoopee.query_cap_name()}\n")
            snooper.add_property("quiet snoop", 1)
        else:
            self.driver.tell_object(snoopee, f"You are being snooped by {snooper.query_cap_name()}.\n")
        self.driver.unguarded(lambda: self.driver.write_file("/d/admin/log/SNOOP", f"{self.driver.ctime(self.driver.time())} {snooper.query_cap_name()} {verb}s {snoopee.query_cap_name()}.\n"))
        snooper.set_snoopee(snoopee)
        if verb == "qsnoop":
            self.driver.tell_object(snooper, "Please share with us the reason why you are quiet snooping?\n: ")
            self.driver.input_to(self.snoop_reason)
            self.snoop_list[snooper] = snoopee
            return 0
        self.driver.user_event(f"{snooper.query_cap_name()} starts {verb}ing {snoopee.query_name()}", "snoop")
        return 1

    def snoop_reason(self, str_):
        """
        Handles the reason input for quiet snooping.
        @param str_ The reason provided by the user
        """
        snooper = self.driver.this_player()
        if self.driver.this_player(1) != snooper:
            self.driver.write("Can't force people...\n")
            return
        if not self.driver.get_master().high_programmer(self.driver.geteuid(snooper)):
            self.driver.write("Not a high programmer.\n")
            return
        if snooper not in self.snoop_list:
            self.driver.write("The snoopee has just logged out.\n")
            return
        if not str_:
            self.driver.write("Snoop canceled.\n")
            self.driver.unguarded(lambda: self.driver.write_file("/d/admin/log/SNOOP", "  Chickened out.\n"))
            return
        self.driver.unguarded(lambda: self.driver.write_file("/d/admin/log/SNOOP", f"  Reason: {str_}\n"))
        if self.driver.efun_snoop(snooper, self.snoop_list[snooper]):
            self.driver.write("Snoop succeeded.\n")
        else:
            self.driver.write("Snoop failed.\n")