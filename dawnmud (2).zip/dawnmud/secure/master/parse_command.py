# /lib/secure/master/parse_command.py
# Provides parsing utilities for commands.

class ParseCommand:
    def __init__(self, driver):
        self.driver = driver

    def parse_command_id_list(self):
        """
        Returns singular identifiers for parsing.
        @return List of identifier strings
        """
        return ["one", "thing"]

    def parse_command_plural_id_list(self):
        """
        Returns plural identifiers for parsing.
        @return List of plural identifier strings
        """
        return ["ones", "things", "them"]

    def parse_command_adjectiv_id_list(self):
        """
        Returns adjective identifiers for parsing.
        @return List of adjective identifier strings
        """
        return ["the", "a", "an"]

    def parse_command_prepos_list(self):
        """
        Returns preposition list for parsing.
        @return List of preposition strings
        """
        return ["in", "on", "at", "along", "upon", "by", "under", "behind", "with", "beside", "into", "onto", "inside", "within", "from"]

    def parse_command_all_word(self):
        """
        Returns the 'all' keyword for parsing.
        @return The 'all' string
        """
        return "all"

    def query_word_list(self, word):
        """
        Queries word lists by type.
        @param word The type of word list
        @return List of words or None
        """
        return self.parse_command_prepos_list() if word == "preposition" else None