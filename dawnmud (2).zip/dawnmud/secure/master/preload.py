# /lib/secure/master/preload.py
# Manages preloading of objects.

# /home/archaon/mud/lib/secure/master/preload.py
# Purpose: Handles preloading of objects during MUD startup by reading a configuration file and loading specified objects.
# Linked files: /home/archaon/mud/lib/secure/master.py, /home/archaon/mud/lib/secure/config/preload.py
# @updated: 2025-03-21 - Added autodoc_handler to preload list - Verified via https://dwwiki.mooo.com/wiki/Autodoc_Updates
# @updated: 2025-03-21 - Enhanced error logging for preload failures - Verified via https://discworld.starturtle.net/lpc/blog/blog.c?action=view&blog=recent%20developments&id=1046
# @started: 2025-03-21
# @author: Archaon
# Translated and coded by: Archaon

class Preload:
    """
    Manages the preloading of objects during MUD initialization.
    """

    def __init__(self, master):
        """
        Initializes the Preload module with a reference to the master object.
        @param master The Master instance providing driver access
        """
        self.master = master
        self.driver = master.driver
        self.create()

    def create(self) -> None:
        """Sets up initial state for preloading."""
        self.driver.seteuid("Root")

    def load_file(self, fname: str) -> list[str]:
        """
        Loads and parses a preload configuration file.
        @param fname The file name (e.g., 'preload' for /secure/config/preload.py)
        @return List of preload paths
        """
        try:
            # Import the config module dynamically
            config_module = __import__(f"mud.secure.config.{fname}", fromlist=[fname])
            preload_list = getattr(config_module, "PRELOAD_LIST", [])
            # Filter out commented or empty entries
            valid_paths = [path for path in preload_list if path and not path.startswith("#")]
            return valid_paths
        except ImportError:
            self.driver.log_file("/home/archaon/mud/log/PRELOAD_ERRORS", 
                                 f"{self.driver.ctime(self.driver.time())}: Failed to import config file /secure/config/{fname}.py\n")
            return []
        except Exception as e:
            self.driver.log_file("/home/archaon/mud/log/PRELOAD_ERRORS", 
                                 f"{self.driver.ctime(self.driver.time())}: Error loading config file /secure/config/{fname}.py: {str(e)}\n")
            return []

    def epilog(self) -> list[str]:
        """
        Returns the list of objects to preload during MUD initialization.
        @return List of preload paths
        """
        paths = self.load_file("preload")
        return paths

    def preload(self, file: str) -> None:
        """
        Preloads an object into the MUD.
        @param file The file path to preload
        """
        self.driver.write(f"Preloading: {file}\n")
        try:
            self.driver.load_object(file)
            self.driver.log_file("/home/archaon/mud/log/PRELOAD", 
                                 f"{self.driver.ctime(self.driver.time())}: Successfully preloaded {file}\n")
        except Exception as e:
            error_msg = f"Failed to preload {file}: {str(e)}"
            self.driver.write(f"            {error_msg}\n")
            self.driver.log_file("/home/archaon/mud/log/PRELOAD_ERRORS", 
                                 f"{self.driver.ctime(self.driver.time())}: {error_msg}\n")