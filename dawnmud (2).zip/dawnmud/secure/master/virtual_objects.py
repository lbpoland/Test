# /lib/secure/master/virtual_objects.py
# Manages virtual object compilation.

class VirtualObjects:
    def __init__(self, driver):
        self.driver = driver

    def compile_object(self, path):
        """
        Compiles a virtual object.
        @param path The virtual object path
        @return Compiled object or None
        """
        if self.driver.file_size(path) > 0:
            return self.driver.find_object("SERVER").create_virtual_object(path)
        bits = path.split(":")
        if len(bits) > 1 and (self.driver.file_size(bits[0]) > 0 or self.driver.file_size(f"{bits[0]}.c") > 0):
            return self.driver.call_other(bits[0], "create_virtual_object", *bits[1:])
        return None