# /lib/secure/master/valid_binary.py
# Validates binary file saving.

class ValidBinary:
    def __init__(self, driver):
        self.driver = driver

    def valid_save_binary(self, fname):
        """
        Checks if a file can be saved as a binary.
        @param fname The file path
        @return 1 if valid, 0 otherwise
        """
        bits = fname.split("/")
        return 1 if bits[0] in ["global", "std", "secure", "cmds", "d", "www", "obj"] else 0