# /lib/secure/master/valid_write.py
# Validates write permissions.

WRITE_FILE_STATS = 1

class ValidWrite:
    def __init__(self, driver):
        self.driver = driver
        self.write_stats = {}

    def valid_write(self, path, euid, func):
        """
        Checks if a user can write to a file.
        @param path The file path
        @param euid The effective user ID
        @param func The calling function
        @return 1 if allowed, 0 otherwise
        """
        master = self.driver.get_master()
        if path and path.endswith(",v"):
            return 0
        if func == "remove_file" and path.startswith("/save/players/"):
            log_msg = f"Deleting {path} by "
            if isinstance(euid, object):
                log_msg += f"{self.driver.file_name(self.driver.previous_object())}->{self.driver.call_stack(2)[0]}\n"
            else:
                log_msg += f"{euid} ({self.driver.file_name(self.driver.previous_object())}->{self.driver.call_stack(2)[0]})\n"
            self.driver.log_file("/d/admin/log/DELETE_PLAYER", log_msg)
        if euid == master:
            return 1
        if not path.startswith("/"):
            path = f"/{path}"
        if WRITE_FILE_STATS:
            if not self.write_stats:
                self.write_stats = {}
            if prev := self.driver.previous_object():
                prev_name = self.driver.base_name(prev)
                self.write_stats[prev_name] = self.write_stats.get(prev_name, {})
                self.write_stats[prev_name][path] = self.write_stats[prev_name].get(path, 0) + 1
        bits = path.split("/")
        prev_ob = self.driver.previous_object()
        if (euid and self.driver.file_size(path) > 0 and
            (not prev_ob or self.driver.file_name(prev_ob) not in ["/secure/cmds/creator/rcsout", "/secure/ftpd"]) and
            not path.endswith(".o") and bits[0] not in ["log", "save", "players"]):
            rcspath = f"/{'/'.join(bits[:-1])}/RCS/{bits[-1]},v" if len(bits) > 2 else f"/{bits[0]}/RCS/{bits[-1]},v" if len(bits) == 2 else f"/{bits[-1]},v"
            if self.driver.file_size(rcspath) > 0:
                if self.driver.read_file(rcspath, 4, 1) == "locks\n":
                    lockname = self.driver.read_file(rcspath, 5, 1).split(":")[0].strip("\t")
                    if ((isinstance(euid, object) and euid.query_name() != lockname) or
                        (isinstance(euid, str) and euid != lockname)):
                        stack = self.driver.previous_object(-1)
                        if not any(self.driver.geteuid(ob) == lockname for ob in stack):
                            return 0
        perms = master.permission_match_path(master.permissions, path)
        return self.driver.check_permission(euid, func, path, perms, self.driver.WRITE_MASK)

    def query_write_stats(self):
        """
        Returns write access statistics.
        @return Copy of write_stats mapping
        """
        return self.write_stats.copy()

    def reset(self):
        """
        Resets write and read statistics.
        """
        self.write_stats = {}
        self.driver.read_stats = {}  # Assuming read_stats is managed elsewhere