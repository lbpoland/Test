# /lib/secure/master/ed_stuff.py
# Manages editor setup and file paths.

class EdStuff:
    def __init__(self, driver):
        self.driver = driver

    def save_ed_setup(self, wiz, setup):
        """
        Saves editor setup for a wizard.
        @param wiz The wizard object
        @param setup The setup value
        @return 1 on success
        """
        wiz.set_ed_setup(setup)
        return 1

    def retrieve_ed_setup(self, wiz):
        """
        Retrieves editor setup for a wizard.
        @param wiz The wizard object
        @return Setup value
        """
        return wiz.query_ed_setup()

    def make_path_absolute(self, str_):
        """
        Converts a path to absolute if a player context exists.
        @param str_ The path to convert
        @return Absolute path or original string
        """
        if tp := self.driver.this_player():
            return tp.get_path(str_)
        return str_

    def get_save_file_name(self, file, who):
        """
        Generates a save file name for editor crashes.
        @param file The original file path
        @param who The user object
        @return Save file path or None
        """
        if not isinstance(who, object):
            return None
        file_ar = [f for f in file.split("/") if f]
        file = file_ar[-1]
        self.driver.write(f"File saved in \"/w/.dead_ed_files/{who.query_name()}-{file}\"\n")
        return f"/w/.dead_ed_files/{who.query_name()}-{file}"