# /lib/secure/master/permission.py
# Manages permissions and access control.
# @see /obj/handlers/player_handler.py

READ_MASK = 1
WRITE_MASK = 2
GRANT_MASK = 4
LOCK_MASK = 8

class Permission:
    def __init__(self, driver):
        self.driver = driver
        self.positions = {}  # Assuming inherited from master
        self.permissions = {}  # Assuming inherited from master
        self.checked_master = {}  # Assuming inherited from master
        self.unguarded_ob = None  # Assuming set elsewhere

    def add_senior(self, word):
        """
        Adds a senior position.
        @param word The creator name
        @return 1 on success, 0 on failure
        """
        interactives = [ob for ob in self.driver.previous_object(-1) if self.driver.is_interactive(ob)]
        if not interactives:
            self.driver.user_event("inform", f"{self.driver.this_player().query_name()} illegally attempted to call add_senior( {word} )", "cheat")
            self.driver.unguarded(lambda: self.driver.write_file("/log/CHEAT", f"{self.driver.ctime(self.driver.time())}: illegal attempt to call add_senior( {word} ).\n{self.driver.back_trace()}"))
            return 0
        master = self.driver.get_master()
        ph = self.driver.player_handler()
        if ph.test_user(word) and master.query_leader(self.driver.previous_object(-1)):
            self.driver.write_file("/log/PROMOTIONS", f"{self.driver.ctime(self.driver.time())}: {word} was promoted to Senior by {self.driver.geteuid(self.driver.this_interactive())}\n")
            if word not in self.positions or self.positions[word] not in [2, 3]:  # TRUSTEE=2, DIRECTOR=3
                self.positions[word] = 1  # SENIOR=1
            master.save_object("/secure/master")
            return 1
        return 0

    def remove_senior(self, str_):
        """
        Removes a senior position.
        @param str_ The creator name
        @return 1 on success, 0 on failure
        """
        interactives = [ob for ob in self.driver.previous_object(-1) if self.driver.is_interactive(ob)]
        if not interactives:
            self.driver.user_event("inform", f"{self.driver.this_player().query_cap_name()} illegally attempted to call remove_senior({str_})", "cheat")
            self.driver.unguarded(lambda: self.driver.write_file("/log/CHEAT", f"{self.driver.ctime(self.driver.time())}: Illegal attempt to call remove_senior({str_}).\n{self.driver.back_trace()}"))
            return 0
        master = self.driver.get_master()
        if master.query_leader(self.driver.previous_object(-1)) and self.positions.get(str_) == 1:  # SENIOR=1
            self.driver.write_file("/log/DEMOTIONS", f"{self.driver.ctime(self.driver.time())}: {str_} was demoted from Senior by {self.driver.geteuid(self.driver.this_interactive())}\n")
            self.positions.pop(str_, None)
            master.save_object("/secure/master")
            return 1
        return 0

    def add_director(self, str_):
        """
        Adds a director position.
        @param str_ The creator name
        @return 1 on success, 0 on failure
        """
        interactives = [ob for ob in self.driver.previous_object(-1) if self.driver.is_interactive(ob)]
        if not interactives:
            self.driver.user_event("inform", f"{self.driver.this_player().query_cap_name()} illegally attempted to call add_director({str_})", "cheat")
            self.driver.unguarded(lambda: self.driver.write_file("/log/CHEAT", f"{self.driver.ctime(self.driver.time())}: Illegal attempt to call add_director({str_}).\n{self.driver.back_trace()}"))
            return 0
        master = self.driver.get_master()
        ph = self.driver.player_handler()
        if ph.test_user(str_) and master.query_trustee(self.driver.previous_object(-1)):
            self.driver.write_file("/log/PROMOTIONS", f"{self.driver.ctime(self.driver.time())}: {str_} was promoted to Leader by {self.driver.geteuid(self.driver.this_interactive())}\n")
            if self.positions.get(str_) != 2:  # TRUSTEE=2
                self.positions[str_] = 3  # DIRECTOR=3
            master.save_object("/secure/master")
            return 1
        return 0

    def remove_director(self, str_):
        """
        Removes a director position.
        @param str_ The creator name
        @return 1 on success, 0 on failure
        """
        interactives = [ob for ob in self.driver.previous_object(-1) if self.driver.is_interactive(ob)]
        if not interactives:
            self.driver.user_event("inform", f"{self.driver.this_player().query_cap_name()} illegally attempted to call remove_director({str_})", "cheat")
            self.driver.unguarded(lambda: self.driver.write_file("/log/CHEAT", f"{self.driver.ctime(self.driver.time())}: Illegal attempt to call remove_director({str_}).\n{self.driver.back_trace()}"))
            return 0
        master = self.driver.get_master()
        if master.query_trustee(self.driver.previous_object(-1)) and self.positions.get(str_) == 3:  # DIRECTOR=3
            self.driver.write_file("/log/DEMOTIONS", f"{self.driver.ctime(self.driver.time())}: {str_} was demoted from Leader by {self.driver.geteuid(self.driver.this_interactive())}\n")
            self.positions.pop(str_, None)
            master.save_object("/secure/master")
            return 1
        return 0

    def add_trustee(self, str_):
        """
        Adds a trustee position.
        @param str_ The creator name
        @return 1 on success, 0 on failure
        """
        interactives = [ob for ob in self.driver.previous_object(-1) if self.driver.is_interactive(ob)]
        if not interactives:
            self.driver.user_event("inform", f"{self.driver.this_player().query_cap_name()} illegally attempted to call add_tristee({str_})", "cheat")
            self.driver.unguarded(lambda: self.driver.write_file("/log/CHEAT", f"{self.driver.ctime(self.driver.time())}: Illegal attempt to call add_trustee({str_}).\n{self.driver.back_trace()}"))
            return 0
        master = self.driver.get_master()
        ph = self.driver.player_handler()
        if ph.test_user(str_) and master.query_trustee(self.driver.previous_object(-1)):
            self.driver.write_file("/log/PROMOTIONS", f"{self.driver.ctime(self.driver.time())}: {str_} was promoted to Administrator by {self.driver.geteuid(self.driver.this_interactive())}\n")
            self.positions[str_] = 2  # TRUSTEE=2
            master.save_object("/secure/master")
            return 1
        return 0

    def remove_trustee(self, str_):
        """
        Removes a trustee position.
        @param str_ The creator name
        @return 1 on success, 0 on failure
        """
        interactives = [ob for ob in self.driver.previous_object(-1) if self.driver.is_interactive(ob)]
        if not interactives:
            self.driver.user_event("inform", f"{self.driver.this_player().query_cap_name()} illegally attempted to call remove_trustee({str_})", "cheat")
            self.driver.unguarded(lambda: self.driver.write_file("/log/CHEAT", f"{self.driver.ctime(self.driver.time())}: Illegal attempt to call remove_trustee({str_}).\n{self.driver.back_trace()}"))
            return 0
        master = self.driver.get_master()
        if master.query_trustee(self.driver.previous_object(-1)) and self.positions.get(str_) == 2:  # TRUSTEE=2
            self.driver.write_file("/log/DEMOTIONS", f"{self.driver.ctime(self.driver.time())}: {str_} was demoted from Administrator by {self.driver.geteuid(self.driver.this_interactive())}\n")
            self.positions.pop(str_, None)
            master.save_object("/secure/master")
            return 1
        return 0

    def check_domain(self, ob, func, path, mask):
        """
        Checks domain-specific permissions.
        @param ob The requesting object or euid
        @param func The function being called
        @param path The file path
        @param mask Permission mask
        @return 1 if allowed, 0 otherwise
        """
        bits = [b for b in path.split("/") if b and b != "."]
        if len(bits) < 2:
            return mask & READ_MASK
        domain = bits[1]
        euid = self.driver.geteuid(ob) if isinstance(ob, object) else ob
        if euid == self.driver.creator_file(path):
            return 1
        master = f"/d/{domain}/master"
        master_ob = self.driver.find_object(master)
        if not master_ob and master in self.checked_master:
            return mask & READ_MASK
        if not master_ob and master not in self.checked_master:
            try:
                master_ob = self.driver.load_object(master)
            except:
                self.checked_master[master] = True
                return mask & READ_MASK
        if master_ob:
            ret = master_ob.check_permission(euid, bits, mask)
            if ret == -1:
                return 0
            if len(bits) > 2 and bits[2] not in ["master.c", "master.o", "master"] and master.query_senior(euid):
                return 1
            return ret or (master_ob.valid_read(bits, euid, func) if mask & READ_MASK else master_ob.valid_write(bits, euid, func))
        return mask & READ_MASK

    def check_creator(self, ob, func, path, mask):
        """
        Checks creator-specific permissions.
        @param ob The requesting object or euid
        @param func The function being called
        @param path The file path
        @param mask Permission mask
        @return 1 if allowed, 0 otherwise
        """
        bits = [b for b in path.split("/") if b and b != "."]
        if len(bits) < 2:
            return mask & READ_MASK
        creator = bits[1]
        euid = self.driver.geteuid(ob) if isinstance(ob, object) else ob
        if mask & GRANT_MASK:
            return 1 if euid == creator else 0
        if (mask & READ_MASK) and len(bits) >= 3 and bits[2] == "mbox" and self.driver.file_size(f"/w/{bits[1]}/mbox") != -2:
            return euid == bits[1]
        if (mask & READ_MASK) or euid == self.driver.creator_file(path):
            return 1
        master = f"/w/{creator}/master"
        master_ob = self.driver.find_object(master)
        if not master_ob and master in self.checked_master:
            return 0
        if not master_ob and master not in self.checked_master:
            try:
                master_ob = self.driver.load_object(master)
            except:
                self.checked_master[master] = True
                return 0
        return master_ob.check_permission(euid, bits, mask) or master_ob.valid_write(bits, euid, func) if master_ob else 0

    def check_permission(self, ob, func, path, perms, mask):
        """
        Checks permission for an action on a path.
        @param ob The requesting object or euid
        @param func The function being called
        @param path The file path
        @param perms Permission mapping
        @param mask Permission mask
        @return 1 if allowed, 0 otherwise
        """
        master = self.driver.get_master()
        if perms and "all" in perms and perms["all"] & mask:
            return 1
        if path.startswith("/save/boards/lordboard") and self.driver.base_name(ob) != "/obj/handlers/board_handler":
            self.driver.log_file("/d/admin/log/LORDBOARD", f"{self.driver.ctime(self.driver.time())[4:19]}: ob {self.driver.base_name(ob)} player {self.driver.this_player().query_name()} prev {self.driver.base_name(self.driver.previous_object())}\n")
        stack = []
        if self.unguarded_ob == ob:
            tmp = self.driver.base_name(ob)
            if tmp in ["/global/player", "/global/playtester", "/global/creator", "/global/lord"]:
                name = ob.query_name()
                allowed_paths = [
                    f"/save/players/{name[0]}/{name}",
                    f"/save/players/{name[0]}/{name}.o",
                    f"/save/players/{name[0]}/{name}.o.gz",
                    f"/save/ramdisk/players/{name[0]}/{name}",
                    f"/save/ramdisk/players/{name[0]}/{name}.o",
                    f"/save/ramdisk/players/{name[0]}/{name}.o.gz"
                ]
                if path in allowed_paths:
                    return 1
                stack = [ob] + self.driver.previous_object(-1)
            elif tmp == path:
                return 1
            else:
                stack = [ob]
        elif self.unguarded_ob and self.driver.base_name(ob) == "/secure/simul_efun":
            stack = [self.driver.previous_object(1)] if self.unguarded_ob == self.driver.previous_object(1) else [ob] + self.driver.previous_object(-1)
        elif self.unguarded_ob:
            stack = self.driver.previous_object(-1)
            stack = stack[:next((i for i, x in enumerate(stack) if x == self.unguarded_ob), len(stack)) + 1] + [ob]
        else:
            stack = [ob] + self.driver.previous_object(-1)
        for i in range(len(stack) - 1, -1, -1):
            if not stack[i]:
                return 0
            if stack[i] == self.driver.this_object():
                continue
            if isinstance(stack[i], object):
                if self.driver.file_name(stack[i]) == "/secure/simul_efun":
                    continue
                euid = self.driver.geteuid(stack[i])
                if not euid:
                    return 0
            else:
                euid = stack[i]
            if euid == master.get_root_uid():
                continue
            if master.query_director(euid) and mask & READ_MASK:
                continue
            if master.query_trustee(euid):
                continue
            if perms:
                if euid in perms and perms[euid] & mask:
                    continue
                if "all" in perms and perms["all"] & LOCK_MASK:
                    return 0
            if path.startswith("/w/"):
                if self.check_creator(stack[i], func, path, mask):
                    continue
            elif path.startswith("/d/"):
                if self.check_domain(stack[i], func, path, mask):
                    continue
            else:
                return mask & READ_MASK
            return 0
        return 1

    def permission_match_path(self, m, path):
        """
        Matches permissions to a path hierarchy.
        @param m Permission mapping
        @param path The file path
        @return Matching permissions or None
        """
        if not m:
            return None
        bits = [b for b in path.split("/") if b and b != "."]
        p = ""
        found = {}
        if "/" in m:
            found.update(m["/"])
        for i in range(len(bits) + 1):
            if p in m:
                old = found.copy()
                found.update(m[p])
                if len(found) != len(old) + len(m[p]):
                    found = old
                    for euid, mask in m[p].items():
                        found[euid] = found.get(euid, 0) | mask
            if i < len(bits):
                p += f"/{bits[i]}"
        return found if found else None

    def valid_grant(self, euid, path, mask):
        """
        Validates grant permissions.
        @param euid The effective user ID
        @param path The file path
        @param mask Permission mask
        @return 1 if valid, 0 otherwise
        """
        if not path.startswith("/"):
            path = f"/{path}"
        result = self.check_permission(euid, None, path, self.permission_match_path(self.permissions, path), GRANT_MASK)
        if not result or mask & (READ_MASK | WRITE_MASK):
            return result
        try:
            domain = path.split("/d/")[1].split("/")[0]
        except IndexError:
            return 0
        master = f"/d/{domain}/master"
        master_ob = self.driver.find_object(master)
        if not master_ob and master in self.checked_master:
            return 0
        if not master_ob and master not in self.checked_master:
            try:
                master_ob = self.driver.load_object(master)
            except:
                self.checked_master[master] = True
                return 0
        director = master_ob.query_director() or master_ob.query_lord()
        prev_euids = [self.driver.geteuid(ob) for ob in self.driver.previous_object(-1)]
        return 1 if self.driver.get_master().query_director(prev_euids + [euid]) and director in prev_euids else 0

    def query_permissions(self):
        """
        Queries all permissions including domain-specific ones.
        @return Combined permissions mapping
        """
        doms = [d for d in self.driver.get_dir("/d/") if d != "lost+found"]
        blue = {}
        for dom in doms:
            master = f"/d/{dom}/master"
            master_ob = self.driver.find_object(master)
            if not master_ob and master in self.checked_master:
                continue
            if not master_ob and master not in self.checked_master:
                try:
                    master_ob = self.driver.load_object(master)
                except:
                    self.checked_master[master] = True
                    continue
            tmp = master_ob.query_access()
            if isinstance(tmp, dict):
                blue.update(tmp)
        return {**self.permissions, **blue}

    def add_permission(self, euid, path, mask):
        """
        Adds a permission to a path.
        @param euid The effective user ID
        @param path The file path
        @param mask Permission mask
        @return 1 on success, 0 on failure
        """
        bits = path.split("/")
        if path.startswith("/d/") and len(bits) >= 3:
            master = f"/d/{bits[2]}/master"
            master_ob = self.driver.find_object(master)
            if not master_ob and master in self.checked_master:
                return 0
            if not master_ob and master not in self.checked_master:
                try:
                    master_ob = self.driver.load_object(master)
                except:
                    self.checked_master[master] = True
                    return self.driver.notify_fail("Failed to load master file.\n")
            if mask & LOCK_MASK and not any(master_ob.query_lord() == self.driver.geteuid(ob) for ob in self.driver.previous_object(-1)):
                return self.driver.notify_fail(f"You are not the leader of $C${bits[2]}.\n")
            return master_ob.add_permission(euid, path, mask)
        if path not in self.permissions:
            self.permissions[path] = {euid: mask}
        else:
            self.permissions[path][euid] = self.permissions[path].get(euid, 0) | mask
        self.driver.unguarded(lambda: self.driver.get_master().save_object("/secure/master"))
        return 1

    def add_read_permission(self, euid, path):
        """
        Adds read permission to a path.
        @param euid The effective user ID
        @param path The file path
        @return 1 on success, 0 on failure
        """
        prev = self.driver.base_name(self.driver.previous_object())
        if prev not in ["/d/admin/room/access_control", "/cmds/creator/permit"]:
            self.driver.user_event("inform", f"{self.driver.this_interactive().query_cap_name()} illegally attempted to call add_read_permission({euid}, {path})", "cheat")
            self.driver.unguarded(lambda: self.driver.write_file("/log/CHEAT", f"{self.driver.ctime(self.driver.time())}: Illegal attempt to call add_read_permission({euid}, {path}).\n{self.driver.back_trace()}"))
            return 0
        if self.add_permission(euid, path, READ_MASK):
            self.driver.write(f"Added read permission for {euid} to {path}.\n")
            return 1
        return 0

    def add_write_permission(self, euid, path):
        """
        Adds write permission to a path.
        @param euid The effective user ID
        @param path The file path
        @return 1 on success, 0 on failure
        """
        prev = self.driver.base_name(self.driver.previous_object())
        if prev not in ["/d/admin/room/access_control", "/cmds/creator/permit"]:
            self.driver.user_event("inform", f"{self.driver.this_player(1).query_cap_name()} illegally attempted to call add_write_permission({euid}, {path})", "cheat")
            self.driver.unguarded(lambda: self.driver.write_file("/log/CHEAT", f"{self.driver.ctime(self.driver.time())}: Illegal attempt to call add_write_permission({euid}, {path}).\n{self.driver.back_trace()}"))
            return 0
        if self.add_permission(euid, path, WRITE_MASK):
            self.driver.write(f"Added write permission for {euid} to {path}.\n")
            return 1
        return 0

    def add_grant_permission(self, euid, path):
        """
        Adds grant permission to a path.
        @param euid The effective user ID
        @param path The file path
        @return 1 on success, 0 on failure
        """
        prev = self.driver.base_name(self.driver.previous_object())
        if prev not in ["/d/admin/room/access_control", "/cmds/creator/permit"]:
            self.driver.user_event("inform", f"{self.driver.this_player(1).query_cap_name()} illegally attempted to call add_grant_permission({euid}, {path})", "cheat")
            self.driver.unguarded(lambda: self.driver.write_file("/log/CHEAT", f"{self.driver.ctime(self.driver.time())}: Illegal attempt to call add_grant_permission({euid}, {path}).\n{self.driver.back_trace()}"))
            return 0
        if self.add_permission(euid, path, GRANT_MASK):
            self.driver.write(f"Added grant permission for {euid} to {path}.\n")
            return 1
        return 0

    def lock_path(self, path):
        """
        Locks a path for all users.
        @param path The file path
        @return 1 on success, 0 on failure
        """
        prev = self.driver.base_name(self.driver.previous_object())
        if prev not in ["/d/admin/room/access_control", "/cmds/creator/permit"]:
            self.driver.user_event("inform", f"{self.driver.this_player(1).query_cap_name()} illegally attempted to call lock_path({path})", "cheat")
            self.driver.unguarded(lambda: self.driver.write_file("/log/CHEAT", f"{self.driver.ctime(self.driver.time())}: Illegal attempt to call lock_path({path}).\n{self.driver.back_trace()}"))
            return 0
        if self.add_permission("all", path, LOCK_MASK):
            self.driver.write(f"Restricted access for all to {path}.\n")
            return 1
        return 0

    def remove_permission(self, euid, path, mask):
        """
        Removes a permission from a path.
        @param euid The effective user ID
        @param path The file path
        @param mask Permission mask
        @return 1 on success, 0 on failure
        """
        bits = path.split("/")
        if path.startswith("/d/") and len(bits) >= 3:
            master = f"/d/{bits[2]}/master"
            master_ob = self.driver.find_object(master)
            if not master_ob and master in self.checked_master:
                return 0
            if not master_ob and master not in self.checked_master:
                try:
                    master_ob = self.driver.load_object(master)
                except:
                    self.checked_master[master] = True
                    return self.driver.notify_fail("Failed to load master file.\n")
            if mask & LOCK_MASK and not any(master_ob.query_lord() == self.driver.geteuid(ob) for ob in self.driver.previous_object(-1)):
                return self.driver.notify_fail(f"You are not the lord of $C${bits[2]}.\n")
            return master_ob.remove_permission(euid, path, mask)
        if path not in self.permissions or euid not in self.permissions[path]:
            self.driver.notify_fail(f"The euid \"{euid}\" does not have any permissions to remove in {path}.\n")
            return 0
        self.permissions[path][euid] &= ~mask
        if not self.permissions[path][euid]:
            if len(self.permissions[path]) == 1:
                self.permissions.pop(path, None)
            else:
                self.permissions[path].pop(euid, None)
        self.driver.unguarded(lambda: self.driver.get_master().save_object("/secure/master"))
        return 1

    def remove_read_permission(self, euid, path):
        """
        Removes read permission from a path.
        @param euid The effective user ID
        @param path The file path
        @return 1 on success, 0 on failure
        """
        prev = self.driver.base_name(self.driver.previous_object())
        if prev not in ["/d/admin/room/access_control", "/cmds/creator/permit"]:
            self.driver.user_event("inform", f"{self.driver.this_player(1).query_cap_name()} illegally attempted to call remove_read_permission({euid}, {path})", "cheat")
            self.driver.unguarded(lambda: self.driver.write_file("/log/CHEAT", f"{self.driver.ctime(self.driver.time())}: Illegal attempt to call remove_read_permission({euid}, {path}).\n{self.driver.back_trace()}"))
            return 0
        if self.remove_permission(euid, path, READ_MASK):
            self.driver.write(f"Removed read permission for {euid} to {path}.\n")
            return 1
        return 0

    def remove_write_permission(self, euid, path):
        """
        Removes write permission from a path.
        @param euid The effective user ID
        @param path The file path
        @return 1 on success, 0 on failure
        """
        prev = self.driver.base_name(self.driver.previous_object())
        if prev not in ["/d/admin/room/access_control", "/cmds/creator/permit"]:
            self.driver.user_event("inform", f"{self.driver.this_player(1).query_cap_name()} illegally attempted to call remove_write_permission({euid}, {path})", "cheat")
            self.driver.unguarded(lambda: self.driver.write_file("/log/CHEAT", f"{self.driver.ctime(self.driver.time())}: Illegal attempt to call remove_write_permission({euid}, {path}).\n{self.driver.back_trace()}"))
            return 0
        if self.remove_permission(euid, path, WRITE_MASK):
            self.driver.write(f"Removed write permission for {euid} to {path}.\n")
            return 1
        return 0

    def remove_grant_permission(self, euid, path):
        """
        Removes grant permission from a path.
        @param euid The effective user ID
        @param path The file path
        @return 1 on success, 0 on failure
        """
        prev = self.driver.base_name(self.driver.previous_object())
        if prev not in ["/d/admin/room/access_control", "/cmds/creator/permit"]:
            self.driver.user_event("inform", f"{self.driver.this_player(1).query_cap_name()} illegally attempted to call remove_grant_permission({euid}, {path})", "cheat")
            self.driver.unguarded(lambda: self.driver.write_file("/log/CHEAT", f"{self.driver.ctime(self.driver.time())}: Illegal attempt to call remove_grant_permission({euid}, {path}).\n{self.driver.back_trace()}"))
            return 0
        if self.remove_permission(euid, path, GRANT_MASK):
            self.driver.write(f"Removed grant permission for {euid} to {path}.\n")
            return 1
        return 0

    def unlock_path(self, path):
        """
        Unlocks a path for all users.
        @param path The file path
        @return 1 on success, 0 on failure
        """
        prev = self.driver.base_name(self.driver.previous_object())
        if prev not in ["/d/admin/room/access_control", "/cmds/creator/permit"]:
            self.driver.user_event("inform", f"{self.driver.this_player(1).query_cap_name()} illegally attempted to call unlock_path({path})", "cheat")
            self.driver.unguarded(lambda: self.driver.write_file("/log/CHEAT", f"{self.driver.ctime(self.driver.time())}: Illegal attempt to call unlock_path({path}).\n{self.driver.back_trace()}"))
            return 0
        if self.remove_permission("all", path, LOCK_MASK):
            self.driver.write(f"Removed access restrictions for all to {path}.\n")
            return 1
        return 0