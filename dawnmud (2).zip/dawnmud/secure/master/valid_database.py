# /lib/secure/master/valid_database.py
# Validates database access.

class ValidDatabase:
    def __init__(self, driver):
        self.driver = driver

    def valid_database(self, ob, action, info):
        """
        Checks if an object can access the database.
        @param ob The requesting object
        @param action The database action
        @param info Additional info array
        @return -1 if valid, 0 otherwise
        """
        obname = self.driver.base_name(ob)
        return -1 if obname in ["/obj/handlers/clusters", "/obj/handlers/map", "/cmds/creator/osql", "/cmds/errors_base"] else 0