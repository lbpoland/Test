# /lib/secure/master/creator_file.py
# Determines creator and domain assignments for files.

class CreatorFile:
    def __init__(self, driver):
        self.driver = driver

    def creator_file(self, file, author=0):
        """
        Determines the creator for a given file path.
        @param file The file path or object
        @param author Flag to determine author (optional)
        @return Creator name or None
        """
        if not file or not isinstance(file, str):
            return "NOONE"
        if isinstance(file, object):
            file = self.driver.file_name(file)
        str_ = [s for s in file.split("/") if s]
        if len(str_) < 2:
            return None
        master = self.driver.get_master()
        root_uid = master.get_root_uid()
        bb_uid = master.get_bb_uid()
        match str_[0]:
            case "secure":
                return root_uid
            case "obj":
                if len(str_) > 2 and str_[1] == "secure":
                    return "ims"
                return None
            case "global" | "std" | "cmds" | "room":
                return bb_uid
            case "net":
                return "Network"
            case "www":
                if len(str_) > 2 and str_[1] == "secure":
                    return "Root"
                return "WWW"
            case "tmp":
                return "monster" if str_[1] == "mon-shad" else None
            case "failsafe":
                return "failsafe"
            case "d":
                if len(str_) < 3:
                    return None
                if not author or str_[1] not in master.query_domains():
                    return str_[1].capitalize()
                return self.driver.find_object(f"/d/{str_[1]}/master").author_file(str_)
            case "w":
                if len(str_) < 3:
                    return "womble-frog" if str_[1] in ["common", "development", "meeting"] else None
                return str_[1]
        return None

    def author_file(self, bing):
        """
        Wrapper for creator_file with author flag.
        @param bing The file path or object
        @return Author name or None
        """
        return self.creator_file(bing, 1)

    def domain_file(self, bing):
        """
        Determines the domain for a file path.
        @param bing The file path or object
        @return Domain name or None
        """
        str_ = self.creator_file(bing)
        if not str_:
            return str_
        if str_[0].isupper():
            return str_
        return "Creator"