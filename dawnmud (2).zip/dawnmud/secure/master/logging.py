# /lib/secure/master/logging.py
# Handles error logging and tracing.

MAX_SIZE = 50000

class Logging:
    def __init__(self, driver):
        self.driver = driver

    def get_wiz_name(self, file):
        """
        Gets the wizard name for a file.
        @param file File path or object
        @return Wizard name
        """
        if not self.driver.previous_object():
            return "root"
        if isinstance(file, object):
            file = self.driver.file_name(file)
        file = [f for f in file.split("/") if f]
        if file[0] == "w":
            return file[1] if self.driver.file_size(f"/w/{file[1]}") == -2 else "root"
        return "dom" if file[0] == "d" else "root"

    def get_dom_name(self, file):
        """
        Gets the domain name for a file.
        @param file File path or object
        @return Domain name or None
        """
        if isinstance(file, object):
            file = self.driver.file_name(file)
        file = [f for f in file.split("/") if f]
        return file[1] if file[0] == "d" and len(file) >= 2 else None

    def get_prg_name(self, file):
        """
        Gets the program name for a file.
        @param file File path or object
        @return Program name
        """
        if isinstance(file, object):
            file = self.driver.file_name(file)
        file = [f for f in file.split("/") if f]
        return file[1] if file[0] == "w" else "root"

    def different(self, fn, pr):
        """
        Checks if two file paths differ.
        @param fn First file path
        @param pr Second file path
        @return True if different
        """
        fn = fn.split("#")[0] + ".c"
        return fn != pr and fn != f"/{pr}"

    def trace_line(self, obj, prog, file, line):
        """
        Formats a trace line.
        @param obj The object involved
        @param prog The program file
        @param file The source file
        @param line The line number
        @return Formatted trace string
        """
        objfn = self.driver.file_name(obj) if obj else "<none>"
        ret = objfn
        if self.different(objfn, prog):
            ret += f" ({prog})"
        ret += f" in {file}:{line}\n" if file != prog else f" at line {line}\n"
        return ret

    def printable_arg(self, arg):
        """
        Formats an argument for display.
        @param arg The argument to format
        @return Formatted string
        """
        max_len = self.driver.get_config("__MAX_STRING_LENGTH__")
        arg_type = type(arg).__name__
        if arg_type in ["list", "dict", "type"]:  # Assuming CLASS maps to type
            arg_str = str(arg)
            if len(arg_type) + len(arg_str) + 4 < max_len:
                return f"({arg_type}) {arg_str}"
            return f"({arg_type}) <too large>"
        elif isinstance(arg, str):
            if len("string") + len(arg) + 4 < max_len:
                return f"(string) \"{arg}\""
            return "(string) <too large>"
        return f"({arg_type}) {arg}"

    def trace_args(self, args):
        """
        Formats function arguments for trace.
        @param args List of arguments
        @return Formatted string
        """
        if not args:
            return " (void)"
        tmp = [self.printable_arg(a) for a in args]
        return f"\n(\n    {', '.join(tmp)}\n)"

    def trace_locals(self, args):
        """
        Formats local variables for trace.
        @param args List of local variables
        @return Formatted string
        """
        if not args:
            return " none."
        tmp = [self.printable_arg(a) for a in args]
        return f"\n    {', '.join(tmp)}"

    def standard_trace(self, mp, flag=0):
        """
        Generates a standard error trace.
        @param mp Error mapping
        @param flag Include detailed args/locals if 0
        @return Trace string
        """
        ret = (f"{mp['error']}Object: {self.trace_line(mp['object'], mp['program'], mp['file'], mp['line'])}"
               f"Arguments were:{self.trace_args(mp['arguments'])}\nLocals were:{self.trace_locals(mp['locals'])}\n\n")
        trace = mp["trace"]
        max_len = self.driver.get_config("__MAX_STRING_LENGTH__")
        for i, t in enumerate(trace):
            ret += f"({i + 1}) '{t['function']}' in {self.trace_line(t['object'], t['program'], t['file'], t['line'])}"
            if not flag and (len(ret) + len(self.trace_args(t["arguments"])) + len(self.trace_locals(t["locals"])) + 20) < max_len:
                ret += f"Arguments were:{self.trace_args(t['arguments'])}\nLocals were:{self.trace_locals(t['locals'])}\n"
        return ret

    def error_handler(self, error, caught):
        """
        Logs and handles runtime errors.
        @param error Error mapping
        @param caught Flag indicating if caught
        """
        ret = f"--------------------\n{self.driver.ctime(self.driver.time())}:  {self.standard_trace(error)}"
        file = "catch" if caught else "runtime"
        try:
            obname = error["error"].split("Error in loading object '")[1].split("'")[0]
        except IndexError:
            obname = self.driver.file_name(error["object"]) if error["object"] else error["program"]
        name = self.get_wiz_name(obname)
        if name == "root":
            path = f"/log/{file}"
        elif name == "dom":
            if obname.startswith("/d/am/short/flats/"):
                path = f"/d/am/short/flats/{file}"
            elif obname.startswith(("/d/am/elm/", "/d/am/lame")):
                path = f"/d/am/short/flats/{file}"
            else:
                path = f"/d/{self.get_dom_name(obname)}/{file}"
        else:
            path = f"/w/{name}/{file}"
            self.driver.tell_creator(name, f"A runtime error occurred in the file {obname}, logged to {path}.\n")
        call_stack_funcs = self.driver.call_stack(2)
        if "init_dynamic_arg" in call_stack_funcs or "query_dynamic_auto_load" in call_stack_funcs:
            path = f"/d/admin/log/auto_{file}"
        if self.driver.file_size(path) > MAX_SIZE:
            self.driver.unguarded(lambda: self.driver.rm(f"{path}.old"))
            self.driver.unguarded(lambda: self.driver.rename(path, f"{path}.old"))
        self.driver.unguarded(lambda: self.driver.write_file(path, ret))
        if (tp := self.driver.this_player(1)) and self.driver.find_object("/secure/simul_efun"):
            tp.set_last_error(error)
            if not caught:
                if tp.query_creator():
                    self.driver.tell_object(tp, f"{error['error']}Object: {self.trace_line(error['object'], error['program'], error['file'], error['line'])}\nTrace written to {path}\n")
                else:
                    self.driver.tell_object(tp, "A runtime error occurred.\nPlease use the \"bug\" command to report it, describing what you tried to do when it happened.\n")

    def log_error(self, file, message):
        """
        Logs compilation errors or warnings.
        @param file The file path
        @param message The error message
        """
        if "Warning:" in message:
            efile, colour = ("type-error", "%^RED%^") if "Trying to put" in message else ("warnings", "%^CYAN%^")
        else:
            efile, colour = "error-log", "%^RED%^"
        if (tp := self.driver.this_player(1)) and tp.query_creator():
            self.driver.tell_object(tp, f"{colour}{message}%^RESET%^")
        name = self.get_wiz_name(file)
        epath = f"/log/{efile}" if name == "root" else f"/d/{self.get_dom_name(file)}/{efile}" if name == "dom" else f"/w/{name}/{efile}"
        if self.driver.file_size(epath) > MAX_SIZE:
            self.driver.unguarded(lambda: self.driver.rm(f"{epath}.old"))
            self.driver.unguarded(lambda: self.driver.rename(epath, f"{epath}.old"))
        self.driver.unguarded(lambda: self.driver.write_file(epath, message))

    def do_log(self, person, text):
        """
        Logs player-specific errors.
        @param person The player's name
        @param text The log text
        """
        if self.driver.file_name(self.driver.previous_object()) != "/std/smart_log" or self.driver.file_size(f"/w/{person}") != -2:
            return
        self.driver.unguarded(lambda: self.driver.rm(f"/w/{person}/PLAYER_ERROR_LOG"))
        self.driver.unguarded(lambda: self.driver.write_file(f"/w/{person}/PLAYER_ERROR_LOG", text))

    def forward_error(self, file, text):
        """
        Forwards error reports to a file.
        @param file The target file path
        @param text The error text
        """
        prev = self.driver.file_name(self.driver.previous_object())
        if prev not in ["/secure/cmds/creator/errors", "/www/secure/errors"]:
            return
        self.driver.unguarded(lambda: self.driver.write_file(file, text))