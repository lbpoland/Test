# /lib/secure/master/create_dom_creator.py
# Manages domain creation and creator employment/dismissal.
# @see /obj/handlers/player_handler.py
# @see /obj/handlers/quest_handler.py

BACKUP_DIR = "/save/creators/"

class CreateDomCreator:
    def __init__(self, driver):
        self.driver = driver

    def create_domain(self, name, lord):
        """
        Creates a new domain with a specified lord.
        @param name The domain name
        @param lord The lord's name
        @return 1 on success, 0 on failure
        """
        master = self.driver.get_master()
        prev_obs = self.driver.previous_object(-1)
        interactives = [ob for ob in prev_obs if self.driver.is_interactive(ob)]
        if not (master.high_programmer(prev_obs) and interactives):
            self.driver.write("Cheat!\n")
            return 0
        if master.high_programmer(name.capitalize()):
            self.driver.write("Invalid name....\n")
            return 0
        if self.driver.file_size(f"/d/{name}") != -1:
            self.driver.write("Domain already exists (or invalid).\n")
            return 0
        if "/" in name:
            self.driver.write("Invalid to have a / in the domain name.\n")
            return 0
        if not self.driver.player_handler().test_creator(lord):
            self.driver.write("The lord must exist.... and be a creator already.\n")
            return 0
        self.driver.mkdir(f"/d/{name}")
        master.add_lord(lord)
        file = self.driver.read_file("/std/dom/master.c")
        self.driver.write_file(f"/d/{name}/master.c", f'#define LORD "{lord}"\n')
        self.driver.write_file(f"/d/{name}/master.c", f'#define DOMAIN "{name}"\n')
        self.driver.write_file(f"/d/{name}/master.c", file)
        file = self.driver.read_file("/std/dom/common.c")
        self.driver.write_file(f"/d/{name}/common.c", f'#define DOM_TITLE "the domain of {name}"\n')
        self.driver.write_file(f"/d/{name}/common.c", f'#define LORD "{lord}"\n')
        self.driver.write_file(f"/d/{name}/common.c", f'#define DOMAIN "{name}"\n')
        self.driver.write_file(f"/d/{name}/common.c", file)
        file = self.driver.read_file("/std/dom/loader.c")
        self.driver.write_file(f"/d/{name}/loader.c", f'#define DOMAIN "{name}"\n')
        self.driver.write_file(f"/d/{name}/loader.c", file)
        master.save_object("/secure/master")
        self.driver.write(f"Created domain {name}.\n")
        self.driver.write_file("/log/PROMOTIONS", f"Domain {name} created with a lord of {lord} by {self.driver.geteuid(interactives[0])} at {self.driver.ctime(self.driver.time())}\n")
        return 1

    def employ_creator(self, name):
        """
        Employs a user as a creator with backups.
        @param name The creator's name
        @return 2 on success, 1 on partial success, 0 on failure
        """
        master = self.driver.get_master()
        prev_obs = self.driver.previous_object(-1)
        interactives = [ob for ob in prev_obs if self.driver.is_interactive(ob)]
        if not (master.query_lord(prev_obs) and interactives):
            return 0
        ph = self.driver.player_handler()
        if not ph.test_user(name):
            self.driver.write("User does not exist.\n")
            return 1
        if self.driver.file_size(f"{BACKUP_DIR}{name}/save_file.o") > 0:
            self.driver.write("Player file has already been backed up.\n")
            return 1
        fname = ph.query_player_file_name(name)
        if self.driver.file_size(f"{fname}.o.gz") > 0:
            self.driver.unguarded(lambda: self.driver.uncompress_file(f"{fname}.o.gz"))
        self.driver.mkdir(f"{BACKUP_DIR}{name}")
        self.driver.unguarded(lambda: self.driver.cp(f"{fname}.o", f"{BACKUP_DIR}{name}/save_file.o"))
        self.backup_vaults(name, 0)
        self.backup_bank(name, 0)
        self.backup_quest_library(name, 0)
        if player := self.driver.find_player(name):
            player.set_creator(1)
            player.save()
            self.driver.tell_object(player, f"You have been employed by {self.driver.geteuid(interactives[0]).capitalize()}.\n")
            self.driver.tell_object(player, "Quit and log back in to get the creator commands.\n")
            self.driver.tell_object(player, "Be sure to look over the directories, especially /doc. \"help create\" will give you a brief list of commands.\n")
            self.driver.tell_object(player, "Womble on, mighty frog.\n")
        else:
            self.driver.unguarded(lambda: self.driver.write_file(f"{fname}.o", f"creator 1\nhome_dir \"/w/{name}\"\n"))
        self.driver.unguarded(lambda: self.driver.compress_file(f"{fname}.o.gz"))
        if self.driver.file_size(f"/w/{name}") == -1:
            self.driver.unguarded(lambda: self.driver.mkdir(f"/w/{name}"))
            self.driver.unguarded(lambda: self.driver.write_file(f"/w/{name}/workroom.c", f'#define CREATOR "{name}"\n'))
            self.driver.unguarded(lambda: self.driver.write_file(f"/w/{name}/workroom.c", self.driver.read_file("/std/creator/workroom.c")))
            self.driver.unguarded(lambda: self.driver.cp("/std/creator/creator_kit.o", f"/w/{name}/creator_kit.o"))
        self.driver.unguarded(lambda: self.driver.write_file("/log/EMPLOYMENT", f"{self.driver.ctime(self.driver.time())}: {name} employed by {interactives[0].query_name()}\n"))
        self.driver.write(f"{name.capitalize()} employed.\n")
        ph.remove_cache_entry(name)
        return 2

    def dismiss_creator(self, str_):
        """
        Dismisses a creator and restores backups.
        @param str_ Format: "name reason"
        @return 1 on success, 0 on failure
        """
        master = self.driver.get_master()
        prev_obs = self.driver.previous_object(-1)
        interactives = [ob for ob in prev_obs if self.driver.is_interactive(ob)]
        if not (master.query_lord(prev_obs) and interactives):
            return 0
        try:
            name, reason = str_.split(" ", 1)
        except ValueError:
            self.driver.notify_fail("You need to give a reason!\n")
            return 0
        ph = self.driver.player_handler()
        if not ph.test_creator(name):
            self.driver.notify_fail(f"{name} is not a creator!\n")
            return 0
        if master.query_lord(name):
            self.driver.write("Cannot dismiss Lords.\n")
            return 0
        self.driver.unguarded(lambda: self.driver.write_file("/log/DISMISSALS", f"{self.driver.ctime(self.driver.time())}: {name} dismissed by {interactives[0].query_name()}\nreason: {reason}\n"))
        fname = ph.query_player_file_name(name)
        if player := self.driver.find_player(name):
            player.set_creator(0)
            player.save()
            self.driver.tell_object(player, f"You have been dismissed by {interactives[0].query_name().capitalize()}.\n")
            player.quit()
            if self.driver.file_size(f"{fname}.o.gz") != -1:
                self.driver.unguarded(lambda: self.driver.uncompress_file(f"{fname}.o.gz"))
        else:
            if self.driver.file_size(f"{fname}.o.gz") != -1:
                self.driver.unguarded(lambda: self.driver.uncompress_file(f"{fname}.o.gz"))
            self.driver.unguarded(lambda: self.driver.write_file(f"{fname}.o", "creator 0\nhome_dir 0\n"))
            self.driver.unguarded(lambda: self.driver.compress_file(f"{fname}.o"))
        self.driver.write(f"{name.capitalize()} dismissed.\n")
        save_file = f"{BACKUP_DIR}{name}/save_file.o"
        if self.driver.file_size(save_file) == -1:
            save_file = f"{BACKUP_DIR}{name}.o"
        self.backup_vaults(name, 1)
        self.backup_bank(name, 1)
        self.backup_quest_library(name, 1)
        if self.driver.file_size(save_file) > 0:
            self.driver.unguarded(lambda: self.driver.write_file(save_file, f"last_log_on {self.driver.time()}\n"))
            self.driver.unguarded(lambda: self.driver.cp(save_file, f"{fname}.o"))
            self.driver.unguarded(lambda: self.driver.rm(save_file))
            self.driver.unguarded(lambda: self.driver.rm(f"{fname}.o.gz"))
            self.driver.unguarded(lambda: self.driver.compress_file(f"{fname}.o"))
        if self.driver.file_size(f"/w/{name}") == -2:
            self.driver.unguarded(lambda: self.driver.rename(f"/w/{name}", f"/w/.old_creators/{name}"))
        self.driver.rm(save_file)
        self.driver.rmdir(f"{BACKUP_DIR}{name}")
        ph.remove_cache_entry(name)
        return 1

    def eligible_creator(self, player):
        """
        Checks if a player is eligible to become a creator.
        @param player The player object
        @return 1 if eligible, 0 otherwise
        """
        reasoning = (
            "  You do not have a *right* to create here.  In order to enhance your\n"
            "chances to be employed, you should demonstrate by your actions that you\n"
            "are worthy.\n"
            "  If our Creators find lots of your bug, typo, and idea reports in their\n"
            "directories, then your chances are improved.  If you have been a trouble-\n"
            "maker here, your chances are very slim.  Harrassing the Lords for a\n"
            "position will not help your chances either.\n"
            "  Having access to a MUD's file system is a great responsibility.  It\n"
            "cannot be given out to strangers who have not demonstrated their trust-\n"
            "worthiness.  After investing a fair amount of your time and energy in\n"
            "playing at DiscWorld, you are less likely to try to hurt it.  This is\n"
            "why we cannot give out instant creatorships unless we know you from\n"
            "elsewhere.  Please try to be understanding about our policy.\n\n"
        )
        age = -player.query_time_on()
        level = player.query_level()
        if level >= 150 and age > 432000:
            self.driver.write(
                f"  You have achieved the *minimum* requirements necessary to apply for a\n"
                f"creatorship at {self.driver.mud_name()}.  You must now pass a review of the Lords to be\naccepted.\n{reasoning}"
            )
            return 1
        age_str = ""
        if age > 86400:
            age_str += f"{age // 86400} day{'s' if age > 172800 else ''}"
        if age % 86400 > 3600:
            age_str += f"{' and ' if age > 86400 else ''}{(age % 86400) // 3600} hour{'s' if age % 86400 > 7200 else ''}"
        self.driver.write(
            f"  The *minimum* requirements to apply for a creatorship on {self.driver.mud_name()} are\n"
            f"to be level 150 in your guild and at least five days old .\n"
            f"You are level {level}, and your age is {age_str}.\n{reasoning}"
        )
        return 0

    def backup_vaults(self, name, restore):
        """
        Backs up or restores vault data.
        @param name The creator's name
        @param restore 0 to backup, 1 to restore
        """
        base = "/save/vaults/"
        creator_dir = f"{BACKUP_DIR}{name}/vaults/"
        if not restore:
            vaults = self.driver.get_dir(base)
            self.driver.mkdir(creator_dir)
            for vault in vaults:
                file = f"{base}{vault}/{name}.o"
                if self.driver.file_size(file) != -1:
                    self.driver.cp(file, f"{creator_dir}/{vault}.o")
        else:
            if self.driver.file_size(creator_dir) == -1:
                return
            vaults = self.driver.get_dir(base)
            for vault in vaults:
                file = f"{base}{vault}/{name}.o"
                if self.driver.file_size(file) != -1:
                    self.driver.rm(file)
            vaults = self.driver.get_dir(creator_dir)
            for vault in vaults:
                tmp = vault.split(".")[0]
                self.driver.cp(f"{creator_dir}{vault}", f"{base}{tmp}/{name}.o")
                self.driver.rm(f"{creator_dir}{vault}")
            self.driver.rmdir(creator_dir)

    def backup_bank(self, name, restore):
        """
        Backs up or restores bank data.
        @param name The creator's name
        @param restore 0 to backup, 1 to restore
        """
        base = "/save/bank_accounts/"
        bank_file = f"{base}{name[0]}/{name}.o"
        bank_dir = f"{BACKUP_DIR}{name}/bank_account"
        if not restore:
            self.driver.mkdir(bank_dir)
            if self.driver.file_size(bank_file) != -1:
                self.driver.cp(bank_file, bank_dir)
        else:
            saved_file = f"{bank_dir}/{name}.o"
            if self.driver.file_size(bank_dir) == -1:
                return
            self.driver.rm(bank_file)
            if self.driver.file_size(saved_file) != -1:
                self.driver.cp(saved_file, bank_file)
                self.driver.rm(saved_file)
            self.driver.rmdir(bank_dir)

    def backup_quest_library(self, name, restore):
        """
        Backs up or restores quest library data.
        @param name The creator's name
        @param restore 0 to backup, 1 to restore
        """
        base = "/save/library/"
        library_file = f"{base}{name[0]}/{name}.o"
        library_dir = f"{BACKUP_DIR}{name}/quest_library"
        if not restore:
            self.driver.mkdir(library_dir)
            if self.driver.file_size(library_file) != -1:
                self.driver.cp(library_file, library_dir)
        else:
            saved_file = f"{library_dir}/{name}.o"
            if self.driver.file_size(library_dir) == -1:
                return
            self.driver.rm(library_file)
            if self.driver.file_size(saved_file) != -1:
                self.driver.cp(saved_file, library_file)
                self.driver.rm(saved_file)
            self.driver.rmdir(library_dir)