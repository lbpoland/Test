# /lib/secure/master/valid_link.py
# Validates file linking permissions.

class ValidLink:
    def __init__(self, driver):
        self.driver = driver

    def valid_link(self, from_, to):
        """
        Checks if linking between files is allowed.
        @param from_ The source file path
        @param to The target file path
        @return Always 0 (disabled)
        """
        return 0