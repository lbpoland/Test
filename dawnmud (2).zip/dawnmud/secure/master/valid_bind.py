# /lib/secure/master/valid_bind.py
# Validates function binding permissions.

class ValidBind:
    def __init__(self, driver):
        self.driver = driver
        self._simul_efun = None

    def valid_bind(self, binder, old_owner, new_owner):
        """
        Validates binding of a function from old_owner to new_owner by binder.
        @param binder The binding object
        @param old_owner The original owner object
        @param new_owner The new owner object
        @return 1 if valid, 0 otherwise
        """
        if not self._simul_efun:
            self._simul_efun = self.driver.find_object("/secure/simul_efun")
        if binder == self._simul_efun:
            return 1
        if self.driver.file_name(new_owner).startswith("/secure/"):
            return 0
        if self.driver.is_interactive(new_owner):
            return 0
        womble = self.driver.file_name(old_owner).split("/")
        if len(womble) < 1 or womble[-1][0] != ".":
            return 0
        return old_owner == binder