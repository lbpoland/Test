# /lib/secure/master/query_pl_level.py
# Queries player permission levels.

class QueryPlLevel:
    def __init__(self, driver):
        self.driver = driver

    def query_player_level(self, what):
        """
        Determines player permission level for specific actions.
        @param what The action or feature
        @return Permission level (1 or 0)
        """
        if not self.driver.this_player():
            return 0
        match what:
            case "error messages":
                return 1
            case "trace" | "wizard":
                return 1 if self.driver.this_player().query_creator() else 0
        return 0