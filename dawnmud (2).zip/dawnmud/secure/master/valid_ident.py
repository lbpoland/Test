# /lib/secure/master/valid_ident.py
# Validates ident permissions.

class ValidIdent:
    def __init__(self, driver):
        self.driver = driver

    def valid_ident(self, euid):
        """
        Checks if an euid can use ident.
        @param euid The effective user ID
        @return 1 if high programmer, 0 otherwise
        """
        return 1 if self.driver.get_master().high_programmer(euid) else 0