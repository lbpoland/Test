# /secure/bulk_delete.py
# Translated from /secure/bulk_delete.c (2003 Discworld MUD library)
# Purpose: Automatically deletes inactive player files and mail
# Last modified in original: Unknown

import asyncio
import random
from datetime import datetime

# Constants
ERASE_RATE = 30
MIN_DELAY = 604800  # 7 days
MAIL_UNREAD_TIME = 15552000  # 180 days
MAIL_INACTIVE_TIME = 31536000  # 365 days
ALPHABET = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m",
            "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"]
SAVEFILE = "/secure/bulk_delete.os"
FOLDER_H = "/obj/handlers/folder_handler.py"
PLAYER_SAVE_DIR = "/save/players/"  # Assumed path, adjust as needed

class BulkDelete:
    def __init__(self, driver):
        self.driver = driver
        self.dirs = []
        self.current = None
        self.fname = None
        self.folder = []
        self.create()

    def create(self):
        """Initializes the bulk delete system."""
        if self.driver.mud_name() != "Discworld":
            return
        self.driver.seteuid("Root")
        if self.driver.file_size(SAVEFILE) >= 0:
            var = self.driver.unguarded(lambda: self.driver.read_file(SAVEFILE))
            self.dirs = self.driver.restore_variable(var) if var else []
        asyncio.create_task(self.continuous_erase())

    async def reset(self):
        """Saves state and ensures continuous erase runs."""
        var = self.driver.save_variable(self.dirs)
        self.driver.unguarded(lambda: self.driver.write_file(SAVEFILE, var, 1))
        if not any(t.function == "continuous_erase" for t in asyncio.all_tasks()):
            asyncio.create_task(self.continuous_erase())

    async def continuous_erase(self, all_files=None):
        """Periodically erases inactive files."""
        if not all_files:
            if not self.dirs:
                self.dirs = ALPHABET.copy()
            self.current = self.dirs[random.randint(0, len(self.dirs) - 1)]
            self.driver.log_file("EXPIRED", f"{datetime.now()} Starting letter {self.current}\n")
            self.dirs.remove(self.current)
            all_files = self.driver.get_dir(f"{PLAYER_SAVE_DIR}{self.current}/*.o") + \
                        self.driver.get_dir(f"{PLAYER_SAVE_DIR}{self.current}/*.o.gz")
        for i, name in enumerate(all_files[:ERASE_RATE]):
            if name.endswith(".o") or name.endswith(".o.gz"):
                name = name.split("/")[-1].split(".")[0]
                self.check_name(name)
            await asyncio.sleep(1)  # Rate limiting
        remaining = all_files[ERASE_RATE:]
        if remaining:
            await asyncio.sleep(ERASE_RATE)
            await self.continuous_erase(remaining)
        else:
            await self.reset()

    def check_name(self, name):
        """Checks and deletes inactive player data."""
        time_on = -self.driver.player_handler().test_age(name)
        last_log_on = self.driver.player_handler().test_last(name)
        current_time = self.driver.time()
        folder_h = self.driver.find_object(FOLDER_H)
        
        if (current_time - last_log_on) > MAIL_INACTIVE_TIME:
            tmp = folder_h.mail_count(name)
            if tmp[0]:
                self.driver.log_file("EXPIRED", f"{datetime.now()} erased mail for {name}\n")
                folder_h.delete_account(name)
            return
        
        if self.driver.player_handler().test_creator(name) or \
           self.driver.player_handler().test_property(name, "no delete"):
            return
        
        if (current_time - last_log_on) < MIN_DELAY:
            return
        
        if (current_time - last_log_on) > (time_on * 60):
            self.delete_name(name)
            return
        
        if (current_time - last_log_on) > MAIL_UNREAD_TIME:
            tmp = folder_h.mail_count(name)
            if not tmp[1]:
                return
            self.folder = folder_h.get_messages(name, "inbox")
            unread = [i for i, msg in enumerate(self.folder) if msg.status == "N"]
            if unread:
                folder_h.delete_it(name, "inbox", unread)

    def delete_name(self, name):
        """Deletes a player’s files."""
        self.driver.log_file("EXPIRED", f"{datetime.now()} Timed out player deletion: {name}\n")
        fname = self.driver.player_handler().query_player_file_name(name)
        self.driver.unguarded(lambda: self.driver.rm(f"{fname}.o"))
        self.driver.unguarded(lambda: self.driver.rm(f"{fname}.o.gz"))
        self.driver.find_object("/secure/related_files").delete_related_files(name, True)
        self.driver.player_handler().remove_cache_entry(name)

    def delete_files(self, letter):
        """Manually deletes files for a letter."""
        prev_ob = self.driver.previous_object(-1)
        if not any(self.driver.is_interactive(ob) for ob in prev_ob):
            self.driver.log_file("CHEAT", f"{datetime.now()}: illegal attempt to delete timed out player files\nTrace: {self.driver.back_trace()}")
            return False
        if not self.driver.get_master().high_programmer(prev_ob):
            self.driver.log_file("CHEAT", f"{datetime.now()}: illegal attempt to delete timed out player files\nTrace: {self.driver.back_trace()}")
            return False
        self.driver.log_file("EXPIRED", f"Manually Requested Processing of {letter}.\n")
        self.current = letter
        all_files = self.driver.get_dir(f"{PLAYER_SAVE_DIR}{letter}/*.o") + \
                    self.driver.get_dir(f"{PLAYER_SAVE_DIR}{letter}/*.o.gz")
        asyncio.create_task(self.continuous_erase(all_files))
        return True

    def clean_up_files(self, dir):
        """Cleans up unused files in specified directories."""
        prev_ob = self.driver.previous_object(-1)
        if not any(self.driver.is_interactive(ob) for ob in prev_ob):
            self.driver.log_file("CHEAT", f"{datetime.now()}: illegal attempt to delete unused files\nTrace: {self.driver.back_trace()}")
            return False
        if not self.driver.get_master().high_programmer(prev_ob):
            self.driver.log_file("CHEAT", f"{datetime.now()}: illegal attempt to delete unused files\nTrace: {self.driver.back_trace()}")
            return False
        if dir == "artifacts":
            all_files = self.driver.get_dir("/save/artifacts/*.o")
        elif dir == ".dead_ed_files":
            all_files = self.driver.get_dir("/w/.dead_ed_files/")
        else:
            self.driver.notify_fail("Invalid directory.\n")
            return False
        all_files = [f for f in all_files if f not in [".", ".."]]
        if not all_files:
            self.driver.notify_fail("Directory empty.\n")
            return False
        for i, file in enumerate(reversed(all_files)):
            if dir == "artifacts":
                asyncio.create_task(asyncio.sleep(5 * (i + 1), lambda: self.check_name(file)))
            elif dir == ".dead_ed_files":
                asyncio.create_task(asyncio.sleep(5 * (i + 1), lambda: self.check_name(file.split("-")[0])))
        return True

    def stats(self):
        """Returns current processing stats."""
        return [
            ("current letter", self.current),
            ("remaining dirs", ", ".join(self.dirs) if self.dirs else "0")
        ]