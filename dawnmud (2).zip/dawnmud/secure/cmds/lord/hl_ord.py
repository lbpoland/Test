# /lib/secure/cmds/lord/hl_ord.py
# Displays lord channel history.
# @see /obj/handlers/hist_handler.py
# @see /secure/master.py

HIST = "/obj/handlers/hist_handler"

class HlOrd:
    def __init__(self, driver):
        self.driver = driver

    def cmd(self):
        """
        Shows the lord channel history to authorized users.
        @return 1 on success, 0 if unauthorized or no history
        """
        tp = self.driver.this_player()
        if not self.driver.get_master().query_lord(self.driver.geteuid(tp)):
            return 0
        self.driver.seteuid(self.driver.geteuid(tp))
        hist = self.driver.find_object(HIST).query_lord_history()
        if not isinstance(hist, list) or not hist:
            self.driver.notify_fail("Nobody said anything on the lord channel.\n")
            return 0
        self.driver.write("The lord channel history is:\n")
        for entry in hist:
            if len(entry) > 2:
                msg = tp.fix_string(f"*{entry[2][11:19]}* {entry[0]}{entry[1]:>{tp.query_cols() - len(entry[0]) - 11}}\n")
            else:
                msg = tp.fix_string(f"{entry[0]}{entry[1]:>{tp.query_cols() - len(entry[0])}}\n")
            self.driver.efun_tell_object(tp, msg)
        return 1

    def dest_me(self):
        """
        Destroys the object.
        """
        self.driver.destruct(self.driver.this_object())

    def clean_up(self):
        """
        Cleans up by destroying the object.
        """
        self.dest_me()

    def reset(self):
        """
        Resets by destroying the object.
        """
        self.dest_me()