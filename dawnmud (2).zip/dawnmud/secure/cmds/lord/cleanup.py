# /lib/secure/cmds/lord/cleanup.py
# Executes bulk file deletion for lords.
# @see /secure/bulk_delete.py

class Cleanup:
    def __init__(self, driver):
        self.driver = driver

    def cmd(self, mess):
        """
        Deletes files specified in the message.
        @param mess The file specification string
        @return None (notifies via write/notify_fail)
        """
        if self.driver.find_object("/secure/bulk_delete").delete_files(mess):
            self.driver.write("Ok.\n")
        else:
            self.driver.notify_fail("Sorry.\n")