# /lib/secure/cmds/creator/finderrors.py
# Manages error report directories and counts.
# @see /obj/handlers/finderror_helper.py
# @see /cmds/creator/errors.py

HELPER = "/obj/handlers/finderror_helper"
ERROR_CMD = "/cmds/creator/errors"

class Finderrors:
    def __init__(self, driver):
        self.driver = driver

    def finished_count_errors(self, player, status, data):
        """
        Displays error counts for directories.
        @param player The player object
        @param status Query status
        @param data Query results
        """
        errors = {}
        total = [0, 0, 0]
        for direc in data:
            count = errors.get(direc["Directory"], [0, 0, 0])
            if direc["Type"] == "BUG":
                count[0] = direc["COUNT(Id)"]
                total[0] += count[0]
            elif direc["Type"] == "TYPO":
                count[1] = direc["COUNT(Id)"]
                total[1] += count[1]
            else:
                count[2] = direc["COUNT(Id)"]
                total[2] += count[2]
            errors[direc["Directory"]] = count
        paths = sorted(errors.keys())
        txt = "$P$finderrors$P$BUGS TYPO IDEA\n"
        for key in paths:
            txt += f"{errors[key][0]:4d} {errors[key][1]:4d} {errors[key][2]:4d} {key}\n"
        txt += "-------------\n"
        txt += f"{total[0]:4d} {total[1]:4d} {total[2]:4d}\n"
        self.driver.tell_object(player, txt)

    def count_errors(self):
        """
        Counts errors in defined directories.
        @return 1 on success, -1 on failure
        """
        result = self.driver.find_object(HELPER).query_dirs_count(self.driver.this_player(), self.finished_count_errors)
        if result:
            self.driver.add_succeeded_mess(["Retrieving error count, this may take several seconds.\n", ""])
            return 1
        self.driver.add_failed_mess("You have no finderrors directories defined. Add them with 'finderrors add'\n")
        return -1

    def finished_next_dir(self, player, status, data):
        """
        Proceeds to the next directory with errors.
        @param player The player object
        @param status Query status
        @param data Query results
        """
        if len(data) != 1 or not isinstance(data[0], dict):
            self.driver.tell_object(player, "Unable to find the next directory with errors.\n")
        else:
            self.driver.find_object(ERROR_CMD).errors_in_dir(data[0]["Directory"], 0)

    def get_next_error(self):
        """
        Retrieves the next directory with errors.
        @return 1 on success
        """
        self.driver.find_object(HELPER).query_next_dir(self.driver.this_player(), self.finished_next_dir)
        self.driver.add_succeeded_mess(["Retrieving error count, this may take several seconds.\n", ""])
        return 1

    def list_error_directories(self):
        """
        Lists directories monitored for errors.
        @return 1 on success, -1 on failure
        """
        dirs = self.driver.find_object(HELPER).query_directories(self.driver.this_player().query_name())
        if dirs:
            self.driver.tell_object(self.driver.this_player(), f"$P$finderrors list$P${chr(10).join(dirs)}\n")
            self.driver.add_succeeded_mess("")
            return 1
        self.driver.add_failed_mess("No directories have been added to finderrors.\n")
        return -1

    def add_directory(self, directory, recursive):
        """
        Adds a directory to monitor for errors.
        @param directory The directory path
        @param recursive Include subdirectories (1 or 0)
        @return 1 on success, -1 on failure
        """
        if not directory.endswith("/"):
            directory += "/"
        if self.driver.file_size(directory) != -2:
            self.driver.add_failed_mess(f"{directory} is not a directory.\n")
            return -1
        self.driver.find_object(HELPER).add_directory(self.driver.this_player(), directory, recursive)
        return 1

    def remove_directory(self, directory, recursive):
        """
        Removes a directory from error monitoring.
        @param directory The directory path
        @param recursive Include subdirectories (1 or 0)
        @return 1 on success, -1 on failure
        """
        result = self.driver.find_object(HELPER).remove_directory(self.driver.this_player(), directory, recursive)
        if result:
            self.driver.add_succeeded_mess("Directory removed successfully.\n")
            return 1
        self.driver.add_failed_mess("Could not remove directory. Was it on your finderrors list?\n")
        return -1

    def query_patterns(self):
        """
        Returns command patterns.
        @return List of patterns and callbacks
        """
        return [
            "add <word>", lambda w: self.add_directory(w, 0),
            "add <word> recursive", lambda w: self.add_directory(w, 1),
            "remove <word>", lambda w: self.remove_directory(w, 0),
            "remove <word> recursive", lambda w: self.remove_directory(w, 1),
            "list", self.list_error_directories,
            "count", self.count_errors,
            "", self.get_next_error
        ]