# /lib/secure/cmds/creator/tail.py
# Displays the tail of files or objects.
# @see /secure/simul_efun/wiz_present.py

class Tail:
    def __init__(self, driver):
        self.driver = driver

    def cmd(self, str_, num):
        """
        Shows the last lines of files or objects.
        @param str_ File or object specification
        @param num Number of lines to display
        @return 1 on success, 0 on failure
        """
        num = abs(num) or 20
        if not str_:
            self.driver.notify_fail("Tail what file(s)/object(s)?\n")
            return 0
        tp = self.driver.this_player()
        filenames = tp.get_files(str_)
        wiz = self.driver.find_object("/secure/simul_efun/wiz_present")
        if not filenames:
            obs = wiz.wiz_present(str_, tp)
            if obs:
                filenames = [self.driver.base_name(ob) + (".c" if self.driver.file_size(self.driver.base_name(ob)) <= 0 else "") for ob in obs]
            else:
                self.driver.notify_fail(f"{str_}: No such file(s)/object(s).\n")
                return 0
        filenames = [f for f in filenames if self.driver.file_size(f) != -2 and f[-2:] != ".."]
        for i, fname in enumerate(filenames):
            if len(filenames) > 1:
                self.driver.printf(f"{'-' * 80}\nFILE : {fname}\n")
            if self.driver.file_size(fname) < 0:
                self.driver.write("That file/object is not readable, or does not exist.\n")
            else:
                content = self.driver.read_file(fname, max(0, self.driver.file_length(fname) + 1 - num))
                self.driver.write(content)
        return 1

    def query_patterns(self):
        """
        Returns command patterns.
        @return List of patterns and callbacks
        """
        return [
            "<number> <string>", lambda n, s: self.cmd(s, int(n)),
            "<string>", lambda s: self.cmd(s, 20)
        ]