# /lib/secure/cmds/creator/load.py
# Loads objects into memory.

class Load:
    def __init__(self, driver):
        self.driver = driver

    def cmd(self, str_):
        """
        Loads specified objects into memory.
        @param str_ File specification
        @return 1 on success, 0 on failure
        """
        if not str_:
            self.driver.notify_fail("Load what?\n")
            return 0
        filenames = self.driver.this_player().get_cfiles(str_)
        if not filenames:
            self.driver.notify_fail("No such object.\n")
            return 0
        failed = []
        succ = []
        load_err = ""
        for fname in filenames:
            if self.driver.file_size(fname) < 0:
                failed.append(fname)
                continue
            try:
                fname.load_up_with_yellow()  # Assuming this is a method on loaded objects
            except Exception as e:
                load_err += f"Failed to load {fname}, error: {str(e)}"
            else:
                succ.append(fname)
        ret = ""
        if failed:
            size = len(failed)
            ret += f"{self.driver.query_multiple_short(failed)} {'is' if size == 1 else 'are'} not {'a ' if size == 1 else ''}regular file{'s' if size > 1 else ''}.\n"
        if load_err:
            ret += load_err
        if succ:
            ret += f"$I$5=$C$Loaded {self.driver.query_multiple_short(succ)}.\n"
        self.driver.this_player().show_message(f"$P$Load$P${ret}")
        return 1