# /lib/secure/cmds/creator/cat.py
# Displays file contents with optional line numbers.

class Cat:
    def __init__(self, driver):
        self.driver = driver

    def cmd(self, str_, line_numbers=False):
        """
        Displays the contents of one or more files.
        @param str_ File specification
        @param line_numbers Include line numbers (default: False)
        @return 1 on success, 0 on failure
        """
        if not str_:
            self.driver.notify_fail("Cat what file ?\n")
            return 0
        filenames = self.driver.this_player().get_files(str_)
        if not filenames:
            self.driver.notify_fail(f"{str_}: No such file.\n")
            return 0
        for fname in filenames:
            if len(filenames) > 1:
                self.driver.write(f"FILE : {fname}\n")
            if line_numbers:
                content = self.driver.read_file(fname)
                if content:
                    lines = content.split("\n")
                    w = len(str(len(lines)))
                    formatted_lines = [f"{i + 1:>{w}}: {line}" for i, line in enumerate(lines)]
                    self.driver.printf("\n".join(formatted_lines) + "\n")
                else:
                    self.driver.write(f"{fname}: No such file.\n")
            else:
                self.driver.cat(fname)
        return 1

    def query_patterns(self):
        """
        Returns command patterns.
        @return List of patterns and callbacks
        """
        return ["-n <string'file'>", lambda s: self.cmd(s, True), "<string'file'>", lambda s: self.cmd(s, False)]