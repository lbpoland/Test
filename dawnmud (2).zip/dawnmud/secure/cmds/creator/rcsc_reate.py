# /lib/secure/cmds/creator/rcscreate.py
# Creates RCS files with initial comments.
# @see /secure/master.py

CMD_NUM = 5

class Rcscreate:
    def __init__(self, driver):
        self.driver = driver
        self.globals = {}
        self.ret = {}
        self.cmd_str = None

    def cmd(self, arg):
        """
        Creates RCS files for specified files.
        @param arg Format: "[-c] file [file...]"
        @return 1 on success, 0 on failure
        """
        if not arg:
            self.driver.notify_fail("rcscreate: No arguments.\n")
            return 0
        bits = [b for b in arg.split() if b]
        arg = ""
        add_comments = False
        nfiles = 0
        master = self.driver.get_master()
        tp = self.driver.this_player()
        for bit in bits:
            if bit.startswith("-"):
                if bit[1] == "c":
                    add_comments = True
                else:
                    arg += f" {bit}"
            else:
                files = tp.get_files(bit)
                for file in files:
                    if not master.valid_write(file, self.driver.geteuid(tp), "cmd"):
                        self.driver.notify_fail(f"You do not have write access to {file}\n")
                        continue
                    tmp = file.split("/")
                    if tmp[-1] in ["RCS", ".", "..", "ERROR_REPORTS"]:
                        continue
                    dir_ = f"/{'/'.join(tmp[:-1])}/RCS" if len(tmp) > 1 else "/RCS"
                    if self.driver.file_size(dir_) == -1:
                        self.driver.write(f"No directory {dir_}, creating one.\n")
                        self.driver.mkdir(dir_)
                    if add_comments:
                        tmp_content = self.driver.read_file(file)
                        if file.endswith((".c", ".h")):
                            tmp_content = tmp_content.replace("\n", "").replace("\n", "")
                            self.driver.write_file(file, f"\n\n\n{tmp_content}")
                        else:
                            tmp_content = tmp_content.replace("#  -*- LPC -*-  #\n", "").replace("# -*- LPC -*- #\n", "")
                            self.driver.write_file(file, "#  -*- LPC -*- #\n#\n#$", True)
                            self.driver.write_file(file, "Locker$\n#$")
                            self.driver.write_file(file, f"Id$\n#\n#\n#\n\n{tmp_content}")
                    arg += f" {file[1:]}"
                    nfiles += 1
        if not nfiles:
            self.driver.notify_fail(f"rcscreate: no such file {arg}.\n")
            return 0
        self.driver.printf("Enter a comment.\n")
        self.cmd_str = arg
        tp.do_edit(None, self.do_ci)
        return 1

    def do_ci(self, comment):
        """
        Executes RCS creation with comment.
        @param comment The initial comment
        """
        if not comment:
            self.driver.printf("No comment given, aborting.\n")
            return
        cmd = ["-w" + self.driver.this_player().query_name(), "-i", "-u", f"-t-{comment}"] + self.cmd_str.split()
        fd = self.driver.external_start(CMD_NUM, cmd, self.read_call_back, self.write_call_back, self.close_call_back)
        self.globals[fd] = self.driver.this_player()
        self.ret[fd] = ""

    def read_call_back(self, fd, mess):
        """
        Handles RCS output.
        @param fd File descriptor
        @param mess Output message
        """
        mess = mess.replace("/home/atuin/lib", "")
        self.ret[fd] += mess

    def write_call_back(self, fd):
        """
        Handles write errors.
        @param fd File descriptor
        """
        self.driver.tell_object(self.globals[fd], "rcscreate: Write_call_back called.\n")

    def close_call_back(self, fd):
        """
        Finalizes RCS creation.
        @param fd File descriptor
        """
        if self.ret[fd]:
            self.globals[fd].more_string(self.ret[fd])
        else:
            self.driver.tell_object(self.globals[fd], "rcscreate completed.\n")
        self.ret.pop(fd, None)
        self.globals.pop(fd, None)