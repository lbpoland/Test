# /lib/secure/cmds/creator/rcsbatchin.py
# Batch checks in locked RCS files.
# @see /secure/simul_efun/rcs_handler.py

CMD_NUM = 5

class Rcsbatchin:
    def __init__(self, driver):
        self.driver = driver
        self.globals = {}
        self.ret = {}
        self.cmds = {}
        self.comments = {}
        self.locks = {}
        self.completed = {}

    def cmd(self):
        """
        Initiates batch check-in of locked files.
        @return 1 on success
        """
        tp = self.driver.this_player()
        rcs = self.driver.find_object("RCS_HANDLER")
        self.locks[tp] = rcs.query_locks(tp)
        if not self.locks[tp]:
            self.driver.printf("You don't have any files locked.\n")
            del self.locks[tp]
            return 1
        self.ask_about_file(tp)
        return 1

    async def check_complete(self, player):
        """
        Waits for check-in completion before proceeding.
        @param player The player object
        """
        if player not in self.completed:
            await asyncio.sleep(1)
            asyncio.create_task(self.check_complete(player))
        else:
            del self.completed[player]
            self.ask_about_file(player)

    def ask_about_file(self, player):
        """
        Prompts for check-in confirmation.
        @param player The player object
        """
        if player not in self.locks or not self.locks[player]:
            return
        self.driver.tell_object(player, f"Check in {self.locks[player][0]}? (y/N/q)\n")
        self.driver.input_to(self.get_answer, 0, player)

    def get_answer(self, answer, player):
        """
        Handles user response for check-in.
        @param answer User input ('y', 'N', 'q')
        @param player The player object
        """
        if answer.lower() in ["y"]:
            tmp = self.locks[player][0].split("/")
            if self.driver.file_size(f"/{'/'.join(tmp[:-1])}/RCS/{tmp[-1]},v") > 0:
                arg = self.locks[player][0][1:]
                self.driver.tell_object(player, "Enter a comment.\n")
                self.cmds[player] = arg
                player.do_edit("", self.do_ci, self, "", player)
            else:
                self.driver.tell_object(player, f"ERROR: No RCS file for {self.locks[player][0]}\n")
                if len(self.locks[player]) > 1:
                    self.locks[player] = self.locks[player][1:]
                    self.ask_about_file(player)
                else:
                    del self.locks[player]
        elif answer.lower() in ["q"]:
            del self.locks[player]
        elif len(self.locks[player]) > 1:
            self.locks[player] = self.locks[player][1:]
            self.ask_about_file(player)
        else:
            del self.locks[player]

    def do_ci(self, comment, player):
        """
        Executes the RCS check-in with comment.
        @param comment The check-in comment
        @param player The player object
        """
        if not comment:
            self.driver.tell_object(player, "No comment given, skipping.\n")
            if len(self.locks[player]) > 1:
                self.locks[player] = self.locks[player][1:]
                self.ask_about_file(player)
            else:
                del self.locks[player]
            return
        cmd = ["-w" + player.query_name(), "-u", f"-m{comment}"] + self.cmds[player].split()
        fd = self.driver.external_start(CMD_NUM, cmd, self.read_call_back, self.write_call_back, self.close_call_back)
        self.globals[fd] = player
        self.ret[fd] = ""
        self.comments[player] = comment
        if len(self.locks[player]) > 1:
            self.completed[player] = 0
            self.driver.tell_object(player, "Checking in... please wait\n")
            asyncio.create_task(self.check_complete(player))

    def read_call_back(self, fd, mess):
        """
        Handles RCS output.
        @param fd File descriptor
        @param mess Output message
        """
        mess = mess.replace("/home/atuin/lib", "")
        self.ret[fd] += mess

    def write_call_back(self, fd):
        """
        Handles write errors.
        @param fd File descriptor
        """
        self.driver.tell_object(self.globals[fd], "rcsin: Write_call_back called.\n")

    def close_call_back(self, fd):
        """
        Finalizes RCS check-in.
        @param fd File descriptor
        """
        tp = self.globals[fd]
        rcs = self.driver.find_object("RCS_HANDLER")
        if self.ret[fd]:
            tp.more_string(self.ret[fd])
            for i, line in enumerate(self.ret[fd].split("\n")):
                if i + 2 < len(self.ret[fd].split("\n")) and line.strip() == "done":
                    file = line.split("<--")[1].strip() if "<--" in line else None
                    if file:
                        rcs.remove_lock(tp, file)
                        lname = ""
                        if file[0] == "d":
                            bits = file.split("/")
                            if len(bits) >= 2 and bits[1] in self.driver.find_object("/secure/master").query_domains():
                                master = self.driver.find_object(f"/d/{bits[1]}/master")
                                lname = master.query_changelog(file) if master else f"/d/{bits[1]}/ChangeLog"
                        elif file[0] != "w":
                            lname = "/log/ChangeLog"
                        if lname:
                            log = tp.fix_string(f" * {self.driver.ctime(self.driver.time())[4:]} {file} {tp.query_name()}\n{self.comments[tp]}\n", 80, 21)
                            self.driver.log_file(lname, log)
        else:
            self.driver.tell_object(tp, "rcsin completed.\n")
        if len(self.locks[tp]) > 1:
            self.locks[tp] = self.locks[tp][1:]
            self.completed[tp] = 1
        else:
            del self.completed[tp]
            del self.locks[tp]
        del self.comments[tp]
        self.ret.pop(fd, None)
        self.globals.pop(fd, None)