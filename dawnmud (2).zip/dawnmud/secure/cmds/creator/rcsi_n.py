# /lib/secure/cmds/creator/rcsin.py
# Checks in RCS files with comments.
# @see /secure/simul_efun/wiz_present.py
# @see /secure/simul_efun/rcs_handler.py

CMD_NUM = 5

class Rcsin:
    def __init__(self, driver):
        self.driver = driver
        self.globals = {}
        self.ret = {}
        self.cmds = {}
        self.comments = {}

    def cmd(self, arg):
        """
        Checks in specified RCS files.
        @param arg Format: "[options] file [file...]"
        @return 1 on success, 0 on failure
        """
        if not arg:
            self.driver.notify_fail("rcsin: No arguments.\n")
            return 0
        bits = [b for b in arg.split() if b]
        arg = ""
        nfiles = 0
        notin = []
        wiz = self.driver.find_object("/secure/simul_efun/wiz_present")
        tp = self.driver.this_player()
        for bit in bits:
            if bit.startswith("-"):
                arg += f" {bit}"
            else:
                files = tp.get_files(bit)
                if files:
                    for file in files:
                        tmp = file.split("/")
                        if self.driver.file_size(f"/{'/'.join(tmp[:-1])}/RCS/{tmp[-1]},v") > 0:
                            arg += f" {file[1:]}"
                            nfiles += 1
                        else:
                            notin.append(file)
                else:
                    things = wiz.wiz_present(bit, tp)
                    if things:
                        file = self.driver.file_name(things[0]).split("#")[0]
                        if self.driver.file_size(file) <= 0:
                            file += ".c"
                        tmp = file.split("/")
                        if self.driver.file_size(f"/{'/'.join(tmp[:-1])}/RCS/{tmp[-1]},v") > 0:
                            arg += f" {file[1:]}"
                            nfiles += 1
                        else:
                            notin.append(file)
        if not nfiles:
            if notin:
                self.driver.notify_fail(f"rcsin: file not in RCS {self.driver.query_multiple_short(notin)}.\n")
            else:
                self.driver.notify_fail(f"rcsin: no such file {arg}.\n")
            return 0
        if notin:
            self.driver.write(f"rcsin: file not in RCS {self.driver.query_multiple_short(notin)}.\n")
        self.driver.printf("Enter a comment.\n")
        self.cmds[tp] = arg
        tp.do_edit(None, self.do_ci)
        return 1

    def do_ci(self, comment):
        """
        Executes RCS check-in with comment.
        @param comment The check-in comment
        """
        tp = self.driver.this_player()
        if not comment:
            self.driver.printf("No comment given, aborting.\n")
            return
        cmd = ["-w" + tp.query_name(), "-u", f"-m{comment}"] + self.cmds[tp].split()
        fd = self.driver.external_start(CMD_NUM, cmd, self.read_call_back, self.write_call_back, self.close_call_back)
        self.globals[fd] = tp
        self.ret[fd] = ""
        self.comments[tp] = comment

    def read_call_back(self, fd, mess):
        """
        Handles RCS output.
        @param fd File descriptor
        @param mess Output message
        """
        mess = mess.replace("/home/atuin/lib", "")
        self.ret[fd] += mess

    def write_call_back(self, fd):
        """
        Handles write errors.
        @param fd File descriptor
        """
        self.driver.tell_object(self.globals[fd], "rcsin: Write_call_back called.\n")

    def close_call_back(self, fd):
        """
        Finalizes RCS check-in.
        @param fd File descriptor
        """
        tp = self.globals[fd]
        rcs = self.driver.find_object("RCS_HANDLER")
        if self.ret[fd]:
            tp.more_string(self.ret[fd])
            lines = self.ret[fd].split("\n")
            i = 0
            while i + 2 < len(lines):
                if lines[i + 2].strip() == "done":
                    file = lines[i].split("<--")[1].strip() if "<--" in lines[i] else None
                    if file:
                        rcs.remove_lock(tp, file)
                        lname = ""
                        if file[0] == "d":
                            bits = file.split("/")
                            if len(bits) >= 2 and bits[1] in self.driver.find_object("/secure/master").query_domains():
                                master = self.driver.find_object(f"/d/{bits[1]}/master")
                                lname = master.query_changelog(file) if master else f"/d/{bits[1]}/ChangeLog"
                        elif file[0] != "w":
                            lname = "/log/ChangeLog"
                        if lname:
                            log = tp.fix_string(f" * {self.driver.ctime(self.driver.time())[4:]} {file} {tp.query_name()}\n{self.comments[tp]}\n", 80, 21)
                            self.driver.log_file(lname, log)
                    i += 3
                elif "No such file or directory" in lines[i]:
                    i += 1
                elif lines[i + 1].startswith("ci:"):
                    i += 2
                else:
                    i += 3
        else:
            self.driver.tell_object(tp, "rcsin completed.\n")
        self.ret.pop(fd, None)
        self.globals.pop(fd, None)
        self.comments.pop(tp, None)