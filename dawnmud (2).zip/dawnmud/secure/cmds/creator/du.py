# /lib/secure/cmds/creator/du.py
# Calculates disk usage recursively.
# @see /secure/master.py

MAX_FILES = 1000

class Du:
    def __init__(self, driver):
        self.driver = driver
        self._counts = {}

    def rec_du(self, path):
        """
        Recursively calculates disk usage in kilobytes.
        @param path The directory path
        @return Total size in KB
        """
        if not path.endswith("/"):
            path += "/"
        files = self.driver.get_dir(f"{path}*")
        self._counts[self.driver.this_player()] = self._counts.get(self.driver.this_player(), 0) + len(files)
        tot = 0
        for fname in files:
            if fname in [".", ".."]:
                continue
            size = self.driver.file_size(f"{path}{fname}")
            if size > 0:
                tot += size
            elif size == -2 and self._counts[self.driver.this_player()] < MAX_FILES:
                size = self.rec_du(f"{path}{fname}")
                self.driver.printf(f"{path + fname:<30} {size:>5}\n")
                tot += size * 1024
        return (tot + 1023) // 1024

    def cmd(self, path):
        """
        Displays disk usage for a path.
        @param path The path to analyze
        @return 1 on success, 0 on failure
        """
        if not path:
            return 0
        self._counts[self.driver.this_player()] = 0
        if self.driver.get_master().valid_read(path, self.driver.geteuid(self.driver.this_player())):
            total = self.rec_du(path)
            self.driver.printf(f"{'Total:':<30} {total:>5}\n")
            if self._counts[self.driver.this_player()] >= MAX_FILES:
                self.driver.printf("Note: count truncated due to file limit\n")
            return 1
        self.driver.add_failed_mess("You must have read access to a path to use du on it.\n")
        return 0

    def query_patterns(self):
        """
        Returns command patterns.
        @return List of patterns and callbacks
        """
        return ["", lambda: self.cmd(self.driver.this_player().query_path()), "<string'path'>", lambda p: self.cmd(p)]