# /lib/secure/cmds/creator/dbxframe.py
# Displays debug frame information from errors.

class Dbxframe:
    def __init__(self, driver):
        self.driver = driver

    def print_vars(self, vars_):
        """
        Formats variables for display.
        @param vars_ Array of variables
        @return Formatted string
        """
        result = []
        for var in vars_:
            if isinstance(var, dict):
                result.append("([ ... ])")
            elif callable(var):
                result.append("(: ... :)")
            elif isinstance(var, int):
                if var:
                    result.append(str(var))
                elif var is None:
                    result.append("NULL")
                elif var is ...:  # Using Ellipsis for undefined
                    result.append("UNDEFINED")
                else:
                    result.append("0")
            elif isinstance(var, str):
                result.append(f"\"{var}\"")
            elif isinstance(var, list):
                result.append("({ ... })")
            elif isinstance(var, float):
                result.append(str(var))
            elif isinstance(var, bytes):
                result.append("<BUFFER>")
        return ", ".join(result)

    def cmd(self, str_):
        """
        Displays a specific error frame for a player.
        @param str_ Format: "[<who>] <frame>"
        @return 1 on success, 0 on failure
        """
        if not str_:
            self.driver.write("dbxframe [<who>] <frame>\n")
            return 1
        parts = str_.split()
        if len(parts) == 1:
            who, num = None, int(parts[0]) if parts[0].isdigit() else None
        elif len(parts) == 2 and parts[1].isdigit():
            who, num = parts[0], int(parts[1])
        else:
            self.driver.write("dbxframe [<who>] <frame>\n")
            return 1
        if who:
            who = self.driver.this_player().expand_nickname(who)
            ob = self.driver.find_player(who)
            if not ob:
                self.driver.write("No such player.\n")
                return 1
        else:
            ob = self.driver.this_player()
        frame = ob.get_last_error()
        if not frame:
            self.driver.write("No error.\n")
            return 1
        if num < 1 or num > len(frame.get("trace", [])):
            self.driver.notify_fail("No such frame.\n")
            return 0
        frame = frame["trace"][num - 1]
        file = f"/{frame['file']}" if not frame['file'].startswith("/") else frame['file']
        self.driver.printf(f"------{file}:{frame['line']} - {frame['function']}({self.print_vars(frame['arguments'])})\n")
        self.driver.printf(f"locals: {self.print_vars(frame['locals'])}\n")
        self.driver.printf("----------------------------------------------------------------\n")
        self.driver.write(f"{self.driver.read_file(file, frame['line'] - 5, 5) or ''}%^YELLOW%^=>"
                          f"{self.driver.read_file(file, frame['line'], 1) or ''}%^RESET%^"
                          f"{self.driver.read_file(file, frame['line'] + 1, 5) or ''}")
        return 1