# /lib/secure/cmds/creator/locks.py
# Lists locked files in the current directory.

class Locks:
    def __init__(self, driver):
        self.driver = driver

    def cmd(self, _):
        """
        Displays locked files in the current directory.
        @param _ Unused argument
        @return 1 on success
        """
        tp = self.driver.this_player()
        path = tp.query_current_path()
        files = self.driver.get_dir(f"{path}/")
        self.driver.write("locked files in this directory:\n")
        for fname in files:
            full_path = f"{path}/{fname}"
            bits = full_path.split("/")
            rcspath = f"/{'/'.join(bits[:-1])}/RCS/{bits[-1]},v"
            if self.driver.file_size(rcspath) > 0:
                tmp = self.driver.read_file(rcspath, 4, 1)
                if tmp == "locks\n":
                    lockname = self.driver.read_file(rcspath, 5, 1).split(":")[0].strip("\t")
                    self.driver.printf(f"{full_path} locked by {lockname}\n")
        return 1

    def help(self):
        """
        Provides help text for the command.
        @return Help string
        """
        return "Displays the files that are locked in your current directory."