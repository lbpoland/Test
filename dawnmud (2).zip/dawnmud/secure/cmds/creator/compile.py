# /lib/secure/cmds/creator/compile.py
# Compiles source files.

class Compile:
    def __init__(self, driver):
        self.driver = driver

    def cmd(self, str_):
        """
        Compiles one or more source files.
        @param str_ File specification
        @return 1 on success, 0 on failure
        """
        if not str_:
            self.driver.notify_fail("Syntax: compile <files>\n")
            return 0
        bits = self.driver.this_player().get_files(str_)
        if not bits:
            self.driver.notify_fail("Syntax: compile <files>\n")
            return 0
        # Assuming __RUNTIME_LOADING__ is not defined in Python context
        try:
            error_str = self.driver.generate_source(bits)
            if not error_str:
                self.driver.printf(f"Compiled {', '.join(bits)} OK.\n")
            else:
                self.driver.printf(f"Error compiling {', '.join(bits)}: {error_str}\n")
        except Exception as e:
            self.driver.printf(f"Error compiling {', '.join(bits)}: {str(e)}\n")
        return 1