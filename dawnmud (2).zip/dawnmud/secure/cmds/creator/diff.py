# /lib/secure/cmds/creator/diff.py
# Compares files using an external diff command.
# @see /secure/master.py

class Diff:
    def __init__(self, driver):
        self.driver = driver
        self.globals = {}
        self.files = {}
        self.ret = {}

    def cmd(self, arg):
        """
        Compares two files or writes diff to a third.
        @param arg Format: "file1 file2 [output]"
        @return 1 on success, 0 on failure
        """
        if not arg:
            arg = ""
        else:
            bits = [b for b in arg.split() if b]
            last = ""
            arg = ""
            for bit in bits:
                if bit.startswith("-"):
                    continue
                bit = self.driver.this_player().get_path(bit)[1:]
                if not bit:
                    self.driver.notify_fail("Your wombles just expired.\n")
                    return 0
                if not self.driver.get_master().valid_read(bit, self.driver.this_player(), 0):
                    self.driver.notify_fail(f"Permission denied: {bit} .\n")
                    return 0
                stat_info = self.driver.unguarded(lambda: self.driver.stat(bit))
                if stat_info and isinstance(stat_info[0], str):
                    self.driver.notify_fail("Can't use diff on directories.\n")
                    return 0
                arg += f" {last}"
                last = bit
            num = len([b for b in bits if not b.startswith("-")])
            if num == 2:
                arg += f" {last}"
            last = f"/{last}"
            if num > 3:
                self.driver.notify_fail("Can't compare more than two files")
                return 0
            if num == 3 and self.driver.file_size(last) > 0:
                self.driver.notify_fail(f"File {last} exists.\n")
                return 0

        fd = self.driver.external_start(7, arg, self.read_call_back, self.write_call_back, self.close_call_back)
        if fd == -1:
            self.driver.notify_fail("diff failed somehow.\n")
            return 0
        self.globals[fd] = self.driver.this_player()
        if num == 3 and self.driver.get_master().valid_write(last, self.driver.this_player(), 0):
            self.files[fd] = last
        self.ret[fd] = ""
        return 1

    def read_call_back(self, fd, mess):
        """
        Handles diff output.
        @param fd File descriptor
        @param mess Output message
        """
        mess = mess.replace("/usr/bin/", "")
        self.ret[fd] += mess

    def write_call_back(self, fd):
        """
        Handles write errors.
        @param fd File descriptor
        """
        self.driver.tell_object(self.globals[fd], "diff: Whoops! fatal error.\n")

    def close_call_back(self, fd):
        """
        Finalizes diff operation.
        @param fd File descriptor
        """
        if fd in self.files:
            self.driver.write_file(self.files[fd], self.ret[fd])
        else:
            output = "those files are the same" if not self.ret[fd] else self.ret[fd]
            self.globals[fd].more_string(output)
        self.ret.pop(fd, None)
        self.files.pop(fd, None)
        self.globals.pop(fd, None)