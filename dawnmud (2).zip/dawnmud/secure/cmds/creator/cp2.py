# /lib/secure/cmds/creator/cp2.py
# Alternative file copy command with simpler logic.
# @see /secure/master.py

class Cp2:
    def __init__(self, driver):
        self.driver = driver

    def cmd(self, str_):
        """
        Copies files to a destination with basic checks.
        @param str_ Format: "source [source...] destination"
        @return 1 on success, 0 on failure
        """
        if not str_:
            self.driver.notify_fail("Usage : cp file [file|dir...]\n")
            return 0
        fnames = str_.split()
        filenames = self.driver.this_player().get_files("/".join(fnames[:-1]))
        filenames = [f for f in filenames if not f.endswith(".")]
        if not filenames:
            self.driver.notify_fail("Usage : cp file [file|dir...]\n")
            return 0
        dest = self.driver.this_player().get_path(fnames[-1])
        if not dest:
            self.driver.write("No destination\n")
            return 1
        show_ok = False
        for src in filenames:
            if not self.driver.get_master().valid_copy(src, self.driver.geteuid(self.driver.this_player()), ""):
                self.driver.notify_fail("Permission denied.\n")
                return 0
            if self.driver.file_size(src) == -1:
                self.driver.write(f"No such file : {src}\n")
                continue
            if self.driver.file_size(dest) > -1:
                self.driver.write(f"File exists : {dest}\n")
                continue
            result = self.driver.cp(src, dest)
            if result == 1:
                show_ok = True
            elif result == -1:
                self.driver.write(f"{src} is unreadable.\n")
            elif result == -2:
                self.driver.write(f"{dest} is unreadable.\n")
            elif result == -3:
                self.driver.write(f"An I/O error has occurred copying {src} to {dest}\n")
            else:
                self.driver.write(f"Unable to copy {src} to {dest}\n")
        if show_ok:
            self.driver.write("Ok.\n")
        return 1