# /lib/secure/cmds/creator/rcsout.py
# Checks out RCS files with locking.
# @see /secure/simul_efun/wiz_present.py
# @see /secure/simul_efun/rcs_handler.py
# @see /secure/master.py

CMD_NUM = 3

class Rcsout:
    def __init__(self, driver):
        self.driver = driver
        self.globals = {}
        self.files = {}
        self.ret = {}

    def cmd(self, arg):
        """
        Checks out and locks specified RCS files.
        @param arg Format: "[-f] file [file...]"
        @return 1 on success, 0 on failure
        """
        if not arg:
            self.driver.notify_fail("rcsout: No arguments.\n")
            return 0
        bits = [b for b in arg.split() if b]
        arg = ""
        force = bits[0] == "-f"
        if force:
            bits = bits[1:]
        nfiles = 0
        wiz = self.driver.find_object("/secure/simul_efun/wiz_present")
        tp = self.driver.this_player()
        master = self.driver.get_master()
        for bit in bits:
            if bit.startswith("-"):
                arg += f" {bit}"
            else:
                things = wiz.wiz_present(bit, tp)
                files = list({self.driver.base_name(t) + (".c" if self.driver.file_size(self.driver.base_name(t)) <= 0 else "") for t in things}) if things else []
                files.extend(tp.get_files(bit))
                for file in set(files):
                    if master.valid_write(file, self.driver.geteuid(tp), "cmd"):
                        arg += f" {file[1:]}"
                        nfiles += 1
                    else:
                        self.driver.notify_fail(f"You do not have write access to {file}\n")
        if not nfiles:
            return 0
        cmd = f" -l {'-f ' if force else ''}-w{tp.query_name()}{arg}"
        fd = self.driver.external_start(CMD_NUM, cmd, self.read_call_back, self.write_call_back, self.close_call_back)
        self.globals[fd] = tp
        self.ret[fd] = ""
        return 1

    def read_call_back(self, fd, mess):
        """
        Handles RCS checkout output.
        @param fd File descriptor
        @param mess Output message
        """
        mess = mess.replace("/home/atuin/lib", "")
        self.ret[fd] += mess

    def write_call_back(self, fd):
        """
        Handles write errors.
        @param fd File descriptor
        """
        self.driver.tell_object(self.globals[fd], "rcsout: Whoops! fatal error.\n")

    def close_call_back(self, fd):
        """
        Finalizes RCS checkout operation.
        @param fd File descriptor
        """
        tp = self.globals[fd]
        rcs = self.driver.find_object("RCS_HANDLER")
        if self.ret[fd]:
            tp.more_string(self.ret[fd])
            lines = self.ret[fd].split("\n")
            i = 0
            while i + 2 < len(lines):
                if lines[i + 2].strip() == "done":
                    file = lines[i].split("-->")[1].strip() if "-->" in lines[i] else None
                    if file:
                        rcs.add_lock(tp, file)
                    i += 3
                elif "No such file or directory" in lines[i]:
                    i += 1
                elif lines[i + 1].startswith("co:"):
                    i += 2
                else:
                    i += 3
        else:
            self.driver.tell_object(tp, "rcsout completed.\n")
        self.ret.pop(fd, None)
        self.globals.pop(fd, None)