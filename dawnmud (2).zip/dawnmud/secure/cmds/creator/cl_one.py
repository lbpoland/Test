# /lib/secure/cmds/creator/clone.py
# Clones objects for creators.
# @see /secure/simul_efun/wiz_present.py

class Clone:
    def __init__(self, driver):
        self.driver = driver

    def cmd(self, str_):
        """
        Clones an object and attempts to move it to the player or environment.
        @param str_ File specification or obvar assignment
        @return 1 on success, 0 on failure
        """
        if not str_:
            self.driver.notify_fail("Clone what ?\n")
            return 0
        obvarname = None
        if "=" in str_:
            obvarname, str_ = str_.split("=", 1)
        filenames = self.driver.this_player().get_cfiles(str_)
        if not filenames:
            self.driver.notify_fail("No such file.\n")
            return 0
        for fname in filenames:
            if self.driver.file_size(fname) < 0 and self.driver.file_size(f"{fname}.c") < 0:
                self.driver.notify_fail("No such file.\n")
                return 0
            ob = self.driver.clone_object(fname)
            if obvarname:
                self.driver.this_player().set_obvar(obvarname, ob)
            if ob:
                try:
                    mov = ob.move(self.driver.this_player())
                except Exception as e:
                    self.driver.this_player().handle_error(str(e), "move(this_player())")
                    mov = True
                if mov:
                    try:
                        ob.move(self.driver.environment(self.driver.this_player()))
                    except Exception as e:
                        self.driver.this_player().handle_error(str(e), "move(environment())")
                env = self.driver.environment(ob)
                loc = "you" if env == self.driver.this_player() else "here" if env == self.driver.environment(self.driver.this_player()) else self.driver.find_object("/secure/simul_efun/wiz_present").desc_object(env)
                self.driver.printf(f"Ok. Object {ob} cloned and put in {loc}.\n")
                self.driver.say(f"{self.driver.this_player().query_cap_name()} fetches {ob.one_short()} from another dimension.\n")
            else:
                self.driver.printf("Failed to clone.\n")
        return 1