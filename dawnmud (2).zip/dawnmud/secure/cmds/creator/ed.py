# /lib/secure/cmds/creator/ed.py
# Opens an editor for file manipulation.
# @see /secure/simul_efun/wiz_present.py
# @see /secure/master.py

class Ed:
    def __init__(self, driver):
        self.driver = driver
        self.people = []

    def cmd(self, str_):
        """
        Opens an editor for a file or object.
        @param str_ File or object specification
        @return 1 on success, 0 on failure
        """
        tp = self.driver.this_player()
        self.people.append(tp)
        if tp.query_editor() == "magic":
            str_ = str_ or " "
            tp.do_edit(None, self.fini_editor, None, str_)
            return 1
        if not str_:
            tp.set_in_editor("(hidden)")
            self.driver.ed("frog", self.fini_editor)
            return 1
        wiz_present = self.driver.find_object("/secure/simul_efun/wiz_present")
        things = wiz_present.wiz_present(str_, tp)
        if things:
            spam = self.driver.file_name(things[0]).split("#")[0]
            filenames = [f"{spam}.c"] if self.driver.file_size(spam) < 0 else [spam]
        else:
            filenames = tp.get_files(str_)
        if not filenames:
            str_ = tp.get_path(str_)
        else:
            str_ = filenames[0]
            if len(filenames) > 1:
                loop = 0
                while loop < len(filenames) and self.driver.file_size(filenames[loop]) < 0:
                    loop += 1
                if loop >= len(filenames):
                    self.driver.printf("No such file.\n")
                    self.people.remove(tp)
                    return 0
                str_ = filenames[loop]
                self.driver.printf(f"Ambiguous, using : {str_}\n")
        if self.driver.file_size(str_) == -2:
            self.driver.printf("directory\n")
            self.people.remove(tp)
            return 0
        tp.set_in_editor(str_)
        self.driver.printf(f"Editing: {str_} ")
        if not self.driver.get_master().valid_write(str_, self.driver.geteuid(), "frog"):
            self.driver.printf("[read only]\n")
        else:
            self.driver.printf("\n")
        self.driver.ed(str_, self.fini_editor)
        return 1

    def fini_editor(self):
        """
        Cleans up after editing session ends.
        """
        tp = self.driver.this_player()
        if isinstance(tp, object):
            if tp in self.people:
                self.people.remove(tp)
            tp.set_in_editor(None)

    def clean_up(self):
        """
        Removes null entries and destructs if empty.
        @return 1 to keep object
        """
        self.people = [p for p in self.people if p]
        if not self.people:
            self.driver.destruct(self.driver.this_object())
        return 1

    def reset(self):
        """
        Resets by removing null entries and destructing if empty.
        """
        self.people = [p for p in self.people if p]
        if not self.people:
            self.driver.destruct(self.driver.this_object())