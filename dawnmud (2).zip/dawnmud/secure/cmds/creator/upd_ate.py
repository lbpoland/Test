# /lib/secure/cmds/creator/update.py
# Updates objects in memory.
# @see /secure/simul_efun/wiz_present.py

class Update:
    def __init__(self, driver):
        self.driver = driver

    def do_update(self, ov):
        """
        Updates objects by reloading or cloning.
        @param ov Array of objects to update
        @return 1 on success, 0 on failure
        """
        rsv = self.driver.load_object("room/void")
        if not rsv:
            self.driver.notify_fail("The void is lost!\n")
            return 0
        wiz = self.driver.find_object("/secure/simul_efun/wiz_present")
        for ob in ov:
            if not ob:
                continue
            if self.driver.is_interactive(ob):
                self.driver.write(f"Can't update interactive object: {ob.query_name()}\n")
                continue
            env = self.driver.environment(ob)
            invent = self.driver.all_inventory(ob)
            invent = [i for i in invent if not (self.driver.userp(i) or i.query_property("unique"))] or [i.move(rsv) or None for i in invent]
            pname = self.driver.file_name(ob)
            static_arg = ob.query_static_auto_load()
            dynamic_arg = ob.query_dynamic_auto_load()
            if "#" not in pname:
                ob.dest_me()
                if ob:
                    ob.dwep()
                if ob:
                    self.driver.destruct(ob)
                if ob:
                    self.driver.notify_fail("I can't seem to destruct the old object.\n")
                    return 0
                ob = self.driver.load_object(pname)
                if static_arg:
                    ob.init_static_arg(static_arg)
                if dynamic_arg:
                    ob.init_dynamic_arg(dynamic_arg)
            else:
                loaded = self.driver.find_object(pname.split("#")[0])
                if loaded:
                    loaded.dest_me()
                    if loaded:
                        loaded.dwep()
                    if loaded:
                        self.driver.destruct(loaded)
                dup = self.driver.clone_object(pname.split("#")[0])
                if dup and ob:
                    ob.dest_me()
                    if ob:
                        ob.dwep()
                    if ob:
                        self.driver.destruct(ob)
                    ob = dup
                    if static_arg:
                        ob.init_static_arg(static_arg)
                    if dynamic_arg:
                        ob.init_dynamic_arg(dynamic_arg)
            if not ob:
                self.driver.printf("I seem to have lost your object.\n")
                return 1
            for item in invent:
                if item:
                    item.move(ob)
            if env:
                ob.move(env)
            self.driver.printf(f"Updated {wiz.desc_f_object(ob)}.\n")
        return 1

    def cmd(self, str_):
        """
        Initiates update of specified objects or environment.
        @param str_ Object or file specification ('here' for environment)
        @return 1 on success, 0 on failure
        """
        tp = self.driver.this_player()
        wiz = self.driver.find_object("/secure/simul_efun/wiz_present")
        tring = str_
        if not str_ or str_ == "here":
            str_ = self.driver.file_name(self.driver.environment(tp))
            if str_ == "/room/void":
                self.driver.notify_fail("The Surgeon General warns you that it is hazardous to update the void while standing in it.\n")
                return 0
            str_ = self.driver.base_name(str_)
            filenames = [f"/{str_}"]
            str_ = "here"
        else:
            filenames = tp.get_cfiles(str_)
        if not filenames:
            val = wiz.wiz_present(tring, tp)
            if not val:
                self.driver.notify_fail("No matching objects/filenames\n")
                return 0
            return self.do_update(val)
        obs = []
        for fname in filenames:
            ob = self.driver.find_object(fname)
            if not ob:
                if self.driver.file_size(fname) >= 0:
                    try:
                        ob = self.driver.load_object(fname)
                        self.driver.printf(f"Loaded {fname}\n")
                    except Exception as e:
                        self.driver.printf(f"Failed to load {fname}, error: {str(e)}\n")
                else:
                    val = wiz.wiz_present(tring, tp)
                    obs.extend(val)
            else:
                obs.append(ob)
        return self.do_update(obs) if obs else 0