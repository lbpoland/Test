# /lib/secure/cmds/creator/exec.py
# Executes inline LPC code by compiling a temporary file.
# @see /secure/master.py

LOG_FILE = "/d/admin/log/EXEC.log"

class Exec:
    def __init__(self, driver):
        self.driver = driver

    def do_exec(self, str_, suc_ref):
        """
        Executes code by creating and running a temporary object.
        @param str_ The code to execute
        @param suc_ref Reference to success flag
        @return Execution result or None
        """
        tp = self.driver.this_player()
        if not tp:
            suc_ref[0] = "fail"
            return None
        wiz_dir = f"/w/{tp.query_name()}"
        if self.driver.file_size(wiz_dir) != -2:
            suc_ref[0] = "fail"
            self.driver.notify_fail(f"Directory: {wiz_dir} does not exist.\n")
            return None
        file = f"{wiz_dir}/exec_tmp"
        ob = self.driver.find_object(file)
        if ob:
            ob.dest_me()
            if ob:
                self.driver.destruct(ob)
        if self.driver.file_size(f"{file}.c") > 0:
            self.driver.rm(f"{file}.c")
        self.driver.unguarded(lambda: self.driver.write_file(LOG_FILE, f"{self.driver.ctime(self.driver.time())} - {tp.query_name()}: {str_}\n"))
        file_header = tp.query_property("exec_include")
        if file_header:
            self.driver.write_file(f"{file}.c", f"#include \"{file_header}\"\n\n")
        self.driver.write_file(f"{file}.c", "void dest_me() { destruct(this_object()); }\n"
                                            f"mixed do_call() {{\n{str_};\n}}\n")
        try:
            ret = self.driver.find_object(file).do_call()
        except Exception as e:
            suc_ref[0] = str(e)
            ret = None
        ob = self.driver.find_object(file)
        if ob:
            ob.dest_me()
        self.driver.rm(f"{file}.c")
        return ret

    def cmd(self, str_):
        """
        Executes provided code and displays results.
        @param str_ The code to execute
        @return 1 on success, 0 on failure
        """
        suc_ref = [None]
        ret = self.do_exec(str_, suc_ref)
        if suc_ref[0] == "fail":
            return 0
        if not suc_ref[0]:
            self.driver.this_player().more_string(f"\nReturns: {ret}\n", "Exec results")
        else:
            self.driver.printf(f"Exec failed: {suc_ref[0]}")
        return 1