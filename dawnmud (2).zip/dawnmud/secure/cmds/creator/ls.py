# /lib/secure/cmds/creator/ls.py
# Lists directory contents with various formatting options.
# @see /secure/master.py
# @see /obj/handlers/autodoc_handler.py

MASK_C = 1
MASK_F = 2
MASK_T = 4
MASK_L = 8
MASK_A = 16
MASK_D = 32
MASK_O = 64

class Ls:
    def __init__(self, driver):
        self.driver = driver

    def dir_entry(self, path, name, size, mask):
        """
        Formats a directory entry.
        @param path The directory path
        @param name The file name
        @param size The file size
        @param mask Display options mask
        @return Formatted entry string
        """
        tmp = ""
        if size == -2:
            if mask & MASK_F:
                name += "/"
            return f"   - {name}"
        if self.driver.find_object(f"{path}{name}"):
            if mask & MASK_F:
                tmp += "*"
        autodoc = self.driver.find_object("/obj/handlers/autodoc_handler")
        if (mask & MASK_F) and autodoc.is_autodoc_file(f"{path}{name}"):
            tmp += "@"
        name += tmp
        size = (size // 1024) + 1
        return f"{str(size):>{4 if size < 1000 else len(str(size))}} {name}"

    def ls(self, str_, mask):
        """
        Lists directory contents based on mask options.
        @param str_ The directory path
        @param mask Display options mask
        @return 0 if no files, else prints and returns None
        """
        path = str_
        if self.driver.file_size(str_) == -2 and str_[-1] != "/" and not (mask & MASK_D):
            path += "/"
        if mask & MASK_A:
            path += "*"
        direc = self.driver.get_dir(path, -1)
        if not isinstance(direc, list):
            self.driver.printf("No files.\n")
            return 0
        if not (mask & MASK_A):
            direc = [d for d in direc if d[0][0] != "."]
        if not direc:
            if self.driver.file_size(str_) == -2:
                self.driver.printf("No files.\n")
            else:
                self.driver.printf(f"ls: {str_}: No such file or directory.\n")
            return 0
        path = f"{path}/" if self.driver.file_size(path) == -2 and path[-1] != "/" else "/".join(path.split("/")[:-1]) + "/"
        if path == "":
            path = "/"
        bing = [""] * len(direc)
        tp = self.driver.this_player()
        cols = tp.query_cols()
        master = self.driver.get_master()
        if not (mask & MASK_C) and not (mask & MASK_L):
            if mask & MASK_T:
                direc.sort(key=lambda x: x[2], reverse=True)
            if not (mask & MASK_F) and not (mask & MASK_O):
                bong = "\n".join(direc) + "\n"
            else:
                for i, (name, size, _) in enumerate(direc):
                    is_dir = size == -2 or name == ".."
                    loaded = self.driver.find_object(f"{path}{name}")
                    autodoc = self.driver.find_object("/obj/handlers/autodoc_handler").is_autodoc_file(f"{path}{name}")
                    suffix = "/" if is_dir and (mask & MASK_F) else ("*" if loaded and (mask & MASK_F) else "") + ("@" if autodoc and (mask & MASK_F) else "")
                    if mask & MASK_O:
                        color = "%^GREEN%^" if is_dir else "%^MAGENTA%^" if loaded else "%^RESET%^"
                        bing[i] = f"{color}{name}{'%^RESET%^' if is_dir or loaded else ''}{suffix}"
                    else:
                        bing[i] = f"{name}{suffix}"
                bong = "\n".join(bing)
        elif not (mask & MASK_L):
            if mask & MASK_T:
                direc.sort(key=lambda x: x[2], reverse=True)
            for i, (name, size, _) in enumerate(direc):
                bing[i] = self.dir_entry(path, name, size, mask) + "\n"
            bong = "\n".join(bing)
            if mask & MASK_O:
                for name, size, _ in direc:
                    color = "%^GREEN%^" if size == -2 or name == ".." else "%^MAGENTA%^" if self.driver.find_object(f"{path}{name}") else "%^RESET%^"
                    bong = bong.replace(f" {name}", f" {color}{name}{'%^RESET%^' if color != '%^RESET%^' else ''}")
        else:
            if not (mask & MASK_D) and self.driver.file_size(str_) == -2:
                str_ = f"{str_}/" if str_[-1] != "/" else str_
                str_ += "*"
            direc = self.driver.get_dir(str_, -1)
            if not (mask & MASK_A):
                direc = [d for d in direc if d[0][0] != "."]
            if not direc:
                return 0
            if mask & MASK_T:
                direc.sort(key=lambda x: x[2], reverse=True)
            current_time = self.driver.time()
            for i, (name, size, mod_time) in enumerate(direc):
                tmp2 = self.driver.ctime(mod_time)
                tmp = f"{tmp2[4:10]} {tmp2[20:24]}" if mod_time + (6 * 30 * 24 * 60 * 60) < current_time or mod_time - 3600 > current_time else tmp2[4:16]
                creator_d = master.author_file(f"{str_}{name}/.") or "Root"
                domain_d = master.domain_file(f"{str_}{name}/.") or "Root"
                creator = master.author_file(f"{str_}{name}") or "Root"
                domain = master.domain_file(f"{str_}{name}") or "Root"
                if size == -2:
                    bing[i] = f"drwxr{master.valid_write(f'{str_}{name}/fl.uff', domain_d, 'get_dir') and 'w' or '-'}{master.valid_read(f'{str_}{name}', 'NOBODY', 'get_dir') and 'r' or '-'}{master.valid_write(f'{str_}{name}/fl.uff', 'NOBODY', 'get_dir') and 'w' or '-'}{master.valid_read(f'{str_}{name}', 'NOBODY', 'get_dir') and 'x' or '-'} {2 if name == '..' and str_ == '/' else 0:3d} {creator_d:11.11s} {domain_d:11.11s}      0 {tmp:12s} {('%^GREEN%^' if mask & MASK_O else '')}{name}{('%^RESET%^' if mask & MASK_O else '')}{('/' if mask & MASK_F else '')}"
                else:
                    stats = self.driver.stat(f"{str_}{name}")
                    k = len(stats) > 1 and stats[2]
                    bing[i] = f"-rw{'x' if k else '-'}{master.valid_read(f'{str_}{name}', domain, 'get_dir') and 'r' or '-'}{master.valid_write(f'{str_}{name}', domain, 'get_dir') and 'w' or '-'}{master.valid_read(f'{str_}{name}', 'NOBODY', 'get_dir') and 'r' or '-'}{master.valid_write(f'{str_}{name}', 'NOBODY', 'get_dir') and 'w' or '-'}   1 {creator:11.11s} {domain:11.11s} {size:6d} {tmp:12s} {('%^MAGENTA%^' if k and mask & MASK_O else '')}{name}{('%^RESET%^' if k and mask & MASK_O else '')}{('*' if k and mask & MASK_F else '')}{('@' if mask & MASK_F and self.driver.find_object('/obj/handlers/autodoc_handler').is_autodoc_file(f'{str_}{name}') else '')}"
            bong = "\n".join(bing)
        tp.more_string(bong, str_, True)

    def cmd(self, str_):
        """
        Lists directory contents with specified options.
        @param str_ Format: "[options] [path]"
        @return 1 on success, 0 on failure
        """
        mask = MASK_C | MASK_F
        tp = self.driver.this_player()
        if str_:
            if tp.query_property("ls_command_nickname"):
                str_ = tp.expand_nickname(str_)
            bits = [b for b in str_.split() if b]
            for i, bit in enumerate(bits[:]):
                if bit.startswith("-"):
                    for c in bit[1:]:
                        if c == "-":
                            continue
                        elif c == "t":
                            mask |= MASK_T
                        elif c == "l":
                            mask |= MASK_L
                        elif c == "C":
                            mask |= MASK_C
                        elif c == "a":
                            mask |= MASK_A
                        elif c == "d":
                            mask |= MASK_D
                        elif c == "o":
                            mask |= MASK_O
                        elif c == "F":
                            mask |= MASK_F
                        elif c == "1":
                            mask &= ~MASK_C
                        elif c == "v":
                            self.driver.write("ls version 2.6 (c) 1995-1998 Turrican@Discworld\n")
                            return 1
                        elif c == "h":
                            self.driver.printf("Usage: ls [OPTION]... [PATH]...\n\n"
                                               "  -a      do not hide entries \"..\" and \".\"\n"
                                               "  -d      list directory entries instead of contents\n"
                                               "  -h      display this help and exit\n"
                                               "  -l      use a long listing format\n"
                                               "  -o      colorize entries according to type\n"
                                               "  -v      print version information and exit\n"
                                               "  -C      list entries by columns\n"
                                               "  -F      append a character to entries according to type\n"
                                               "  -1      list one file per line\n"
                                               "  -t      sort by date\n")
                            return 1
                        else:
                            self.driver.printf(f"Unknown option -{c}\nTry `ls -h' for more information.\n")
                            return 1
                    bits.pop(0)
            str_ = " ".join(bits)
        path = tp.query_path() if not str_ else tp.get_path(str_)
        if not path:
            self.driver.notify_fail("No current directory.\n")
            return 0
        if self.driver.get_master().valid_read(f"{path}/", self.driver.geteuid(tp), "get_dir"):
            self.ls(path, mask)
        else:
            self.driver.notify_fail(f"$I$0=ls: {str_}: Permission denied.\n")
            return 0
        return 1

    def check_dots(self, arg):
        """
        Filters out dot files.
        @param arg Directory entry
        @return True if not a dot file
        """
        return arg[0][0] != "."

    def is_dir(self, arg, path):
        """
        Checks if an entry is a directory.
        @param arg Directory entry
        @param path Base path
        @return True if directory
        """
        return self.driver.file_size(self.driver.this_player().get_path(f"{path}/{arg}")) == -2