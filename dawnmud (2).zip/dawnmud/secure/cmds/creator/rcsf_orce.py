# /lib/secure/cmds/creator/rcsforce.py
# Forces RCS lock release with optional mail notification.
# @see /secure/simul_efun/rcs_handler.py
# @see /obj/handlers/player_handler.py
# @see /obj/handlers/auto_mailer.py

CMD_NUM = 5

class Rcsforce:
    def __init__(self, driver):
        self.driver = driver
        self.globals = {}
        self.ret = {}
        self.lockers = {}

    def cmd(self, arg):
        """
        Forces release of RCS locks with optional mail.
        @param arg Format: "[options] file"
        @return 1 on success, 0 on failure
        """
        if not arg:
            self.driver.notify_fail("rcsforce: No arguments.\n")
            return 0
        bits = [b for b in arg.split() if b]
        arg = ""
        nfiles = 0
        for bit in bits:
            if bit.startswith("-"):
                arg += f" {bit}"
            else:
                files = self.driver.this_player().get_files(bit)
                if files:
                    file = files[0]
                    filen = file
                    arg += f" {file[1:]}"
                    nfiles += 1
        if not nfiles:
            self.driver.notify_fail(f"rcsforce: no such file {arg}.\n")
            return 0
        bits = file.split("/")
        rcsfile = f"/{'/'.join(bits[:-1])}/RCS/{bits[-1]},v"
        if self.driver.file_size(rcsfile) < 0:
            self.driver.notify_fail("That file is not in RCS.\n")
            return 0
        lockline = self.driver.read_file(rcsfile, 4, 1)
        if "locks; strict:" in lockline:
            self.driver.notify_fail("That file is not locked.\n")
            return 0
        locker = self.driver.read_file(rcsfile, 5, 1).split(":")[0][1:]
        master = self.driver.get_master()
        tp = self.driver.this_player()
        ph = self.driver.player_handler()
        if not master.query_senior(tp.query_name()) and ph.test_creator(locker):
            if file.startswith("/d/"):
                bits = file.split("/")
                domain_master = self.driver.find_object(f"/d/{bits[1]}/master")
                if not domain_master or not domain_master.can_rcsforce(file, tp.query_name(), locker):
                    return 0
            else:
                return 0
        cmd = ["-w" + locker, "-u", f"-m Forcibly unlocked by {tp.query_name()}"] + arg.split()
        args = {"player": tp, "cmd": cmd, "locker": locker, "filen": filen}
        if ph.test_creator(locker):
            self.driver.printf("Edit mail? (y/[n]): ")
            self.driver.input_to(self.edit_mail, 0, args)
        else:
            self.driver.write(f"Not sending mail to {locker} since they are not a creator any more.\n")
            fd = self.driver.external_start(CMD_NUM, cmd, self.read_call_back, self.write_call_back, self.close_call_back)
            self.globals[fd] = tp
            self.ret[fd] = ""
            self.lockers[fd] = locker
        return 1

    def edit_mail(self, choice, args):
        """
        Handles mail edit decision.
        @param choice User input ('y' or 'n')
        @param args Command arguments
        """
        if not choice or choice.lower() == "n":
            self.driver.printf("No.\n")
            self.do_ci(None, args)
        elif choice.lower() != "y":
            self.driver.printf("Invalid choice. Please answer y or n. (y/[n]): ")
            self.driver.input_to(self.edit_mail, 0, args)
        else:
            self.driver.printf("Yes. Entering editor.\n")
            args["player"].do_edit(None, self.do_ci, self, None, args)

    def do_ci(self, text, args):
        """
        Executes RCS force release with optional mail.
        @param text Mail text (optional)
        @param args Command arguments
        """
        mailer = self.driver.find_object("AUTO_MAILER")
        mailer.auto_mail(args["locker"], args["player"].query_name(), "Automatic RCSForce Mail", "",
                         f"Your file: {args['filen']}, has been forcibly unlocked by: {args['player'].query_name()}.\nEnjoy.\n\nAutomatic RCSForce Mailer.\n" + (f"\n{text}" if text else ""))
        fd = self.driver.external_start(CMD_NUM, args["cmd"], self.read_call_back, self.write_call_back, self.close_call_back)
        self.globals[fd] = args["player"]
        self.ret[fd] = ""
        self.lockers[fd] = args["locker"]

    def read_call_back(self, fd, mess):
        """
        Handles RCS output.
        @param fd File descriptor
        @param mess Output message
        """
        mess = mess.replace("/home/atuin/lib", "")
        self.ret[fd] += mess

    def write_call_back(self, fd):
        """
        Handles write errors.
        @param fd File descriptor
        """
        self.driver.tell_object(self.globals[fd], "rcsforce: write_call_back() called.\n")

    def close_call_back(self, fd):
        """
        Finalizes RCS force release.
        @param fd File descriptor
        """
        tp = self.globals[fd]
        if self.ret[fd]:
            tp.more_string(self.ret[fd])
            for i, line in enumerate(self.ret[fd].split("\n")):
                if i + 2 < len(self.ret[fd].split("\n")) and line.strip() == "done":
                    file = line.split("<--")[1].strip() if "<--" in line else None
                    if file:
                        self.driver.find_object("RCS_HANDLER").remove_lock(self.lockers[fd], file)
        else:
            self.driver.tell_object(tp, "rcsforce completed.\n")
        self.ret.pop(fd, None)
        self.globals.pop(fd, None)
        self.lockers.pop(fd, None)