# /lib/secure/cmds/creator/rcsrelease.py
# Releases RCS locks and updates files.
# @see /secure/simul_efun/wiz_present.py
# @see /secure/simul_efun/rcs_handler.py
# @see /secure/master.py

CMD_NUM = 3

class Rcsrelease:
    def __init__(self, driver):
        self.driver = driver
        self.globals = {}
        self.files = {}
        self.ret = {}

    def cmd(self, arg):
        """
        Releases locks and updates RCS files.
        @param arg Format: "[options] file [file...]"
        @return 1 on success, 0 on failure
        """
        if not arg:
            self.driver.notify_fail("rcsrelease: No arguments.\n")
            return 0
        bits = [b for b in arg.split() if b]
        arg = ""
        nfiles = 0
        wiz = self.driver.find_object("/secure/simul_efun/wiz_present")
        tp = self.driver.this_player()
        master = self.driver.get_master()
        for bit in bits:
            if bit.startswith("-"):
                arg += f" {bit}"
            else:
                files = tp.get_files(bit)
                if files:
                    for file in files:
                        if master.valid_write(file, self.driver.geteuid(tp), "cmd"):
                            arg += f" {file[1:]}"
                            nfiles += 1
                        else:
                            self.driver.notify_fail(f"You do not have write access to {file}\n")
                else:
                    things = wiz.wiz_present(bit, tp)
                    if things:
                        file = self.driver.file_name(things[0]).split("#")[0]
                        if self.driver.file_size(file) <= 0:
                            file += ".c"
                        if master.valid_write(file, self.driver.geteuid(tp), "cmd"):
                            arg += f" {file[1:]}"
                            nfiles += 1
                        else:
                            self.driver.notify_fail(f"You do not have write access to {file}\n")
        if not nfiles:
            self.driver.notify_fail(f"No such file: {arg}\n")
            return 0
        cmd = f" -f -u -w{tp.query_name()}{arg}"
        fd = self.driver.external_start(CMD_NUM, cmd, self.read_call_back, self.write_call_back, self.close_call_back)
        self.globals[fd] = tp
        self.ret[fd] = ""
        return 1

    def read_call_back(self, fd, mess):
        """
        Handles RCS release output.
        @param fd File descriptor
        @param mess Output message
        """
        mess = mess.replace("/home/atuin/lib", "")
        self.ret[fd] += mess

    def write_call_back(self, fd):
        """
        Handles write errors.
        @param fd File descriptor
        """
        self.driver.tell_object(self.globals[fd], "rcsrelease: Whoops! fatal error.\n")

    def close_call_back(self, fd):
        """
        Finalizes RCS release operation.
        @param fd File descriptor
        """
        tp = self.globals[fd]
        rcs = self.driver.find_object("RCS_HANDLER")
        if self.ret[fd]:
            tp.more_string(self.ret[fd])
            lines = self.ret[fd].split("\n")
            i = 0
            while i + 2 < len(lines):
                if lines[i + 2].strip() == "done":
                    file = lines[i].split("-->")[1].strip() if "-->" in lines[i] else None
                    if file:
                        rcs.remove_lock(tp, file)
                    i += 3
                elif "No such file or directory" in lines[i]:
                    i += 1
                elif lines[i + 1].startswith("co:"):
                    i += 2
                else:
                    i += 3
        else:
            self.driver.tell_object(tp, "rcsrelease completed.\n")
        self.ret.pop(fd, None)
        self.globals.pop(fd, None)