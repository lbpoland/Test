# /lib/secure/cmds/creator/printerrors.py
# Prints error reports to a file.
# @see /obj/handlers/error_handler.py
# @see /obj/handlers/autodoc_handler.py

class Printerrors:
    def __init__(self, driver):
        self.driver = driver

    def cmd(self, str_):
        """
        Collects and writes bug reports for a directory.
        @param str_ Directory path
        @return 1 on success, 0 on failure
        """
        if not str_:
            self.driver.notify_fail("Usage:\nprinterrors <path>\n note that this will overwrite any previous print_errors.txt file\n")
            return 0
        if not str_.startswith("/"):
            str_ = f"{self.driver.this_player().query_path()}/{str_}"
        if str_.endswith("0"):
            str_ = str_[:-1]
        if str_.endswith("/"):
            str_ = str_[:-1]
        player = self.driver.this_player().query_name()
        self.driver.write_file(f"/w/{player}/print_errors.txt", "", True)
        self.driver.write("%^YELLOW%^Starting to collect bugreports, this may take a while.%^RESET%^\n")
        query = {"recursive": 1, "dir": str_, "status": ["open", "considering", "fixing"]}
        self.driver.find_object("ERROR_HANDLER").do_query_multiple_bug_details(query, lambda result, results: self.finish_details(player, result, results))
        return 1

    def get_bug(self, complete):
        """
        Formats a bug report.
        @param complete Error data structure
        @return Formatted string
        """
        error = complete["details"]
        ret = f"{error['summary']['category']} {error['summary']['type']} {error['summary']['status']}\n"
        ret += f"Filename       : {error['summary']['filename']}\n"
        ret += f"Directory      : {error['summary']['directory']}\n"
        ret += f"Made by        : {error['summary']['reporter'].capitalize()}\n"
        ret += f"at             : {self.driver.ctime(error['summary']['entry_date'])}\n\n"
        for forward in complete.get("forwards", []):
            ret += f"Forwarded by   : {forward['forwarder'].capitalize()}\n"
            ret += f"from           : {forward['old_directory']}\n"
            ret += f"at             : {self.driver.ctime(forward['date'])}\n"
        ret += error["report"]
        if error.get("runtime") and error["runtime"]:
            ret += f"[RUNTIME]\n{error['runtime']}"
        for comment in complete.get("comments", []):
            ret += f"\nComment by     : {comment['commenter'].capitalize()}\n"
            ret += f"at             : {self.driver.ctime(comment['date'])}\n"
            ret += comment["comment"]
        ret += "\n------------------------------------------------------------------------------"
        return ret

    def finish_details(self, player, result, results):
        """
        Writes collected bug details to a file.
        @param player The player name
        @param result Query result code
        @param results Query results
        """
        if result != 1:  # Assuming DB_SUCCESS is 1
            self.driver.tell_creator(player, f"Failed to return the results {results}")
            return
        for detail in results:
            str_ = self.get_bug(detail)
            self.driver.unguarded(lambda: self.driver.write_file(f"/w/{player}/print_errors.txt", str_))
        self.driver.tell_creator(player, "Finished gathering the details.\n")