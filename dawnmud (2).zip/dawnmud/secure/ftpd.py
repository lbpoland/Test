# /secure/ftpd.py
# Translated from /secure/ftpd.c (2003 Discworld MUD library)
# Purpose: Implements an FTP server for file transfers
# Last modified in original: Unknown

import asyncio
import os
from datetime import datetime

# Constants from ftp.h, network.h, etc.
FTP_PORT = 21  # Assumed default FTP port
DELAY_LOG_FLUSH = 5
STREAM = "STREAM"
STREAM_BINARY = "STREAM_BINARY"
MASK_D = 1
MASK_L = 2
MASK_A = 4
MASK_F = 8
MASK_C = 16
MASK_R = 32
STRING = 0
FILE = 1
DOWNLOAD = 2
BLOCK_SIZE = 1024  # Assumed, adjust as needed
EESUCCESS = 0
EEWOULDBLOCK = -2
EECALLBACK = -3
EEALREADY = -4

class Session:
    def __init__(self):
        self.fd = None
        self.user_name = None
        self.logged_in = False
        self.cwd = None
        self.type = None
        self.idle = 0
        self.last_data = 0
        self.data_fd = -1
        self.pasv_fd = -1
        self.data_addr = None
        self.data_port = 0
        self.use_default = False
        self.offset = 0
        self.rnfr = None
        self.pasv_cb = False

class Dataconn:
    def __init__(self):
        self.path = None
        self.data = None
        self.pos = 0
        self.parent_fd = None
        self.type = None
        self.len = 0
        self.append = False

class Ftpd:
    def __init__(self, driver):
        self.driver = driver
        self.socket_info = {}
        self.data_sockets = {}
        self._log_file_info = {}
        self._log_file_flush_id = None
        self.create()

    def create(self):
        """Initializes the FTP server."""
        self.driver.seteuid("Root")
        self.driver.set_socket_type(STREAM)
        print(f"{self.driver.mud_name()}\n")
        if self.driver.mud_name() != "Discworld":
            asyncio.create_task(self.setup_ftp())
        else:
            self.driver.destruct(self)

    async def flush_log_files(self):
        """Flushes log file buffers."""
        self._log_file_flush_id = None
        for fname, data in list(self._log_file_info.items()):
            del self._log_file_info[fname]
            self.driver.unguarded(lambda: self.driver.write_file(fname, data))
        self._log_file_info = {}

    def log_write(self, name, fmt, *args):
        """Writes to log files with delayed flush."""
        if not self._log_file_flush_id:
            self._log_file_flush_id = asyncio.create_task(asyncio.sleep(DELAY_LOG_FLUSH, self.flush_log_files))
        if name not in self._log_file_info:
            self._log_file_info[name] = ""
        if args:
            self._log_file_info[name] += fmt % args
        else:
            self._log_file_info[name] += fmt

    async def setup_ftp(self):
        """Sets up the FTP server socket."""
        x = await self.driver.event_create_socket(FTP_PORT)
        if x < 0:
            if self:
                self.driver.destruct(self)
            return
        asyncio.create_task(self.check_connections())

    def query_connections(self):
        """Returns current FTP connections."""
        return [sess.user_name.capitalize() if sess.logged_in else "login"
                for sess in self.socket_info.values() if sess.user_name]

    def ls(self, path, mask):
        """Lists directory contents in FTP format."""
        if not (mask & MASK_D) and self.driver.file_size(path) == -2:
            if path[-1] == "/":
                path += "*"
            else:
                path += "/*"
        
        if not (mask & MASK_L):
            files = self.driver.get_dir(path)
            if not files:
                return ""
            if not (mask & MASK_A):
                files = [f for f in files if f not in [".", ".."]]
            if not files:
                return ""
            if "*" not in path and "?" not in path:
                return f"{files[0]}\n"
            j = path.rfind("/")
            path = path[:j + 1]
            for i, file in enumerate(files):
                tmp = f"{path}{file}/"
                if mask & MASK_F:
                    if "/./" in tmp or "/../" in tmp:
                        files[i] += "/"
                        continue
                    if self.driver.file_size(tmp) == -2:
                        files[i] += "/"
                    elif self.driver.stat(tmp[:-1])[2]:
                        files[i] += "*"
            if mask & MASK_C:
                return "\n".join([f"{f:<70}" for f in files]) + "\n"
            return "\n".join(files) + "\n"
        
        if not (mask & MASK_R):
            xfiles = self.driver.get_dir(path, -1)
            if not (mask & MASK_A):
                xfiles = [x for x in xfiles if self.check_dots(x)]
            if not xfiles:
                return "total 0\n"
            creator = self.driver.get_master().author_file(path) or "Root"
            domain = self.driver.get_master().domain_file(path) or "Root"
            i = path.rfind("/")
            path = path[:i + 1] if i >= 0 else ""
            current_time = self.driver.time()
            files = []
            for xfile in xfiles:
                tmp2 = datetime.fromtimestamp(xfile[2]).strftime("%b %d %H:%M:%S %Y")
                if xfile[2] + (6 * 30 * 24 * 60 * 60) < current_time or \
                   xfile[2] - (60 * 60) > current_time:
                    tmp = f"{tmp2[4:10]} {tmp2[20:24]}"
                else:
                    tmp = tmp2[4:16]
                if xfile[1] == -2:
                    files.append(f"drwxrwxr-x   0 {creator:<8} {domain:<8}        0 {tmp:>12} "
                                 f"{xfile[0]}{'/' if mask & MASK_F else ''}")
                else:
                    stats = self.driver.stat(path + xfile[0])
                    files.append(f"-rw{'x' if len(stats) > 2 and stats[2] else '-'}rw-r--   1 "
                                 f"{creator:<8} {domain:<8} {xfile[1]:>8} {tmp:>12} "
                                 f"{xfile[0]}{'*' if len(stats) > 2 and stats[2] and (mask & MASK_F) else ''}")
            return f"total {len(xfiles)}\n" + "\n".join(files) + "\n"
        
        if path[-1] != "*":
            return self.ls(path, mask & ~MASK_R)
        path = path[:-2]
        files = [""]
        tmp = ""
        while files:
            self.driver.reset_eval_cost()
            if files[0] == "":
                tmp += self.ls(path + "/*", mask & ~MASK_R)
            else:
                tmp += self.ls(path + files[0] + "/*", mask & ~MASK_R)
            xfiles = self.driver.get_dir(path + files[0] + "/*", -1)
            files = files[1:] + [f"{files[0]}/{x[0]}" for x in xfiles if x[1] == -2 and x[0] not in [".", ".."]]
        return tmp

    async def data_conn(self, fd, mess, name, type_):
        """Handles data connection for file transfers."""
        sess = self.socket_info[fd]
        data_mode_name = "ASCII" if type_ == STRING or (type_ == FILE and sess.type == STRING) else "BINARY"
        data_mode = STREAM if data_mode_name == "ASCII" else STREAM_BINARY
        t = Dataconn()
        t.path = name
        t.data = mess.replace("\n", "\r\n") if type_ == STRING else mess
        t.pos = sess.offset
        t.parent_fd = fd
        t.type = type_
        t.len = len(mess) if type_ == STRING else self.driver.file_size(mess)
        
        if sess.pasv_fd != -1:
            if sess.pasv_cb:
                new_fd = await self.driver.socket_accept(sess.pasv_fd, self.data_read_callback,
                                                        self.data_write_callback)
                if new_fd < 0:
                    await self.driver.event_write(fd, "425 Can't open data connection.\r\n")
                    self.driver.socket_close(sess.pasv_fd)
                    sess.pasv_fd = -1
                    return
                self.driver.socket_close(sess.pasv_fd)
                sess.pasv_fd = new_fd
            else:
                self.data_sockets[sess.pasv_fd] = t
                return
        else:
            sess.use_default = True
            if sess.data_fd != -1:
                await self.driver.event_write(fd, "425 Can't open data connection.\r\n")
                return
            new_fd = self.driver.socket_create(data_mode, self.data_read_callback,
                                              self.data_close_callback)
            if new_fd < 0:
                await self.driver.event_write(fd, "425 Can't create data socket.\r\n")
                return
            if not sess.data_addr:
                await self.driver.event_write(fd, "425 Can't open data connection.\r\n")
                self.driver.socket_close(new_fd)
                return
            addr, _ = self.driver.socket_address(fd, 1).split(" ", 1)
            addr = f"{addr} {FTP_PORT - 1}"
            ret = self.driver.socket_bind(new_fd, 0, addr)
            if ret < 0:
                await self.driver.event_write(fd, f"425 Can't build data connection: {self.driver.socket_error(ret)}.\r\n")
                self.driver.socket_close(new_fd)
                return
        
        self.data_sockets[new_fd] = t
        sess.data_fd = new_fd
        if sess.pasv_fd == -1:
            ret = await self.driver.socket_connect(new_fd, f"{sess.data_addr} {sess.data_port}",
                                                  self.data_read_callback, self.data_write_callback)
            if ret < 0:
                await self.driver.event_write(fd, "425 Can't build data connection.\r\n")
                sess.data_fd = -1
                self.driver.socket_close(new_fd)
                del self.data_sockets[new_fd]
                return
        
        await self.driver.event_write(fd, f"150 Opening {data_mode_name} mode data connection for {name} "
                                        f"({t.len} bytes).\r\n")
        if sess.pasv_fd != -1:
            await self.data_write_callback(new_fd)

    async def read_connection(self, fd, path, append):
        """Handles reading from a data connection."""
        sess = self.socket_info[fd]
        data_mode_name = "BINARY" if sess.type == BINARY else "ASCII"
        data_mode = STREAM_BINARY if data_mode_name == "BINARY" else STREAM
        opath = path
        if append != 1:
            path += ".ftptmp"
            if self.driver.file_size(path) > -1:
                try:
                    self.driver.rm(path)
                except:
                    pass
        t = Dataconn()
        t.path = path
        t.parent_fd = fd
        t.pos = 0 if not append else (self.driver.file_size(opath) if self.driver.file_size(opath) != -1 else 0)
        t.type = DOWNLOAD
        t.append = append
        
        if sess.pasv_fd != -1:
            if sess.pasv_cb:
                new_fd = await self.driver.socket_accept(sess.pasv_fd, self.data_read_callback,
                                                        self.data_write_callback)
                if new_fd < 0:
                    await self.driver.event_write(fd, "425 Can't open data connection.\r\n")
                    self.driver.socket_close(sess.pasv_fd)
                    sess.pasv_fd = -1
                    return
                self.driver.socket_close(sess.pasv_fd)
                sess.pasv_fd = new_fd
            else:
                self.data_sockets[sess.pasv_fd] = t
                return
        else:
            sess.use_default = True
            if sess.data_fd != -1:
                await self.driver.event_write(fd, "425 Can't open data connection.\r\n")
                return
            new_fd = self.driver.socket_create(data_mode, self.data_read_callback,
                                              self.data_close_callback)
            if new_fd < 0:
                await self.driver.event_write(fd, "425 Can't create data socket.\r\n")
                return
            addr, _ = self.driver.socket_address(fd, 1).split(" ", 1)
            addr = f"{addr} {FTP_PORT - 1}"
            ret = self.driver.socket_bind(new_fd, 0, addr)
            if ret < 0:
                await self.driver.event_write(fd, f"425 Can't build data connection: {self.driver.socket_error(ret)}.\r\n")
                self.driver.socket_close(new_fd)
                return
        
        self.data_sockets[new_fd] = t
        sess.data_fd = new_fd
        if sess.pasv_fd == -1:
            ret = await self.driver.socket_connect(new_fd, f"{sess.data_addr} {sess.data_port}",
                                                  self.data_read_callback, self.data_write_callback)
            if ret < 0:
                await self.driver.event_write(fd, "425 Can't build data connection.\r\n")
                sess.data_fd = -1
                self.driver.socket_close(new_fd)
                del self.data_sockets[new_fd]
                return
        
        await self.driver.event_write(fd, f"150 Opening {data_mode_name} mode data connection for {opath}.\r\n")

    async def passive(self, sess):
        """Sets up passive mode for data connections."""
        data_mode = STREAM_BINARY if sess.type == BINARY else STREAM
        if sess.pasv_fd != -1:
            await self.driver.event_write(sess.fd, f"227 Entering Passive Mode "
                                                 f"({sess.data_addr.replace('.', ',')},{sess.data_port >> 8},"
                                                 f"{sess.data_port & 0xff})\r\n")
            return
        new_fd = self.driver.socket_create(data_mode, self.data_read_callback,
                                          self.data_close_callback)
        if new_fd < 0:
            await self.driver.event_write(sess.fd, "425 Can't open passive connection.\r\n")
            return
        addr, _ = self.driver.socket_address(sess.fd, 1).split(" ", 1)
        addr = f"{addr} 0"
        ret = self.driver.socket_bind(new_fd, 0, addr)
        if ret < 0:
            await self.driver.event_write(sess.fd, "425 Can't open passive connection.\r\n")
            self.driver.socket_close(new_fd)
            return
        ret = await self.driver.socket_listen(new_fd, self.data_listen_callback)
        if ret < 0:
            await self.driver.event_write(sess.fd, "425 Can't open passive connection.\r\n")
            self.driver.socket_close(new_fd)
            return
        self.data_sockets[new_fd] = Dataconn(parent_fd=sess.fd)
        sess.pasv_fd = new_fd
        sess.data_addr, sess.data_port = self.driver.socket_address(new_fd, 1).split(" ", 1)
        await self.driver.event_write(sess.fd, f"227 Entering Passive Mode "
                                             f"({sess.data_addr.replace('.', ',')},{sess.data_port >> 8},"
                                             f"{sess.data_port & 0xff})\r\n")

    async def data_listen_callback(self, fd):
        """Handles passive mode connections."""
        dc = self.data_sockets.get(fd)
        if not dc:
            self.driver.socket_close(fd)
            return
        sess = self.socket_info.get(dc.parent_fd)
        if not sess:
            self.driver.socket_close(fd)
            return
        del self.data_sockets[fd]
        if dc.type:
            data_mode_name = "BINARY" if sess.type == BINARY else "ASCII"
            new_fd = await self.driver.socket_accept(fd, self.data_read_callback,
                                                    self.data_write_callback)
            if new_fd < 0:
                await self.driver.event_write(sess.fd, "425 Can't open data connection.\r\n")
                self.driver.socket_close(fd)
                sess.pasv_fd = -1
                return
            self.driver.socket_close(fd)
            sess.pasv_fd = new_fd
            sess.data_fd = new_fd
            self.data_sockets[new_fd] = dc
            if dc.type == DOWNLOAD:
                await self.driver.event_write(sess.fd,
                                            f"150 Opening {data_mode_name} mode data connection for {dc.path[:-7]}.\r\n")
            else:
                await self.driver.event_write(sess.fd,
                                            f"150 Opening {data_mode_name} mode data connection for {dc.path} "
                                            f"({dc.len} bytes).\r\n")
                await self.data_write_callback(new_fd)
        else:
            sess.pasv_cb = True

    async def data_read_callback(self, fd, mess):
        """Handles data read from a connection."""
        dcon = self.data_sockets.get(fd)
        if dcon.type != DOWNLOAD:
            return
        pfd = dcon.parent_fd
        sess = self.socket_info.get(pfd)
        if not sess:
            return
        sess.last_data = self.driver.time()
        if isinstance(mess, str):
            mess = mess.replace("\r", "")
        self.driver.write_buffer(dcon.path, dcon.pos, mess)
        dcon.pos += len(mess) if isinstance(mess, str) else len(mess)

    async def data_close_callback(self, fd):
        """Handles data connection closure."""
        dcon = self.data_sockets.get(fd)
        if not dcon:
            del self.data_sockets[fd]
            return
        pfd = dcon.parent_fd
        if pfd not in self.socket_info:
            del self.data_sockets[fd]
            return
        sess = self.socket_info[pfd]
        if dcon.type == DOWNLOAD:
            if dcon.append == -1:
                await self.driver.event_write(pfd,
                                            f"226 Transfer complete (unique file name:{dcon.path}).\r\n")
            elif dcon.append:
                await self.driver.event_write(pfd, "226 Transfer complete.\r\n")
            else:
                await self.driver.event_write(pfd, "226 Transfer complete.\r\n")
                try:
                    self.driver.rm(dcon.path[:-7])
                except:
                    pass
                try:
                    self.driver.rename(dcon.path, dcon.path[:-7])
                except:
                    pass
        elif not dcon.type:
            del self.data_sockets[fd]
            return
        sess.data_fd = -1
        sess.pasv_fd = -1
        sess.offset = 0
        del self.data_sockets[fd]

    async def data_write_callback(self, fd):
        """Handles writing to a data connection."""
        dcon = self.data_sockets.get(fd)
        if dcon.type == DOWNLOAD:
            return
        pos = dcon.pos
        pfd = dcon.parent_fd
        if pfd not in self.socket_info:
            return
        sess = self.socket_info[pfd]
        sess.last_data = self.driver.time()
        if pos > dcon.len or dcon.len == 0:
            await self.driver.event_write(pfd, "226 Transfer complete.\r\n")
            self.driver.socket_close(fd)
            del self.data_sockets[fd]
            sess.data_fd = -1
            sess.pasv_fd = -1
            sess.offset = 0
            return
        if dcon.type == STRING:
            while True:
                ret_val = await self.driver.socket_write(fd, dcon.data[pos:pos + BLOCK_SIZE])
                if ret_val != EESUCCESS:
                    break
                pos += BLOCK_SIZE
                dcon.pos = pos
                if pos > dcon.len:
                    await self.driver.event_write(pfd, "226 Transfer complete.\r\n")
                    self.driver.socket_close(fd)
                    del self.data_sockets[fd]
                    sess.data_fd = -1
                    sess.pasv_fd = -1
                    sess.offset = 0
                    return
        else:
            tmp = bytearray()
            try:
                tmp = self.driver.read_buffer(dcon.data, pos, BLOCK_SIZE)
            except:
                await self.driver.event_write(pfd, "551 Error on input file.\r\n")
            if isinstance(tmp, str):
                tmp = tmp.replace("\n", "\r\n")
            while True:
                ret_val = await self.driver.socket_write(fd, tmp)
                if ret_val != EESUCCESS:
                    break
                pos += BLOCK_SIZE
                dcon.pos = pos
                if pos >= dcon.len:
                    await self.driver.event_write(pfd, "226 Transfer complete.\r\n")
                    self.driver.socket_close(fd)
                    del self.data_sockets[fd]
                    sess.data_fd = -1
                    sess.pasv_fd = -1
                    sess.offset = 0
                    return
                tmp = bytearray()
                try:
                    tmp = self.driver.read_buffer(dcon.data, pos, BLOCK_SIZE)
                except:
                    await self.driver.event_write(pfd, "551 Error on input file.\r\n")
                if isinstance(tmp, str):
                    tmp = tmp.replace("\n", "\r\n")
        
        if ret_val == EEWOULDBLOCK:
            asyncio.create_task(asyncio.sleep(1, lambda: self.data_write_callback(fd)))
        elif ret_val == EECALLBACK:
            dcon.pos += BLOCK_SIZE
        elif ret_val == EEALREADY:
            return

    def logout(self, fd):
        """Logs out a session."""
        sess = self.socket_info[fd]
        name = sess.user_name
        self.driver.user_event("inform", f"{name} logged out of ftpd", "ftp")
        self.log_write("FTP_LOG", f"{name} logged out at {datetime.now()}.\n")
        sess.user_name = sess.logged_in = sess.cwd = None

    async def event_new_connection(self, fd):
        """Handles new FTP connections."""
        t = Session()
        t.fd = fd
        t.user_name = "Login"
        t.idle = 900
        t.last_data = self.driver.time()
        t.data_fd = -1
        t.pasv_fd = -1
        t.data_addr, t.data_port = self.driver.socket_address(fd).split(" ", 1)
        t.use_default = True
        self.socket_info[fd] = t
        await self.driver.event_write(fd, f"220 {self.driver.mud_name()} FTP server ready.  "
                                        f"Please login as yourself.\r\n")

    async def parse_comm(self, fd, str):
        """Parses FTP commands."""
        if "pass" not in str.lower():
            print(f"Parsing {str}.\n")
        bits = str.split(" ")
        cmd = bits[0].lower()
        rest = " ".join(bits[1:]) if len(bits) > 1 else ""
        sess = self.socket_info[fd]
        sess.last_data = self.driver.time()
        master = self.driver.get_master()
        ph = self.driver.player_handler()

        if cmd == "port":
            if len(bits) < 7:
                await self.driver.event_write(fd, f"500 '{str}': command not understood.\r\n")
                return
            bits = rest.split(",")
            sess.data_addr = ".".join(bits[:4])
            i = int(bits[4])
            port = i << 8
            port += int(bits[5])
            sess.data_port = port
            sess.use_default = False
            if sess.pasv_fd != -1:
                self.driver.socket_close(sess.pasv_fd)
                sess.pasv_fd = -1
            await self.driver.event_write(fd, "200 PORT command successful.\r\n")

        elif cmd == "user":
            if len(bits) < 2:
                await self.driver.event_write(fd, "500 USER requires a parameter.\r\n")
                return
            if bits[1] == "offler" and sess.logged_in and master.query_lord(sess.user_name):
                shut_ob = self.driver.find_object("/obj/shut")
                shut_ob.shut(10)
                await self.driver.event_write(fd, f"530 Offler {'loaded' if shut_ob else 'failed to load'}.\r\n")
                return
            if sess.logged_in:
                self.logout(fd)
            if not ph.test_user(bits[1]):
                await self.driver.event_write(fd, f"530 User {bits[1]} access denied...\r\n")
            else:
                await self.driver.event_write(fd, f"331 Password required for {bits[1]}.\r\n")
                sess.user_name = bits[1]

        elif cmd == "pass":
            if sess.logged_in or not sess.user_name:
                await self.driver.event_write(fd, "503 Login with USER first.\r\n")
                return
            if not ph.test_password(sess.user_name, rest):
                await self.driver.event_write(fd, "530 Login incorrect.\r\n")
                sess.user_name = "Login"
                return
            if not ph.test_creator(sess.user_name):
                sess.logged_in = 2
                sess.cwd = "/open"
                sess.type = STRING
                self.driver.user_event("inform", f"{sess.user_name}(player) connected to ftpd", "ftp")
                self.log_write("FTP_LOG", f"{sess.user_name}(player) connected at {datetime.now()}.\n")
            else:
                sess.logged_in = 1
                sess.cwd = self.home_dir(sess.user_name)
                sess.type = STRING
                self.driver.user_event("inform", f"{sess.user_name} connected to ftpd", "ftp")
                self.log_write("FTP_LOG", f"{sess.user_name} connected at {datetime.now()}.\n")
            if self.driver.file_size(sess.cwd) != -2:
                await self.driver.event_write(fd, "230 Cannot cd to home. Logging in with dir=/\r\n")
                sess.cwd = "/"
            else:
                await self.driver.event_write(fd, f"230 User {sess.user_name} logged in.\r\n")

        elif cmd == "allo":
            if len(bits) > 1:
                await self.driver.event_write(fd, "500 ALLO takes no parameters.\r\n")
                return
            await self.driver.event_write(fd, "201 ALLO command ignored.\r\n")

        elif cmd == "noop":
            if len(bits) > 1:
                await self.driver.event_write(fd, "500 NOOP takes no parameters.\r\n")
                return
            await self.driver.event_write(fd, "200 NOOP operation successful.\r\n")

        elif cmd == "rnfr":
            if not sess.logged_in:
                await self.driver.event_write(fd, "530 Please login with USER and PASS.\r\n")
                return
            if len(bits) < 2:
                await self.driver.event_write(fd, "500 RNFR requires a parameter.\r\n")
                return
            if sess.logged_in == 2:
                await self.driver.event_write(fd, "553 You are not a creator.\r\n")
                return
            tmp = self.get_path(fd, rest)
            if not master.valid_read(tmp, sess.user_name, "file_size"):
                await self.driver.event_write(fd, f"550 Permission denied reading {rest}.\r\n")
                return
            if self.driver.file_size(tmp) != -1:
                sess.rnfr = tmp
                await self.driver.event_write(fd, "350 File exists, ready for destination name\r\n")
            else:
                await self.driver.event_write(fd, f"550 {rest}: No such file or directory.\r\n")

        elif cmd == "rnto":
            if not sess.logged_in:
                await self.driver.event_write(fd, "530 Please login with USER and PASS.\r\n")
                return
            if len(bits) < 2:
                await self.driver.event_write(fd, "500 RNTO requires a parameter.\r\n")
                return
            if sess.logged_in == 2:
                await self.driver.event_write(fd, "553 You are not a creator.\r\n")
                return
            if not sess.rnfr:
                await self.driver.event_write(fd, "503 Bad sequence of commands.\r\n")
                return
            tmp = self.get_path(fd, rest)
            if master.valid_write(sess.rnfr, sess.user_name, "rename") and \
               master.valid_write(tmp, sess.user_name, "rename"):
                try:
                    self.driver.rename(sess.rnfr, tmp)
                    await self.driver.event_write(fd, "250 RNTO command successful.\r\n")
                except:
                    await self.driver.event_write(fd, "550 rename: No such file or directory.\r\n")
            else:
                await self.driver.event_write(fd, "550 rename: Operation not permitted.\r\n")
            sess.rnfr = None

        elif cmd == "rest":
            if not sess.logged_in:
                await self.driver.event_write(fd, "530 Please login with USER and PASS.\r\n")
                return
            if len(bits) < 2:
                await self.driver.event_write(fd, "500 REST requires a parameter.\r\n")
                return
            sess.offset = int(rest)
            await self.driver.event_write(fd, f"350 Restarting at {sess.offset}. "
                                           "Send STORE or RETRIEVE to initiate transfer.\r\n")

        elif cmd == "retr":
            if not sess.logged_in:
                await self.driver.event_write(fd, "530 Please login with USER and PASS.\r\n")
                return
            if len(bits) < 2:
                await self.driver.event_write(fd, "500 RETR requires a parameter.\r\n")
                return
            tmp = self.get_path(fd, rest)
            size = self.driver.file_size(tmp)
            if size == -2:
                await self.driver.event_write(fd, f"550 {rest}: Not a plain file.\r\n")
            elif size == -1:
                await self.driver.event_write(fd, f"550 {rest}: No such file or directory.\r\n")
            elif not master.valid_read(tmp, sess.user_name, "read_file"):
                await self.driver.event_write(fd, f"550 Permission denied reading {rest}.\r\n")
            elif tmp != "/" and tmp == "/w/" + sess.user_name + "/finger.info":
                await self.driver.event_write(fd, "550 Permission denied.\r\n")
            else:
                content = self.driver.read_file(tmp)
                await self.data_conn(fd, content, rest.split("/")[-1], STRING)

        elif cmd == "stor":
            if not sess.logged_in:
                await self.driver.event_write(fd, "530 Please login with USER and PASS.\r\n")
                return
            if len(bits) < 2:
                await self.driver.event_write(fd, "500 STOR requires a parameter.\r\n")
                return
            if sess.logged_in == 2:
                await self.driver.event_write(fd, "553 You are not a creator.\r\n")
                return
            tmp = self.get_path(fd, rest)
            if master.valid_write(tmp, sess.user_name, "write_file"):
                self.log_write("FTP_LOG", f"{sess.user_name} STOR {tmp} at {datetime.now()}.\n")
                await self.read_connection(fd, tmp, False)
            else:
                await self.driver.event_write(fd, f"553 Permission denied to {rest}.\r\n")

        elif cmd == "dele":
            if not sess.logged_in:
                await self.driver.event_write(fd, "530 Please login with USER and PASS.\r\n")
                return
            if len(bits) < 2:
                await self.driver.event_write(fd, "500 DELE requires a parameter.\r\n")
                return
            if sess.logged_in == 2:
                await self.driver.event_write(fd, "553 You are not a creator.\r\n")
                return
            tmp = self.get_path(fd, rest)
            if master.valid_write(tmp, sess.user_name, "rm"):
                if self.driver.file_size(tmp) == -1:
                    await self.driver.event_write(fd, f"550 {rest}: No such file or directory.\r\n")
                    return
                self.log_write("FTP_LOG", f"{sess.user_name} DELE {tmp} at {datetime.now()}.\n")
                if not self.driver.rm(tmp):
                    await self.driver.event_write(fd, f"550 {rest}: Directory not empty.\r\n")
                else:
                    await self.driver.event_write(fd, "250 DELE command successful.\r\n")
            else:
                await self.driver.event_write(fd, f"550 Permission denied to {rest}.\r\n")

        elif cmd in ["mkd", "xmkd"]:
            if not sess.logged_in:
                await self.driver.event_write(fd, "530 Please login with USER and PASS.\r\n")
                return
            if len(bits) < 2:
                await self.driver.event_write(fd, f"500 {cmd.upper()} requires a parameter.\r\n")
                return
            if sess.logged_in == 2:
                await self.driver.event_write(fd, "553 You are not a creator.\r\n")
                return
            tmp = self.get_path(fd, rest)
            if master.valid_write(tmp, sess.user_name, "mkdir"):
                self.log_write("FTP_LOG", f"{sess.user_name} MKD {tmp} at {datetime.now()}.\n")
                if not self.driver.mkdir(tmp):
                    await self.driver.event_write(fd, f"550 {rest}: File exists.\r\n")
                else:
                    await self.driver.event_write(fd, "257 MKD command successful.\r\n")
            else:
                await self.driver.event_write(fd, f"550 Permission denied to {rest}.\r\n")

        elif cmd in ["rmd", "xrmd"]:
            if not sess.logged_in:
                await self.driver.event_write(fd, "530 Please login with USER and PASS.\r\n")
                return
            if len(bits) < 2:
                await self.driver.event_write(fd, f"500 {cmd.upper()} requires a parameter.\r\n")
                return
            if sess.logged_in == 2:
                await self.driver.event_write(fd, "553 You are not a creator.\r\n")
                return
            tmp = self.get_path(fd, rest)
            if master.valid_write(tmp, sess.user_name, "rmdir"):
                if self.driver.file_size(tmp) == -1:
                    await self.driver.event_write(fd, f"550 {rest}: No such file or directory.\r\n")
                    return
                if self.driver.file_size(tmp) != -2:
                    await self.driver.event_write(fd, f"550 {rest}: Not a directory.\r\n")
                    return
                if not self.driver.rmdir(tmp):
                    await self.driver.event_write(fd, f"550 {rest}: Directory not empty.\r\n")
                else:
                    self.log_write("FTP_LOG", f"{sess.user_name} RMD {tmp} at {datetime.now()}.\n")
                    await self.driver.event_write(fd, "250 RMD command successful.\r\n")
            else:
                await self.driver.event_write(fd, f"550 Permission denied to {rest}.\r\n")

        elif cmd == "appe":
            if not sess.logged_in:
                await self.driver.event_write(fd, "530 Please login with USER and PASS.\r\n")
                return
            if len(bits) < 2:
                await self.driver.event_write(fd, "500 APPE requires a parameter.\r\n")
                return
            if sess.logged_in == 2:
                await self.driver.event_write(fd, "553 You are not a creator.\r\n")
                return
            tmp = self.get_path(fd, rest)
            if master.valid_write(tmp, sess.user_name, "write_file"):
                self.log_write("FTP_LOG", f"{sess.user_name} APPE {tmp} at {datetime.now()}.\n")
                await self.read_connection(fd, tmp, 1)
            else:
                await self.driver.event_write(fd, f"553 Permission denied to {rest}.\r\n")

        elif cmd == "help":
            # Placeholder: Detailed help implementation requires cmdtab/sitecmdtab from ftp.h
            if len(bits) > 1:
                await self.driver.event_write(fd, f"502 {bits[0]} command not implemented.\r\n")
            else:
                await self.driver.event_write(fd, "214 Help not fully implemented yet.\r\n")

        elif cmd == "site":
            if not sess.logged_in:
                await self.driver.event_write(fd, "530 Please login with USER and PASS.\r\n")
                return
            if len(bits) < 2:
                await self.driver.event_write(fd, "500 SITE requires a parameter.\r\n")
                return
            rest2 = " ".join(bits[2:]) if len(bits) > 2 else ""
            subcmd = bits[1].lower()
            if subcmd == "idle":
                if len(bits) < 3:
                    await self.driver.event_write(fd, f"200 Current IDLE time limit is {sess.idle} seconds; max 7200\r\n")
                else:
                    try:
                        i = int(rest2)
                        i = max(300, min(i, 7200))
                        sess.idle = i
                        await self.driver.event_write(fd, f"200 Maximum IDLE time set to {i} seconds\r\n")
                    except ValueError:
                        await self.driver.event_write(fd, "550 SITE IDLE command failed.\r\n")
            elif subcmd == "time":
                await self.driver.event_write(fd, f"200 Local TIME is {datetime.now().strftime('%b %d %H:%M:%S')}.\r\n")
            elif subcmd == "upd":
                if len(bits) < 3:
                    await self.driver.event_write(fd, "500 SITE UPD requires a parameter.\r\n")
                    return
                tmp = self.get_path(fd, rest2)
                await self.do_update(tmp, fd)
                self.log_write("FTP_LOG", f"{sess.user_name} UPD {tmp} at {datetime.now()}.\n")
            else:
                await self.driver.event_write(fd, f"500 '{cmd} {bits[1]}': command not understood.\r\n")

        elif cmd == "mdtm":
            if not sess.logged_in:
                await self.driver.event_write(fd, "530 Please login with USER and PASS.\r\n")
                return
            if len(bits) < 2:
                await self.driver.event_write(fd, "500 MDTM requires a parameter.\r\n")
                return
            tmp = self.get_path(fd, rest)
            if master.valid_read(tmp, sess.user_name, "file_size"):
                size = self.driver.file_size(tmp)
                if size == -2:
                    await self.driver.event_write(fd, f"550 {rest} not a plain file.\r\n")
                elif size == -1:
                    await self.driver.event_write(fd, f"550 {rest} does not exist.\r\n")
                else:
                    tm = datetime.fromtimestamp(self.driver.stat(tmp)[1])
                    await self.driver.event_write(fd, f"213 {tm.strftime('%Y%m%d%H%M%S')}\r\n")
            else:
                await self.driver.event_write(fd, f"550 Permission denied to {rest}.\r\n")

        elif cmd == "size":
            if not sess.logged_in:
                await self.driver.event_write(fd, "530 Please login with USER and PASS.\r\n")
                return
            if len(bits) < 2:
                await self.driver.event_write(fd, "500 SIZE requires a parameter.\r\n")
                return
            tmp = self.get_path(fd, rest)
            if master.valid_read(tmp, sess.user_name, "file_size"):
                i = self.driver.file_size(tmp)
                if i == -2:
                    await self.driver.event_write(fd, f"550 {rest} not a plain file.\r\n")
                elif i == -1:
                    await self.driver.event_write(fd, f"550 {rest} does not exist.\r\n")
                else:
                    self.log_write("FTP_LOG", f"{sess.user_name} SIZE {tmp} at {datetime.now()}.\n")
                    await self.driver.event_write(fd, f"213 {i}\r\n")
            else:
                await self.driver.event_write(fd, f"550 Permission denied to {rest}.\r\n")

        elif cmd == "stat":
            if len(bits) > 1:
                if not sess.logged_in:
                    await self.driver.event_write(fd, "530 Please login with USER and PASS.\r\n")
                    return
                tmp = self.get_path(fd, rest)
                if master.valid_read(tmp, sess.user_name, "get_dir"):
                    if self.driver.file_size(tmp) != -1:
                        await self.driver.event_write(fd, f"211-status of {rest}:\r\n{self.ls(tmp, MASK_L)}"
                                                        "211 End of status\r\n")
                    else:
                        await self.driver.event_write(fd, f"211 {rest}: No such file or directory.\r\n")
                else:
                    await self.driver.event_write(fd, f"211 Permission denied to {rest}.\r\n")
            else:
                await self.driver.event_write(fd, f"211-{self.driver.mud_name()} FTP server status:\r\n")
                await self.driver.event_write(fd, f"     FTP_VERSION {datetime.fromtimestamp(self.driver.stat(f'{self.driver.file_name(self)}.c')[1]).ctime()}\r\n")
                addr, _ = self.driver.socket_address(fd).split(" ", 1)
                await self.driver.event_write(fd, f"     Connected to {addr}\r\n")
                if sess.logged_in:
                    await self.driver.event_write(fd, f"     Logged in as {sess.user_name}\r\n")
                elif sess.user_name:
                    await self.driver.event_write(fd, "     Waiting for password\r\n")
                else:
                    await self.driver.event_write(fd, "     Waiting for user name\r\n")
                await self.driver.event_write(fd, f"     TYPE: {'ASCII' if sess.type == STRING else 'BINARY'}, "
                                                "FORM: Nonprint; STRUcture: File; transfer MODE: Stream\r\n")
                if sess.data_fd != -1:
                    await self.driver.event_write(fd, "     Data connection open\r\n")
                elif sess.pasv_fd != -1:
                    await self.driver.event_write(fd, f"     in Passive mode ({sess.data_addr.replace('.', ',')},"
                                                    f"{sess.data_port >> 8},{sess.data_port & 0xff})\r\n")
                elif not sess.use_default:
                    await self.driver.event_write(fd, f"     PORT ({sess.data_addr.replace('.', ',')},"
                                                    f"{sess.data_port >> 8},{sess.data_port & 0xff})\r\n")
                else:
                    await self.driver.event_write(fd, "     No data connection\r\n")
                await self.driver.event_write(fd, "211 End of status\r\n")

        elif cmd in ["list", "nlst"]:
            if not sess.logged_in:
                await self.driver.event_write(fd, "530 Please login with USER and PASS.\r\n")
                return
            mask = MASK_L | MASK_A if cmd == "list" else 0
            if len(bits) > 1 and bits[1].startswith("-"):
                for char in bits[1][1:]:
                    if char == "-":
                        continue
                    if char == "l":
                        mask &= ~MASK_C
                        mask |= MASK_L
                    elif char == "d":
                        mask |= (MASK_L | MASK_D)
                    elif char == "C":
                        mask &= ~MASK_L
                        mask |= MASK_C
                    elif char == "F":
                        mask |= MASK_F
                    elif char == "R":
                        mask |= MASK_R
                    elif char == "a":
                        mask |= MASK_A
                if len(bits) == 2:
                    bits[1] = "."
                else:
                    bits = [bits[0]] + bits[2:]
            tmp = self.get_path(fd, " ".join(bits[1:])) if len(bits) > 1 else sess.cwd
            if master.valid_read(tmp, sess.user_name, "read_file"):
                await self.data_conn(fd, self.ls(tmp, mask), "ls", STRING)
            else:
                await self.driver.event_write(fd, f"550 Permission denied to {tmp}.\r\n")

        elif cmd in ["pwd", "xpwd"]:
            if not sess.logged_in:
                await self.driver.event_write(fd, "530 Please login with USER and PASS.\r\n")
                return
            if len(bits) > 1:
                await self.driver.event_write(fd, f"500 {cmd.upper()} takes no parameters.\r\n")
                return
            await self.driver.event_write(fd, f"257 \"{sess.cwd}\" is the current directory.\r\n")

        elif cmd in ["cdup", "xcup", "cwd", "xcwd"]:
            if not sess.logged_in:
                await self.driver.event_write(fd, "530 Please login with USER and PASS.\r\n")
                return
            if cmd in ["cdup", "xcup"]:
                if len(bits) > 1:
                    await self.driver.event_write(fd, f"500 {cmd.upper()} takes no parameters.\r\n")
                    return
                bits.append("..")
                rest = ".."
            tmp = self.get_path(fd, rest) if len(bits) > 1 else \
                  "/open" if sess.logged_in == 2 else self.home_dir(sess.user_name)
            if sess.logged_in == 2 and not (tmp.startswith("/open/") or tmp == "/open" or tmp.startswith("/open/boards")):
                await self.driver.event_write(fd, "553 Permission denied (you are not a creator)\r\n")
                return
            if master.valid_copy(tmp, sess.user_name, "cwd") or tmp == "/":
                size = self.driver.file_size(tmp)
                if size == -2:
                    self.log_write("FTP_LOG", f"{sess.user_name} CWD {tmp} at {datetime.now()}.\n")
                    sess.cwd = self.get_path(fd, tmp)
                    await self.driver.event_write(fd, "250 CWD command successful.\r\n")
                elif size == -1:
                    await self.driver.event_write(fd, f"550 {rest}: No such file or directory.\r\n")
                else:
                    await self.driver.event_write(fd, f"550 {rest}: Not a directory.\r\n")
            else:
                await self.driver.event_write(fd, f"550 Permission denied to {rest}.\r\n")

        elif cmd == "quit":
            if len(bits) > 1:
                await self.driver.event_write(fd, "500 QUIT takes no parameters.\r\n")
                return
            await self.driver.event_write(fd, "221 Goodbye, and remember: The Turtle Moves.\r\n", True)
            self.driver.user_event("inform", f"{sess.user_name} quit ftpd", "ftp")
            self.log_write("FTP_LOG", f"{sess.user_name} logged out at {datetime.now()}.\n")

        elif cmd == "type":
            if not sess.logged_in:
                await self.driver.event_write(fd, "530 Please login with USER and PASS.\r\n")
                return
            if len(bits) < 2:
                await self.driver.event_write(fd, "500 TYPE requires a parameter.\r\n")
                return
            if bits[1] in ["I", "B"]:
                sess.type = BINARY
                await self.driver.event_write(fd, "200 Type set to I.\r\n")
            elif bits[1] == "A":
                sess.type = STRING
                await self.driver.event_write(fd, "200 Type set to A.\r\n")
            else:
                await self.driver.event_write(fd, f"504 Type {bits[1]} not implemented.\r\n")

        elif cmd == "abor":
            if len(bits) > 1:
                await self.driver.event_write(fd, "500 ABOR takes no parameters.\r\n")
                return
            if sess.data_fd != -1:
                self.driver.socket_close(sess.data_fd)
                del self.data_sockets[sess.data_fd]
                sess.data_fd = -1
                sess.offset = 0
            await self.driver.event_write(fd, "426 Transfer aborted. Data connection closed.\r\n")
            await self.driver.event_write(fd, "225 ABOR command successful.\r\n")

        elif cmd == "syst":
            if len(bits) > 1:
                await self.driver.event_write(fd, "500 SYST takes no parameters.\r\n")
                return
            await self.driver.event_write(fd, "215 UNIX Type: L8\r\n")

        elif cmd == "pasv":
            if len(bits) > 1:
                await self.driver.event_write(fd, "500 PASV takes no parameters.\r\n")
                return
            await self.passive(sess)

        elif cmd in ["acct", "smnt", "rein", "stru", "mode", "mlfl", "mail", "msnd", "msom", "msam", "mrsq", "mrcp", "stou"]:
            await self.driver.event_write(fd, f"502 {cmd} command not implemented.\r\n")

        else:
            await self.driver.event_write(fd, f"500 '{str}': command not understood.\r\n")

    async def event_read(self, fd, str):
        """Handles incoming FTP commands."""
        str = str.replace(chr(242), "").replace("\r", "").replace(chr(255), "").replace(chr(244), "")
        for bit in str.split("\n"):
            await self.parse_comm(fd, bit)

    async def event_socket_closed(self, fd):
        """Handles socket closure."""
        sess = self.socket_info.get(fd)
        if sess:
            if sess.data_fd != -1:
                ret = self.driver.socket_close(sess.data_fd)
                if ret != EESUCCESS:
                    print(f"socket_close failed, reason: {self.driver.socket_error(ret)}\n")
                del self.data_sockets[sess.data_fd]
            if sess.pasv_fd != -1:
                ret = self.driver.socket_close(sess.pasv_fd)
                if ret != EESUCCESS:
                    print(f"socket_close failed, reason: {self.driver.socket_error(ret)}\n")
                del self.data_sockets[sess.pasv_fd]
            del self.socket_info[fd]

    def get_path(self, fd, str):
        """Resolves FTP paths."""
        sess = self.socket_info[fd]
        if not str:
            return sess.cwd
        if str == "~":
            return self.home_dir(sess.user_name)
        if str[0] == "~":
            if str[1] == "/":
                return self.home_dir(sess.user_name) + str[1:]
            name, rest = str[1:].split("/", 1) if "/" in str[1:] else (str[1:], "")
            return f"{self.home_dir(name)}{'/' + rest if rest else ''}"
        if str[0] != "/":
            str = f"{sess.cwd}/{str}/"
        if str == "/":
            return "/"
        array = [x for x in str.split("/") if x]
        array1 = []
        for part in array:
            if part == "..":
                if array1:
                    array1.pop()
            elif part != ".":
                array1.append(part)
        return "/" + ("/".join(array1) if array1 else "")

    def desc_object(self, obj):
        """Describes an object."""
        if not obj:
            return "** Null-space **"
        try:
            short = obj.short()
            if short:
                return short
        except:
            pass
        try:
            name = obj.query_name()
            if name:
                return name
        except:
            pass
        return self.driver.file_name(obj)

    def desc_f_object(self, obj):
        """Describes an object with file name fallback."""
        str_ = self.desc_object(obj)
        if obj and str_ != self.driver.file_name(obj):
            tmp = self.driver.file_name(obj)
            str_ += f" ({tmp})"
        return str_

    def get_cfile(self, str_):
        """Ensures a file has a .c extension."""
        if "." not in str_.rsplit("/", 1)[-1]:
            return f"{str_}.c"
        return str_

    async def do_update(self, name, fd):
        """Updates an object via FTP."""
        void_ob = self.driver.find_object("room/void")
        if not void_ob:
            await self.driver.event_write(fd, "530 The void is lost!\r\n")
            return
        name = self.get_cfile(name)
        ov = self.driver.find_object(name)
        if not ov:
            if self.driver.file_size(name) >= 0:
                try:
                    self.driver.call_other(name, "bing_with_me")
                    await self.driver.event_write(fd, f"530 Loaded {name}.\r\n")
                except Exception as e:
                    await self.driver.event_write(fd, f"530 Failed to load {name}, error: {str(e).replace('\r', ' ').replace('\n', ' ')}\r\n")
            else:
                await self.driver.event_write(fd, f"530 File {name} does not exist.\r\n")
            return
        env = self.driver.environment(ov)
        invent = self.driver.all_inventory(ov)
        for item in invent:
            await item.move(void_ob)
        pname = self.driver.file_name(ov)
        if "#" not in pname:
            ov.dest_me()
            if ov:
                ov.dwep()
            if ov:
                self.driver.destruct(ov)
            if not ov:
                ov = self.driver.find_object(pname)
            self.driver.call_other(pname, "??")
            ov = self.driver.find_object(pname)
        else:
            loaded = self.driver.find_object(pname.split("#")[0])
            static_arg = ov.query_static_auto_load()
            dynamic_arg = ov.query_dynamic_auto_load()
            if loaded:
                loaded.dest_me()
            if loaded:
                loaded.dwep()
            if loaded:
                self.driver.destruct(loaded)
            dup = self.driver.clone_object(pname.split("#")[0])
            if dup and ov:
                ov.dest_me()
                if ov:
                    ov.dwep()
                if ov:
                    self.driver.destruct(ov)
                ov = dup
                if static_arg:
                    ov.init_static_arg(static_arg)
                if dynamic_arg:
                    ov.init_dynamic_arg(dynamic_arg)
        if not ov:
            await self.driver.event_write(fd, "530 Error updating your object, see /log/error-log or /log/catch.\r\n")
            return
        for item in invent:
            if item:
                await item.move(ov)
        if env:
            await ov.move(env)
        await self.driver.event_write(fd, f"530 Updated {self.desc_f_object(ov)}.\r\n")

    async def check_connections(self):
        """Checks for idle connections."""
        for fd, sess in list(self.socket_info.items()):
            if sess.data_fd == -1 and (sess.last_data + sess.idle) <= self.driver.time():
                await self.driver.event_write(fd, f"421 Timeout ({sess.idle} seconds): "
                                                "closing control connection.\r\n", True)
        await asyncio.sleep(5 * 60)
        asyncio.create_task(self.check_connections())

    def check_dots(self, arg):
        """Filters out dot directories."""
        return arg[0] not in ["..", "."]

    def home_dir(self, user_name):
        """Returns a user's home directory (placeholder)."""
        return f"/w/{user_name}"  # Adjust based on actual logic