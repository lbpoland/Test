# /secure/security.py
# Translated from /secure/security.c (2003 Discworld MUD library)
# Purpose: Provides unguarded function calls
# Last modified in original: Unknown

class Security:
    def __init__(self, driver):
        self.driver = driver

    def call_unguarded(self, func, *args):
        """Calls a function on the previous object without security checks."""
        return self.driver.call_other(self.driver.previous_object(), func, *args[:4])