# /secure/related_files.py
# Translated from /secure/related_files.c (2003 Discworld MUD library)
# Purpose: Deletes related player files
# Last modified in original: Unknown

class RelatedFiles:
    def __init__(self, driver):
        self.driver = driver

    def delete_related_files(self, name, mail=True, refresh_type=0):
        """Deletes files related to a player."""
        prev_ob = self.driver.previous_object()
        allowed = ["/secure/bulk_delete", "/secure/delete_clear", "/obj/handlers/refresh"]
        if prev_ob and self.driver.base_name(prev_ob) not in allowed:
            if not self.driver.get_master().high_programmer(self.driver.previous_object(-1)) and \
               (prev_ob.query_name() != name):
                self.driver.tell_object(self.driver.find_player("ceres"), f"Not doing erasing. {prev_ob}\n")
                trace = self.driver.back_trace()
                self.driver.unguarded(lambda: self.driver.write_file("/log/CHEAT",
                                                                     f"{datetime.now().ctime()}: illegal attempt to delete related files using /secure/related_files\nTrace: {trace}"))
                return
        
        self.driver.unguarded(lambda: self.driver.rm(f"/save/artifacts/{name}"))
        self.driver.unguarded(lambda: self.driver.rm(f"/save/bank_accounts/{name[0]}/{name}.o"))
        self.driver.unguarded(lambda: self.driver.rm(f"/save/cmr_library/{name}.o"))
        try:
            self.driver.find_object("/obj/handlers/library").restart(name)
        except:
            pass
        self.driver.unguarded(lambda: self.driver.rm(f"/save/library/{name[0]}/{name}.o"))
        self.driver.unguarded(lambda: self.driver.rm(f"/save/philosophies/{name[0]}/{name}.o"))
        for dir_ in self.driver.get_dir("/save/vaults"):
            self.driver.unguarded(lambda: self.driver.rm(f"/save/vaults/{dir_}/{name}.o"))