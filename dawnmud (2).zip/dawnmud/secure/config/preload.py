# /home/archaon/mud/lib/secure/config/preload.py
# Purpose: Defines the list of objects to preload when the MUD driver starts.
# Linked files: /home/archaon/mud/lib/secure/master/preload.py
# @updated: 2025-03-21 - Enabled autodoc_handler by default - Verified via https://dwwiki.mooo.com/wiki/Autodoc_Updates
# @updated: 2025-03-21 - Added new weather handler variant - Verified via https://discworld.starturtle.net/lpc/blog/blog.c?action=view&blog=recent%20developments&id=1047
# @started: 2025-03-21
# @author: Archaon
# Translated and coded by: Archaon

"""
This module specifies the objects to be preloaded during MUD startup.
Lines starting with '#' are comments and ignored by the preloader.
"""

PRELOAD_LIST = [
    "/home/archaon/mud/std/object",
    "/home/archaon/mud/std/container",
    "/home/archaon/mud/obj/container",
    "/home/archaon/mud/obj/weapon",
    "/home/archaon/mud/obj/armour",
    "/home/archaon/mud/obj/clothing",
    "/home/archaon/mud/std/room",
    "/home/archaon/mud/global/virtual/compiler",
    "/home/archaon/mud/global/virtual/setup_compiler/SetupCompiler",
    "/home/archaon/mud/room/void",
    "/home/archaon/mud/std/race",
    "/home/archaon/mud/std/races/standard",
    "/home/archaon/mud/obj/monster",
    "/home/archaon/mud/d/am/hospital",
    "/home/archaon/mud/d/am/cityroom",
    "/home/archaon/mud/obj/handlers/armoury",
    "/home/archaon/mud/secure/related_files",
    "/home/archaon/mud/global/player",
    "/home/archaon/mud/global/creator",
    "/home/archaon/mud/global/lord",
    "/home/archaon/mud/obj/handlers/weather",           # Original weather handler
    "/home/archaon/mud/obj/handlers/weather_v2",        # New variant from 2025 update
    "/home/archaon/mud/d/guilds/wizards/books/beginners",
    "/home/archaon/mud/d/guilds/wizards/Ankh-Morpork/inside/gymnasium",
    "/home/archaon/mud/d/guilds/wizards/chars/frenkel",
    "# /home/archaon/mud/secure/ftpd",                  # Disabled: FTP daemon
    "# /home/archaon/mud/net/daemon/http",              # Disabled: HTTP daemon
    "# /home/archaon/mud/net/daemon/pop3",              # Disabled: POP3 daemon (lag issues)
    "/home/archaon/mud/net/intermud3/intermud",
    "/home/archaon/mud/global/virtual/data_compiler",
    "/home/archaon/mud/secure/delete_clear",
    "/home/archaon/mud/secure/bulk_delete",
    "/home/archaon/mud/net/daemon/board_thingy",
    "/home/archaon/mud/obj/handlers/artifact_handler",
    "/home/archaon/mud/obj/handlers/autodoc/autodoc_handler",  # Enabled per 2025 update
    "/home/archaon/mud/obj/handlers/error_tracker",
    "/home/archaon/mud/d/admin/obj/inv_check",
    "# /home/archaon/mud/secure/ftp_auth",              # Disabled: FTP auth
    "/home/archaon/mud/obj/handlers/club_handler",
    "/home/archaon/mud/obj/handlers/twiki",
    "/home/archaon/mud/obj/handlers/corpse_handler",
    "/home/archaon/mud/secure/loader",
    "# /home/archaon/mud/net/snmp/snmp",                # Disabled: SNMP daemon
]