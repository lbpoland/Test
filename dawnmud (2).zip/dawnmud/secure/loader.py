# /secure/loader.py
# Translated from /secure/loader.c (2003 Discworld MUD library)
# Purpose: Manages pre-loading of domain objects
# Last modified in original: Unknown

import asyncio

class Loader:
    def __init__(self, driver):
        self.driver = driver
        self.pre_load = []
        self.create()

    def create(self):
        """Initializes the loader with domain pre-loads."""
        master = self.driver.get_master()
        for domain in master.query_domains():
            self.driver.unguarded(lambda: self.driver.restore_object(f"/d/{domain}/loader"))
            if not self.pre_load:
                self.pre_load = []
            for i, preload in enumerate(self.pre_load):
                if preload and preload.split("/")[1] != domain:
                    print(f"invalid {domain} preload: {preload}\n")
                else:
                    print(f"{domain} pre_loading {preload}.\n")
                    try:
                        self.driver.call_other(preload, "??")
                    except:
                        asyncio.create_task(self.do_load(preload))

    async def do_load(self, str_):
        """Loads an object after a delay."""
        self.driver.call_other(str_, "??")

    def validate(self, domain, who):
        """Validates access for pre-load modifications."""
        master = self.driver.get_master()
        if domain not in master.query_domains():
            return False
        if not self.driver.is_user(who) or not self.driver.is_interactive(who):
            return False
        name = who.query_name()
        return master.query_trustee(name) or \
               master.is_leader_of(name, domain) or \
               master.is_deputy_of(name, domain)

    def add_pre_load(self, domain, str_):
        """Adds a pre-load entry for a domain."""
        prev_ob = self.driver.previous_object(1)
        if not self.validate(domain, prev_ob):
            return False
        if str_.split("/")[1] != domain:
            return False
        self.driver.unguarded(lambda: self.driver.restore_object(f"/d/{domain}/loader"))
        if not self.pre_load:
            self.pre_load = []
        if str_ not in self.pre_load:
            self.pre_load.append(str_)
        self.driver.save_object(f"/d/{domain}/loader")
        return True

    def remove_pre_load(self, domain, str_):
        """Removes a pre-load entry from a domain."""
        prev_ob = self.driver.previous_object(1)
        if not self.validate(domain, prev_ob):
            return False
        self.driver.unguarded(lambda: self.driver.restore_object(f"/d/{domain}/loader"))
        if not self.pre_load:
            self.pre_load = []
        if str_ not in self.pre_load:
            return False
        self.pre_load.remove(str_)
        self.driver.save_object(f"/d/{domain}/loader")
        return True

    def query_pre_load(self, domain):
        """Queries pre-load entries for a domain."""
        if domain not in self.driver.get_master().query_domains():
            return []
        self.driver.unguarded(lambda: self.driver.restore_object(f"/d/{domain}/loader"))
        return self.pre_load if self.pre_load else []