# /secure/rcs_handler.py
# Translated from /secure/rcs_handler.c (2003 Discworld MUD library)
# Purpose: Manages RCS file locks
# Last modified in original: Unknown

import asyncio

SAVE_FILE = "/secure/rcs_handler"
CMD_NUM = 5
MAX_MOD_TIME = 86400 * 90

class RcsHandler:
    def __init__(self, driver):
        self.driver = driver
        self._locks = {}
        self.create()

    def create(self):
        """Initializes the RCS handler."""
        self.driver.unguarded(lambda: self.driver.restore_object(SAVE_FILE))
        asyncio.create_task(asyncio.sleep(2, lambda: self.clean_up(None)))

    async def clean_up(self, names=None):
        """Cleans up expired or invalid locks."""
        if not names:
            names = list(self._locks.keys())
        if not names:
            return
        name = names[0]
        if len(names) > 1:
            asyncio.create_task(asyncio.sleep(random.randint(0, 14), lambda: self.clean_up(names[1:])))
        changed = False
        i = 0
        for file in self._locks.get(name, [])[:]:
            if i > 100:
                break
            i += 1
            if self.driver.file_size(file) <= 0:
                self._locks[name].remove(file)
                changed = True
            elif (self.driver.time() - self.driver.stat(file)[1]) > MAX_MOD_TIME or \
                 not self.driver.player_handler().test_creator(name):
                cmd = ["-w" + name, "-u", "-mForcibly released due to inactivity", file[1:]]
                self.driver.external_start(CMD_NUM, cmd, self.read_call_back,
                                           self.write_call_back, self.close_call_back)
                self._locks[name].remove(file)
                changed = True
        if not self._locks.get(name):
            self._locks.pop(name, None)
            changed = True
        if changed:
            self.driver.unguarded(lambda: self.driver.save_object(SAVE_FILE, 2))

    def read_call_back(self, fd, mess):
        """Callback for external read (placeholder)."""
        pass

    def write_call_back(self, fd):
        """Callback for external write (placeholder)."""
        pass

    def close_call_back(self, fd):
        """Callback for external close (placeholder)."""
        pass

    def add_lock(self, cre, file):
        """Adds a file lock."""
        name = cre.lower() if isinstance(cre, str) else cre.query_name()
        if file[0] != "/":
            file = f"/{file}"
        if name not in self._locks:
            self._locks[name] = [file]
        elif file not in self._locks[name]:
            self._locks[name].append(file)
        self.driver.unguarded(lambda: self.driver.save_object(SAVE_FILE, 2))

    def remove_lock(self, cre, file):
        """Removes a file lock."""
        name = cre.lower() if isinstance(cre, str) else cre.query_name()
        if file[0] != "/":
            file = f"/{file}"
        if name in self._locks and file in self._locks[name]:
            self._locks[name].remove(file)
            self.driver.unguarded(lambda: self.driver.save_object(SAVE_FILE, 2))

    def query_non_creators(self):
        """Returns locks for non-creators."""
        return {k: v for k, v in self._locks.items() if not self.driver.player_handler().test_creator(k)}

    def query_locks(self, cre):
        """Returns locks for a creator."""
        name = cre.lower() if isinstance(cre, str) else cre.query_name()
        return self._locks.get(name, [])

    def reset_locks(self, cre, start):
        """Resets locks based on RCS file state."""
        name = cre.lower() if isinstance(cre, str) else cre.query_name()
        if name not in self._locks:
            return
        changed = False
        for i, file in enumerate(self._locks[name][start:start + 100]):
            idx = file.rfind("/")
            rcsfile = f"{file[:idx + 1]}RCS/{file[idx + 1:]},v"
            if self.driver.file_size(rcsfile) > 0:
                tmp = self.driver.read_file(rcsfile, 4, 1)
                if tmp == "locks\n":
                    lockname = self.driver.read_file(rcsfile, 5, 1).split(":", 1)[0].strip()
                    if lockname != name:
                        self._locks[name].remove(file)
                        changed = True
                else:
                    self._locks[name].remove(file)
                    changed = True
        if not self._locks[name]:
            self._locks.pop(name)
            changed = True
        if changed:
            self.driver.unguarded(lambda: self.driver.save_object(SAVE_FILE, 2))

    def help(self):
        """Returns help text."""
        return "Displays the files that are locked in your current directory."