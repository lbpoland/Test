# /secure/player/delete_clear.py
# Translated from /secure/player/delete_clear.c (2003 Discworld MUD library)
# Purpose: Clears deleted player files
# Last modified in original: Unknown

import asyncio

ONE_DAY = 60 * 60 * 24
SAVE_FILE = "/save/del_pl_check"
DELETE_DIR = "delete"  # Assumed from player_handler.h

class DeleteClear:
    def __init__(self, driver):
        self.driver = driver
        self.last_clear = 0
        self.create()

    def create(self):
        """Initializes the delete clear object."""
        self.driver.seteuid("Root")
        self.driver.restore_object(SAVE_FILE)
        if self.last_clear + ONE_DAY < self.driver.time():
            asyncio.create_task(self.do_delete_check())
        else:
            asyncio.create_task(asyncio.sleep(self.last_clear + ONE_DAY - self.driver.time(), self.do_delete_check))

    async def do_delete_check(self):
        """Deletes expired player files."""
        bits = self.driver.get_dir(f"/players/{DELETE_DIR}/*.o") + \
               self.driver.get_dir(f"/players/{DELETE_DIR}/*.o.gz")
        for bit in bits:
            rubbish = self.driver.stat(f"/players/{DELETE_DIR}/{bit}")
            if rubbish[1] + ONE_DAY < self.driver.time():
                self.driver.log_file("EXPIRED", f"Requested player deletion: {bit}.\n")
        self.last_clear = self.driver.time()
        self.driver.save_object(SAVE_FILE)