# /secure/simul_efun/add_command.py
# Translated from /secure/simul_efun/add_command.c (2003 Discworld MUD library)
# Purpose: Provides command addition efuns
# Last modified in original: Unknown

class AddCommand:
    def __init__(self, driver):
        self.driver = driver

    def add_command(self, verb, pattern=None, func=None):
        """Adds a command to the current player."""
        if not verb:
            self.driver.write("Need to specify a verb for add_command.\n")
            return
        if not pattern:
            self.driver.write("Need to specify a pattern for add_command.\n")
            return
        player = self.driver.this_player()
        if player:
            player.add_command(verb, self.driver.previous_object(), pattern, func)

    def add_succeeded_mess(self, mess, indir=None):
        """Adds a success message for the current player."""
        if indir is None:
            indir = []
        player = self.driver.this_player()
        if player:
            player.add_succeeded_mess(self.driver.previous_object(), mess, indir)

    def add_succeeded_ob(self, ob):
        """Adds a succeeded object for the current player."""
        player = self.driver.this_player()
        if player:
            player.add_succeeded(ob)

    def add_failed_mess(self, mess, indir=None):
        """Adds a failure message for the current player."""
        if indir is None:
            indir = []
        player = self.driver.this_player()
        if player:
            player.add_failed_mess(self.driver.previous_object(), mess, indir)