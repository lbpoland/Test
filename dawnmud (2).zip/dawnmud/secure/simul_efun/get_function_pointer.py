# /secure/simul_efun/get_function_pointer.py
# Translated from /secure/simul_efun/get_function_pointer.c (2003 Discworld MUD library)
# Purpose: Generates function pointers from LPC code
# Last modified in original: Unknown

class GetFunctionPointer:
    def __init__(self, driver):
        self.driver = driver

    def get_function_pointer(self, lpc):
        """Creates a function pointer from LPC code."""
        def tmp(lpc_str):
            self.driver.write_file("/secure/functemp.c", f"mixed bing(){{return {lpc_str};}}")
            try:
                func = self.driver.find_object("/secure/functemp").bing()
                self.driver.destruct(self.driver.find_object("/secure/functemp"))
            except:
                func = None
            self.driver.rm("/secure/functemp.c")
            return func
        
        return self.driver.bind(lambda: self.driver.evaluate(tmp, lpc), self.driver.previous_object())