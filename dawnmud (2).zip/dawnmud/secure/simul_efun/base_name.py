# /secure/simul_efun/base_name.py
# Translated from /secure/simul_efun/base_name.c (2003 Discworld MUD library)
# Purpose: Extracts base name from file path
# Last modified in original: Unknown

class BaseName:
    def __init__(self, driver):
        self.driver = driver

    def base_name(self, val):
        """Extracts the base name from a path or object."""
        if not val:
            return ""
        name = val if isinstance(val, str) else self.driver.file_name(val)
        base = name.split("#")[0] if "#" in name else name
        return base