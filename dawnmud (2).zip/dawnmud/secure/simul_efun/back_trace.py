# /secure/simul_efun/back_trace.py
# Translated from /secure/simul_efun/back_trace.c (2003 Discworld MUD library)
# Purpose: Generates a backtrace
# Last modified in original: Unknown

from datetime import datetime

class BackTrace:
    def __init__(self, driver):
        self.driver = driver

    def back_trace(self):
        """Generates a backtrace string."""
        ret = f"Time: {datetime.now().ctime()}\n"
        progs = [p[1:-2] for p in self.driver.call_stack(0)]  # Program names
        obs = [self.driver.file_name(o)[1:] for o in self.driver.call_stack(1)]  # Objects
        funcs = self.driver.call_stack(2)  # Function names
        
        for i in range(len(progs) - 1, 0, -1):
            name = obs[i].query_name() if hasattr(obs[i], "query_name") else "null"
            if obs[i] == progs[i]:
                ret += f"{funcs[i]}() in /{progs[i]} ({name})\n"
            else:
                ret += f"{funcs[i]}() in inherited file /{progs[i]} in /{obs[i]} ({name})\n"
        return ret