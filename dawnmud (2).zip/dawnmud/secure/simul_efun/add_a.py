# /secure/simul_efun/add_a.py
# Translated from /secure/simul_efun/add_a.c (2003 Discworld MUD library)
# Purpose: Adds indefinite article to strings
# Last modified in original: Unknown

class AddA:
    def add_a(self, s):
        """Adds 'a' or 'an' to a string based on vowel start."""
        if not isinstance(s, str):
            return None
        i = 0
        while i < len(s) and s[i] == " ":
            i += 1
        if i + 1 < len(s) and s[i:i+2] == "a " or i + 2 < len(s) and s[i:i+3] == "an ":
            return s
        if i < len(s) and s[i].lower() in "aeiou":
            return f"an {s[i:]}"
        return f"a {s[i:]}"

    def vowel(self, i):
        """Checks if a character is a vowel."""
        return i.lower() in "aeiou"