# /secure/simul_efun/add_action.py
# Translated from /secure/simul_efun/add_action.c (2003 Discworld MUD library)
# Purpose: Provides action-related efuns
# Last modified in original: Unknown

LIV = "/obj/handlers/livings"

class AddAction:
    def __init__(self, driver):
        self.driver = driver
        self._nf = None  # Notify fail message

    def enable_commands(self):
        """Enables commands for an object."""
        ob = self.driver.previous_object()
        self.driver.set_this_player(ob)
        self.driver.find_object(LIV).enable_commands(ob)

    def set_living_name(self, name):
        """Sets a living name for an object."""
        self.driver.find_object(LIV).set_living_name(name, self.driver.previous_object())

    def living(self, ob):
        """Checks if an object is a living entity."""
        if not ob:
            return False
        return ob._living()  # Assumes _living() is defined in living objects

    def _notify_fail(self, mes):
        """Sets the notify fail message and returns 0."""
        self._nf = mes
        return False

    def query_notify_fail(self):
        """Returns the current notify fail message."""
        return self._nf

    def command(self, cmd):
        """Executes a command and returns evaluation cost."""
        time = self.driver.eval_cost()
        prev_ob = self.driver.previous_object()
        result = self.driver.evaluate(
            self.driver.bind(lambda: self.driver.call_other(prev_ob, "_process_input", cmd), prev_ob)
        )
        if result:
            return self.driver.eval_cost() - time + 1
        return 0

    def actions_defined(self, *args):
        """Placeholder for actions defined (returns empty list)."""
        return []

    def set_this_player(self, ob):
        """Sets the current player (restricted use)."""
        raise RuntimeError("Illegal use of set_this_player.")