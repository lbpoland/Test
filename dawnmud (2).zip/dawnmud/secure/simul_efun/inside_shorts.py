# /secure/simul_efun/inside_shorts.py
# Translated from /secure/simul_efun/inside_shorts.c (2003 Discworld MUD library)
# Purpose: Generates descriptive shorts for nested objects
# Last modified in original: Unknown

class InsideShorts:
    def __init__(self, driver):
        self.driver = driver

    def ob_short(self, ob):
        """Returns short description for an object."""
        if ob.query_clothing():
            return ob.query_pocket_mess()
        return "$ob_short$"

    def inside_the_short(self, ob=None, play=None):
        """Generates 'the' short description with nesting."""
        if not play:
            play = self.driver.this_player()
        if not ob:
            ob = self.driver.environment(play)
        str_ = self.ob_short(ob).replace("$ob_short$", ob.the_short())
        while self.driver.environment(ob) and \
              self.driver.environment(ob) != play and \
              self.driver.environment(ob) != self.driver.environment(play):
            ob = self.driver.environment(ob)
            str_ += f" inside {self.ob_short(ob).replace('$ob_short$', ob.the_short())}"
        return str_

    def inside_a_short(self, ob=None, play=None):
        """Generates 'a' short description with nesting."""
        if not play:
            play = self.driver.this_player()
        if not ob:
            ob = self.driver.environment(play)
        str_ = self.ob_short(ob).replace("$ob_short$", ob.a_short())
        while self.driver.environment(ob) and \
              self.driver.environment(ob) != play and \
              self.driver.environment(ob) != self.driver.environment(play):
            ob = self.driver.environment(ob)
            str_ += f" inside {self.ob_short(ob).replace('$ob_short$', ob.the_short())}"
        return str_

    def inside_one_short(self, ob=None, play=None):
        """Generates 'one' short description with nesting."""
        if not play:
            play = self.driver.this_player()
        if not ob:
            ob = self.driver.environment(play)
        str_ = self.ob_short(ob).replace("$ob_short$", ob.one_short())
        while self.driver.environment(ob) and \
              self.driver.environment(ob) != play and \
              self.driver.environment(ob) != self.driver.environment(play):
            ob = self.driver.environment(ob)
            str_ += f" inside {self.ob_short(ob).replace('$ob_short$', ob.the_short())}"
        return str_