# /secure/simul_efun/mapping.py
# Translated from /secure/simul_efun/mapping.c (2003 Discworld MUD library)
# Purpose: Mapping manipulation
# Last modified in original: Unknown

class Mapping:
    def __init__(self, driver):
        self.driver = driver

    def m_delete(self, map_, key):
        """Deletes a key from a mapping."""
        new_map = dict(map_)
        new_map.pop(key, None)
        return new_map