# /lib/secure/simul_efun/virtual.py
# Handles virtual object cloning.
# @see /obj/handlers/garbage.py

class Virtual:
    def __init__(self, driver):
        self.driver = driver
        self.garbage_handler = None

    def clone_object(self, str_, *args):
        """
        Clones an object, falling back to virtual creation if needed.
        @param str_ The object file path
        @param args Arguments for initialization
        @return Cloned object or None
        """
        ob = self.driver.efun_clone_object(str_, *args) if args else self.driver.efun_clone_object(str_)
        if not ob and self.driver.file_size(str_) > 0:
            ob = self.driver.find_object("SERVER").create_virtual_object(str_, 1)
        if ob:
            if not self.garbage_handler:
                try:
                    self.garbage_handler = self.driver.load_object("/obj/handlers/garbage")
                except:
                    pass
            if self.garbage_handler:
                try:
                    self.garbage_handler.cloned(ob)
                except:
                    pass
        return ob