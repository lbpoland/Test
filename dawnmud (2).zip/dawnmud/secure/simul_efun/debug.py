# /secure/simul_efun/debug.py
# Translated from /secure/simul_efun/debug.c (2003 Discworld MUD library)
# Purpose: Debugging utilities
# Last modified in original: Unknown

class Debug:
    def __init__(self, driver):
        self.driver = driver

    def debug_printf(self, fmt, *args):
        """Prints debug message to environment or player."""
        env = self.driver.previous_object()
        if env:
            while self.driver.environment(env):
                env = self.driver.environment(env)
        if (not env or not env.query_is_room() or self.driver.base_name(env) == "/room/rubbish") and \
           self.driver.this_player():
            env = self.driver.environment(self.driver.this_player())
        if env:
            self.driver.event(env, "inform", f"{self.driver.previous_object()}:\n{fmt % args}", "debug")

    def tell_creator(self, cres, fmt, *args):
        """Sends message to specified creators."""
        if not isinstance(cres, list):
            cres = [cres]
        for cre in cres:
            if isinstance(cre, str):
                cre = self.driver.find_player(cre)
            if cre and cre.query_creator():
                msg = f"{self.driver.previous_object()}:\n{fmt % args if args else fmt}"
                self.driver.tell_object(cre, msg)