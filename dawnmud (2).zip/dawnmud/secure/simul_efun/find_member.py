# /secure/simul_efun/find_member.py
# Translated from /secure/simul_efun/find_member.c (2003 Discworld MUD library)
# Purpose: Finds all occurrences in an array
# Last modified in original: Unknown

class FindMember:
    def __init__(self, driver):
        self.driver = driver

    def find_member(self, target, array):
        """Finds all indices of target in array."""
        locs = []
        start = 0
        while start != -1:
            start = array.index(target, start) if target in array[start:] else -1
            if start != -1:
                locs.append(start)
                start += 1
        return locs