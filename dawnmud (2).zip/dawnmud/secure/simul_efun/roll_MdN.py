# /lib/secure/simul_efun/roll_MdN.py
# Simulates rolling dice.

class RollMdN:
    def __init__(self, driver):
        self.driver = driver

    def roll_MdN(self, dice, sides):
        """
        Rolls M dice with N sides.
        @param dice Number of dice
        @param sides Number of sides per die
        @return Total roll result
        """
        import random
        roll = 0
        if dice > 0 and sides > 0:
            for _ in range(dice):
                roll += 1 + random.randint(0, sides - 1)
        return roll