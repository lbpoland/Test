# /lib/secure/simul_efun/multiple_short.py
# Generates a descriptive string for multiple objects.
# @see /global/player.py

class MultipleShort:
    def __init__(self, driver):
        self.driver = driver

    def query_multiple_short(self, args, type_="a", no_dollars=False, quiet=False, dark=None):
        """
        Creates a short description for multiple objects.
        @param args Array of objects or strings
        @param type_ The short type ('a', 'the', etc.) (default: 'a')
        @param no_dollars Disable dollar sign wrapping (default: False)
        @param quiet Suppress extra output (default: False)
        @param dark Darkness check override (default: None)
        @return Formatted string
        """
        args = list(args)
        tp = self.driver.this_player()
        if no_dollars and args and isinstance(args[0], object) and dark is None and tp and self.driver.environment(tp):
            dark = tp.check_dark(self.driver.environment(tp).query_light())
            if dark:
                return "some objects you cannot make out"
        if not type_:
            type_ = "a"
        func = f"{type_}_short"
        all_objects = all(isinstance(x, object) for x in args[:len(args)])
        if all_objects and not no_dollars:
            args = [self.driver.call_other(x, func, quiet) for x in args]
            return f"$M${''.join(args)}$M$"
        for i, arg in enumerate(args):
            if isinstance(arg, object):
                args[i] = self.driver.call_other(arg, func, quiet)
            elif isinstance(arg, list) and len(arg) > 1:
                args[i] = f"${type_}_short:{self.driver.file_name(arg[1])}$"
        if not args:
            return ""
        elif len(args) == 1:
            ret = args[0]
        else:
            ret = f"{', '.join(args[:-1])} and {args[-1]}"
        if no_dollars:
            return tp.convert_message(ret) if tp else self.driver.find_object("/global/player").convert_message(ret)
        return ret