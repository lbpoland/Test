# /lib/secure/simul_efun/snoop_simul.py
# Manages snooping functionality with security checks.
# @see /secure/master.py

class SnoopSimul:
    def __init__(self, driver):
        self.driver = driver

    def snoop(self, sno, snop=None):
        """
        Initiates snooping on an object with validation.
        @param sno The object to snoop
        @param snop The optional target to snoop on (default: None)
        @return 1 if successful, 0 otherwise
        """
        master_ob = self.driver.find_object("/secure/master")
        if master_ob.valid_snoop(sno, snop, self.driver.previous_object()):
            if not snop:
                self.driver.efun_snoop(sno)
            else:
                self.driver.efun_snoop(sno, snop)
            return 1
        return 0