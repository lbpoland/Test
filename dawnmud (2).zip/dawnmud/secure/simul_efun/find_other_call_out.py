# /secure/simul_efun/find_other_call_out.py
# Translated from /secure/simul_efun/find_other_call_out.c (2003 Discworld MUD library)
# Purpose: Finds call_outs on another object
# Last modified in original: Unknown

class FindOtherCallOut:
    def __init__(self, driver):
        self.driver = driver

    def find_other_call_out(self, ob, co):
        """Finds a call_out on a specified object."""
        return self.driver.evaluate(self.driver.bind(lambda: self.driver.find_call_out(co), ob))