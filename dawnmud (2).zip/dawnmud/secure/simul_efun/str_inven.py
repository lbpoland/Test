# /lib/secure/simul_efun/str_inven.py
# Groups inventory by short descriptions.

class StrInven:
    def __init__(self, driver):
        self.driver = driver

    def query_strange_inventory(self, arr):
        """
        Groups objects in an array by their short descriptions.
        @param arr Array of objects
        @return Array of [description, objects] pairs
        """
        inv = []
        for ob in arr:
            desc = ob.short()
            if not desc or desc == "":
                continue
            i = next((i for i, x in enumerate(inv) if x[0] == desc), -1)
            if i >= 0:
                inv[i][1].append(ob)
            else:
                inv.append([desc, [ob]])
        return inv