# /lib/secure/simul_efun/process_value.py
# Processes dynamic LPC-like function calls from strings.

class ProcessValue:
    def __init__(self, driver):
        self.driver = driver
        self.pattern = [r"\|", r" *[0-9]+ *", r".*"]
        self.token = [2, 3, 4]  # PV_BAR, PV_INT, PV_STR

    def process_value(self, s):
        """
        Evaluates a string as a function call with arguments.
        @param s The input string (e.g., "func|arg1 arg2")
        @return The function result or None
        """
        import re
        parts = s.split("|", 1)
        func = parts[0]
        arg = parts[1] if len(parts) > 1 else None
        if ":" in func:
            func, file = func.split(":", 1)
            ob = self.driver.find_object(file)
            if not ob:
                return None
        else:
            ob = self.driver

        params = [func]
        if arg:
            assoc = [[], []]
            for pat, tok in zip(self.pattern, self.token):
                matches = re.findall(pat, arg)
                for match in matches:
                    assoc[0].append(match)
                    assoc[1].append(tok)
            assoc[0] = [x for i, x in enumerate(assoc[0]) if not (x == "" and assoc[1][i] == 0)]
            assoc[1] = [x for i, x in enumerate(assoc[1]) if assoc[0][i] != "" or x != 0]
            for i, item in enumerate(assoc[0]):
                if assoc[1][i] == 0:
                    self.driver.write(f"process_value: syntax error: {item}\n")
                    return None
            i = 0
            while i < len(assoc[0]) - 1:
                if assoc[1][i + 1] == 2 and assoc[0][i].endswith("\\"):  # PV_BAR
                    assoc[0][i] = assoc[0][i][:-1]
                    if i + 2 < len(assoc[0]):
                        assoc[0][i] += assoc[0][i + 1] + assoc[0][i + 2]
                        assoc[0] = assoc[0][:i + 1] + assoc[0][i + 3:]
                        assoc[1] = assoc[1][:i + 1] + assoc[1][i + 3:]
                    else:
                        assoc[0][i] += assoc[0][i + 1]
                        assoc[0] = assoc[0][:i + 1]
                        assoc[1] = assoc[1][:i + 1]
                else:
                    i += 1
            for i, val in enumerate(assoc[0]):
                if assoc[1][i] == 3:  # PV_INT
                    params.append(int(val.strip()))
                elif assoc[1][i] in [4, 5]:  # PV_STR, PV_QUOTED
                    params.append(val)

        return self.driver.call_other(ob, *params)

    def process_string(self, s):
        """
        Processes a string with embedded function calls.
        @param s The input string with @@ delimiters
        @return Processed string
        """
        ss = s.split("@@")
        if s.startswith("@@"):
            ss = [""] + ss
        for i in range(1, len(ss), 2):
            proc = self.process_value(ss[i])
            if isinstance(proc, str):
                ss[i] = proc
        return "".join(ss)