# /secure/simul_efun/alt_move.py
# Translated from /secure/simul_efun/alt_move.c (2003 Discworld MUD library)
# Purpose: Alternative move function
# Last modified in original: Unknown

class AltMove:
    def __init__(self, driver):
        self.driver = driver

    def alt_move(self, dest, ob):
        """Moves an object to a destination."""
        if not ob:
            return
        self.driver.evaluate(self.driver.bind(lambda: self.driver.move_object(dest), ob))