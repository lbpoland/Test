# /lib/secure/simul_efun/tell_creator.py
# Sends messages to creators.
# @see /secure/simul_efun/modified_efuns.py

class TellCreator:
    def __init__(self, driver):
        self.driver = driver

    def tell_creator(self, cre, fmt, *args):
        """
        Sends a formatted message to a creator.
        @param cre Creator name or object
        @param fmt Format string
        @param args Format arguments
        """
        if isinstance(cre, str):
            cre = self.driver.find_player(cre)
        if isinstance(cre, object) and cre.query_creator():
            msg = fmt % args if args else fmt
            self.driver.tell_object(cre, msg)