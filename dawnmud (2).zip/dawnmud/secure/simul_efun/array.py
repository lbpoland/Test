# /secure/simul_efun/array.py
# Translated from /secure/simul_efun/array.c (2003 Discworld MUD library)
# Purpose: Array manipulation functions
# Last modified in original: Unknown

class Array:
    def __init__(self, driver):
        self.driver = driver

    def delete(self, arr, start, len_):
        """Deletes a segment from an array."""
        return arr[:start] + arr[start + len_:]

    def insert(self, arr, el, pos):
        """Inserts an element into an array."""
        if isinstance(arr, str):
            return arr[:pos] + el + arr[pos:]
        return arr[:pos] + [el] + arr[pos:]

    def all_environment(self, ob=None):
        """Returns all environments of an object."""
        if not ob:
            ob = self.driver.previous_object()
        ret = []
        while self.driver.environment(ob):
            ob = self.driver.environment(ob)
            ret.append(ob)
        return ret