# /secure/simul_efun/amtime.py
# Translated from /secure/simul_efun/amtime.c (2003 Discworld MUD library)
# Purpose: Provides Ankh-Morpork time functions
# Last modified in original: Unknown

# Constants from am_time.h (assumed)
AM_SECONDS_PER_HALF_YEAR = 15552000  # Placeholder
AM_SECONDS_PER_DAY = 86400
AM_SECONDS_PER_HOUR = 3600
AM_SECONDS_PER_MINUTE = 60

class Amtime:
    def __init__(self, driver):
        self.driver = driver

    def ordinal(self, number):
        """Returns a number with ordinal suffix."""
        if 10 < number % 100 < 14:
            return f"{number}th"
        if number % 10 == 1:
            return f"{number}st"
        if number % 10 == 2:
            return f"{number}nd"
        if number % 10 == 3:
            return f"{number}rd"
        return f"{number}th"

    def amtime(self, number, format_=None):
        """Returns Ankh-Morpork time string."""
        return self.driver.find_object("/obj/handlers/am_time_handler").query_am_time(number, format_)

    def query_time_string(self, t, max_elements=None, am_time=False, use_words=False):
        """Converts time to a string."""
        toret = []
        if am_time:
            year = AM_SECONDS_PER_HALF_YEAR * 2
            day = AM_SECONDS_PER_DAY
            hour = AM_SECONDS_PER_HOUR
            minute = AM_SECONDS_PER_MINUTE
        else:
            year = 60 * 60 * 24 * 365
            day = 60 * 60 * 24
            hour = 60 * 60
            minute = 60

        if t >= year:
            toret.append(f"{t // year} year{'s' if t >= year * 2 else ''}")
            t %= year
            year = -1
        if t >= day:
            toret.append(f"{t // day} day{'s' if t >= day * 2 else ''}")
            t %= day
            day = -1
        elif year == -1:
            toret.append("0 days")
        if t >= hour:
            toret.append(f"{t // hour} hour{'s' if t >= hour * 2 else ''}")
            t %= hour
        elif day == -1:
            toret.append("0 hours")
        if t >= minute:
            toret.append(f"{t // minute} minute{'s' if t >= minute * 2 else ''}")
            t %= minute
        elif hour == -1:
            toret.append("0 minutes")
        if t > 0:
            toret.append(f"{t} second{'s' if t > 1 else ''}")

        if max_elements is None:
            max_elements = 2
        if max_elements > 0:
            toret = toret[:max_elements]

        if use_words:
            for i, item in enumerate(toret):
                num, unit = item.split(" ", 1)
                if int(num) != 0:
                    toret[i] = f"{self.driver.query_num(int(num))} {unit}"
                else:
                    toret[i] = item

        toret = [x for x in toret if x.split()[0] != "0"]
        if not toret:
            return "no time at all"
        return self.driver.query_multiple_short(toret)