# /lib/secure/simul_efun/qip.py
# Overrides IP queries for specific users.
# @see /secure/simul_efun/modified_efuns.py

class Qip:
    def __init__(self, driver):
        self.driver = driver

    def query_ip_number(self, player):
        """
        Returns the IP number, overridden for 'elera'.
        @param player The player object
        @return IP number string
        """
        if player.query_name() == "elera":
            return "192.188.161.157"
        return self.driver.efun_query_ip_number(player)

    def query_ip_name(self, player):
        """
        Returns the IP name, overridden for 'elera'.
        @param player The player object
        @return IP name string
        """
        if player.query_name() == "elera":
            return "terminal157.cslabs.iastate.edu"
        return self.driver.efun_query_ip_name(player)