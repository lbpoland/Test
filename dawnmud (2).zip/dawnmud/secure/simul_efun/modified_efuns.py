# /lib/secure/simul_efun/modified_efuns.py
# Provides modified versions of standard efuns with additional security and functionality.
# @see /secure/simul_efun/base_name.py
# @see /obj/handlers/livings.py
# @see /secure/master.py

import asyncio
from datetime import datetime

MAX_SIZE = 50000
LIV = "/obj/handlers/livings"
LOG_NAME = lambda x: x if x.startswith('/') else f"/log/{x}"
DELAY_LOG_FLUSH = 15

class ModifiedEfuns:
    def __init__(self, driver):
        self.driver = driver
        self._callouttime = 0
        self._calloutfunc = {}
        self._log_file_info = {}
        self._log_file_flush_id = None
        self._loggers = {}
        self._reset_eval_message = "simul_efun updated"
        self._reset_eval_message_count = 1
        self._in_reference_allowed = False
        self.eval_cost_time = 0
        self.eval_cost_real_time = 0
        self.reset_eval_message = None
        self.eval_ob = None

    def say(self, str_, avoid=None):
        """
        Sends a say message to the environment, avoiding specified objects.
        @param str_ The message to say
        @param avoid Objects or array of objects to exclude (optional)
        """
        prev_ob = self.driver.previous_object()
        if not isinstance(avoid, list):
            avoid = [self.driver.this_player(), prev_ob] + ([avoid] if avoid else [])
        else:
            avoid += [self.driver.this_player(), prev_ob]
        env = self.driver.environment(prev_ob)
        if not env:
            tp = self.driver.this_player()
            if tp and self.driver.environment(tp):
                self.driver.event(self.driver.environment(tp), "say", str_, avoid)
            else:
                self.driver.event(prev_ob, "say", str_, avoid)
        else:
            outer_env = self.driver.environment(env)
            self.driver.event(outer_env if outer_env else env, "say", str_, avoid)

    def tell_room(self, ob, str_, avoid=None):
        """
        Sends a message to all in a room.
        @param ob The room object or path
        @param str_ The message to send
        @param avoid Objects to exclude (optional)
        """
        if not ob or not (isinstance(ob, object) or isinstance(ob, str)):
            return
        if isinstance(ob, str):
            ob = self.driver.load_object(ob)
        self.driver.event(ob, "say", str_, avoid)

    def tell_object(self, ob, str_):
        """
        Sends a message to a specific object.
        @param ob The target object
        @param str_ The message to send
        """
        if isinstance(ob, object):
            ob.do_efun_write(str_)

    def reference_allowed(self, referree, referrer=None):
        """
        Checks if a referrer is allowed to reference a referree based on visibility and permissions.
        @param referree The object being referenced
        @param referrer The object or name requesting reference (optional)
        @return 1 if allowed, 0 otherwise
        """
        if not referree:
            return 0
        invis = referree.query_invis()
        if not invis or not referree.query_creator() or self._in_reference_allowed:
            return 1
        self._in_reference_allowed = True
        if not referrer:
            referrer = self.driver.this_player()
        if isinstance(referrer, object):
            if not referrer or referree == referrer:
                self._in_reference_allowed = False
                return 1
            referrer_name = referrer.query_name()
            referrer_obj = referrer
        elif isinstance(referrer, str):
            referrer_name = referrer
            referrer_obj = self.driver.find_player(referrer)
        else:
            self._in_reference_allowed = False
            return 0
        if not referrer_name:
            self._in_reference_allowed = False
            return 1
        allowed = referree.query_allowed()
        if isinstance(allowed, list):
            if referrer_name in allowed or \
               ("playtesters" in allowed and self.driver.playtester_handler().query_playtester(referrer_name)):
                self._in_reference_allowed = False
                return 1
        ret = 0
        if invis == 3:
            ret = self.driver.get_master().high_programmer(referrer_name)
        elif invis == 2:
            ret = self.driver.get_master().query_lord(referrer_name)
        elif invis == 1:
            ret = referrer_obj.query_creator() if referrer_obj else self.driver.player_handler().test_creator(referrer_name)
        else:
            ret = 1
        self._in_reference_allowed = False
        return ret

    def find_living(self, word):
        """
        Finds a living object by name, respecting reference permissions.
        @param word The name to search for
        @return The found object or None
        """
        if not word:
            return None
        thing = self.driver.find_object(LIV).find_living(word)
        if not thing or not self.driver.this_player():
            return thing
        return thing if self.reference_allowed(thing) else None

    def find_player(self, word):
        """
        Finds a player by name, respecting reference permissions.
        @param word The player name
        @return The player object or None
        """
        if not word:
            return None
        thing = self.driver.find_object(LIV).find_player(word)
        if not thing or not self.driver.this_player():
            return thing
        return thing if self.reference_allowed(thing) and thing.query_property("player") else None

    def users(self):
        """
        Returns all interactive users, filtered by reference permissions.
        @return Array of user objects
        """
        prev_ob = self.driver.previous_object()
        master_ob = self.driver.get_master()
        if not self.driver.this_player() or prev_ob in [master_ob, self.driver.find_object("/obj/shut"), self.driver.find_object("/obj/handlers/livings")]:
            return self.driver.efun_users()
        return [u for u in self.driver.efun_users() if u and self.reference_allowed(u)]

    def named_livings(self):
        """
        Returns all named livings, filtered by reference permissions.
        @return Array of living objects
        """
        return [l for l in self.driver.find_object(LIV).named_livings() if self.reference_allowed(l)]

    def children(self, name):
        """
        Returns all clones of a file, filtered for sensitive paths.
        @param name The file name
        @return Array of cloned objects
        """
        if "global/lord" in name:
            return [c for c in self.driver.efun_children(name) if self.reference_allowed(c)]
        return self.driver.efun_children(name)

    def user_event(self, from_, first, *args):
        """
        Triggers an event across all users.
        @param from_ The event source or type
        @param first The event name or first argument
        @param args Additional arguments
        """
        users = self.driver.efun_users()
        if isinstance(from_, str):
            for user in users:
                self.driver.call_other(user, f"event_{from_}", self.driver.previous_object(), first, *args)
        elif isinstance(from_, object) and isinstance(first, str):
            for user in users:
                self.driver.call_other(user, f"event_{first}", from_, *args)

    async def flush_log_files(self):
        """
        Flushes buffered log data to files, rotating if necessary.
        """
        self._log_file_flush_id = None
        for fname, data in list(self._log_file_info.items()):
            size = self.driver.file_size(LOG_NAME(fname))
            if size > MAX_SIZE:
                for i in range(5, 0, -1):
                    old_name = LOG_NAME(fname) + (f".{i}" if i > 0 else "")
                    new_name = LOG_NAME(fname) + f".{i + 1}"
                    if self.driver.file_size(old_name) >= 0:
                        if i == 5:
                            self.driver.unguarded(lambda: self.driver.rm(old_name))
                        else:
                            self.driver.unguarded(lambda: self.driver.rename(old_name, new_name))
                self.driver.unguarded(lambda: self.driver.rename(LOG_NAME(fname), LOG_NAME(fname) + ".1"))
            self._log_file_info.pop(fname)
            fname = fname + "BAD" if size == -2 else fname
            self.driver.unguarded(lambda: self.driver.write_file(LOG_NAME(fname), data))

    def log_file(self, name, fmt, *args):
        """
        Logs a message to a file with buffering and rotation.
        @param name The log file name
        @param fmt The format string
        @param args Format arguments
        """
        if len(fmt) > 8000:
            fmt = fmt[:8000] + "\n\nPlus more...\n\n"
        self._loggers[name] = self.driver.base_name(self.driver.previous_object())
        fmt = self.driver.terminal_colour(fmt, {})
        if not self._log_file_flush_id:
            self._log_file_flush_id = asyncio.create_task(asyncio.sleep(DELAY_LOG_FLUSH, self.flush_log_files))
        if name not in self._log_file_info:
            self._log_file_info[name] = ""
        self._log_file_info[name] += fmt % args if args else fmt

    def query_loggers(self):
        """
        Returns the mapping of loggers.
        @return Mapping of log file names to originating objects
        """
        return self._loggers

    def mud_name(self):
        """
        Returns the capitalized MUD name.
        @return The MUD name
        """
        return "Discworld".capitalize()  # Assuming MUD_NAME is "Discworld"

    def cat(self, file, start_line, number):
        """
        Displays a file's contents with line limits.
        @param file The file path
        @param start_line Starting line number
        @param number Number of lines to display
        """
        bing = self.driver.read_file(file, start_line, number)
        if bing:
            self.driver.printf(bing[:5001])

    def wizardp(self, arg):
        """
        Checks if an object is a wizard.
        @param arg The object to check
        @return 1 if wizard, 0 otherwise
        """
        return isinstance(arg, object) and self.driver.is_interactive(arg) and arg.query_creator()

    def exec(self, to, from_):
        """
        Executes a process switch with security checks.
        @param to The target object
        @param from_ The source object
        @return 1 if successful, 0 otherwise
        """
        if not (isinstance(to, object) and isinstance(from_, object)):
            return 0
        prev_file = self.driver.file_name(self.driver.previous_object())
        if prev_file.startswith("/secure/login") or prev_file.startswith("/secure/nlogin"):
            return self.driver.efun_exec(to, from_)
        s = ""
        tp = self.driver.this_player()
        if tp:
            s += f"TP: {tp.query_name():8s} "
        tp1 = self.driver.this_player(1)
        if tp1:
            s += f"TP1: {tp1.query_name():8s} "
        s += f"PO: {prev_file:8s}"
        self.log_file("ILLEGAL", f"Exec: {s:40s} : {datetime.now().ctime()}\n")
        return 0

    async def call_out(self, fun, delay, *args):
        """
        Schedules a delayed function call with loop detection.
        @param fun The function or function name
        @param delay The delay in seconds
        @param args Arguments to pass to the function
        @return Callout ID
        """
        if self._callouttime != self.driver.time():
            self._callouttime = self.driver.time()
            self._calloutfunc = {}
        if delay == 0:
            func = f"{fun}{self.driver.file_name(self.driver.previous_object())}" if callable(fun) else fun
            if func in self._calloutfunc and self._calloutfunc[func] == -1:
                delay = 2
            elif self._calloutfunc.get(func, 0) + 1 > 100:
                delay = 2
                self._calloutfunc[func] = -1
                prev_ob = self.driver.previous_object()
                name = prev_ob.query_name() if isinstance(prev_ob.query_name(), str) else self.driver.file_name(prev_ob)
                self.log_file("CALL_OUT_LOG", f"{datetime.now().ctime()}: Object {prev_ob} ({name}) seems to loop in function {fun}.\n")
            else:
                self._calloutfunc[func] = self._calloutfunc.get(func, 0) + 1
        return await self.driver.evaluate(self.driver.bind(lambda: self.driver.efun_call_out(fun, delay, *args), self.driver.previous_object()))

    def query_verb(self):
        """
        Returns the current verb, falling back to player's verb if needed.
        @return The verb string
        """
        verb = self.driver.efun_query_verb() if hasattr(self.driver, "efun_query_verb") else ""
        if verb or not isinstance(self.driver.this_player(), object):
            return verb
        return self.driver.this_player().query_current_verb()

    def strcasecmp(self, str1, str2):
        """
        Case-insensitive string comparison.
        @param str1 First string
        @param str2 Second string
        @return Comparison result
        """
        return -1 if str1.lower() < str2.lower() else (1 if str1.lower() > str2.lower() else 0)

    def tail(self, fname, nlines=None):
        """
        Displays the tail of a file.
        @param fname The file path
        @param nlines Number of lines (optional, defaults to 20 in compat mode)
        @return String content or 1/0 in compat mode
        """
        offset = self.driver.file_size(fname)
        if offset < 0:
            return 0
        if nlines is None:  # COMPAT_TAIL mode
            offset = max(0, offset - 54 * 20)
            str_ = self.driver.read_bytes(fname, offset, 1080)
            if not str_:
                return 0
            if offset:
                str_ = str_[str_.find("\n") + 1:]
            self.driver.write(str_)
            return 1
        else:
            chunk = nlines * 80
            num_nl = 0
            p = -1
            str_ = ""
            while offset > 0 and num_nl <= nlines:
                num_nl = 0
                offset -= chunk
                if offset < 0:
                    chunk += offset
                    offset = 0
                str_ = self.driver.read_bytes(fname, offset, chunk) + str_
                p = -1
                while p < len(str_) - 1:
                    p = str_.find("\n", p + 1)
                    if p != -1:
                        num_nl += 1
            skip = num_nl - nlines
            p = -1
            while skip > 0:
                p = str_.find("\n", p + 1)
                skip -= 1
            return str_[p + 1 if p != -1 else 0:]

    def write(self, str_):
        """
        Writes a message to the current player.
        @param str_ The message to write
        """
        tp = self.driver.this_player()
        if not tp:
            return
        if isinstance(str_, int):
            str_ = str(str_)
        tp.do_efun_write(str_)

    def notify_fail(self, stuff):
        """
        Sets a failure message for the current player.
        @param stuff The message or function returning a message
        @return 0 if failed, else efun result
        """
        tp = self.driver.this_player()
        if not tp:
            return 0
        if callable(stuff):
            stuff = self.driver.evaluate(stuff)
        if not isinstance(stuff, str):
            return 0
        tp.print_messages()
        stuff = tp.convert_message(stuff)
        stuff = tp.fit_message(stuff)
        stuff = tp.fix_string(stuff)
        return self.driver.efun_notify_fail(stuff) if hasattr(self.driver, "efun_notify_fail") else self._notify_fail(stuff)

    def replace(self, str_, bing, rep=None):
        """
        Replaces occurrences in a string.
        @param str_ The original string
        @param bing String or array of replacements
        @param rep Replacement string (optional if bing is array)
        @return Modified string
        """
        if isinstance(bing, list):
            for i in range(0, len(bing), 2):
                if isinstance(bing[i], str) and isinstance(bing[i + 1], str):
                    str_ = str_.replace(bing[i], bing[i + 1])
            return str_
        if not isinstance(str_, str) or not isinstance(rep, str):
            return str_
        return str_.replace(bing, rep)

    def cap_words(self, words):
        """
        Capitalizes each word in a string.
        @param words The input string
        @return Capitalized string
        """
        return " ".join(word.capitalize() for word in words.split())

    def uniq_array(self, arr):
        """
        Returns unique elements from an array.
        @param arr The input array
        @return Array of unique elements
        """
        return list(dict.fromkeys(arr))

    def shout(self, words, avoid=None):
        """
        Broadcasts a shout to all users except those specified.
        @param words The shout message
        @param avoid Object to exclude (optional)
        """
        for thing in self.driver.efun_users():
            if thing and thing != avoid and not thing.check_earmuffs("shout") and thing != self.driver.this_player():
                thing.event_say(self.driver.previous_object(), words, [])

    def reset_eval_cost(self):
        """
        Resets evaluation cost with loop detection logging.
        """
        current_time = self.driver.time()
        real_time = self.driver.real_time()
        prev_ob = self.driver.previous_object()
        if current_time == self.eval_cost_time and prev_ob == self.eval_ob:
            if real_time - self.eval_cost_real_time > 5:
                stack = ""
                obs = self.driver.call_stack(1)
                funs = self.driver.call_stack(2)
                for i, ob in enumerate(obs):
                    stack += f"{self.driver.base_name(ob)}#{ob.query_name() if self.driver.clonep(ob) else ''}->{funs[i]}()\n"
                self.reset_eval_message = f"{self.driver.query_multiple_short([self.driver.file_name(o) for o in self.driver.previous_object(-1)])} uses reset_eval_cost to last {real_time - self.eval_cost_real_time} seconds\n{stack}"
        else:
            if self.reset_eval_message:
                self.log_file("GARBAGE", f"{datetime.fromtimestamp(self.eval_cost_time).ctime()} {self.reset_eval_message}\n")
            self.reset_eval_message = None
            self.eval_cost_time = current_time
            self.eval_cost_real_time = real_time
            self.eval_ob = prev_ob
        self.driver.efun_reset_eval_cost()

    def member_array(self, item, arr, start=0, flag=0):
        """
        Finds the index of an item in an array with optional substring matching.
        @param item The item to find
        @param arr The array to search
        @param start Starting index
        @param flag Enable substring matching
        @return Index or -1
        """
        if not arr or not isinstance(arr, list):
            return -1
        if not flag:
            return arr.index(item, start) if item in arr[start:] else -1
        if isinstance(item, str):
            tmp = [x[:len(item)] for x in arr]
            return tmp.index(item, start) if item in tmp[start:] else -1
        return -1

    def event(self, ob, func, *rest):
        """
        Triggers an event on an object and its inventory.
        @param ob The target object or array
        @param func The event name
        @param rest Additional arguments
        """
        origin = self.driver.previous_object()
        if isinstance(ob, list):
            ob = [x for x in ob if x]
            for o in ob:
                self.driver.call_other(o, f"event_{func}", origin, *rest)
        elif isinstance(ob, object):
            self.driver.call_other(ob, f"event_{func}", origin, *rest)
            bing = [x for x in self.driver.all_inventory(ob) if x and x != origin]
            for b in bing:
                self.driver.call_other(b, f"event_{func}", origin, *rest)

    def move_object(self, ob):
        """
        Moves an object with initialization.
        @param ob The destination object or path
        """
        prev_ob = self.driver.previous_object()
        if isinstance(ob, str):
            ob = self.driver.find_object(ob)
        self.driver.evaluate(self.driver.bind(lambda: self.driver.efun_move_object(ob), prev_ob))
        if ob.no_init():
            return
        tp = self.driver.this_player()
        if self.driver.living(prev_ob):
            self.driver.efun_set_this_player(prev_ob)
            ob.init()
            for item in [x for x in self.driver.all_inventory(ob) if x != prev_ob]:
                item.init()
        obs = [x for x in self.driver.all_inventory(ob) if self.driver.living(x) and x != prev_ob]
        for bing in obs:
            self.driver.efun_set_this_player(bing)
            prev_ob.init()
        if self.driver.living(ob):
            self.driver.efun_set_this_player(ob)
            prev_ob.init()
        self.driver.efun_set_this_player(tp)

    def db_exec(self, fd, fmt, *args):
        """
        Executes a database command with timing logging.
        @param fd The database file descriptor
        @param fmt The SQL command format
        @param args Command arguments
        @return Command result
        """
        start_time = self.driver.real_time()
        if not args:
            ret = self.driver.evaluate(self.driver.bind(lambda: self.driver.efun_db_exec(fd, fmt), self.driver.previous_object()))
        else:
            ret = self.driver.evaluate(self.driver.bind(lambda: self.driver.efun_db_exec(fd, fmt % args), self.driver.previous_object()))
        if self.driver.real_time() - start_time > 1:
            self.log_file("GARBAGE", f"db_exec in {self.driver.previous_object()}, time: {self.driver.real_time() - start_time}\n")
        return ret

    def db_connect(self, *args):
        """
        Placeholder for database connection.
        @param args Connection arguments
        @return Error message
        """
        raise RuntimeError("No database installed")

    def db_fetch(self, fd, row):
        """
        Placeholder for database fetch.
        @param fd The database file descriptor
        @param row The row number
        @return Error message
        """
        raise RuntimeError("No database installed")

    def db_close(self, fd):
        """
        Placeholder for database close.
        @param fd The database file descriptor
        """
        pass

    def shutdown(self, bing):
        """
        Shuts down the MUD with logging for unauthorized calls.
        @param bing Shutdown code
        """
        thing = self.driver.base_name(self.driver.previous_object())
        if thing not in ["/obj/shut", "/global/lord"]:
            self.driver.unguarded(lambda: self.driver.write_file("/d/admin/log/SHUTDOWN.log", f"value {bing}\n{self.driver.back_trace()}"))
        self.driver.efun_shutdown(bing)

    def real_time(self):
        """
        Returns the real time (defaults to game time).
        @return Current time in seconds
        """
        return self.driver.time()

    def memory_summary(self):
        """
        Placeholder for memory summary.
        @return Static message
        """
        return "Not on this mud...\n"

    def debug_info(self, operation, ob):
        """
        Provides debug info with security checks.
        @param operation The debug operation type
        @param ob The target object
        @return Debug info or error message
        """
        if operation != 2:
            return self.driver.efun_debug_info(operation, ob)
        path = f"{self.driver.base_name(ob)}.c"
        if not self.driver.get_master().valid_read(path, self.driver.this_player().query_name(), "debug_info"):
            self.driver.unguarded(lambda: self.driver.write_file("/d/admin/log/DEBUG_INFO.log",
                                                                 f"{datetime.now().ctime()}: {self.driver.this_player().query_name()} tried to debug {self.driver.base_name(ob)}.\n"))
            return "You are not authorised to do that.\n"
        if self.driver.is_interactive(ob) and not self.driver.this_player().query_lord() and ob != self.driver.this_player():
            self.driver.unguarded(lambda: self.driver.write_file("/d/admin/log/DEBUG_INFO.log",
                                                                 f"{datetime.now().ctime()}: {self.driver.this_player().query_name()} tried to debug {ob.query_name()}.\n"))
            return "Only Lords can dump an interactive object.\n"
        return self.driver.efun_debug_info(operation, ob)

    def input_to(self, fun, flag, *args):
        """
        Sets up an input handler with timing logging.
        @param fun The function or function name
        @param flag Input flag
        @param args Additional arguments
        """
        async def input_handler(input_, ob, fun_, args_):
            t = self.driver.real_time()
            if callable(fun_):
                await self.driver.evaluate(fun_, input_, *args_)
            else:
                await self.driver.call_other(ob, fun_, input_, *args_)
            if self.driver.real_time() - t > 1:
                input_str = "******" if fun_ == "logon2" else input_
                self.log_file("GARBAGE", f"input_to {fun_} ({input_str}) in {ob}, time: {self.driver.real_time() - t}\n")

        if not isinstance(flag, int):
            args = (flag,) + args
            flag = 0
        prev_ob = self.driver.previous_object()
        self.driver.efun_input_to(input_handler, flag, prev_ob, fun, args)