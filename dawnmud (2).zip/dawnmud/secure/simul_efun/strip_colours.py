# /lib/secure/simul_efun/strip_colours.py
# Removes colour codes from strings.
# @see /secure/simul_efun/mxp.py

class StripColours:
    def __init__(self, driver):
        self.driver = driver
        self.term_cache = None

    def strip_colours(self, str_):
        """
        Strips colour codes from a string using a dumb terminal setting.
        @param str_ The input string with potential colour codes
        @return Stripped string
        """
        TERM_HANDLER = "/obj/handlers/term"
        if not isinstance(self.term_cache, dict):
            try:
                self.term_cache = self.driver.find_object(TERM_HANDLER).set_term_type("dumb")
            except:
                self.term_cache = {}
        if str_ != "%^":
            return self.driver.terminal_colour(str_, self.term_cache)
        return ""