# /lib/secure/cmds/creator/grep.py
# Executes grep on files with permission checks.
# @see /secure/master.py

class Grep:
    def __init__(self, driver):
        self.driver = driver
        self.globals = {}
        self.files = {}
        self.ret = {}

    def check_perms(self, done, file):
        """
        Checks read permissions for a file.
        @param done Accumulated list of permitted files
        @param file The file to check
        @return Updated list of permitted files
        """
        perm = self.driver.get_master().valid_read(file, self.driver.this_player().query_name(), "cat")
        if not perm:
            return done
        if isinstance(perm, int):
            perm = file
        return done + [perm]

    def cmd(self, arg):
        """
        Runs grep on specified files.
        @param arg Format: "[options] pattern file [file...]"
        @return 1 on success, 0 on failure
        """
        if not arg:
            arg = ""
        bits = [b for b in arg.split() if b]
        arg = ""
        search = False
        nfiles = 0
        for bit in bits:
            if bit.startswith("-"):
                if bit in ["-r", "--recursive", "-d=recurse", "--directories=recurse", "-recursive", "-directories=recurse"] and not self.driver.this_player().query_lord():
                    continue
                arg += f" {bit}"
            elif not search:
                search = True
                arg += f" {bit}"
            else:
                files = self.driver.this_player().get_files(bit)
                files = self.check_perms([], files)
                for file in files:
                    arg += f" {file[1:]}"
                    nfiles += 1
        if nfiles or not search:
            fd = self.driver.external_start(6, arg, self.read_call_back, self.write_call_back, self.close_call_back)
        else:
            self.driver.notify_fail("Grep needs at least one file.\n")
            return 0
        if fd == -1:
            self.driver.notify_fail("grep failed somehow.\n")
            return 0
        self.globals[fd] = self.driver.this_player()
        self.ret[fd] = ""
        self.driver.write("grep started.\n")
        return 1

    def read_call_back(self, fd, mess):
        """
        Handles grep output.
        @param fd File descriptor
        @param mess Output message
        """
        mess = mess.replace("/usr/bin/", "")
        self.ret[fd] += mess

    def write_call_back(self, fd):
        """
        Handles write errors.
        @param fd File descriptor
        """
        self.driver.tell_object(self.globals[fd], "grep: Whoops! fatal error.\n")

    def close_call_back(self, fd):
        """
        Finalizes grep operation.
        @param fd File descriptor
        """
        if self.ret[fd]:
            self.globals[fd].more_string(self.ret[fd])
        else:
            self.driver.tell_object(self.globals[fd], "grep finished.\n")
        self.ret.pop(fd, None)
        self.globals.pop(fd, None)