# /lib/secure/cmds/creator/mylocks.py
# Manages RCS locks for the current user.
# @see /secure/simul_efun/rcs_handler.py

class Mylocks:
    def __init__(self, driver):
        self.driver = driver

    def cmd(self, person):
        """
        Lists or verifies RCS locks for a user.
        @param person Creator name, directory, or 'verify'
        @return 1 on success, -1 on failure
        """
        tp = self.driver.this_player()
        rcs = self.driver.find_object("RCS_HANDLER")
        if person == "verify":
            locked = sorted(rcs.query_locks(tp))
            asyncio.create_task(self.verify_lock(tp, locked))
            self.driver.write("Verifying\n")
            return 1
        who_string = "You have " if not person or self.driver.file_size(person) == -2 else f"{person.capitalize()} has "
        locked = rcs.query_locks(tp if not person else person)
        if person and self.driver.file_size(person) == -2:
            locked = [l for l in locked if l.startswith(person)]
        if not locked:
            self.driver.add_failed_mess(f"{who_string}no files locked.\n")
            return -1
        locked = sorted(locked)
        self.driver.write(f"{who_string}the following files locked:\n{chr(10).join(locked)}\n")
        return 1

    async def verify_lock(self, pl, locks):
        """
        Verifies and removes invalid locks.
        @param pl The player object
        @param locks List of locked files
        """
        if not locks:
            return
        file = locks[0]
        bits = file.split("/")
        rcsfile = f"/{'/'.join(bits[:-1])}/RCS/{bits[-1]},v"
        remove = False
        if self.driver.file_size(rcsfile) < 0:
            remove = True
        else:
            lockline = self.driver.read_file(rcsfile, 4, 1)
            if "locks; strict:" not in lockline:
                bits = self.driver.read_file(rcsfile, 5, 1).split(":")
                if bits[0][0] != "\t":
                    remove = True
        if remove:
            self.driver.tell_object(pl, f"Removing non-existant lock for {locks[0]}\n")
            self.driver.find_object("RCS_HANDLER").remove_lock(pl.query_name(), locks[0])
        if len(locks) > 1:
            await asyncio.sleep(1)
            asyncio.create_task(self.verify_lock(pl, locks[1:]))

    def query_patterns(self):
        """
        Returns command patterns.
        @return List of patterns and callbacks
        """
        return ["", lambda: self.cmd(None), "<string'creator|directory|verify'>", lambda p: self.cmd(p)]