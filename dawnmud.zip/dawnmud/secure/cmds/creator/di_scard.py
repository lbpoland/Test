# /lib/secure/cmds/creator/discard.py
# Discards loaded objects with confirmation for resistant ones.
# @see /secure/simul_efun/wiz_present.py

class Discard:
    def __init__(self, driver):
        self.driver = driver

    def cmd(self, str_):
        """
        Attempts to discard specified objects.
        @param str_ Object specification
        @return 1 on success, 0 on failure
        """
        file_names = self.driver.this_player().get_cfiles(str_)
        if not file_names:
            self.driver.add_failed_mess(f"No such object: {str_}\n")
            return 0
        no_dis = []
        for fname in file_names:
            discard_obj = self.driver.find_object(fname)
            if not discard_obj:
                self.driver.printf(f"{fname} is not loaded.\n")
                continue
            try:
                discard_obj.dest_me()
            except Exception as e:
                self.driver.this_player().handle_error(str(e), "dest_me")
            if discard_obj:
                no_dis.append(discard_obj)
        if no_dis:
            self.ask_discard(no_dis)
        else:
            self.driver.write("Ok.\n")
        return 1

    def ask_discard(self, obs):
        """
        Prompts for confirmation to force-discard resistant objects.
        @param obs Array of objects resisting discard
        """
        if not isinstance(obs, list) or not obs:
            self.driver.printf("Nothing left to be discarded.\n")
            return
        wiz_present = self.driver.find_object("/secure/simul_efun/wiz_present")
        self.driver.printf(f"{wiz_present.desc_object(obs[0])} has a violent objection to being dested.\n"
                           "Are you sure you want to do this? ")
        self.driver.input_to(self.no_discard, 0, obs)

    def no_discard(self, s, obs):
        """
        Handles user response to discard confirmation.
        @param s User input ('yes' or 'no')
        @param obs Array of objects to process
        """
        wiz_present = self.driver.find_object("/secure/simul_efun/wiz_present")
        name = wiz_present.desc_object(obs[0])
        if self.driver.this_player().affirmative(s):
            try:
                obs[0].dwep()
            except Exception as e:
                self.driver.this_player().handle_error(str(e), "DWEP")
            if obs[0]:
                try:
                    self.driver.destruct(obs[0])
                except:
                    pass
                if obs[0]:
                    self.driver.printf(f"{name} REALLY doesn't want to be discarded.\n{name} didn't destruct.\n")
                    return
        self.driver.printf(f"{name} discarded.\n")
        self.ask_discard(obs[1:])

    def query_patterns(self):
        """
        Returns command patterns.
        @return List of patterns and callbacks
        """
        return ["<string>", lambda s: self.cmd(s)]