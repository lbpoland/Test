# /lib/secure/cmds/creator/zcat.py
# Decompresses and displays contents of gzipped files.
# @see /secure/master.py
# @see /secure/simul_efun/strip_colours.py

CMD_NUM = 9

class Zcat:
    def __init__(self, driver):
        self.driver = driver
        self.globals = {}
        self.files = {}
        self.ret = {}

    def cmd(self, fname, list_):
        """
        Displays contents of compressed files.
        @param fname File specification
        @param list_ List mode flag
        @return 1 on success, -1 on failure
        """
        tp = self.driver.this_player()
        files = tp.get_files(fname)
        if not files:
            files.append(tp.get_path(fname))
        euid = self.driver.geteuid(tp)
        args = "--stdout" + (" --list" if list_ else "")
        master = self.driver.get_master()
        files = list(set(files))
        count = 0
        for file in files:
            if master.valid_read(file, euid, "cat"):
                args += f" {file[1:]}"
                count += 1
            else:
                self.driver.tell_object(tp, f"You don't have write access to {file}.\n")
        if not count:
            self.driver.add_failed_mess("zcat must have at least one argument.\n")
            return -1
        self.driver.log_file("/d/admin/log/ZCAT", f"{self.driver.ctime(self.driver.time())}: {tp.query_name()} {args}\n")
        fd = self.driver.external_start(CMD_NUM, args, self.read_call_back, self.write_call_back, self.close_call_back)
        if fd == -1:
            self.driver.add_failed_mess("zcat failed to start.\n")
            return -1
        self.globals[fd] = tp
        self.ret[fd] = ""
        self.driver.tell_object(tp, "zcat started.\n")
        return 1

    def read_call_back(self, fd, mess):
        """
        Handles zcat output.
        @param fd File descriptor
        @param mess Output message
        """
        mess = mess.replace("/bin/", "")
        max_len = self.driver.get_config("__MAX_STRING_LENGTH__")
        new_total = len(self.ret[fd]) + len(mess)
        if new_total > max_len:
            mess = mess[:new_total - max_len]
        self.ret[fd] += mess

    def write_call_back(self, fd):
        """
        Handles write errors.
        @param fd File descriptor
        """
        self.driver.tell_object(self.globals[fd], "zcat: A fatal error has occurred -- write_call_back was called.\n")

    def close_call_back(self, fd):
        """
        Finalizes zcat operation.
        @param fd File descriptor
        """
        tp = self.globals[fd]
        strip = self.driver.find_object("/secure/simul_efun/strip_colours")
        if self.ret[fd]:
            try:
                tp.more_string(strip.strip_colours(self.ret[fd]))
            except:
                self.driver.efun_tell_object(tp, self.ret[fd])
        else:
            self.driver.tell_object(tp, "zcat finished.\n")
        self.ret.pop(fd, None)
        self.globals.pop(fd, None)

    def query_patterns(self):
        """
        Returns command patterns.
        @return List of patterns and callbacks
        """
        return [
            "<string>", lambda f: self.cmd(f, 0),
            "{-l|--list|list} <string>", lambda _, f: self.cmd(f, 1)
        ]