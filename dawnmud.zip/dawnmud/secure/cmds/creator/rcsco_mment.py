# /lib/secure/cmds/creator/rcscomment.py
# Adds comments to RCS revisions.
# @see /secure/simul_efun/wiz_present.py

CMD_NUM = 8

class Rcscomment:
    def __init__(self, driver):
        self.driver = driver
        self.globals = {}
        self.ret = {}

    def cmd(self, arg):
        """
        Adds a comment to an RCS revision.
        @param arg Format: "[options] file [file...]"
        @return 1 on success, 0 on failure
        """
        if not arg:
            self.driver.notify_fail("rcscomment: No arguments.\n")
            return 0
        bits = [b for b in arg.split() if b]
        arg = ""
        nfiles = 0
        wiz = self.driver.find_object("/secure/simul_efun/wiz_present")
        tp = self.driver.this_player()
        for bit in bits:
            if bit.startswith("-"):
                arg += f" {bit}"
            else:
                files = tp.get_files(bit)
                if files:
                    for file in files:
                        arg += f" {file[1:]}"
                        nfiles += 1
                else:
                    things = wiz.wiz_present(bit, tp)
                    if things:
                        file = self.driver.file_name(things[0]).split("#")[0]
                        if self.driver.file_size(file) <= 0:
                            file += ".c"
                        arg += f" {file[1:]}"
                        nfiles += 1
        if not nfiles:
            self.driver.notify_fail(f"rcscomment: no such file {arg}.\n")
            return 0
        self.driver.printf("Enter a revision number: ")
        self.driver.input_to(self.get_rev, 0, {"player": tp, "arg": arg, "revision": None})
        return 1

    def get_rev(self, revision, args):
        """
        Collects revision number for comment.
        @param revision User input revision
        @param args Command arguments
        """
        if not revision:
            self.driver.printf("No revision given, aborting.\n")
            return
        args["revision"] = revision
        self.driver.printf("Enter a comment.\n")
        args["player"].do_edit(None, self.do_comment, None, None, args)

    def do_comment(self, comment, args):
        """
        Executes RCS comment addition.
        @param comment The comment text
        @param args Command arguments
        """
        if not comment:
            self.driver.printf("No comment given, aborting.\n")
            return
        cmd = [f"-w{args['player'].query_name()}", f"-m{args['revision']}:{comment}"] + args["arg"].split()
        fd = self.driver.external_start(CMD_NUM, cmd, self.read_call_back, self.write_call_back, self.close_call_back)
        self.globals[fd] = args["player"]
        self.ret[fd] = ""

    def read_call_back(self, fd, mess):
        """
        Handles RCS output.
        @param fd File descriptor
        @param mess Output message
        """
        mess = mess.replace("/home/atuin/lib", "")
        self.ret[fd] += mess

    def write_call_back(self, fd):
        """
        Handles write errors.
        @param fd File descriptor
        """
        self.driver.tell_object(self.globals[fd], "rcscomment: write_call_back() called.\n")

    def close_call_back(self, fd):
        """
        Finalizes RCS comment addition.
        @param fd File descriptor
        """
        if self.ret[fd]:
            self.globals[fd].more_string(self.ret[fd])
        else:
            self.driver.tell_object(self.globals[fd], "rcscomment completed.\n")
        self.ret.pop(fd, None)
        self.globals.pop(fd, None)