# /lib/secure/cmds/creator/cp.py
# Copies files with permission checks.
# @see /secure/master.py

class Cp:
    def __init__(self, driver):
        self.driver = driver

    def cmd(self, str_):
        """
        Copies files to a destination.
        @param str_ Format: "source [source...] destination"
        @return 1 on success, 0 on failure
        """
        if not str_:
            self.driver.notify_fail("Usage : cp file [file|dir...]\n")
            return 0
        fnames = str_.split()
        filenames = self.driver.this_player().get_files("/".join(fnames[:-1]))
        filenames = [f for f in filenames if not f.endswith(".")]
        if not filenames:
            self.driver.notify_fail("Usage : cp file [file|dir...]\n")
            return 0
        dest = self.driver.this_player().get_path(fnames[-1])
        if not dest:
            self.driver.write("No destination\n")
            return 1
        for src in filenames:
            if not self.driver.get_master().valid_copy(src, self.driver.geteuid(self.driver.this_player()), ""):
                self.driver.notify_fail("Permission denied.\n")
                return 0
            fs = self.driver.file_size(dest)
            if fs == -2:
                names = src.split("/")
                dstr = f"{dest}/{names[-1]}"
                if self.driver.file_size(dstr) != -1:
                    self.driver.write(f"file exists {dstr}\n")
                    continue
            else:
                if fs != -1:
                    self.driver.write(f"File exists : {dest}\n")
                    continue
                dstr = dest
            result = self.driver.cp(src, dstr)
            if result == 1:
                self.driver.write(f"{src} copied to {dstr}.\n")
            elif result == -1:
                self.driver.write(f"{src} is unreadable.\n")
            elif result == -2:
                self.driver.write(f"{dstr} is unreadable.\n")
            elif result == -3:
                self.driver.write(f"I/O error copying {src} to {dstr}.\n")
        return 1