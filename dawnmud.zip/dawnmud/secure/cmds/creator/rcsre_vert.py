# /lib/secure/cmds/creator/rcsrevert.py
# Reverts RCS files to previous versions.
# @see /secure/simul_efun/wiz_present.py

CMD_NUM = 8

class Rcsrevert:
    def __init__(self, driver):
        self.driver = driver
        self.globals = {}
        self.ret = {}

    def cmd(self, arg):
        """
        Reverts specified RCS files.
        @param arg Format: "[options] file [file...]"
        @return 1 on success, 0 on failure
        """
        if not arg:
            self.driver.notify_fail("rcsrevert: No arguments.\n")
            return 0
        bits = [b for b in arg.split() if b]
        arg = ""
        nfiles = 0
        wiz = self.driver.find_object("/secure/simul_efun/wiz_present")
        tp = self.driver.this_player()
        for bit in bits:
            if bit.startswith("-"):
                arg += f" {bit}"
            else:
                files = tp.get_files(bit)
                if files:
                    for file in files:
                        arg += f" {file[1:]}"
                        nfiles += 1
                else:
                    things = wiz.wiz_present(bit, tp)
                    if things:
                        file = self.driver.file_name(things[0]).split("#")[0]
                        if self.driver.file_size(file) <= 0:
                            file += ".c"
                        arg += f" {file[1:]}"
                        nfiles += 1
        if not nfiles:
            self.driver.notify_fail(f"rcsrevert: no such file {arg}.\n")
            return 0
        cmd = [f"-w{tp.query_name()}", "-u", "-l"] + arg.split()
        fd = self.driver.external_start(CMD_NUM, cmd, self.read_call_back, self.write_call_back, self.close_call_back)
        self.globals[fd] = tp
        self.ret[fd] = ""
        return 1

    def read_call_back(self, fd, mess):
        """
        Handles RCS revert output.
        @param fd File descriptor
        @param mess Output message
        """
        mess = mess.replace("/home/atuin/lib", "")
        self.ret[fd] += mess

    def write_call_back(self, fd):
        """
        Handles write errors.
        @param fd File descriptor
        """
        self.driver.tell_object(self.globals[fd], "rcsrevert: write_call_back() called.\n")

    def close_call_back(self, fd):
        """
        Finalizes RCS revert operation.
        @param fd File descriptor
        """
        if self.ret[fd]:
            self.globals[fd].more_string(self.ret[fd])
        else:
            self.driver.tell_object(self.globals[fd], "rcsin completed.\n")
        self.ret.pop(fd, None)
        self.globals.pop(fd, None)