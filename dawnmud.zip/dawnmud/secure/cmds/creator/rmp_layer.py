# /lib/secure/cmds/creator/rmplayer.py
# Deletes player accounts with authorization checks.
# @see /obj/handlers/player_handler.py
# @see /secure/master.py

class Rmplayer:
    def __init__(self, driver):
        self.driver = driver

    def sure(self, response, player, lord, reason, immediately):
        """
        Confirms and executes player deletion.
        @param response User confirmation ('YES' or other)
        @param player Player name to delete
        @param lord Deleting lord's name
        @param reason Deletion reason
        @param immediately Immediate deletion flag
        """
        prev_obs = self.driver.previous_object(-1)
        if prev_obs and self.driver.find_object("/secure/simul_efun") not in prev_obs:
            self.driver.log_file("CHEAT", f"{self.driver.ctime(self.driver.time())}: illegal attempt to delete a player.\nTrace: {self.driver.back_trace()}")
            self.driver.write("Illegal use of rmplayer.\n")
            return
        if response == "YES":
            self.driver.write("Ok. Deleting\n")
            olduid = self.driver.geteuid()
            self.driver.seteuid("Root")
            ph = self.driver.player_handler()
            src, ext = None, None
            for path, extension in [
                (ph.query_player_ram_file_name(player), ".o.gz"),
                (ph.query_player_disk_file_name(player), ".o.gz"),
                (ph.query_player_disk_file_name(player), ".o"),
                (ph.query_delete_player_file_name(player), ".o.gz"),
                (ph.query_delete_player_file_name(player), ".o")
            ]:
                if self.driver.file_size(f"{path}{extension}") > 0:
                    src, ext = path, extension
                    break
            if src and ext:
                if not immediately:
                    self.driver.unguarded(lambda: self.driver.cp(f"{src}{ext}", f"/save/players/appeal/{player}{ext}"))
                self.driver.unguarded(lambda: self.driver.rm(f"{src}{ext}"))
                if src == ph.query_player_ram_file_name(player):
                    self.driver.unguarded(lambda: self.driver.rm(f"{ph.query_player_disk_file_name(player)}{ext}"))
                ph.remove_cache_entry(player)
                self.driver.unguarded(lambda: self.driver.write_file("/log/SUSPEND", f"{self.driver.ctime(self.driver.time())} {player} deleted by {lord} because {reason}.\n"))
            self.driver.seteuid(olduid)
        else:
            self.driver.write("Ok. Not deleting\n")

    def cmd(self, player, reason, immediately):
        """
        Initiates player account deletion.
        @param player Player name to delete
        @param reason Reason for deletion
        @param immediately Immediate deletion flag
        @return 1 on success, 0 on failure
        """
        master = self.driver.get_master()
        prev_obs = self.driver.previous_object(-1)
        if not master.query_liaison_deputy_or_lord(prev_obs):
            self.driver.unguarded(lambda: self.driver.log_file("CHEAT", f"{self.driver.ctime(self.driver.time())}: illegal attempt to delete a player.\nTrace: {self.driver.back_trace()}"))
            self.driver.notify_fail("Sorry: only directors can delete players.\n")
            return 0
        ph = self.driver.player_handler()
        if not ph.test_user(player):
            self.driver.notify_fail(f"Sorry, but {player} isn't a player\n")
            return 0
        if not master.high_programmer(prev_obs) and master.query_lord(player):
            self.driver.unguarded(lambda: self.driver.log_file("CHEAT", f"{self.driver.ctime(self.driver.time())}: Illegal attempt to delete a director.\nTrace: {self.driver.back_trace()}"))
            self.driver.notify_fail("Sorry.\n")
            return 0
        if not master.query_lord(prev_obs) and ph.test_age(player) < -86400:
            self.driver.add_failed_mess("Only directors can immediately delete players over 24 hours old.\n")
            return 0
        if not master.query_lord(prev_obs) and ph.test_creator(player):
            self.driver.add_failed_mess("You cannot delete creators.\n")
            return 0
        if not reason:
            self.driver.notify_fail("You must give a reason.\n")
            return 0
        self.driver.write(f"This will permanently delete the player {player}.\nTHIS IS PERMANENT.\nAre you sure? (only \"YES\" will delete the player) ")
        self.driver.input_to(self.sure, 0, player, self.driver.this_player().query_name(), reason, immediately)
        return 1

    def query_patterns(self):
        """
        Returns command patterns.
        @return List of patterns and callbacks
        """
        return [
            "<word'player name'> <string'reason'>", lambda p, r: self.cmd(p, r, 0),
            "immediately <word'player name'> <string'reason'>", lambda _, p, r: self.cmd(p, r, 1)
        ]