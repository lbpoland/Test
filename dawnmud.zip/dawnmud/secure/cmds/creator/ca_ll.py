# /lib/secure/cmds/creator/call.py
# Calls functions on objects for creators.
# @see /obj/handlers/parser.py
# @see /d/liaison/master.py
# @see /secure/simul_efun/modified_efuns.py

LMASTER = "/d/liaison/master"

class Call:
    def __init__(self, driver):
        self.driver = driver

    def cmd(self, str_):
        """
        Calls a function on specified objects with arguments.
        @param str_ Format: "[obvar=]lfun(arg[,arg...]) object[s]"
        @return 1 on success, 0 on failure
        """
        if not str_:
            self.driver.notify_fail("USAGE : call [obvar=]lfun(arg[,arg[,arg...]]) object[s]\n")
            return 0
        obvarname = None
        if "=" in str_:
            obvarname, str_ = str_.split("=", 1)
        parts = ("&" + str_ + "&").split(")")
        if len(parts) < 2 or "(" not in parts[0]:
            self.driver.notify_fail("USAGE : call [obvar=]lfun(arg[,arg[,arg...]]) object[s]\n")
            return 0
        fn = parts[0].split("(")[0][1:].replace(" ", "")
        args_str = parts[0].split("(")[1]
        parts[0] = args_str
        parser = self.driver.find_object("/obj/handlers/parser")
        args = parser.parse_args(")".join(parts), ")")
        if not args:
            return 1
        argv, os = args[0], args[1][:-1].lstrip()
        if not os:
            self.driver.notify_fail(f"Can't find object {os}.\n")
            return 0
        wiz_present = self.driver.find_object("/secure/simul_efun/wiz_present")
        ov = [ob for ob in wiz_present.wiz_present(os, self.driver.this_player()) if self.driver.reference_allowed(ob, self.driver.this_player())]
        if not ov:
            return 0
        argv = argv + [None] * max(0, 6 - len(argv))
        for ob in ov:
            fish = ob
            file = None
            while shad := self.driver.shadow(fish, 0):
                fish = shad
                if f := self.driver.function_exists(fn, fish):
                    file = f
            if not file:
                file = self.driver.function_exists(fn, ob)
            if file:
                if ob != self.driver.this_player() and ob.query_property("player"):
                    log_file = "/d/admin/log/CALL_LIAISONS.log" if self.driver.find_object(LMASTER).query_member(self.driver.this_player().query_name()) else "/d/admin/log/CALL_CREATORS.log"
                    self.driver.unguarded(lambda: self.driver.write_file(log_file,
                                                                         f"{self.driver.ctime(self.driver.time())}: {self.driver.this_player().query_name()} ({self.driver.this_player()}) called {fn}({', '.join(str(a) for a in argv if a is not None)}) on {ob.query_name()} ({ob})\n"))
                    self.driver.user_event("inform", f"{self.driver.this_player().query_name()} called {fn}({', '.join(str(a) for a in argv if a is not None)}) on {ob.query_name()}", "calls")
                retobj = self.driver.call_other(ob, fn, *argv)
                self.driver.printf(f"*** function on '{wiz_present.desc_object(ob)}' found in {file} ***\n")
                self.driver.write(f"$P$Call result$P$Returned: {retobj}\n")
                if obvarname and isinstance(retobj, object):
                    self.driver.this_player().set_obvar(obvarname, retobj)
            else:
                self.driver.printf(f"*** function on '{wiz_present.desc_object(ob)}' Not found ***\n")
        return 1