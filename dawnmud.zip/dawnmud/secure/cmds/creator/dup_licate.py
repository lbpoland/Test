# /lib/secure/cmds/creator/duplicate.py
# Duplicates cloned objects with their state.
# @see /secure/simul_efun/wiz_present.py

class Duplicate:
    def __init__(self, driver):
        self.driver = driver

    def do_duplicate(self, ov):
        """
        Duplicates objects, preserving static and dynamic state.
        @param ov Array of objects to duplicate
        @return 1 on success
        """
        for i, obj in enumerate(ov):
            if not obj:
                continue
            pname = self.driver.file_name(obj)
            if "#" not in pname:
                self.driver.write(f"Can't duplicate {obj.short()} (not a clone).\n")
                continue
            pname = pname.split("#")[0]
            static_arg = obj.query_static_auto_load()
            dynamic_arg = obj.query_dynamic_auto_load()
            dup = self.driver.clone_object(pname)
            if dup and obj:
                ov[i] = dup
                if static_arg:
                    dup.init_static_arg(dict(static_arg))
                if dynamic_arg:
                    dup.init_dynamic_arg(dict(dynamic_arg))
                dup.add_property("cloned by", self.driver.this_player().query_name())
            if not ov[i]:
                self.driver.printf("I seem to have lost your object.\n")
                return 1
            if not dup.move(self.driver.this_player()):
                self.driver.write(f"{dup.short()} duplicated and put in you.\n")
            elif not dup.move(self.driver.environment(self.driver.this_player())):
                self.driver.write(f"{dup.short()} duplicated and put in here.\n")
            elif not dup.move("/room/broken"):
                self.driver.write(f"{dup.short()} duplicated and put in /room/broken.\n")
            else:
                self.driver.write(f"Couldn't find anyplace to put {dup.short()}!\n")
                dup.move("/room/rubbish")
        return 1

    def cmd(self, str_):
        """
        Initiates duplication of specified objects.
        @param str_ Object specification
        @return 1 on success, 0 on failure
        """
        wiz_present = self.driver.find_object("/secure/simul_efun/wiz_present")
        val = wiz_present.wiz_present(str_, self.driver.this_player())
        if not val:
            self.driver.notify_fail("No matching objects\n")
            return 0
        return self.do_duplicate(val)