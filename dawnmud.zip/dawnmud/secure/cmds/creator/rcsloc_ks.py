# /lib/secure/cmds/creator/rcslocks.py
# Lists RCS lock status for files.
# @see /secure/simul_efun/wiz_present.py

class Rcslocks:
    def __init__(self, driver):
        self.driver = driver

    def cmd(self, arg):
        """
        Displays lock status for specified files.
        @param arg Format: "[options] file [file...]"
        @return 1 on success, 0 on failure
        """
        if not arg:
            self.driver.notify_fail("rcslocks: No arguments.\n")
            return 0
        bits = [b for b in arg.split() if b]
        arg = ""
        files = []
        wiz = self.driver.find_object("/secure/simul_efun/wiz_present")
        tp = self.driver.this_player()
        for bit in bits:
            if bit.startswith("-"):
                arg += f" {bit}"
            else:
                new_files = tp.get_files(bit)
                if new_files:
                    files.extend(new_files)
                else:
                    things = wiz.wiz_present(bit, tp)
                    if things:
                        file = self.driver.file_name(things[0]).split("#")[0]
                        if self.driver.file_size(file) <= 0:
                            file += ".c"
                        files.append(file)
        if not files:
            self.driver.notify_fail(f"rcslocks: no such file {arg}.\n")
            return 0
        for fname in files:
            bits = fname.split("/")
            rcsfile = f"/{'/'.join(bits[:-1])}/RCS/{bits[-1]},v"
            if self.driver.file_size(rcsfile) < 0:
                self.driver.write(f"File {fname} is not on RCS.\n")
            else:
                lockline = self.driver.read_file(rcsfile, 4, 1)
                if "locks; strict:" not in lockline:
                    bits = self.driver.read_file(rcsfile, 5, 1).split(":")
                    if bits[0].startswith("\t"):
                        locker = bits[0][1:]
                        self.driver.write(f"File {fname} locked by {locker}.\n")
                    else:
                        self.driver.write(f"{fname} is not locked.\n")
        return 1