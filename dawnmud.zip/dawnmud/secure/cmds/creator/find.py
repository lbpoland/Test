# /lib/secure/cmds/creator/find.py
# Searches for function implementations in objects or files.
# @see /secure/simul_efun/wiz_present.py

EXTRACT_CODE = 1
LINE_NUMBERS = 2
FIND_ALL = 4

class Find:
    def __init__(self, driver):
        self.driver = driver

    def file_exists(self, str_):
        """
        Checks if a file exists.
        @param str_ The file path
        @return True if file exists, False otherwise
        """
        return self.driver.file_size(str_) > -1

    def cmd(self, str_):
        """
        Finds where a function is defined in objects or files.
        @param str_ Format: "[-a|-d|-n] function() <object(s)>"
        @return 1 on success, 0 on failure
        """
        if not str_:
            self.driver.notify_fail("Usage: find [-a] [-d] [-n] function() <object(s)>\n")
            return 0
        flags = 0
        while str_.startswith("-"):
            s, str_ = str_.split(" ", 1)
            s = s[1:]
            if s == "d":
                flags |= EXTRACT_CODE
                flags &= ~FIND_ALL
            elif s == "n":
                flags |= (LINE_NUMBERS | EXTRACT_CODE)
                flags &= ~FIND_ALL
            elif s == "a":
                flags = FIND_ALL
            else:
                self.driver.notify_fail(f"Unknown option '{s}'.\n")
                return 0
        if "()" in str_:
            func, thing = str_.split("()", 1)
            func += "()"
            thing = thing.strip()
        else:
            parts = str_.split(" ", 1)
            if len(parts) != 2:
                return 0
            func, thing = parts
        user = self.driver.this_player()
        wiz = self.driver.find_object("/secure/simul_efun/wiz_present")
        obs = wiz.wiz_present(thing, user)
        if not obs:
            self.driver.notify_fail(f"Can't find {thing}.\n")
            return 0
        s = ""
        fnd = []
        for ob in obs:
            list_ = ([ob] + [self.driver.find_object(x) for x in self.driver.deep_inherit_list(ob)]) if flags & FIND_ALL else [ob]
            for k, item in enumerate(list_):
                ping = self.driver.function_exists(func, item, 1)
                if ping and ping not in [x[1] for x in fnd]:
                    s += f"*** {wiz.desc_object(item)}: {func} found in {ping}\n"
                    fnd.append([func, ping])
                elif not (flags & FIND_ALL):
                    s += f"*** {wiz.desc_object(item)}: {func} not found.\n"
                fish = item
                while fish := self.driver.shadow(fish, 0):
                    if self.driver.function_exists(func, fish, 1):
                        s += f"      Shadowed by {self.driver.file_name(fish)}\n"
                        fnd.append([func, self.driver.base_name(fish)])
        if (flags & FIND_ALL) and not fnd:
            s += f"*** {func} not found.\n"
        if (flags & EXTRACT_CODE) and fnd:
            if len(fnd) > 2:
                s += "Can only extract code from one object at a time.\n"
            else:
                ping = f"{fnd[1]}.c"
                func = fnd[0]
                if not self.file_exists(ping):
                    self.driver.notify_fail(f"The file for {thing} doesn't exist.\n")
                    return 0
                tmp = self.driver.read_file(ping)
                if not tmp:
                    self.driver.notify_fail("Could not read file.\n")
                    return 0
                import re
                pattern = [f"\n[a-z_ \t]*[\* ][ \t]*{func[:-2]}[ \t]*\([a-zA-Z0-9, _\*\n\t]*(?:\.\.\.)?[ \t]*\)[ \t\n]*{{", r"\n\}"]
                tokens = [1, 2]
                tmp = self.driver.reg_assoc(tmp, pattern, tokens)
                j = next(i for i, t in enumerate(tmp[1]) if t == 1)
                if flags & LINE_NUMBERS:
                    startline = len("".join(tmp[0][:j + 1]).split("\n"))
                j += 1
                i = tmp[0][j].find("\n")
                while i != -1 and tmp[0][j][i] != "}":
                    i += 1
                if i != -1:
                    tmp_str = tmp[0][j - 1][1:] + tmp[0][j][:i + 1]
                    if flags & LINE_NUMBERS:
                        lines = tmp_str.split("\n")
                        tmp_str = "\n".join(f"{startline + idx} {line}" for idx, line in enumerate(lines))
                    user.more_string(f"{s}{tmp_str}", None, True)
                    return 1
                tmp_str = "".join(tmp[0][j - 1:j + 2])
                if flags & LINE_NUMBERS:
                    lines = tmp_str.split("\n")
                    tmp_str = "\n".join(f"{startline + idx} {line}" for idx, line in enumerate(lines))
                s += tmp_str
        user.more_string(s, None, True)
        return 1