# /lib/secure/cmds/creator/semicolon.py
# Evaluates LPC-like expressions for creators.
# @see /obj/handlers/parser.py

class Semicolon:
    def __init__(self, driver):
        self.driver = driver

    def cmd(self, str_):
        """
        Evaluates an expression string and prints the result.
        @param str_ The expression to evaluate
        @return 1 on success
        """
        parser = self.driver.find_object("/obj/handlers/parser")
        parser.init_expr(str_)
        res = parser.expr()
        self.driver.printf(f"Returns: {res[0] if isinstance(res, list) and len(res) == 1 else res}\n")
        parser.finish_expr()
        return 1