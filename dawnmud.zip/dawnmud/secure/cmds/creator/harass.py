# /lib/secure/cmds/creator/harass.py
# Logs a player's output via snooping.

class Harass:
    def __init__(self, driver):
        self.driver = driver
        self.info = ""
        self.busy = {}

    def create(self):
        """
        Initializes the harass object with Root privileges.
        """
        self.driver.seteuid("Root")

    def receive_snoop(self, bing):
        """
        Appends snooped output to the log.
        @param bing The snooped text
        """
        self.info += bing

    def query_result(self):
        """
        Returns the logged output.
        @return The logged text
        """
        return self.info

    async def remind(self):
        """
        Periodically reminds the player to stop logging.
        """
        tp = self.driver.this_player()
        if tp in self.busy:
            self.driver.write("Type harass again to stop logging.\n")
            await asyncio.sleep(60)
            asyncio.create_task(self.remind())

    def query_patterns(self):
        """
        Returns command patterns.
        @return List of patterns and callbacks
        """
        async def harass_func():
            tp = self.driver.this_player()
            if tp in self.busy:
                result = self.busy[tp].query_result()
                self.driver.unguarded(lambda: self.driver.write_file(
                    f"/d/liaison/secure/harass/{tp.query_name()}{self.driver.time()}",
                    result))
                self.driver.destruct(self.busy[tp])
                del self.busy[tp]
                self.driver.write("Log written.\n")
                return 1
            else:
                self.busy[tp] = self.driver.clone_object(__file__)
                if self.driver.efun_snoop(self.busy[tp], tp):
                    self.driver.write("Started logging.\nType harass again to stop.\n")
                    asyncio.create_task(self.remind())
                    return 1
                else:
                    self.driver.destruct(self.busy[tp])
                    del self.busy[tp]
                    self.driver.write("Failed.\n")
                    return 1
        return ["", harass_func]