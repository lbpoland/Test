# /lib/secure/cmds/creator/banish.py
# Bans player names for authorized creators.
# @see /obj/handlers/player_handler.py
# @see /d/liaison/master.py
# @see /secure/master.py

LIAISON = "/d/liaison/master"

class Banish:
    def __init__(self, driver):
        self.driver = driver

    def cmd(self, str_):
        """
        Bans a player name with a reason.
        @param str_ Format: "<name> <reason>"
        @return 1 on success, 0 on failure
        """
        tp = self.driver.this_player()
        if tp != self.driver.this_player(1) or tp.GetForced():
            return 0
        master_ob = self.driver.get_master()
        liaison_ob = self.driver.find_object(LIAISON)
        if not master_ob.query_senior(self.driver.geteuid(tp)) and not liaison_ob.query_deputy(self.driver.geteuid(tp)):
            self.driver.notify_fail("Only Liaison domain deputies, Senior Creators and above can banish player names.\n")
            return 0
        if not str_ or len(parts := str_.split(" ", 1)) < 2:
            self.driver.notify_fail("Syntax : banish <name> <reason>\n")
            return 0
        name, reason = parts[0].lower(), parts[1]
        if "." in name or "/" in name:
            return 0
        if self.driver.file_size(f"/banish/{name[0]}/{name}.o") >= 0:
            self.driver.notify_fail("That name is already banished.\n")
            return 0
        ph = self.driver.player_handler()
        ph.remove_cache_entry(name)
        if ph.test_user(name):
            self.driver.notify_fail("That is a player. You must rm or mv the player file first.\n")
            return 0
        ban = f"Banished by : {tp.query_name()}\n{self.driver.ctime(self.driver.time())}\nBanish Reason : {reason}\n"
        self.driver.unguarded(lambda: self.driver.write_file(f"/banish/{name[0]}/{name}.o", ban))
        self.driver.write(f"{name} banished.\n")
        return 1

    def query_patterns(self):
        """
        Returns command patterns.
        @return List of patterns and callbacks
        """
        return ["", lambda: self.cmd(None), "<string>", lambda s: self.cmd(s)]