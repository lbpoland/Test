# /home/archaon/mud/lib/secure/login.py
# Translated from /secure/login.c (2003 Discworld MUD library)
# Purpose: Manages player login process with a state machine.
# Last modified in original: Unknown
# @see /home/archaon/mud/lib/secure/simul_efun/autodoc_handler.py for documentation generation integration.

import asyncio
import random
import re
import json
from datetime import datetime
from typing import Any, Dict, List, Optional, Callable

# Constants from login.h, data.h, etc.
RL_NORMAL: int = 4
RL_NONEW: int = 3
RL_PT: int = 2
RL_CRE: int = 1
QUOTE_HANDLER: str = "/home/archaon/mud/obj/handlers/pqf_handler"
MULTIPLAYER: str = "/home/archaon/mud/obj/handlers/multiplayer"
LIVING: str = "/home/archaon/mud/obj/handlers/livings"
CLUB_HANDLER: str = "/home/archaon/mud/obj/handlers/club_handler"
BASTARDS: str = "/home/archaon/mud/lib/secure/bastards"
FILE_PATH: str = "/home/archaon/mud/doc/login"
LOGIN_SCRIPT: str = f"{FILE_PATH}/login_script.txt"
READ_INPUT: int = 1
SLEEP: int = 2
MIN_LEN: int = 3
MAX_LEN: int = 12
ADMIN_EMAIL: str = "trustees@dawnmud.com"  # Updated for Dawn MUD
FREE_DOMAINS: List[str] = ["hotmail.com", "yahoo.com"]
TIMEOUT_TIME: int = 120
THROWOUT_TIME: int = 2 * TIMEOUT_TIME
MIN_RESET_TIME: int = 86400
WITHOUT_LOGINS_NOT_IN_QUEUE: int = 1
UNCOMPRESSED_FULL: int = 2
COMPRESSED_FULL: int = 4

class State:
    """Represents a state in the login state machine."""
    def __init__(self, name: str, action: Optional[str] = None, write: Optional[str] = None, 
                 noecho: bool = False, events: Dict[str, str] = None):
        self.name = name
        self.action = action
        self.write = write
        self.noecho = noecho
        self.events = events or {}

class Login:
    """
    Login object managing the player login process with a state machine.
    """

    def __init__(self, driver: Any) -> None:
        """
        Initializes the login object with driver integration and state machine.
        @param driver The driver instance providing efuns and runtime support.
        """
        self.driver = driver
        self._states: Dict[str, State] = self._load_states()  # From login.o
        self._state: Optional[str] = None
        self._last_state: Optional[str] = None
        self._event: Optional[str] = None
        self._last_event: Optional[str] = None
        self._login_start_time: int = 0
        self._counter: int = 0
        self._data: Dict[str, Any] = {}
        self._run_level: int = RL_NORMAL
        self._terminal_name: Optional[str] = None
        self._rows: int = 0
        self._cols: int = 0
        self.connection_id: Optional[int] = None  # Set by driver on connect
        self.create()

    def create(self) -> None:
        """Sets up initial state and starts timeout."""
        self.driver.seteuid("Root")
        if self.driver.is_interactive(self):
            self.driver.resolve(self.driver.query_ip_number(self), "")
        asyncio.create_task(self._timeout_task())

    def _load_states(self) -> Dict[str, State]:
        """
        Loads the state machine from login.o data.
        @return Dictionary of states with actions and transitions.
        """
        # Hardcoded from login.o for pure Python runtime
        return {
            "check-reconnecting": State("check-reconnecting", "check_reconnecting", events={
                "input": "quit", "input-yes": "reconnect", "input-restart": "restart",
                "input-y": "reconnect", "return-no": "player-login"
            }),
            "check-new-password": State("check-new-password", "check_new_password", events={
                "return-failed": "main-menu", "return-invalid": "get-new-password",
                "return-ok": "reread-password"
            }),
            "get-gender": State("get-gender", write="Are you male or female? ", events={"input": "set-gender"}),
            "check-guest-name": State("check-guest-name", "check_new_name", events={
                "return-failed": "main-menu", "return-invalid": "retry-guest-name",
                "return-ok": "get-capitalization"
            }),
            "password-advice": State("password-advice", write="/home/archaon/mud/doc/login/NEW_USER_PASSWORD", 
                                    noecho=True, events={"input": "check-new-password"}),
            "restart": State("restart", "restart", events={"return": "player-login"}),
            "get-new-password": State("get-new-password", write="Enter password: ", noecho=True, 
                                     events={"input": "check-new-password"}),
            "retry-guest-name": State("retry-guest-name", write="Please try again: ", events={"input": "check-guest-name"}),
            "check-login-access": State("check-login-access", "check_login_access", events={
                "input": "main-menu", "return-ok": "read-password"
            }),
            "new-player-auth": State("new-player-auth", "new_player_auth", events={"input": "main-menu"}),
            "retry-password": State("retry-password", write="Enter your password: ", noecho=True, 
                                   events={"input": "check-password"}),
            "verify-password": State("verify-password", "verify_password", events={
                "return-invalid": "get-new-password", "return-ok": "get-capitalization"
            }),
            "check-email": State("check-email", "check_email", events={
                "return-invalid": "get-valid-email", "return-ok": "new-player-auth"
            }),
            "read-delete-password": State("read-delete-password", write="Enter password: ", noecho=True, 
                                         events={"input": "check-delete-password"}),
            "check-password": State("check-password", "check_password", events={
                "input": "main-menu", "return-failed": "main-menu", "return-ok": "check-queue",
                "return-invalid": "retry-password", "return-new": "get-capitalization"
            }),
            "request-password": State("request-password", "request_password", events={
                "input": "main-menu", "return-invalid": "get-password-name"
            }),
            "check-guest-access": State("check-guest-access", "check_guest_access", events={
                "input": "main-menu", "return-ok": "get-guest-name"
            }),
            "reread-password": State("reread-password", write="Enter password again: ", noecho=True, 
                                    events={"input": "verify-password"}),
            "offer-generated-selection": State("offer-generated-selection", "main_random_name_menu", events={
                "input": "random-lang-choice", "input-m": "main-menu", "input-q": "quit"
            }),
            "get-valid-email": State("get-valid-email", write="Enter your email address: ", 
                                    events={"input": "check-email"}),
            "get-password-name": State("get-password-name", write="Enter your name: ", 
                                      events={"input": "request-password"}),
            "delete-character": State("delete-character", "delete_character", events={"default": "main-menu"}),
            "read-password": State("read-password", "reset_counter", write="/home/archaon/mud/doc/login/WELCOME", 
                                  noecho=True, events={"input": "check-password"}),
            "recheck-new-access": State("recheck-new-access", "check_new_access", events={
                "return-auth": "get-valid-email", "return-ok": "password-advice"
            }),
            "delete-menu": State("delete-menu", write="/home/archaon/mud/doc/login/DELETE", 
                                events={"input": "check-delete-name"}),
            "check-new-name": State("check-new-name", "check_new_name", events={
                "return-generated": "display-generated", "return-failed": "main-menu",
                "return-invalid": "retry-new-name", "return-ok": "confirm-new-name"
            }),
            "confirm-new-name": State("confirm-new-name", write="You have chosen the name [$name], is this correct [y/n]? ", 
                                     events={"input": "new-character-menu", "input-y": "recheck-new-access"}),
            "check-delete-name": State("check-delete-name", "check_delete_name", events={
                "input": "main-menu", "return-ok": "read-delete-password"
            }),
            "retry-delete-password": State("retry-delete-password", write="Enter password: ", noecho=True, 
                                          events={"input": "check-delete-password"}),
            "new-player-login": State("new-player-login", "new_player_login", events={
                "return-error": "main-menu", "default": "finished"
            }),
            "agree-terms": State("agree-terms", events={
                "input": "terms-error", "input-yes": "new-player-login", "input-no": "quit"
            }),
            "list-players": State("list-players", "list_players", events={"input": "main-menu"}),
            "main-menu": State("main-menu", "main_menu", events={
                "return-quit": "quit", "input": "check-login-access", "input-r": "get-password-name",
                "input-f": "finger-player", "input-d": "delete-menu", "input-c": "get-input-name",
                "input-u": "list-players", "input-g": "check-guest-access", "input-m": "main-menu",
                "input-n": "check-new-access", "input-q": "quit"
            }),
            "quit": State("quit", "quit", events={"default": "quit"}),
            "retry-new-name": State("retry-new-name", write="Please try again: ", events={"input": "check-new-name"}),
            "player-login": State("player-login", "player_login", events={
                "return-error": "quit", "default": "finished"
            }),
            "exit-queue": State("exit-queue", "exit_queue", events={
                "return-reconnect": "check-reconnecting", "return-login": "player-login"
            }),
            "get-input-name": State("get-input-name", write="Enter your name: ", events={"input": "check-login-access"}),
            "display-finger": State("display-finger", "finger_player", events={"input": "main-menu"}),
            "check-random-name": State("check-random-name", "check_random_name", events={
                "return-invalid": "offer-generated-selection", "return-ok": "confirm-new-name"
            }),
            "terms-and-conditions": State("terms-and-conditions", "display_terms", events={"return": "terms-wait"}),
            "finger-player": State("finger-player", write="Whom do you wish to finger? ", events={"input": "display-finger"}),
            "queue-wait": State("queue-wait", events={"input": "queue-wait", "input-quit": "quit", "input-q": "quit"}),
            "terms-error": State("terms-error", write="You must enter 'yes' or 'no': ", events={
                "input": "terms-error", "input-yes": "new-player-login", "input-no": "quit"
            }),
            "show-random-names": State("show-random-names", "show_random_names", events={
                "input": "check-random-name", "input-g": "offer-generated-selection", "input-m": "main-menu",
                "input-n": "new-character-menu", "input-q": "quit"
            }),
            "add-to-queue": State("add-to-queue", "add_to_queue", events={"return-ok": "queue-wait", "default": "quit"}),
            "check-delete-password": State("check-delete-password", "check_delete_password", events={
                "input": "main-menu", "return-failed": "main-menu", "return-invalid": "retry-delete-password",
                "return-ok": "delete-character"
            }),
            "random-lang-choice": State("random-lang-choice", "random_lang_choice", events={
                "return": "show-random-names", "return-invalid": "offer-generated-selection"
            }),
            "check-capitalization": State("check-capitalization", "check_capitalization", events={
                "return-invalid": "get-capitalization", "return-ok": "get-gender"
            }),
            "reconnect": State("reconnect", "reconnect", events={"return": "finished", "return-login": "player-login"}),
            "terms-wait": State("terms-wait", events={"input-quit": "quit", "default": "terms-wait", "input-q": "quit"}),
            "check-queue": State("check-queue", "check_full", events={
                "return-ok": "check-reconnecting", "return-full": "add-to-queue"
            }),
            "get-capitalization": State("get-capitalization", "get_capitalization", events={
                "input": "check-capitalization", "input-y": "get-gender"
            }),
            "new-character-menu": State("new-character-menu", "reset_counter", 
                                       write="/home/archaon/mud/doc/login/NEW_USER_NAME", 
                                       events={"input": "check-new-name", "input-g": "offer-generated-selection"}),
            "get-guest-name": State("get-guest-name", "reset_counter", write="/home/archaon/mud/doc/login/GUEST_LOGIN", 
                                   events={"input": "check-guest-name"}),
            "leaving-queue": State("leaving-queue", events={"input": "exit-queue"}),
            "set-gender": State("set-gender", "set_gender", events={
                "return-invalid": "get-gender", "return-ok": "terms-and-conditions"
            }),
            "check-new-access": State("check-new-access", "check_new_access", events={
                "return-auth": "new-character-menu", "input": "main-menu", "return-ok": "new-character-menu"
            })
        }

    async def process_event(self, event: str, type_: str) -> None:
        """
        Processes login events based on the state machine.
        @param event The event input (e.g., user input).
        @param type_ The event type (e.g., "input", "return").
        """
        event_key = f"{type_}-{event.lower()}"
        self.debug_log(f"Processing event: state={self._state}, event={event_key}")
        self._last_event = self._event
        self._event = event_key
        state = self._states.get(self._state, State("unknown"))
        if event_key in state.events:
            await self.enter_state(state.events[event_key])
        elif type_ in state.events:
            await self.enter_state(state.events[type_])
        elif "default" in state.events:
            await self.enter_state(state.events["default"])
        else:
            self.debug_log(f"No event {event_key} in state {self._state}: {list(state.events.keys())}")

    async def enter_state(self, new_state: str) -> None:
        """
        Enters a new state in the login process.
        @param new_state The state to enter.
        """
        self._last_state = self._state
        self._state = new_state
        self.debug_log(f"Entering state: {new_state}")
        if new_state == "finished":
            return
        if new_state not in self._states:
            self.debug_log(f"Invalid state {new_state}; exiting")
            self.dest_me()
            return
        state = self._states[self._state]

        if state.write:
            tmp = self.driver.read_file(state.write) if self.driver.file_size(state.write) > 0 else state.write
            for field, value in self._data.items():
                if isinstance(value, str):
                    tmp = tmp.replace(f"${field}", value)
            if tmp.endswith("\n"):
                tmp = tmp[:-1]
            self.driver.write(f"{tmp}\n")

        if state.action:
            method = getattr(self, state.action, None)
            if method:
                retval = await method(self._event) if asyncio.iscoroutinefunction(method) else method(self._event)
            else:
                self.debug_log(f"Action {state.action} not found")
                retval = READ_INPUT
        else:
            retval = READ_INPUT

        if isinstance(retval, int) and retval == READ_INPUT:
            self.debug_log(f"Reading input for state {new_state}")
            self.driver.input_to(lambda e: asyncio.create_task(self.process_event(e, "input")), state.noecho)
            return

        self.debug_log(f"Action returned: {retval}")
        if new_state == "check-login-access":
            await self.process_event(retval, "return")
        else:
            asyncio.create_task(self.process_event(retval, "return"))

    def debug_log(self, fmt: str, *args) -> None:
        """Logs debug messages."""
        log_entry = f"{datetime.now().strftime('%b %d %H:%M:%S')}: {fmt % args}"
        self.driver.log_file("/home/archaon/mud/log/NLOGIN", f"{log_entry}\n")

    def query_state(self) -> Optional[str]:
        """Returns the current state."""
        return self._state

    def check_valid_name(self, str_: str) -> int:
        """Checks if a name contains only lowercase letters."""
        for i, char in enumerate(str_):
            if char < 'a' or char > 'z':
                return i
        return -1

    def check_name(self, name: str, new_char: bool) -> bool:
        """Validates a player name."""
        if len(name) < MIN_LEN:
            self.driver.write(f"Sorry, the player name {name} is too short (min {MIN_LEN} characters).\n")
            return False
        if len(name) > MAX_LEN:
            self.driver.write(f"Sorry, the player name {name} is too long (max {MAX_LEN} characters).\n")
            return False
        if self.check_valid_name(name) != -1:
            self.driver.write("Invalid characters used in the name. Only letters a-z are allowed.\n")
            return False
        ph = self.driver.player_handler()
        if ph.test_banished(name):
            self.driver.write(f"\nSorry, the player name {name} has been banished.\n")
            return False
        if not ph.test_valid(name) or hasattr(self.driver, "mail_track") and self.driver.mail_track().query_list(name):
            self.driver.write("Sorry, that name is not allowed.\n")
            return False
        if new_char and (ph.test_user(name) or self.driver.living_handler().find_player(name)):
            self.driver.write("Sorry, that name has already been taken.\n")
            return False
        if new_char and self.driver.club_handler().is_club(name):
            self.driver.write("Sorry, that name is already in use for a club or family.\n")
            return False
        return True

    def generate_password(self) -> str:
        """Generates a random 8-character password."""
        pass_ = ""
        for _ in range(8):
            choice = random.randint(0, 2)
            if choice == 2:
                pass_ += chr(65 + random.randint(0, 25))  # A-Z
            elif choice == 1:
                pass_ += chr(97 + random.randint(0, 25))  # a-z
            else:
                pass_ += chr(48 + random.randint(0, 9))   # 0-9
        replacements = {"0": "9", "o": "p", "O": "P", "1": "2", "i": "j", "I": "J", "l": "m"}
        for old, new in replacements.items():
            pass_ = pass_.replace(old, new)
        return pass_

    def main_menu(self, event: str) -> str:
        """Displays the main login menu."""
        self._data = {}
        self._counter = 0
        self.driver.write(self.driver.read_file(f"{FILE_PATH}/BANNER") or "Welcome to Dawn MUD!\n")
        ip = self.driver.query_ip_number(self)
        lh = self.driver.login_handler()
        if lh.site_lockeddown(ip):
            self.driver.write(f"Sorry, your site has been locked down for excessive failed login attempts. "
                              f"Email {ADMIN_EMAIL} if you’ve forgotten your password.\n")
            mess = f"Attempted login from locked down site: {ip}"
            self.driver.log_file("/home/archaon/mud/log/BAD_PASSWORD", 
                                 f"{datetime.now().strftime('%b %d %H:%M:%S')}: {mess}\n")
            self.driver.event(self.driver.users(), "inform", mess, "bad-password")
            return "quit"
        
        shut_ob = self.driver.find_object("/home/archaon/mud/obj/shut")
        if shut_ob and hasattr(shut_ob, "query_time_to_crash"):
            time_to_crash = shut_ob.query_time_to_crash()
            if time_to_crash < 60:
                self.driver.write("Less than one minute to shutdown; try again soon.\n")
                return "quit"
            self.driver.write("Too close to shutdown for non-creators; try again later.\n")
        
        self.driver.write(self.driver.read_file(f"{FILE_PATH}/MAIN_MENU") or 
                          "Options: [n]ew, [c]ontinue, [q]uit\n")
        return READ_INPUT

    def check_delete_name(self, event: str) -> str:
        """Checks if a name is valid for deletion."""
        self._data["name"] = event.replace("input-", "").lower()
        ph = self.driver.player_handler()
        if not ph.test_user(self._data["name"]):
            self.driver.write("There is no such player.\n\nPress enter to continue ")
            return READ_INPUT
        if ph.test_creator(self._data["name"]):
            self.driver.write("Creators cannot be deleted this way.\n\nPress enter to continue ")
            return READ_INPUT
        delete_file = ph.query_delete_player_file_name(self._data["name"])
        if self.driver.file_size(f"{delete_file}.o") > 0 or self.driver.file_size(f"{delete_file}.o.gz") > 0:
            self.driver.write("That character is already marked for deletion.\n\nPress enter to continue ")
            return READ_INPUT
        return "ok"

    def check_delete_password(self, event: str) -> str:
        """Verifies password for character deletion."""
        self._data["password"] = event.replace("input-", "")
        ph = self.driver.player_handler()
        if not ph.test_password(self._data["name"], self._data["password"]):
            self.driver.write("\nPassword incorrect.\n")
            return "invalid"
        self.driver.write("This will PERMANENTLY delete your character, are you sure? [y/n] ")
        return READ_INPUT

    def delete_character(self, event: str) -> str:
        """Deletes a character."""
        ph = self.driver.player_handler()
        if ph.test_creator(self._data["name"]):
            self.driver.write("Creators cannot be deleted this way.\n\nPress enter to continue ")
            return READ_INPUT
        file_name = ph.query_player_file_name(self._data["name"])
        delete_file_name = ph.query_delete_player_file_name(self._data["name"])
        extension = ".o" if self.driver.file_size(f"{file_name}.o") != -1 else ".o.gz"
        
        if self.driver.unguarded(lambda: self.driver.cp(f"{file_name}{extension}", f"{delete_file_name}{extension}")):
            self.driver.unguarded(lambda: self.driver.rm(f"{file_name}{extension}"))
            self.driver.unguarded(lambda: self.driver.rm(f"{ph.query_player_disk_file_name(self._data['name'])}{extension}"))
            self.driver.write("\n\nPLEASE READ:\nCharacter deleted. You have 10 days "
                              "cooling off time to reinstate by logging in again.\n\n")
        else:
            self.driver.write("WARNING! Unable to delete your character.\n\n")
        self.driver.write("Press enter to continue ")
        return READ_INPUT

    def check_new_access(self, event: str) -> str:
        """Checks access for new player creation."""
        self._data["new_player"] = 1
        if self._run_level != RL_NORMAL:
            self.driver.write("Sorry, this site is not open to new players.\n\nPress enter to continue ")
            return READ_INPUT
        if self.driver.find_object("/home/archaon/mud/obj/shut"):
            self.driver.write("Too close to shutdown to create a new character.\n\nPress enter to continue ")
            return READ_INPUT
        
        bastards = self.driver.find_object(BASTARDS)
        access = bastards.query_access(self) if bastards else "DEFAULT"
        if access in ["NO_NEW", "NO_ACCESS"]:
            self.driver.write(f"\nNew player logins are disabled from this site. Email {ADMIN_EMAIL} "
                              "with your desired name, existing characters, and ISP.\n\nPress enter to continue ")
            return READ_INPUT
        elif access == "AUTH_NEW":
            self.driver.write("\nNew player logins require email authorization. Provide an email "
                              "(no free accounts like hotmail).\n\n")
            return "auth"
        
        if not bastards.query_multi(self):
            tmp = [u for u in self.driver.users() if self.driver.is_interactive(u) and
                   not u.query_creator() and not u.query_property("test character") and
                   self.driver.query_ip_number(u) == self.driver.query_ip_number(self) and u != self]
            multi_ob = self.driver.find_object(MULTIPLAYER)
            if multi_ob and multi_ob.check_allowed(self, tmp):
                self.driver.write(self.driver.read_file(f"{FILE_PATH}/MULTIPLAYERS") or 
                                  "Multiple logins not allowed.\n\nPress enter to continue ")
                return READ_INPUT
        return "ok"

    def check_guest_access(self, event: str) -> str:
        """Checks access for guest login."""
        self._data["guest"] = 1
        self._data["new_player"] = 1
        if self._run_level != RL_NORMAL:
            self.driver.write("Sorry, this site is not open to guests.\n\nPress enter to continue ")
            return READ_INPUT
        if self.driver.find_object("/home/archaon/mud/obj/shut"):
            self.driver.write("Too close to shutdown for guest login.\n\nPress enter to continue ")
            return READ_INPUT
        bastards = self.driver.find_object(BASTARDS)
        if bastards and bastards.query_access(self) != "DEFAULT":
            self.driver.write("\nGuest logins are disabled from this site.\n\nPress enter to continue ")
            return READ_INPUT
        return "ok"

    def finger_player(self, event: str) -> str:
        """Displays finger info for a player."""
        player = event.replace("input-", "").lower()
        if player and len(player) > 2 and self.check_valid_name(player) == -1:
            finger_ob = self.driver.find_object("/home/archaon/mud/lib/secure/finger")
            finger_info = finger_ob.finger_info(player, True) if finger_ob else None
            self.driver.write((self.driver.strip_colours(finger_info) if finger_info else 
                               "Sorry, no such player.") + "\n\n")
        else:
            self.driver.write("Invalid name, returning to login menu.\n\n")
        self.driver.write("Press enter to continue ")
        return READ_INPUT

    def list_players(self, event: str) -> str:
        """Lists currently online players."""
        users = [u.query_cap_name() for u in self.driver.users() if u.query_cap_name() and
                 not u.query_invis() and u.query_name() != "logon"]
        self.driver.write("Current players on Dawn MUD:\n" + ", ".join(sorted(users)) + 
                          "\n\nPress enter to continue ")
        return READ_INPUT

    def reset_counter(self, event: str) -> str:
        """Resets the retry counter."""
        self._counter = 0
        return READ_INPUT

    def check_email(self, event: str) -> str:
        """Validates an email address."""
        address = event.replace("input-", "")
        if not re.match(r"^[a-zA-Z0-9+\._-]+@[a-zA-Z0-9\._-]+\.[a-zA-Z0-9\._-]", address):
            self.driver.write("Sorry, that address is invalid. Try again or enter 'q' to quit.\n")
            return "invalid"
        _, domain = address.split("@", 1)
        if domain in FREE_DOMAINS:
            self.driver.write(f"Sorry, {domain} is a free account and not allowed. Try again or email {ADMIN_EMAIL}.\n")
            return "invalid"
        self._data["email"] = address
        return "ok"

    def check_new_name(self, event: str) -> str:
        """Checks a new player name."""
        self._data["name"] = event.replace("input-", "").lower()
        if not self._data["name"] or self._data["name"] in ["", "q"]:
            return "failed"
        self._counter += 1
        if self.check_name(self._data["name"], True):
            self._data["cap_name"] = self._data["name"].capitalize()
            return "ok"
        elif self._counter < 3:
            return "invalid"
        return "failed"

    def check_random_name(self, event: str) -> str:
        """Checks a randomly selected name."""
        tmp = event.replace("input-", "")
        names = self._data.get("random_names", [])
        if not tmp or not tmp[0].isdigit() or int(tmp[0]) - 1 >= len(names):
            return "invalid"
        self._data["name"] = names[int(tmp[0]) - 1].lower()
        return "ok" if self.check_name(self._data["name"], True) else "invalid"

    def main_random_name_menu(self, event: str) -> str:
        """Displays the random name menu."""
        rand_gen = self.driver.random_name_generator()
        langs = rand_gen.query_languages() if rand_gen else ["english"]
        options = [f"{chr(i + ord('1'))} - {lang.capitalize()} (e.g., {rand_gen.unique_name(lang) if rand_gen else 'Example'})"
                   for i, lang in enumerate(langs)]
        self.driver.write("Choose a name style:\n" + "\n".join(options) + 
                          "\nM - Main Menu\nQ - Quit\n\nYour choice? ")
        return READ_INPUT

    def random_lang_choice(self, event: str) -> str:
        """Processes random language choice."""
        choice = event.replace("input-", "")
        rand_gen = self.driver.random_name_generator()
        langs = rand_gen.query_languages() if rand_gen else ["english"]
        if len(choice) == 1 and choice.isdigit() and 1 <= int(choice) <= len(langs):
            return langs[int(choice) - 1]
        self.driver.write("Incorrect choice.\n")
        return "invalid"

    def show_random_names(self, event: str) -> str:
        """Displays a list of random names."""
        lang = event.replace("return-", "")
        rand_gen = self.driver.random_name_generator()
        self._data["random_names"] = [rand_gen.unique_name(lang) if rand_gen else f"Name{i}" for i in range(9)]
        names_list = "\n".join(f"{chr(i + ord('1'))} - {name}" for i, name in enumerate(self._data["random_names"]))
        self.driver.write(f"Choose a name:\n{names_list}\nM - Main Menu\nN - Name Menu\nG - New Names\nQ - Quit\n"
                          "Or type your own name\n\nYour choice? ")
        return READ_INPUT

    def check_new_password(self, event: str) -> str:
        """Validates a new password."""
        self._data["password"] = event.replace("input-", "")
        self.driver.write("\n")
        if not self._data["password"]:
            return "failed"
        if len(self._data["password"]) < 6:
            self.driver.write("Password too short (min 6 characters).\n")
            return "invalid"
        if self._data["password"] == self._data["name"]:
            self.driver.write("Password cannot match your name.\n")
            return "invalid"
        return "ok"

    def verify_password(self, event: str) -> str:
        """Verifies password confirmation."""
        tmp = event.replace("input-", "")
        self.driver.write("\n")
        if tmp == self._data["password"]:
            return "ok"
        self.driver.write("Passwords do not match.\n")
        return "invalid"

    def get_capitalization(self, event: str) -> str:
        """Requests name capitalization preference."""
        if "cap_name" not in self._data:
            self._data["cap_name"] = self._data["name"].capitalize()
        self.driver.write(f"\nHow would you like your name capitalized? [{self._data['cap_name']}] ")
        return READ_INPUT

    def check_capitalization(self, event: str) -> str:
        """Checks capitalization input."""
        tmp = event.replace("input-", "")
        if not tmp:
            return "ok"
        if tmp.lower() != self._data["name"]:
            self.driver.write("Sorry, it must match your name.\n")
            return "invalid"
        self._data["cap_name"] = tmp
        return "ok"

    def request_password(self, event: str) -> str:
        """Requests a temporary password reset."""
        name = event.replace("input-", "").lower()
        ph = self.driver.player_handler()
        bastards = self.driver.find_object(BASTARDS)
        if not ph.test_user(name):
            self.driver.write("No such player.\n\nPress enter to continue ")
            return READ_INPUT
        if ph.test_creator(name):
            self.driver.write(f"Creator passwords cannot be reset this way; email {ADMIN_EMAIL}.\n\nPress enter to continue ")
            return READ_INPUT
        if not ph.test_ip_allowed(name, self.driver.query_ip_number(self)):
            self.driver.write("Cannot reset password from your IP.\n\nPress enter to continue ")
            return READ_INPUT
        email = ph.test_email(name).lstrip()[1:] if ph.test_email(name).startswith(":") else ph.test_email(name).lstrip()
        if not email or not re.match(r"^[A-Za-z0-9_+\.]+@[A-Za-z0-9_]+\.[A-Za-z0-9_\.]+$", email):
            self.driver.write("No valid email address set.\n\nPress enter to continue ")
            return READ_INPUT
        tmp = bastards.query_temp_password(name) if bastards else None
        if tmp and tmp[0] > self.driver.time() - MIN_RESET_TIME:
            self.driver.write(f"Password reset within last {MIN_RESET_TIME // 3600} hours; try later.\n\nPress enter to continue ")
            return READ_INPUT
        pass_ = self.generate_password()
        if bastards:
            bastards.set_temp_password(name, self.driver.crypt(pass_, 0))
        mailer = self.driver.mailer()
        if mailer:
            mailer.do_mail_message(
                email, "admin", "Your temporary password", 0,
                f"The temporary password for {name} is {pass_}\n\nUse within 7 days; set a new password with 'password' command.\n"
            )
        mess = f"Password requested for {name} from {self.driver.query_ip_number(self)}"
        self.driver.log_file("/home/archaon/mud/log/BAD_PASSWORD", 
                             f"{datetime.now().strftime('%b %d %H:%M:%S')}: {mess}\n")
        self.driver.event(self.driver.users(), "inform", mess, "bad-password")
        self.driver.write("An email with a temporary password is on its way.\n\nPress enter to continue ")
        return READ_INPUT

    async def check_login_access(self, event: str) -> str:
        """Checks login access conditions."""
        if event.startswith("input-"):
            self._data["name"] = event.replace("input-", "").lower()
        name = self._data["name"]
        if name.startswith("-"):
            self._data["name"] = name[1:]
            self._data["go_invis"] = -1
        elif name.startswith(":"):
            self._data["name"] = name[1:]
            self._data["go_invis"] = 1
        elif name.startswith("#"):
            self._data["name"] = name[1:]
            self._data["go_invis"] = 2
        name = self._data["name"]
        ph = self.driver.player_handler()
        lh = self.driver.login_handler()
        living = self.driver.living_handler()
        bastards = self.driver.find_object(BASTARDS)
        
        if self._run_level == RL_CRE and not (ph.test_creator(name) or ph.test_property(name, "test character")):
            self.driver.write("Site open to creators only.\n\nPress enter to continue ")
            return READ_INPUT
        elif self._run_level == RL_PT and not (ph.test_creator(name) or ph.test_property(name, "test character") or
                                               self.driver.playtester_handler().query_playtester(name)):
            self.driver.write("Site open to creators and playtesters only.\n\nPress enter to continue ")
            return READ_INPUT
        
        if self.driver.find_object("/home/archaon/mud/obj/shut") and not ph.test_creator(name) and not living.find_player(name):
            self.driver.write("Too close to shutdown to login.\n\nPress enter to continue ")
            return READ_INPUT
        
        if not ph.test_user(name):
            self.driver.write("No player by that name.\n\nPress enter to continue ")
            return READ_INPUT
        
        if not ph.test_ip_allowed(name, self.driver.query_ip_number(self)):
            self.driver.write("Your IP is not permitted for this character.\n\nPress enter to continue ")
            return READ_INPUT
        
        if ph.test_appealing(name):
            self.driver.write(f"Character marked for deletion pending appeal. Contact {ADMIN_EMAIL}.\n\nPress enter to continue ")
            return READ_INPUT
        
        if ph.test_creator(name) or ph.test_property(name, "test character"):
            return "ok"
        
        tmp = bastards.query_lockedout(name) if bastards else None
        if tmp:
            self.driver.write(f"Locked out until {datetime.fromtimestamp(tmp[0]).ctime()} for {tmp[1]}.\n\nPress enter to continue ")
            return READ_INPUT
        
        alt_of = self.driver.playerinfo_handler().query_alt_of(name) if hasattr(self.driver, "playerinfo_handler") else None
        alts = (self.driver.playerinfo_handler().query_alts(alt_of) + [alt_of]) if alt_of else \
                self.driver.playerinfo_handler().query_alts(name) if hasattr(self.driver, "playerinfo_handler") else []
        alts = [a for a in alts if a != name]
        if alts and any(living.find_player(a) for a in alts):
            self.driver.write("Cannot login while an alt is active.\n\nPress enter to continue ")
            return READ_INPUT
        
        tmp = bastards.query_suspended(name) if bastards else None
        if tmp:
            self.driver.write(f"Suspended until {datetime.fromtimestamp(tmp[0]).ctime()}; enter password to see why.\n")
        
        if ph.test_property(name, "authorised player"):
            return "ok"
        
        access = bastards.query_access(self) if bastards else "DEFAULT"
        if access == "NO_ACCESS":
            self.driver.write("Player logins disabled from this site.\n\nPress enter to continue ")
            return READ_INPUT
        elif access in ["NO_NEW", "AUTH_NEW"] and ph.test_age(name) > -(2 * 24 * 60 * 60):
            self.driver.write("New player logins disabled and character too young.\n\nPress enter to continue ")
            return READ_INPUT
        elif access == "ERROR":
            self.driver.write("Invalid site permissions; contact a creator.\n\nPress enter to continue ")
            return READ_INPUT
        
        if not bastards.query_multi(self):
            tmp = [u for u in self.driver.users() if self.driver.is_interactive(u) and
                   not u.query_creator() and not u.query_property("test character") and
                   u.query_name() not in ["logon", name] and
                   self.driver.query_ip_number(u) == self.driver.query_ip_number(self) and u != self]
            multi_ob = self.driver.find_object(MULTIPLAYER)
            if multi_ob and multi_ob.check_allowed(self, tmp):
                self.driver.write("Multiple logins not allowed from this site.\n\nPress enter to continue ")
                return READ_INPUT
        
        return "ok"

    def check_password(self, event: str) -> str:
        """Verifies login password."""
        self._data["password"] = event.replace("input-", "")
        self._counter += 1
        if not self._data["password"]:
            return "failed"
        ph = self.driver.player_handler()
        bastards = self.driver.find_object(BASTARDS)
        lh = self.driver.login_handler()
        if not ph.test_password(self._data["name"], self._data["password"]):
            tmp = bastards.query_temp_password(self._data["name"]) if bastards else None
            if not tmp or self.driver.crypt(self._data["password"], tmp[1]) != tmp[1]:
                if self._counter < 3:
                    self.driver.write("\nPassword incorrect.\n")
                    return "invalid"
                lh.failed_login(self.driver.query_ip_number(self))
                self.driver.write("\nToo many retries.\n\nPress enter to continue ")
                mess = f"{self._data['name'].capitalize()} failed login from " + \
                       (f"{self.driver.query_ip_name(self)} ({self.driver.query_ip_number(self)})" if
                        self.driver.query_ip_name(self) != self.driver.query_ip_number(self) else
                        self.driver.query_ip_number(self))
                self.driver.event(self.driver.users(), "inform", mess, "bad-password")
                self.driver.log_file("/home/archaon/mud/log/BAD_PASSWORD", 
                                     f"{datetime.now().strftime('%b %d %H:%M:%S')}: {mess}\n")
                return READ_INPUT
            reset_ob = self.driver.find_object("/home/archaon/mud/cmds/lord/resetpw")
            if reset_ob and hasattr(reset_ob, "do_reset"):
                reset_ob.do_reset(self._data["name"], self._data["password"])
            self.driver.write("\n\nTemporary password used! Set a new password with 'password'.\n\n")
        
        if bastards:
            bastards.clear_temp_password(self._data["name"])
        tmp = bastards.query_suspended(self._data["name"]) if bastards else None
        if tmp:
            self.driver.write(f"\nSorry, suspended until {datetime.fromtimestamp(tmp[0]).ctime()} for {tmp[1]}.\n\nPress enter to continue ")
            return READ_INPUT
        
        self._data["password-check"] = "ok"
        if not ph.test_gender(self._data["name"]) and ph.test_property(self._data["name"], "new player"):
            return "new"
        return "ok"

    def set_gender(self, event: str) -> str:
        """Sets player gender."""
        tmp = event.replace("input-", "").lower()
        if tmp == "m":
            tmp = "male"
        elif tmp == "f":
            tmp = "female"
        if tmp in ["male", "female"]:
            self._data["gender"] = tmp
            return "ok"
        self.driver.write("Please choose male or female.\n")
        return "invalid"

    async def check_reconnecting(self, event: str) -> str:
        """Checks if player is already connected."""
        if self._data.get("password-check") != "ok":
            self.driver.write("Error\n")
            self.dest_me()
            return "quit"
        living = self.driver.living_handler()
        pl = living.find_player(self._data["name"])
        if pl:
            self.driver.write("You are already playing.\nThrow out the other copy? (y/n/restart) ")
            return READ_INPUT
        return "no"

    async def restart(self, event: str) -> str:
        """Restarts a player session."""
        living = self.driver.living_handler()
        pl = living.find_player(self._data["name"])
        if not pl:
            self.driver.write("Other copy no longer exists; logging in normally.\n")
            return "ok"
        self.driver.tell_object(pl, f"Disconnected by someone from {self.driver.query_ip_name(self)}.\n")
        try:
            await pl.quit()
        except:
            try:
                pl.dest_me()
            except:
                self.driver.destruct(pl)
        if pl:
            self.driver.destruct(pl)
        return "ok"

    async def reconnect(self, event: str) -> str:
        """Reconnects to an existing player session."""
        living = self.driver.living_handler()
        pl = living.find_player(self._data["name"])
        if not pl:
            self.driver.write("Other copy gone; logging in normally.\n")
            return "login"
        if self.driver.is_interactive(pl):
            self.driver.tell_object(pl, f"Disconnected by someone from {self.driver.query_ip_name(self)}.\n")
            ob = self.driver.clone_object("/home/archaon/mud/std/object")
            self.driver.exec(ob, pl)
            ob.dest_me()
        self.driver.exec(pl, self)
        pl.look_me()
        lh = self.driver.login_handler()
        lh.player_reconnected(pl.query_name())
        self.driver.tell_room(self.driver.environment(pl), f"{pl.query_cap_name()} has reconnected.\n", [pl])
        if hasattr(pl, "inform_reconnect_game"):
            pl.inform_reconnect_game()
        if self.driver.query_ip_number(pl) == self.driver.query_ip_name(pl):
            self.driver.resolve(self.driver.query_ip_number(pl), "")
        return "ok"

    def check_full(self, event: str) -> str:
        """Checks if the game is full."""
        ph = self.driver.player_handler()
        lh = self.driver.login_handler()
        if ph.test_creator(self._data["name"]) or ph.test_property(self._data["name"], "test character"):

    def check_full(self, event: str) -> str:
        """Checks if the game is full."""
        ph = self.driver.player_handler()
        lh = self.driver.login_handler()
        if ph.test_creator(self._data["name"]) or ph.test_property(self._data["name"], "test character"):
            return "ok"
        ret = lh.int_is_discworld_full(WITHOUT_LOGINS_NOT_IN_QUEUE)
        if (ret & UNCOMPRESSED_FULL) and ((ret & COMPRESSED_FULL) or not self.driver.compressedp(self)):
            self.driver.write("Sorry, no player slots available.\n\n")
            return "full"
        return "ok"

    async def add_to_queue(self, event: str) -> str:
        """Adds player to login queue."""
        lh = self.driver.login_handler()
        queue = [ob.query_name() for ob in lh.query_login_queue()]
        if self._data["name"] in queue:
            self.driver.write("You are already in the login queue.\n")
            obs = [ob for ob in lh.query_login_queue() if ob.query_name() == self._data["name"]]
            pl = obs[0] if obs else None
            if pl and pl.query_login_ob():
                self.driver.write("Reconnecting you to the login queue.\n")
                if self.driver.is_interactive(pl):
                    self.driver.tell_object(pl, f"Disconnected by someone from {self.driver.query_ip_name(self)}.\n")
                    ob = self.driver.clone_object("/home/archaon/mud/std/object")
                    self.driver.exec(ob, pl)
                    ob.dest_me()
                self.driver.exec(pl, self)
                return "ok"
        
        lh.add_to_login_queue(self)
        living = self.driver.living_handler()
        pl = living.find_player(self._data["name"])
        if pl:
            self.driver.write("You were net-dead; moving to queue start.\n")
        else:
            self.driver.write(f"Placed in login queue at position {len(lh.query_login_queue())}.\n"
                              "Please wait. Type 'quit' to escape.\n")
        for task in asyncio.all_tasks():
            if task.get_name() == "timeout_task":
                task.cancel()
        asyncio.create_task(self.check_status())
        return "ok"

    def display_terms(self, event: str) -> str:
        """Displays terms and conditions."""
        terms_text = self.driver.read_file(f"{FILE_PATH}/TERMS") or "Terms of Service: [Placeholder]\n"
        self.driver.write(terms_text)
        asyncio.create_task(self._terms_delayed())
        return "ok"

    async def _terms_delayed(self) -> None:
        """Prompts for terms agreement after a delay."""
        await asyncio.sleep(30)
        self._counter = 0
        self.driver.write("\nEnter 'yes' to agree or 'no' to decline terms.\n"
                          "By typing 'yes', you agree to these terms: [yes/no] ")
        await self.enter_state("agree-terms")

    def check_terms(self, event: str) -> str:
        """Checks terms agreement response."""
        if event == "input-yes":
            return "yes"
        if event == "input-no" or self._counter > 3:
            return "no"
        self._counter += 1
        return "error"

    def new_player_auth(self, event: str) -> str:
        """Authorizes a new player via email."""
        bastards = self.driver.find_object(BASTARDS)
        try:
            pl = self.driver.clone_object(bastards.query_player_ob(self._data["name"]))
        except Exception as e:
            self.driver.write(f"Error creating player object: {str(e)}\n\nPress enter to continue ")
            return READ_INPUT
        if not pl:
            self.driver.write("Failed to create player object.\n\nPress enter to continue ")
            return READ_INPUT
        pl.set_name(self._data["name"])
        pass_ = self.generate_password()
        pl.set_password(self.driver.crypt(pass_, 0))
        pl.set_email(self._data["email"])
        pl.add_property("authorised player", True)
        pl.add_property("new player", True)
        pl.add_property("authorised email", self._data["email"])
        pl.allow_save()
        pl.save_me()
        pl.dest_me()
        mailer = self.driver.mailer()
        if mailer:
            mailer.do_mail_message(
                self._data["email"], "admin", "Your password", 0,
                f"The password for {self._data['name']} is {pass_}\n\n"
            )
        self.driver.write("Email with password sent.\n\nPress enter to continue ")
        return READ_INPUT

    async def new_player_login(self, event: str) -> str:
        """Logs in a new player."""
        bastards = self.driver.find_object(BASTARDS)
        try:
            pl = self.driver.clone_object(bastards.query_player_ob(self._data["name"]))
        except Exception as e:
            self.driver.write(f"Error cloning player object: {str(e)}\n")
            return "error"
        if not pl:
            self.driver.write("Player object creation failed.\n")
            return "error"
        ph = self.driver.player_handler()
        if ph.test_property(self._data["name"], "authorised player"):
            pl.add_property("authorised player", True)
            pl.add_property("authorised email", ph.test_property(self._data["name"], "authorised email"))
            pl.set_email(ph.test_property(self._data["name"], "authorised email"))
        pl.set_name(self._data["name"])
        if "password" in self._data:
            pl.set_password(self.driver.crypt(self._data["password"], 0))
        if self._data.get("guest"):
            pl.add_property("guest", True)
            pl.set_title("guest of Dawn MUD")
        pl.set_gender(self._data["gender"])
        pl.set_language("general")
        pl.set_default_language("general")
        tp = self
        if not self.driver.exec(pl, tp):
            self.driver.write("Execution failed.\n")
            return "error"
        if tp != self:
            tp.quit()
        self.driver.write("\n")
        pl.move_player_to_start(self._data["name"], not self._data.get("guest"), 
                                self._data.get("cap_name", ""), "", self._data.get("go_invis", 0))
        if self.driver.query_ip_number(pl) == self.driver.query_ip_name(pl):
            self.driver.resolve(self.driver.query_ip_number(pl), "")
        return "ok"

    async def player_login(self, event: str) -> str:
        """Logs in an existing player."""
        if not self.driver.is_interactive(self):
            self.debug_log("Not interactive: state=%s last_state=%s event=%s last_event=%s", 
                           self._state, self._last_state, self._event, self._last_event)
            self.dest_me()
            return "quit"
        ph = self.driver.player_handler()
        cap_name = ph.query_cap_name(self._data["name"])
        delete_file = ph.query_delete_player_file_name(self._data["name"])
        player_file = ph.query_player_file_name(self._data["name"])
        if self.driver.file_size(f"{delete_file}.o") > 0 and \
           self.driver.unguarded(lambda: self.driver.rename(f"{delete_file}.o", f"{player_file}.o")):
            self.driver.write("Removing player from delete queue.\n")
        elif self.driver.file_size(f"{delete_file}.o.gz") > 0 and \
             self.driver.unguarded(lambda: self.driver.rename(f"{delete_file}.o.gz", f"{player_file}.o.gz")):
            self.driver.write("Removing player from delete queue.\n")
        
        bastards = self.driver.find_object(BASTARDS)
        try:
            pl = self.driver.clone_object(bastards.query_player_ob(self._data["name"]))
        except Exception as e:
            self.driver.write(f"Error cloning player: {str(e)}\n")
            return "error"
        if not pl:
            self.driver.write("Player object creation failed.\n")
            return "error"
        tp = self
        if not self.driver.exec(pl, tp):
            self.driver.write("Execution error.\n")
            return "error"
        if tp != self:
            tp.quit()
        self.driver.write("\n")
        pl.move_player_to_start(self._data["name"], False, cap_name, 0, self._data.get("go_invis", 0))
        if self._terminal_name:
            pl.terminal_type(self._terminal_name)
        if self._cols and self._rows:
            pl.window_size(self._cols, self._rows)
        if self.driver.query_ip_number(pl) == self.driver.query_ip_name(pl):
            self.driver.resolve(self.driver.query_ip_number(pl), "")
        return "ok"

    def exit_queue(self, event: str) -> str:
        """Exits the login queue."""
        asyncio.create_task(self._timeout_task())
        living = self.driver.living_handler()
        return "reconnect" if living.find_player(self._data["name"]) else "login"

    def remove_from_login_queue(self) -> None:
        """Removes player from login queue."""
        lh = self.driver.login_handler()
        lh.remove_from_login_queue(self)
        self.driver.tell_object(self, "\n\nYou have exited the login queue!\n\nPlease press enter to continue ")
        asyncio.create_task(self.enter_state("leaving-queue"))

    def quit(self, event: str) -> None:
        """Quits the login process."""
        self.driver.write("Come back soon!\n")
        self.dest_me()

    async def _timeout_task(self) -> None:
        """Handles login timeout."""
        if not self.driver.is_interactive(self):
            self.dest_me()
            return
        if (self.driver.query_idle(self) > TIMEOUT_TIME or
            self.driver.time() > self._login_start_time + THROWOUT_TIME) and \
           self not in self.driver.login_handler().query_login_queue():
            self.driver.write("\nTime out.\n\n")
            self.dest_me()
            return
        await asyncio.sleep(TIMEOUT_TIME)
        asyncio.create_task(self._timeout_task())

    async def check_status(self) -> None:
        """Checks login queue status."""
        if self._data.get("ok_to_login"):
            return
        lh = self.driver.login_handler()
        queue = lh.query_login_queue()
        pos = queue.index(self) + 1 if self in queue else 0
        if not pos:
            lh.add_to_login_queue(self)
            pos = lh.query_login_queue().index(self) + 1
        if pos and pos != self._data.get("login_pos", 0):
            self.driver.write(f"You now have position {pos} in the queue.\n")
        self._data["login_pos"] = pos
        quote_ob = self.driver.find_object(QUOTE_HANDLER)
        quote = "\n".join(quote_ob.query_random_quote()) if quote_ob else "Patience is a virtue."
        self.driver.write(f"{quote:<79}\n")
        await asyncio.sleep(30)
        asyncio.create_task(self.check_status())

    def do_su(self, str_: str) -> bool:
        """Switches user context."""
        ob = self.driver.this_player()
        self._terminal_name = ob.query_cur_term() if hasattr(ob, "query_cur_term") else None
        self._cols = ob.query_cols() if hasattr(ob, "query_cols") else 0
        self._rows = ob.query_rows() if hasattr(ob, "query_rows") else 0
        self.driver.exec(self, ob)
        ob.quit()
        self._data["name"] = str_.lower()
        self.debug_log("Suing to %s", str_)
        asyncio.create_task(self.enter_state("check-login-access"))
        return True

    def do_upgrade(self, old: Any) -> None:
        """Upgrades from an old login object."""
        old.save()
        self._data["name"] = old.query_name()
        self.driver.exec(self, old)
        self.driver.destruct(old)
        asyncio.create_task(self.enter_state("player-login"))

    def logon(self) -> None:
        """Initiates the login process."""
        self.debug_log("Connection received.")
        if not any(t.get_name() == "timeout_task" for t in asyncio.all_tasks()):
            asyncio.create_task(self._timeout_task())
        self._login_start_time = self.driver.time()
        asyncio.create_task(self.enter_state("main-menu"))

    def query_prevent_shadow(self) -> bool:
        """Prevents shadowing."""
        return True

    def do_efun_write(self, str_: str) -> None:
        """Writes formatted output."""
        self.driver.tell_object(self, f"{str_:<79}")

    def query_object_type(self) -> str:
        """Returns object type."""
        return "X"

    def query_gender_string(self) -> str:
        """Returns gender string (placeholder)."""
        return "blue"

    def terminal_type(self, type_: str) -> None:
        """Sets terminal type."""
        self._terminal_name = type_

    def window_size(self, width: int, height: int) -> None:
        """Sets window size."""
        self._cols = width
        self._rows = height

    def net_dead(self) -> None:
        """Handles net dead state."""
        lh = self.driver.login_handler()
        lh.remove_from_login_queue(self)

    def dest_me(self) -> None:
        """Destroys the login object."""
        lh = self.driver.login_handler()
        lh.remove_from_login_queue(self)
        self.driver.destruct(self)

    def query_login_ob(self) -> bool:
        """Indicates this is a login object."""
        return True

    def query_player_file_name(self, name: str) -> str:
        """Returns player file name."""
        return self.driver.player_handler().query_player_file_name(name)

    def query_delete_player_file_name(self, name: str) -> str:
        """Returns delete player file name."""
        return self.driver.player_handler().query_delete_player_file_name(name)

    def query_name(self) -> str:
        """Returns current name."""
        return self._data.get("name", "logon")

    def query_cap_name(self) -> str:
        """Returns capitalized name."""
        return self._data.get("cap_name", "Logon")

    def write_prompt(self) -> None:
        """Writes prompt (placeholder)."""
        pass

    def set_login_port(self, port: int) -> None:
        """Sets the login port (called by master.connect)."""
        self._data["port"] = port
        self.debug_log(f"Login port set to {port}")           