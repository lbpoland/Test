# /lib/secure/items/bomb.py
# Implements a creator tool to disconnect players.
# @see /std/object.py

class Bomb:
    def __init__(self, driver):
        self.driver = driver
        self.setup()

    def setup(self):
        """
        Initializes the bomb object.
        """
        self.driver.set_name("bomb")
        self.driver.set_short("bomb of departure")
        self.driver.set_long("This is a handy creator object to get rid of annoying swine.\n")
        self.driver.set_main_plural("bombs")
        self.driver.reset_drop()

    def reset(self):
        """
        Schedules the bomb to detonate.
        """
        asyncio.create_task(asyncio.sleep(2, self.detonate))

    async def detonate(self):
        """
        Forces the environment to quit and reschedules detonation.
        """
        env = self.driver.environment(self.driver.this_object())
        if env:
            env.quit()
        asyncio.create_task(asyncio.sleep(15, self.detonate))

    def init_dynamic_arg(self, args):
        """
        Initializes dynamic arguments and schedules detonation.
        @param args Mapping of dynamic arguments
        """
        self.driver.init_dynamic_arg(args)
        asyncio.create_task(asyncio.sleep(15, self.detonate))