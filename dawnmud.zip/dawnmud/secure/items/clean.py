# /lib/secure/items/clean.py
# Cleans up old player files and system data.
# @see /secure/master.py
# @see /obj/handlers/library.py
# @see /room/bankmain.py
# @see /obj/handlers/mail_track.py

DAYS60 = 5184000
DAYS90 = 7776000

class Clean:
    def __init__(self, driver):
        self.driver = driver
        self.setup()

    def setup(self):
        """
        Initializes the clean object.
        """
        self.driver.set_name("test")
        self.driver.set_short("test")

    def init(self):
        """
        Sets up command actions.
        """
        self.driver.add_action("purge", self.purge)

    def purge(self, str_):
        """
        Purges old player files and cleans system data.
        @param str_ Command argument (unused)
        @return 1 on success
        """
        letters = list("abcdefghijklmnopqrstuvwxyz")
        self.driver.seteuid("Root")
        t = self.driver.time()
        for letter in letters:
            dir_ = self.driver.get_dir(f"/players/{letter}/*.o")
            for file in dir_:
                s = self.driver.stat(f"/players/{letter}/{file}")
                if s and (t - s[1]) > DAYS60:
                    tmp = file[:-2]  # Remove .o extension
                    if not self.driver.get_master().query_promoted(tmp):
                        self.driver.log_file("EXPIRED", f"{file} unused for > 60 days, moved\n")
                        self.driver.rename(f"/players/{letter}/{file}", f"/players/OLD/{file}")
                    else:
                        self.driver.log_file("EXPIRED", f"{file} unused for > 60 days, promoted, not moved\n")
        self.driver.find_object("/obj/handlers/library").clean_library()
        self.driver.find_object("/room/bankmain").clean_bank()
        self.driver.find_object("/obj/handlers/mail_track").clean_post()
        return 1