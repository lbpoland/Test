# /lib/secure/simul_efun/query_ident.py
# Queries object identification with security restrictions.

class QueryIdent:
    def __init__(self, driver):
        self.driver = driver

    def query_ident(self, ob):
        """
        Returns the object's ident if caller is secure or obj handler.
        @param ob The object to query
        @return Ident string or None
        """
        prev_file = self.driver.file_name(self.driver.previous_object()).split("/")[0]
        if prev_file in ["secure", "obj"]:
            return ob.query_my_ident()
        return None