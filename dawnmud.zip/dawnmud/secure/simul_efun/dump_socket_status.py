# /secure/simul_efun/dump_socket_status.py
# Translated from /secure/simul_efun/dump_socket_status.c (2003 Discworld MUD library)
# Purpose: Dumps socket status
# Last modified in original: Unknown

class DumpSocketStatus:
    def __init__(self, driver):
        self.driver = driver

    def dump_socket_status(self):
        """Returns a formatted string of socket status."""
        ret = "Fd    State      Mode       Local Address          Remote Address\n" \
              "--  ---------  --------  ---------------------  ---------------------\n"
        for item in self.driver.socket_status():
            ret += f"{item[0]:2d}  {item[1]:9}  {item[2]:8}  {item[3]:21}  {item[4]:21}\n"
        return ret