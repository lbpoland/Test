# /lib/secure/simul_efun/uniq_array.py
# Returns unique elements from an array.
# @see /secure/simul_efun/modified_efuns.py

class UniqArray:
    def __init__(self, driver):
        self.driver = driver

    def uniq_array(self, arr):
        """
        Returns unique elements from an array.
        @param arr The input array
        @return Array of unique elements
        """
        return list(dict.fromkeys(arr))