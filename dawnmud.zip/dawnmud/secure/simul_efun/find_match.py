# /secure/simul_efun/find_match.py
# Translated from /secure/simul_efun/find_match.c (2003 Discworld MUD library)
# Purpose: Object matching utilities
# Last modified in original: Unknown

class FindMatch:
    def __init__(self, driver):
        self.driver = driver
        self.rest = []

    def create(self, parent=None):
        """Initializes the find_match object."""
        pass  # Placeholder for inherited create()

    def is_in_me_or_environment(self, thing, person):
        """Checks if thing is in person or their environment."""
        env = self.driver.environment(thing)
        if env == self.driver.environment(person):
            return True
        if not env:
            return True
        while env and not self.driver.living(env):
            env = self.driver.environment(env)
        return env == person

    def filter_in_me_or_environment(self, obs, player):
        """Filters objects in player or their environment."""
        return [ob for ob in obs if self.is_in_me_or_environment(ob, player)]