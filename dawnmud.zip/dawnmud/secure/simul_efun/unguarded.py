# /lib/secure/simul_efun/unguarded.py
# Executes functions without security restrictions.
# @see /secure/master.py

class Unguarded:
    def __init__(self, driver):
        self.driver = driver

    def unguarded(self, f):
        """
        Executes a function bypassing security checks.
        @param f The function to execute
        @return Function result
        """
        master_ob = self.driver.get_master() or self.driver.previous_object()
        # Assuming ORIGIN_LOCAL is simulated by checking call stack depth
        local = len(self.driver.call_stack(1)) == 1
        return master_ob.apply_unguarded(f, local)