# /lib/secure/simul_efun/shuffle.py
# Shuffles an array.

class Shuffle:
    def __init__(self, driver):
        self.driver = driver

    def shuffle(self, args):
        """
        Shuffles the elements of an array.
        @param args The array to shuffle
        @return Shuffled array
        """
        import random
        if not isinstance(args, list):
            return []
        if len(args) < 2:
            return args
        args = list(args)  # Create a copy to avoid modifying the original
        for i in range(len(args)):
            j = random.randint(0, i)
            if i != j:
                args[i], args[j] = args[j], args[i]
        return args