# /lib/secure/simul_efun/pk_check.py
# Checks player-killer status for interactions.
# @see /secure/simul_efun/modified_efuns.py
# @see /obj/handlers/player_handler.py

class PkCheck:
    def __init__(self, driver):
        self.driver = driver

    def pk_check(self, thing1, thing2, off_line=False):
        """
        Determines if a PK interaction is allowed between two entities.
        @param thing1 First entity (object or name)
        @param thing2 Second entity (object or name)
        @param off_line Allow offline checks (default: False)
        @return 1 if blocked, 0 if allowed
        """
        if isinstance(thing1, object) and isinstance(thing2, object) and \
           self.driver.is_interactive(thing1) and self.driver.is_interactive(thing2):
            creators = [x for x in [thing1, thing2] if x.query_creator() or x.query_property("test character")]
            if len(creators) == 1:
                self.driver.debug_printf(f"PK check between {thing1.query_name()} and {thing2.query_name()} failed!\n")
                return 1

        if isinstance(thing1, object) and not self.driver.is_interactive(thing1) and thing1.query_owner_pk_check():
            thing1 = thing1.query_owner_pk_check()
        if not isinstance(thing1, object):
            ob = self.driver.find_player(thing1)
            if ob:
                thing1 = ob

        pk1 = 0
        if isinstance(thing1, object) and self.driver.userp(thing1):
            pk1 = thing1.query_player_killer() and self.driver.is_interactive(thing1)
        elif isinstance(thing1, str):
            if off_line and self.driver.player_handler().test_user(thing1):
                pk1 = self.driver.player_handler().test_player_killer(thing1)
            else:
                return 0
        else:
            return 0

        if isinstance(thing2, object) and not self.driver.is_interactive(thing2) and thing2.query_owner_pk_check():
            thing2 = thing2.query_owner_pk_check()
        if not isinstance(thing2, object):
            ob = self.driver.find_player(thing2)
            if ob:
                thing2 = ob

        pk2 = 0
        if isinstance(thing2, object) and self.driver.userp(thing2):
            pk2 = thing2.query_player_killer() and self.driver.is_interactive(thing2)
        elif isinstance(thing2, str):
            if off_line and self.driver.player_handler().test_user(thing2):
                pk2 = self.driver.player_handler().test_player_killer(thing2)
            else:
                return 0
        else:
            return 0

        return 0 if pk1 and pk2 else 1

    def pk_assist(self, assister, assistee, off_line=False):
        """
        Checks if assisting a PK is allowed.
        @param assister The assisting entity
        @param assistee The assisted entity
        @param off_line Allow offline checks (default: False)
        @return 1 if assist triggers PK rules, 0 otherwise
        """
        if isinstance(assistee, object) and not self.driver.is_interactive(assistee) and assistee.query_owner_pk_check():
            assistee = assistee.query_owner_pk_check()
        if not isinstance(assistee, object):
            ob = self.driver.find_player(assistee)
            if ob:
                assistee = ob
        if not isinstance(assistee, object) or not assistee.query_player_killer():
            return 0

        if isinstance(assister, object) and not self.driver.is_interactive(assister) and assister.query_owner_pk_check():
            assister = assister.query_owner_pk_check()
        if not isinstance(assister, object):
            ob = self.driver.find_player(assister)
            if ob:
                assister = ob
        if not isinstance(assister, object) or not self.driver.userp(assister) or assister.query_player_killer():
            return 0

        attackers = assistee.query_attacker_list()
        return 1 if any(a.query_player_killer() for a in attackers) else 0