# /lib/secure/simul_efun/query_number.py
# Converts numbers to word representations.

class QueryNumber:
    def __init__(self, driver):
        self.driver = driver

    def number_as_string(self, n):
        """
        Converts a number to its word form.
        @param n The number to convert
        @return Word representation
        """
        if not n:
            return "zero"
        if 9 < n < 20:
            return ["ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen",
                    "sixteen", "seventeen", "eighteen", "nineteen"][n - 10]
        tens = ["", "", "twenty", "thirty", "forty", "fifty", "sixty",
                "seventy", "eighty", "ninety"][n // 10]
        ones = n % 10
        return f"{tens}-" + ["", "one", "two", "three", "four", "five", "six",
                             "seven", "eight", "nine"][ones] if ones and tens else tens or ["", "one", "two", "three", "four", "five", "six",
                                                                                           "seven", "eight", "nine"][ones]

    def query_num(self, n, limit=0):
        """
        Converts a number to words with thousand/hundred handling.
        @param n The number to convert
        @param limit Upper limit before returning 'many' (default: 0)
        @return Word representation or 'many'
        """
        if (limit and n > limit) or n < 0 or n > 99999:
            return "many"
        ret = ""
        if i := n // 1000:
            n %= 1000
            if not n:
                return f"{self.number_as_string(i)} thousand"
            ret = f"{self.number_as_string(i)} thousand"
        if i := n // 100:
            n %= 100
            if ret:
                if not n:
                    return f"{ret} and {self.number_as_string(i)} hundred"
                ret += f", {self.number_as_string(i)} hundred"
            else:
                if not n:
                    return f"{self.number_as_string(i)} hundred"
                ret = f"{self.number_as_string(i)} hundred"
        return f"{ret} and {self.number_as_string(n)}" if ret else self.number_as_string(n)

    def word_ordinal(self, num):
        """
        Converts a number to its ordinal word form.
        @param num The number to convert
        @return Ordinal word representation
        """
        part = num % 100
        if part == 0:
            word = "th"
        elif 1 <= part <= 12:
            word = ["first", "second", "third", "fourth", "fifth", "sixth",
                    "seventh", "eighth", "ninth", "tenth", "eleventh", "twelfth"][part - 1]
        elif 13 <= part <= 19:
            word = f"{self.query_num(part, 99999)}th"
        else:
            if part % 10 == 0:
                word = ["twentieth", "thirtieth", "fortieth", "fiftieth", "sixtieth",
                        "seventieth", "eightieth", "ninetieth"][part // 10 - 2]
            else:
                word = f"{['twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'][part // 10 - 2]}-{self.word_ordinal(part % 10)}"
        num = (num // 100) * 100
        if num:
            word = f"{self.query_num(num, 99999)} and {word}" if part > 0 else f"{self.query_num(num, 99999)}{word}"
        return word

    def query_times(self, num):
        """
        Converts a number to a times phrase.
        @param num The number of times
        @return Times phrase
        """
        return "" if num == 0 else "once" if num == 1 else "twice" if num == 2 else f"{self.query_num(num, 0)} times"