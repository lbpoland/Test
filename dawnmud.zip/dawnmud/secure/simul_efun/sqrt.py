# /lib/secure/simul_efun/sqrt.py
# Computes square roots with type handling.

class Sqrt:
    def __init__(self, driver):
        self.driver = driver

    def sqrt(self, number):
        """
        Calculates the square root of a number.
        @param number The number (int or float)
        @return Square root or -1 if negative
        """
        import math
        if isinstance(number, float):
            return math.sqrt(number)
        if not isinstance(number, int):
            raise ValueError(f"Bad argument 1 to sqrt()\nExpected: int or float Got: {type(number).__name__}.")
        if number < 0:
            return -1
        return int(math.sqrt(float(number)))