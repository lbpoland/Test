# /secure/simul_efun/aggregate.py
# Translated from /secure/simul_efun/aggregate.c (2003 Discworld MUD library)
# Purpose: Converts aggregates to strings
# Last modified in original: Unknown

class Aggregate:
    def __init__(self, driver):
        self.driver = driver

    def array_to_string(self, args):
        """Converts an array to a string representation."""
        args = list(args)  # Copy to avoid modifying original
        for i in range(len(args) - 1, -1, -1):
            if isinstance(args[i], list):
                args[i] = self.array_to_string(args[i])
            elif isinstance(args[i], dict):
                args[i] = self.mapping_to_string(args[i])
            else:
                args[i] = str(args[i])
        return f"({{ {', '.join(args)} }})"

    def mapping_to_string(self, map_):
        """Converts a mapping to a string representation."""
        if not isinstance(map_, dict):
            return str(map_)
        args = []
        for key in map_.keys():
            value = map_[key]
            if isinstance(value, list):
                value_str = self.array_to_string(value)
            elif isinstance(value, dict):
                value_str = self.mapping_to_string(value)
            else:
                value_str = str(value)
            args.append(f"{str(key)} : {value_str}")
        return f"([ {', '.join(args)} ])"

    def alt_move(self, dest, ob):
        """Moves an object to a destination."""
        if not ob:
            return
        self.driver.evaluate(self.driver.bind(lambda: self.driver.move_object(dest), ob))

    def extract(self, str_, start, end=None):
        """Extracts a substring."""
        if end is not None:
            return str_[start:end + 1]
        return str_[start:]