# /secure/simul_efun/ctime_elapsed.py
# Translated from /secure/simul_efun/ctime_elapsed.c (2003 Discworld MUD library)
# Purpose: Converts elapsed time to string
# Last modified in original: Unknown

class CtimeElapsed:
    def __init__(self, driver):
        self.driver = driver

    def ctime_elapsed(self, time_elapsed, mode=False):
        """Converts elapsed time to a human-readable string."""
        sec = time_elapsed % 60
        min_ = (time_elapsed // 60) % 60
        hour = (time_elapsed // (60 * 60)) % 24
        day = time_elapsed // (60 * 60 * 24)
        
        if mode:
            seconds = self.driver.query_num(sec)
            minutes = self.driver.query_num(min_)
            hours = self.driver.query_num(hour)
            days = self.driver.query_num(day)
        else:
            seconds = str(sec)
            minutes = str(min_)
            hours = str(hour)
            days = str(day)
        
        retval = []
        if day > 0:
            retval.append(f"{days} day{'s' if day > 1 else ''}")
        if hour > 0:
            retval.append(f"{hours} hour{'s' if hour > 1 else ''}")
        if min_ > 0:
            retval.append(f"{minutes} minute{'s' if min_ > 1 else ''}")
        if sec > 0:
            retval.append(f"{seconds} second{'s' if sec > 1 else ''}")
        
        if not retval:
            return "0 seconds"
        if len(retval) == 1:
            return retval[0]
        return f"{', '.join(retval[:-1])} and {retval[-1]}"