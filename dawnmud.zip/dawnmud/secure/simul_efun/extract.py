# /secure/simul_efun/extract.py
# Translated from /secure/simul_efun/extract.c (2003 Discworld MUD library)
# Purpose: Extracts substring
# Last modified in original: Unknown

class Extract:
    def __init__(self, driver):
        self.driver = driver

    def extract(self, str_, start, end=None):
        """Extracts a substring."""
        if end is not None:
            return str_[start:end + 1]
        return str_[start:]