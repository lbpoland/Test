# /lib/secure/simul_efun/obj_parser.py
# Parses object references in environments for commands.
# @see /secure/simul_efun/multiple_short.py
# @see /obj/handlers/playtesters.py

class ObjMatch:
    def __init__(self):
        self.text = ""
        self.objects = []
        self.result = 0

class ObjMatchContext:
    def __init__(self):
        self.plural = []
        self.him = None
        self.her = None
        self.it = None
        self.ordinal = 0
        self.number_included = 0
        self.ignore_rest = False
        self.fraction = None

EVERY_NUM = 18729487

class ObjParser:
    def __init__(self, driver):
        self.driver = driver
        self._ordinals = {
            "any": 1, "a": 1, "an": 1, "the": 1,
            "1st": 1, "first": 1, "2nd": 2, "second": 2,
            "3rd": 3, "third": 3, "4th": 4, "fourth": 4,
            "5th": 5, "fifth": 5, "6th": 6, "sixth": 6,
            "7th": 7, "seventh": 7, "8th": 8, "eighth": 8,
            "9th": 9, "ninth": 9, "10th": 10, "tenth": 10,
            "last": -1
        }
        self._counters = {
            "1": 1, "one": 1, "2": 2, "two": 2, "3": 3, "three": 3,
            "4": 4, "four": 4, "5": 5, "five": 5, "6": 6, "six": 6,
            "7": 7, "seven": 7, "8": 8, "eight": 8, "9": 9, "nine": 9,
            "10": 10, "ten": 10, "11": 11, "eleven": 11, "12": 12, "twelve": 12,
            "13": 13, "thirteen": 13, "14": 14, "fourteen": 14, "15": 15, "fifteen": 15,
            "16": 16, "sixteen": 16, "17": 17, "seventeen": 17, "18": 18, "eighteen": 18,
            "19": 19, "nineteen": 19, "20": 20, "twenty": 20, "many": 20, "every": EVERY_NUM
        }
        self._fractions = {
            "half": [1, 2], "quarter": [1, 4], "some": [1, 50]
        }

    def fixup_context(self, player, objects, context):
        """
        Updates the player's context with matched objects.
        @param player The player object
        @param objects Array of matched objects
        @param context The obj_match_context to update
        """
        if not player or not objects:
            return
        if len(objects) > 1:
            context.plural = objects
        elif self.driver.living(objects[0]) and objects[0] != player:
            if objects[0].query_male():
                context.him = objects[0]
            elif objects[0].query_female():
                context.her = objects[0]
            else:
                context.it = objects[0]
        else:
            context.it = objects[0]
        player.set_it_them(context)

    def match_object_in_array(self, input, ob_list, type_, player=None):
        """
        Matches objects in an array based on input string.
        @param input The input string to parse
        @param ob_list Array of objects to match against
        @param type_ The parsing type flags
        @param player The player object (optional)
        @return ObjMatch instance with results
        """
        if not player:
            player = self.driver.this_player()
        input = input.lower()
        context = player.query_it_them() if player else ObjMatchContext()
        if not isinstance(context, ObjMatchContext):
            context = ObjMatchContext()
            if player:
                player.set_it_them(context)

        omatch = ObjMatch()
        omatch.text = input
        omatch.objects = []

        if "&" in input:
            for bit in [x for x in input.split("&") if x]:
                result = self.match_object_in_array(bit, ob_list, type_, player)
                if result.result == 1:  # OBJ_PARSER_SUCCESS
                    omatch.objects = list(set(omatch.objects + result.objects))
            if not omatch.objects:
                omatch.result = 2  # OBJ_PARSER_NO_MATCH
                return omatch
            self.fixup_context(player, omatch.objects, context)
            omatch.result = 1
            return omatch

        if not (type_ & 8) and player and not player.query_property("use_and_as_break"):  # OBJ_PARSER_TYPE_EXISTENCE
            input = input.replace(" and ", ",")

        if "," in input:
            for bit in [x for x in input.split(",") if x]:
                result = self.match_object_in_array(bit, ob_list, type_, player)
                if result.result == 1:
                    omatch.objects = list(set(omatch.objects + result.objects))
                elif not (type_ & 8):
                    return result
            self.fixup_context(player, omatch.objects, context)
            omatch.result = 1
            return omatch

        if player:
            nick = player.expand_nickname(input)
            if nick:
                input = nick

        inside_match = None
        if not (type_ & 16):  # OBJ_PARSER_TYPE_NO_NESTED
            n = input.rfind(" in ")
            if n == -1:
                n = input.rfind(" on ")
            if n != -1:
                inside_match = input[:n]
                input = input[n + 4:]

        n = input.find(" ")
        ord_ = 0
        count = 0
        fraction = None
        if n != -1:
            first_word = input[:n]
            rest = input[n + 1:]
            fraction = self._fractions.get(first_word)
            if not fraction:
                try:
                    n, count = map(int, first_word.split("/"))
                    if n > count or n < 0 or count <= 0:
                        omatch.result = 4  # OBJ_PARSER_BAD_FRACTION
                        return omatch
                    fraction = [n, count]
                except ValueError:
                    count = 0
            if fraction:
                input = rest[3:] if rest.startswith("of ") else rest
            n = input.find(" ")

        if n != -1:
            first_word = input[:n]
            rest = input[n + 1:]
            ord_ = self._ordinals.get(first_word, 0)
            if ord_ > 0:
                input = rest
            if not ord_:
                count = self._counters.get(first_word, 0)
                if not count:
                    try:
                        count = int(first_word)
                    except ValueError:
                        pass
                if count > 0:
                    input = rest
                if not count:
                    n = input.rfind(" ")
                    if n != -1:
                        try:
                            ord_ = int(input[n + 1:])
                            input = input[:n]
                        except ValueError:
                            pass
            n = input.find(" ")

        random_item = 0
        if n != -1 and input[:n] == "random":
            random_item = ord_ or 1
            count = EVERY_NUM
            ord_ = 0
            input = input[n + 1:]

        omatch = ObjMatch()
        omatch.text = input
        omatch.objects = []
        bits = [x for x in input.split(" ") if x]
        if not bits:
            omatch.result = 2  # OBJ_PARSER_NO_MATCH
            return omatch

        context.ordinal = ord_
        context.number_included = count
        context.ignore_rest = False
        context.fraction = fraction
        singular_objects = []
        plural_objects = []
        ob_list = [ob for ob in ob_list if ob.query_visible(player)] if player else ob_list

        for ob in ob_list:
            if not inside_match and (type_ & 1):  # OBJ_PARSER_TYPE_LIVING
                if not self.driver.living(ob):
                    continue
            if not inside_match and (type_ & 2):  # OBJ_PARSER_TYPE_PLAYER
                if not self.driver.userp(ob):
                    continue
            obj_info = ob.parse_match_object(bits, player, context)
            if obj_info:
                if obj_info[0] & 1:  # OBJ_PARSER_MATCH_PLURAL
                    plural_objects.extend(obj_info[1])
                if obj_info[0] & 2:  # OBJ_PARSER_MATCH_SINGULAR
                    singular_objects.extend(obj_info[1])
            if context.ignore_rest:
                break

        if len(singular_objects) > 1 and not (ord_ or count):
            if player and not player.query_property("parser_ambiguous"):
                omatch.objects = singular_objects
                omatch.result = 3  # OBJ_PARSER_AMBIGUOUS
                return omatch
            if not random_item:
                singular_objects = singular_objects[:1]
            else:
                import random
                n = random.randint(0, len(singular_objects) - 1)
                singular_objects = singular_objects[n:n + 1]

        if not singular_objects and not plural_objects:
            omatch.result = 2
            return omatch

        if type_ & 4:  # OBJ_PARSER_TYPE_SLOPPY_MATCHING
            omatch.objects = [x for x in singular_objects if x in plural_objects]
        elif random_item:
            omatch.objects = plural_objects or singular_objects
            import random
            n = random.randint(0, len(omatch.objects) - 1)
            omatch.objects = omatch.objects[n:n + 1]
        elif ord_ or count == 1 or count == EVERY_NUM:
            omatch.objects = singular_objects[-1:] if ord_ == -1 else singular_objects
        elif count:
            omatch.objects = plural_objects
        else:
            omatch.objects = plural_objects or singular_objects

        if len(omatch.objects) > 1 and fraction:
            omatch.result = 5  # OBJ_PARSER_FRACTION
            return omatch
        if context.number_included and count != EVERY_NUM:
            omatch.result = 6  # OBJ_PARSER_NOT_ENOUGH
            return omatch

        if inside_match:
            omatch.objects = [thing for thing in omatch.objects if thing.can_find_match_recurse_into(player)]
            if omatch.objects:
                result = self.match_objects_in_environments(inside_match, omatch.objects, type_, player)
                omatch.objects = []
                if result.result == 1:
                    omatch.objects = [thing for thing in result.objects if self.driver.environment(thing) and self.driver.environment(thing).can_find_match_reference_inside_object(thing, player)]
                else:
                    result.text = f"{inside_match} in {input}"
                    return result

        if not omatch.objects:
            omatch.result = 2
            return omatch

        self.fixup_context(player, omatch.objects, context)
        omatch.result = 1
        return omatch

    def match_objects_in_environments(self, input, env_list, type_, player=None):
        """
        Matches objects across multiple environments.
        @param input The input string to parse
        @param env_list Single object or array of environment objects
        @param type_ The parsing type flags
        @param player The player object (optional)
        @return ObjMatch instance with results
        """
        if not player:
            player = self.driver.this_player()
        if not isinstance(env_list, list):
            if input == "all" and env_list.query_is_room() and player.check_dark(env_list.query_light()):
                omatch = ObjMatch()
                omatch.text = input
                omatch.objects = []
                omatch.result = 7  # OBJ_PARSER_TOO_DARK
                return omatch
            tmp_expanded = env_list.find_inv_match(input, player)
        else:
            tmp_expanded = []
            for ob in env_list:
                if not ob:
                    continue
                if input == "all" and ob.query_is_room() and player.check_dark(ob.query_light()):
                    continue
                stuff = ob.find_inv_match(input, player)
                if stuff:
                    tmp_expanded.extend(stuff)

        if not tmp_expanded:
            omatch = ObjMatch()
            omatch.text = input
            omatch.objects = []
            omatch.result = 2
            return omatch

        return self.match_object_in_array(input, tmp_expanded, type_, player)

    def match_objects_for_existence(self, input, env_list, player):
        """
        Checks existence of objects without full parsing.
        @param input The input string
        @param env_list Array of environment objects
        @param player The player object
        @return Array of matched objects
        """
        stuff = self.match_objects_in_environments(input, env_list, 8, player)  # OBJ_PARSER_TYPE_EXISTENCE
        return stuff.objects if stuff.result in [1, 3] else []  # OBJ_PARSER_SUCCESS or AMBIGUOUS

    def match_objects_failed_mess(self, failed_match):
        """
        Generates failure messages for parsing errors.
        @param failed_match The failed ObjMatch instance
        @return Error message string
        """
        if failed_match.result == 0:  # OBJ_PARSER_BAD_ENVIRONMENT
            return f"Cannot find \"{failed_match.text}\" here, access is not allowed.\n"
        elif failed_match.result == 1:  # OBJ_PARSER_NOT_LIVING
            return f"The objects \"{self.driver.query_multiple_short(failed_match.objects)}\" are not living.\n"
        elif failed_match.result == 7:  # OBJ_PARSER_TOO_DARK
            return f"Cannot find \"{failed_match.text}\", it is too dark.\n"
        elif failed_match.result == 2:  # OBJ_PARSER_NO_MATCH
            return f"Cannot find \"{failed_match.text}\", no match.\n"
        elif failed_match.result == 4:  # OBJ_PARSER_BAD_FRACTION
            return f"The fraction \"{failed_match.text}\" is incorrectly specified.\n"
        elif failed_match.result == 5:  # OBJ_PARSER_FRACTION
            return f"Can only reference a single object with a fraction, matched {self.driver.query_multiple_short(failed_match.objects)} please be more specific.\n"
        elif failed_match.result == 3:  # OBJ_PARSER_AMBIGUOUS
            return f"There are multiple matches for \"{failed_match.text}\". See 'help parser' for more information on how to be more specific.\n"
        elif failed_match.result == 6:  # OBJ_PARSER_NOT_ENOUGH
            return f"There are not enough \"{failed_match.text}\" to match as specified.\n"
        else:
            return f"Unknown parser error {failed_match.result}.\n"