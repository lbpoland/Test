# /lib/secure/simul_efun/thing_to_string.py
# Converts complex data types to string representations.

class ThingToString:
    def __init__(self, driver):
        self.driver = driver

    def array_to_string(self, args):
        """
        Converts an array to a string representation.
        @param args The array to convert
        @return String representation
        """
        args = list(args)
        for i in range(len(args) - 1, -1, -1):
            if isinstance(args[i], list):
                args[i] = self.array_to_string(args[i])
            elif isinstance(args[i], dict):
                args[i] = self.mapping_to_string(args[i])
            else:
                args[i] = str(args[i])  # Using Python's str() as %O equivalent
        return f"({{ {', '.join(args)} }})"

    def mapping_to_string(self, map_):
        """
        Converts a mapping to a string representation.
        @param map_ The mapping to convert
        @return String representation
        """
        if not isinstance(map_, dict):
            return str(map_)
        args = []
        for key in map_.keys():
            value = map_[key]
            if isinstance(value, list):
                value_str = self.array_to_string(value)
            elif isinstance(value, dict):
                value_str = self.mapping_to_string(value)
            else:
                value_str = str(value)
            args.append(f"{str(key)} : {value_str}")
        return f"([ {', '.join(args)} ])"