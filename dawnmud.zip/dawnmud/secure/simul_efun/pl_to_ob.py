# /lib/secure/simul_efun/pl_to_ob.py
# Converts player names to objects.
# @see /secure/simul_efun/modified_efuns.py

class PlToOb:
    def __init__(self, driver):
        self.driver = driver

    def player_to_object(self, str_):
        """
        Converts a player name to an object.
        @param str_ The player name
        @return The player object or None
        """
        tmp = str_
        tp = self.driver.this_player()
        if tp:
            tmp = tp.expand_nickname(str_.lower())
        if tmp:
            str_ = tmp
        return self.driver.find_player(str_.lower())