# /lib/secure/simul_efun/mxp.py
# Provides MXP (Mud eXtension Protocol) tag utilities.
# @see /global/player.py

class Mxp:
    def __init__(self, driver):
        self.driver = driver

    def mxp_tag(self, tag, output, player=None):
        """
        Wraps output in an MXP tag if enabled.
        @param tag The MXP tag
        @param output The content to wrap
        @param player The player to check (optional)
        @return Wrapped or plain output
        """
        if not player:
            player = self.driver.this_player()
        if player == 1 or (hasattr(player, "is_mxp_enabled") and player.is_mxp_enabled()):
            return f"MXP<{tag}MXP>{output}MXP</{tag}MXP>"
        return output

    def mxp_tag_args(self, tag, args, output, player=None):
        """
        Wraps output in an MXP tag with arguments if enabled.
        @param tag The MXP tag
        @param args Tag arguments
        @param output The content to wrap
        @param player The player to check (optional)
        @return Wrapped or plain output
        """
        if not player:
            player = self.driver.this_player()
        if player == 1 or (hasattr(player, "is_mxp_enabled") and player.is_mxp_enabled()):
            return f"MXP<{tag} {args}MXP>{output}MXP</{tag}MXP>"
        return output

    def mxp_choice(self, non_mxp, mxp, player=None):
        """
        Chooses between MXP and non-MXP output.
        @param non_mxp The non-MXP output
        @param mxp The MXP output
        @param player The player to check (optional)
        @return Selected output
        """
        if not player:
            player = self.driver.this_player()
        if player == 1 or (hasattr(player, "is_mxp_enabled") and player.is_mxp_enabled()):
            return mxp
        return non_mxp

    def mxp_secure(self, player=None):
        """
        Returns an MXP secure mode command.
        @param player The player to check (optional)
        @return Command string or empty
        """
        if not player:
            player = self.driver.this_player()
        if hasattr(player, "is_mxp_enabled") and player.is_mxp_enabled():
            return f"{chr(27)}[6z"
        return ""

    def mxp_open(self, player=None):
        """
        Returns an MXP open mode command.
        @param player The player to check (optional)
        @return Command string or empty
        """
        if not player:
            player = self.driver.this_player()
        if hasattr(player, "is_mxp_enabled") and player.is_mxp_enabled():
            return f"{chr(27)}[5z"
        return ""

    def mxp_next_secure(self, player=None):
        """
        Returns an MXP next secure command.
        @param player The player to check (optional)
        @return Command string or empty
        """
        if not player:
            player = self.driver.this_player()
        if hasattr(player, "is_mxp_enabled") and player.is_mxp_enabled():
            return f"{chr(27)}[4z"
        return ""

    def mxp_expire(self, category, player=None):
        """
        Returns an MXP expire command for a category.
        @param category The category to expire
        @param player The player to check (optional)
        @return Command string or empty
        """
        if not player:
            player = self.driver.this_player()
        if hasattr(player, "is_mxp_enabled") and player.is_mxp_enabled():
            return f"MXP<EXPIRE {category}MXP>"
        return ""