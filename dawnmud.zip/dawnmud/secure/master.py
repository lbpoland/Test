# /home/archaon/mud/lib/secure/master.py
# Translated from /secure/master.c (2003 Discworld MUD library)
# Purpose: Central security and control object
# Last modified in original: 2003/03/25

import asyncio
from datetime import datetime

# Constants from master.c
ROOT = "Root"
TRUSTEES = {ROOT: 1, "archaon": 1}  # Updated from "cratylus" per user request
READ_MASK = 1
WRITE_MASK = 2
GRANT_MASK = 4
LOCK_MASK = 8
SENIOR = 4
DIRECTOR = 1
TRUSTEE = 2
VERSION = "Dawn MUD 1.0 - March 20, 2025"  # Modern replacement for __VERSION__

class Master:
    def __init__(self, driver):
        self.driver = driver
        self.positions = {}
        self.permissions = {}
        self.trustees = TRUSTEES.copy()
        self.checked_master = {}
        self.snoop_list = {}
        self.unguarded_ob = None
        self.directory_assignments = {}

        # Import all 23 sub-files from master.c, matching original Grok's style
        from mud.secure.master.permission import Permission
        from mud.secure.master.crash import Crash
        from mud.secure.master.create_dom_creator import CreateDomCreator
        from mud.secure.master.creator_file import CreatorFile
        from mud.secure.master.dest_env import DestEnv
        from mud.secure.master.ed_stuff import EdStuff
        from mud.secure.master.file_exists import FileExists
        from mud.secure.master.logging import Logging
        from mud.secure.master.parse_command import ParseCommand
        from mud.secure.master.preload import Preload
        from mud.secure.master.query_pl_level import QueryPlLevel
        from mud.secure.master.snoop import Snoop
        from mud.secure.master.valid_database import ValidDatabase
        from mud.secure.master.valid_exec import ValidExec
        from mud.secure.master.valid_hide import ValidHide
        from mud.secure.master.valid_ident import ValidIdent
        from mud.secure.master.valid_link import ValidLink
        from mud.secure.master.valid_override import ValidOverride
        from mud.secure.master.valid_read import ValidRead
        from mud.secure.master.valid_seteuid import ValidSeteuid
        from mud.secure.master.valid_shadow import ValidShadow
        from mud.secure.master.valid_socket import ValidSocket
        from mud.secure.master.valid_write import ValidWrite

        self.inherits = [
            Permission,
            Crash,
            CreateDomCreator,
            CreatorFile,
            DestEnv,
            EdStuff,
            FileExists,
            Logging,
            ParseCommand,
            Preload,
            QueryPlLevel,
            Snoop,
            ValidDatabase,
            ValidExec,
            ValidHide,
            ValidIdent,
            ValidLink,
            ValidOverride,
            ValidRead,
            ValidSeteuid,
            ValidShadow,
            ValidSocket,
            ValidWrite,
        ]
        self.create()

    def create(self):
        """Initializes the master object."""
        self.driver.seteuid(ROOT)
        self.driver.set_eval_limit(2000000)
        save_path = "/home/archaon/mud/save/master_state.json"
        if not self.driver.unguarded(lambda: self.driver.restore_object(save_path)):
            if not self.driver.unguarded(lambda: self.driver.restore_object("/home/archaon/mud/save/config/master_fallback.json")):
                raise RuntimeError("The master object couldn't restore its save file.")

    def query_name(self):
        """Returns the master object's name."""
        return ROOT

    async def connect(self, port):
        """Handles player connections."""
        login_path = "/home/archaon/mud/lib/secure/login"
        if not self.driver.find_object(login_path):
            Logging.log_file(self, "REBOOT", f"Mud rebooted at {self.driver.ctime(self.driver.time())}[{self.driver.time()}]\n")
        self.driver.printf(f"LPmud version : {VERSION} on port {port}.")
        ob_path = "/home/archaon/mud/lib/secure/nlogin" if port == 4243 else login_path
        ob = self.driver.clone_object(ob_path)
        if not ob:
            self.driver.destruct(self)
            return None
        if hasattr(ob, "set_login_port"):
            ob.set_login_port(port)
        self.driver.printf("\n")
        return ob

    def query_trustee(self, arg):
        """Checks if an entity is a trustee."""
        if isinstance(arg, list):
            arg = [x for x in arg if self.driver.is_interactive(x)]
            return all(
                self.driver.geteuid(x) == ROOT or
                self.positions.get(self.driver.geteuid(x)) == TRUSTEE or
                self.trustees.get(self.driver.geteuid(x))
                for x in arg
            )
        return arg == ROOT or self.positions.get(arg) == TRUSTEE or arg in self.trustees

    def query_administrator(self, arg):
        return self.query_trustee(arg)

    def high_programmer(self, arg):
        return self.query_trustee(arg)

    def query_director(self, arg):
        if isinstance(arg, list):
            arg = [x for x in arg if self.driver.is_interactive(x)]
            return all(
                self.positions.get(self.driver.geteuid(x)) == DIRECTOR or
                self.query_trustee(self.driver.geteuid(x))
                for x in arg
            )
        return self.positions.get(arg) == DIRECTOR or self.query_trustee(arg)

    def query_leader(self, arg):
        return self.query_director(arg)

    def query_lord(self, arg):
        return self.query_director(arg)

    def query_only_director(self, word):
        return self.positions.get(word) == DIRECTOR

    def query_only_leader(self, word):
        return self.query_only_director(word)

    def query_only_lord(self, word):
        return self.query_only_director(word)

    def query_directors(self):
        return [k for k in self.positions.keys() if self.query_only_director(k)]

    def query_leaders(self):
        return self.query_directors()

    def query_lords(self):
        return self.query_directors()

    def query_player_trustee(self, str_):
        return self.query_trustee(str_) and self.driver.player_handler().test_user(str_)

    def query_player_administrator(self, str_):
        return self.query_player_trustee(str_)

    def query_player_high_lord(self, str_):
        return self.query_player_trustee(str_)

    def high_programmers(self):
        return list(self.trustees.keys())

    def query_administrators(self):
        return self.high_programmers()

    def query_trustees(self):
        return self.high_programmers()

    def query_all_directors(self):
        return [k for k in self.positions.keys() if self.query_director(k)]

    def query_all_leaders(self):
        return self.query_all_directors()

    def query_all_lords(self):
        return self.query_all_directors()

    def is_leader_of(self, person, domain):
        dom_master = self.driver.find_object(f"/home/archaon/mud/d/{domain}/master")
        return dom_master.query_lord() == person if dom_master else False

    def is_deputy_of(self, person, domain):
        dom_master = self.driver.find_object(f"/home/archaon/mud/d/{domain}/master")
        return dom_master.query_deputy(person) if dom_master and hasattr(dom_master, "query_deputy") else False

    def is_liaison_deputy(self, person):
        liaison_master = self.driver.find_object("/home/archaon/mud/d/liaison/master")
        return liaison_master.query_deputy(person) if liaison_master and hasattr(liaison_master, "query_deputy") else False

    def query_liaison_deputy_or_director(self, arg):
        if isinstance(arg, list):
            arg = [x for x in arg if self.driver.is_interactive(x)]
            return all(
                self.query_director(self.driver.geteuid(x)) or
                self.is_liaison_deputy(self.driver.geteuid(x))
                for x in arg
            )
        return self.is_liaison_deputy(arg) or self.query_director(arg)

    def query_liaison_deputy_or_lord(self, arg):
        return self.query_liaison_deputy_or_director(arg)

    def query_senior(self, arg):
        if isinstance(arg, list):
            arg = [x for x in arg if self.driver.is_interactive(x)]
            return all(
                self.positions.get(self.driver.geteuid(x)) == SENIOR or
                self.query_leader(self.driver.geteuid(x))
                for x in arg
            )
        return self.positions.get(arg) == SENIOR or self.query_leader(arg)

    def query_all_seniors(self):
        return [k for k in self.positions.keys() if self.query_senior(k)]

    def query_domains(self):
        domains = self.driver.get_dir("/home/archaon/mud/d/")
        return [d for d in domains if d not in ["lost+found", "core"] and not d.endswith("_dev")]

    def valid_load(self, path, euid, func):
        return True  # Simplified; actual logic in sub-module

    def get_root_uid(self):
        return ROOT

    def get_bb_uid(self):
        return "Room"

    def define_include_dirs(self):
        return ["/home/archaon/mud/include/%s"]

    def valid_trace(self):
        return True

    def shut(self, min_):
        self.driver.find_object("/home/archaon/mud/obj/shut").shut(min_)

    def remove_checked_master(self, name):
        self.checked_master.pop(name, None)

    def query_checked_master(self):
        return self.checked_master.copy()

    def apply_unguarded(self, func, local=False):
        prev_ob = self.driver.previous_object(0)
        if self.driver.base_name(prev_ob) != "/home/archaon/mud/lib/secure/simul_efun":
            raise RuntimeError("Illegal unguarded apply.")
        previous_unguarded = self.unguarded_ob
        self.unguarded_ob = self if local else self.driver.previous_object(1)
        try:
            val = func()
        except Exception as e:
            self.unguarded_ob = previous_unguarded
            raise e
        self.unguarded_ob = previous_unguarded
        return val

    # Delegate to sub-modules using call_other style
    def valid_read(self, path, euid, func):
        return ValidRead.valid_read(self, path, euid, func)

    def valid_write(self, path, euid, func):
        return ValidWrite.valid_write(self, path, euid, func)

    def crash(self, reason="unknown"):
        Crash.crash(self, reason)

    def create_dom_creator(self, domain, creator):
        CreateDomCreator.create_dom_creator(self, domain, creator)

    def creator_file(self, path):
        return CreatorFile.creator_file(self, path)

    def dest_env(self, ob):
        DestEnv.dest_env(self, ob)

    def set_ed_setup(self, ob, setup):
        EdStuff.set_ed_setup(self, ob, setup)

    def query_ed_setup(self, ob):
        return EdStuff.query_ed_setup(self, ob)

    def file_exists(self, path):
        return FileExists.file_exists(self, path)

    def log_file(self, file, message):
        Logging.log_file(self, file, message)

    def parse_command(self, command, ob):
        return ParseCommand.parse_command(self, command, ob)

    def preload(self, path):
        Preload.preload(self, path)

    def query_pl_level(self, ob):
        return QueryPlLevel.query_pl_level(self, ob)

    def query_snoop(self, ob):
        return Snoop.query_snoop(self, ob)

    def query_snoopee(self, ob):
        return Snoop.query_snoopee(self, ob)

    def set_snoopee(self, snooper, snoopee):
        Snoop.set_snoopee(self, snooper, snoopee)

    def valid_database(self, ob, action, info):
        return ValidDatabase.valid_database(self, ob, action, info)

    def valid_exec(self, name):
        return ValidExec.valid_exec(self, name)

    def valid_hide(self, ob):
        return ValidHide.valid_hide(self, ob)

    def valid_ident(self, euid):
        return ValidIdent.valid_ident(self, euid)

    def valid_link(self, from_, to):
        return ValidLink.valid_link(self, from_, to)

    def valid_override(self, file, func, filename):
        return ValidOverride.valid_override(self, file, func, filename)

    def valid_seteuid(self, ob, euid):
        return ValidSeteuid.valid_seteuid(self, ob, euid)

    def valid_shadow(self, ob):
        return ValidShadow.valid_shadow(self, ob)

    def valid_socket(self, ob, func, info):
        return ValidSocket.valid_socket(self, ob, func, info)