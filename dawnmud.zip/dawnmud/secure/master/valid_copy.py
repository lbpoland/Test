# /lib/secure/master/valid_copy.py
# Validates file copy permissions.

class ValidCopy:
    def __init__(self, driver):
        self.driver = driver

    def valid_copy(self, path, euid, func):
        """
        Checks if a file can be copied by a user.
        @param path The source file path
        @param euid The effective user ID
        @param func The calling function
        @return 1 if allowed, 0 otherwise
        """
        bits = [b for b in path.split("/") if b and b != "."]
        perms = self.driver.get_master().permission_match_path(self.driver.permissions, path)
        if len(bits) < 2 or bits[0] in ["open", "doc", "log", "mudlib", "w"]:
            return self.driver.check_permission(euid, func, path, perms, self.driver.READ_MASK)
        master_ob = self.driver.find_object(f"/d/{bits[1]}/master")
        if (master_ob and master_ob.copy_with_read(path, euid, func)) or (not master_ob and self.driver.get_master().query_senior(euid)):
            return self.driver.check_permission(euid, func, path, perms, self.driver.READ_MASK)
        return self.driver.check_permission(euid, func, path, perms, self.driver.WRITE_MASK)