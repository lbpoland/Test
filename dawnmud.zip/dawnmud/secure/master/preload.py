# /lib/secure/master/preload.py
# Manages preloading of objects.

class Preload:
    def __init__(self, driver):
        self.driver = driver

    def load_file(self, fname):
        """
        Loads and parses a preload configuration file.
        @param fname The file name
        @return List of preload paths
        """
        str_ = self.driver.read_file(f"/secure/config/{fname}")
        if not str_:
            return []
        bits = [line for line in str_.split("\n") if line and line[0] != "#"]
        return bits

    def epilog(self):
        """
        Returns preload list for initialization.
        @return List of preload paths
        """
        return self.load_file("preload")

    def preload(self, file):
        """
        Preloads an object.
        @param file The file path to preload
        """
        self.driver.printf(f"Preloading: {file}.\n")
        try:
            self.driver.load_object(file)
        except Exception as e:
            self.driver.printf(f"            {str(e)}\n")