# /lib/secure/master/valid_override.py
# Validates function overriding.

class ValidOverride:
    def __init__(self, driver):
        self.driver = driver

    def valid_override(self, file, func, filename):
        """
        Checks if a function can be overridden.
        @param file The file defining the override
        @param func The function name
        @param filename The file being overridden
        @return 1 if valid, 0 otherwise
        """
        bing = [b for b in file.split("/") if b and b != "."]
        if not bing:
            return 0
        match bing[0]:
            case "secure":
                return 1
            case "std" | "obj" | "simul_efun" | "global" | "cmds":
                return 1 if func != "snoop" else 0
            case _:
                return 0