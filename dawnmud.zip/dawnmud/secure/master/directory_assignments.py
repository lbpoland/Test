# /lib/secure/master/directory_assignments.py
# Manages directory assignments for error reporting.
# @see /obj/handlers/player_handler.py
# @see /obj/handlers/error_handler.py

class DirectoryAssignments:
    def __init__(self, driver):
        self.driver = driver
        self._directory_assignments = {}

    def query_assigned_to_directory(self, dir):
        """
        Queries people assigned to a directory.
        @param dir The directory path
        @return List of assigned names
        """
        bits = [b for b in dir.split("/") if b]
        if not bits:
            return []
        match bits[0]:
            case "w":
                if len(bits) > 1 and self.driver.file_size(f"/d/{bits[1]}") == -2:
                    return [bits[1]]
            case "d":
                if len(bits) > 1 and self.driver.file_size(f"/d/{bits[1]}") == -2:
                    return self.driver.find_object(f"/d/{bits[1]}/master").query_assigned_to_directory(bits)
        i = len(bits) - 1
        while i >= 0:
            str_ = "/" + "/".join(bits[:len(bits) - i])
            if str_ in self._directory_assignments:
                return self._directory_assignments[str_]
            i -= 1
        return []

    def assign_people_to_directory(self, dir, people):
        """
        Assigns people to a directory for error reporting.
        @param dir The directory path
        @param people List of names to assign
        @return 1 on success, 0 on failure
        """
        interactives = [ob for ob in self.driver.previous_object(-1) if self.driver.is_interactive(ob)]
        if not interactives:
            self.driver.user_event("inform", f"{self.driver.this_player().query_name()} illegally attempted to call assign_person_to_directory( {dir}, {self.driver.query_multiple_short(people)} )", "cheat")
            self.driver.unguarded(lambda: self.driver.write_file("/log/CHEAT", f"{self.driver.ctime(self.driver.time())}: illegal attempt to call assign_person_to_directory( {dir}, {self.driver.query_multiple_short(people)} ).\n{self.driver.back_trace()}"))
            return 0
        ph = self.driver.player_handler()
        eh = self.driver.find_object("ERROR_HANDLER")
        new_people = [p for p in people if ph.test_creator(p) or p == "nobody"]
        if (len(new_people) == len(people) and
            self.driver.get_master().query_leader(self.driver.previous_object(-1)) and
            self.driver.file_size(dir) == -2):
            dirs = [d for d in dir.split("/") if d]
            if len(dirs) > 1 and dirs[0] == "d":
                return self.driver.find_object(f"/d/{dirs[1]}/master").assign_people_to_directory(dir, people)
            if not self._directory_assignments:
                self._directory_assignments = {}
            people = [] if len(people) == 1 and people[0] == "nobody" else people
            if people:
                if dir in self._directory_assignments and self._directory_assignments[dir]:
                    eh.do_update_directory_assignment(self._directory_assignments[dir][0], people[0], dir, lambda: 1)
                else:
                    eh.do_update_directory_assignment("nobody", people[0], dir, lambda: 1)
                self._directory_assignments[dir] = people
            else:
                self._directory_assignments.pop(dir, None)
            self.driver.get_master().save_object("/secure/master")
            return 1
        self.driver.debug_printf("Bad pumpkins. %s %s\n", new_people, people)
        return 0

    def query_directory_assignments(self):
        """
        Returns all directory assignments.
        @return Mapping of directories to assigned people
        """
        return self._directory_assignments.copy() if self._directory_assignments else {}