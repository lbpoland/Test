# /lib/secure/master/valid_hide.py
# Validates hiding permissions.

class ValidHide:
    def __init__(self, driver):
        self.driver = driver

    def valid_hide(self, ob):
        """
        Checks if an object can hide.
        @param ob The object requesting to hide
        @return 1 if lord, 0 otherwise
        """
        return 1 if self.driver.get_master().query_lord(self.driver.geteuid(ob)) else 0