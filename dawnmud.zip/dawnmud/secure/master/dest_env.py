# /lib/secure/master/dest_env.py
# Handles environment destruction for objects.

class DestEnv:
    def __init__(self, driver):
        self.driver = driver

    def destruct_environment_of(self, ob):
        """
        Moves an object out of its environment before destruction.
        @param ob The object to move
        """
        if env := self.driver.environment(ob):
            a = env.query_dest_dir()
            try:
                ob.move_player(a[0], a[1], "stumbles")
            except:
                ob.move_player("void", "/room/void", "is sucked into the")