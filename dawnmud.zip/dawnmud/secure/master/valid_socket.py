# /lib/secure/master/valid_socket.py
# Validates socket access permissions.

class ValidSocket:
    def __init__(self, driver):
        self.driver = driver

    def valid_socket(self, ob, func, info):
        """
        Checks if an object can perform a socket operation.
        @param ob The requesting object
        @param func The socket function
        @param info Additional info array
        @return 1 if valid, 0 otherwise
        """
        fname = self.driver.file_name(ob)
        if func != "external":
            return 1 if fname.split("/")[0] in ["net", "secure"] else 0
        return 1 if fname.startswith(("/secure/cmds", "/secure/rcs_handler")) else 0