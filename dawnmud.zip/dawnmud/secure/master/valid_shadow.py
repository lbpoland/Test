# /lib/secure/master/valid_shadow.py
# Validates shadowing permissions.

class ValidShadow:
    def __init__(self, driver):
        self.driver = driver

    def valid_shadow(self, ob):
        """
        Checks if an object can be shadowed.
        @param ob The target object
        @return 1 if valid, 0 otherwise
        """
        prev = self.driver.previous_object()
        if prev == ob:
            return 0
        fname = self.driver.file_name(ob)
        return 1 if (not ob.query_prevent_shadow(prev) and
                     not fname.startswith("/secure/") and
                     not fname.startswith("/obj/handlers/") and
                     not self.driver.function_exists("heart_beat", prev, 1) and
                     not fname.startswith("/cmds/")) else 0