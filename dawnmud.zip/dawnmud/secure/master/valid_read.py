# /lib/secure/master/valid_read.py
# Validates read permissions.

FILE_STATS = 1

class ValidRead:
    def __init__(self, driver):
        self.driver = driver
        self.read_stats = {}

    def valid_read(self, path, euid, func):
        """
        Checks if a user can read a file.
        @param path The file path
        @param euid The effective user ID
        @param func The calling function
        @return 1 if allowed, 0 otherwise
        """
        master = self.driver.get_master()
        if euid == master:
            return 1
        if func in ["file_size", "stat"]:
            return 1
        if not path.startswith("/"):
            path = f"/{path}"
        if path.endswith("c") and self.driver.base_name(euid).startswith("/w/"):
            return 0
        if FILE_STATS:
            if not self.read_stats:
                self.read_stats = {}
            if prev := self.driver.previous_object():
                prev_name = self.driver.base_name(prev)
                self.read_stats[prev_name] = self.read_stats.get(prev_name, {})
                self.read_stats[prev_name][path] = self.read_stats[prev_name].get(path, 0) + 1
        perms = master.permission_match_path(master.permissions, path)
        return self.driver.check_permission(euid, func, path, perms, self.driver.READ_MASK)

    def query_read_stats(self):
        """
        Returns read access statistics.
        @return Copy of read_stats mapping
        """
        return self.read_stats.copy()