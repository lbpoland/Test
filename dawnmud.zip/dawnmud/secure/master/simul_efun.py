# /lib/secure/master/simul_efun.py
# Loads the simul_efun object.

class SimulEfun:
    def __init__(self, driver):
        self.driver = driver

    def get_simul_efun(self):
        """
        Loads and returns the simul_efun object path.
        @return Path to simul_efun or None
        """
        fname = "/secure/simul_efun"
        try:
            self.driver.call_other(fname, "??")
        except:
            self.driver.write(f"Failed to load {fname}\n")
            self.driver.shutdown()
            return None
        return fname