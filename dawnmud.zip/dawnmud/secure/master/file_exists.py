# /lib/secure/master/file_exists.py
# Checks file existence.

class FileExists:
    def __init__(self, driver):
        self.driver = driver

    def file_exists(self, path):
        """
        Determines if a file exists.
        @param path The file path
        @return 1 if exists, 0 otherwise
        """
        return 1 if self.driver.file_size(path) >= 0 else 0