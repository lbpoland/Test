# /lib/secure/master/valid_to_c.py
# Validates compile-to-C permissions.

class ValidToC:
    def __init__(self, driver):
        self.driver = driver

    def valid_compile_to_c(self):
        """
        Checks if compile-to-C is allowed.
        @return 1 if valid, 0 otherwise
        """
        prev = self.driver.previous_object()
        if prev == self.driver.this_object():
            return 1
        if prev != self.driver.find_object("/secure/cmds/creator/compile"):
            return 0
        if not self.driver.is_interactive(self.driver.previous_object(1)):
            return 0
        return 1 if self.driver.get_master().query_lord(self.driver.previous_object(-1)) else 0