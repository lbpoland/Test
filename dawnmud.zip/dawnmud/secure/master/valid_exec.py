# /lib/secure/master/valid_exec.py
# Validates exec permissions.

class ValidExec:
    def __init__(self, driver):
        self.driver = driver

    def valid_exec(self, name):
        """
        Checks if a file can execute.
        @param name The file path
        @return 1 if valid, 0 otherwise
        """
        return 1 if name in ["secure/login.c", "secure/nlogin.c"] else 0