# /lib/secure/master/valid_seteuid.py
# Validates seteuid permissions.

class ValidSeteuid:
    def __init__(self, driver):
        self.driver = driver

    def valid_euid(self, str_):
        """
        Checks if an euid is valid for setting.
        @param str_ The euid string
        @return 1 if valid, 0 otherwise
        """
        valid = ["all", "Handlers", "Mailer", "Network", "Room", "Spell", "WWW"]
        if str_ in valid:
            return 1
        domains = [d.capitalize() for d in self.driver.unguarded(lambda: self.driver.get_dir("/d/")) if d != "lost+found"]
        return 1 if str_ in domains else 0

    def valid_seteuid(self, ob, euid):
        """
        Validates if an object can set its euid.
        @param ob The object requesting seteuid
        @param euid The target euid
        @return 1 if valid, 0 otherwise
        """
        if euid == "tmp":
            return 1
        if not isinstance(ob, object):
            return 0
        crea = self.driver.creator_file(self.driver.file_name(ob))
        return 1 if crea in ["Root", "Room"] or euid == crea or not euid else 0