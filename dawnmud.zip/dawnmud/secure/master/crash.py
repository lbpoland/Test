# /lib/secure/master/crash.py
# Handles MUD crash scenarios.

class Crash:
    def __init__(self, driver):
        self.driver = driver

    def crash(self, crash_mess, command_giver, current_object):
        """
        Logs and handles a MUD crash.
        @param crash_mess The crash reason
        @param command_giver The object issuing the command
        @param current_object The current object context
        """
        self.driver.reset_eval_cost()
        log = f"\n{self.driver.ctime(self.driver.time())}:\n"
        if current_object:
            log += f"current object: {self.driver.file_name(current_object)} ({current_object.query_name()})\n"
        if command_giver:
            log += f"command giver: {self.driver.file_name(command_giver)} ({command_giver.query_name()})\n"
        if verb := self.driver.query_verb():
            log += f"command given: {verb}\n"
        log += f"crash reason: {crash_mess}\n"
        things = self.driver.users()
        log += f"[{', '.join(t.query_name() for t in things)}]\n"
        self.driver.log_file("CRASH", log)
        self.driver.flush_log_files()
        messages = [
            "Wodan says: I wonder what this button does...",
            "Wodan says: Ceres, look out for that wire....",
            "Wodan says: Wow, look at the uptime.",
            "Wodan whispers: I don't think we should be doing this on my desk..",
            "Wodan shouts: Look at all that xp!"
        ]
        import random
        crashtxt = f"{messages[random.randint(0, 4)]}\n({crash_mess})\n"
        for thing in things:
            self.driver.reset_eval_cost()
            self.driver.efun_tell_object(thing, crashtxt)
            try:
                thing.quit()
            except:
                pass