# /secure/bastards.py
# Translated from /secure/bastards.c (2003 Discworld MUD library)
# Purpose: Manages site access, suspensions, lockouts, multi-user settings, and temporary passwords
# Last modified in original: Unknown

import asyncio
from datetime import datetime

# Constants from access.h, player_handler.h, etc.
TIMEOUT_TIME = 2419200  # 28 days in seconds
ACCESS_LEVEL = 0
ACCESS_REASON = 1
ACCESS_TIMEOUT = 2
SUSPEND_TIME = 0
SUSPEND_REASON = 1
DEFAULT = 0  # Default access level
PERM_NAMES = {0: "default", 1: "access", 2: "denied"}  # Example mapping, adjust as needed

class Bastards:
    def __init__(self, driver):
        self.driver = driver
        self.driver.seteuid("Root")
        self.names = []  # Not used in original, kept for consistency
        self.site_access = {}
        self.suspended = {}
        self.lockedout = {}
        self.multiuser = {}
        self.temp_passwords = {}
        self.load_state()

    def load_state(self):
        """Loads saved state or initializes if failed."""
        if not self.driver.unguarded(lambda: self.driver.restore_object(self.driver.base_name(self))):
            print("Failed to restore bastards.")
        if not self.site_access:
            print("mmm, no site access")
            self.site_access = {}
        if not self.lockedout:
            self.lockedout = {}
        if not self.multiuser:
            self.multiuser = {}
        if not self.temp_passwords:
            self.temp_passwords = {}
        self.timeout_access()

    async def init(self, driver):
        """Initializes the bastards module and moves to void if it exists."""
        if self.driver.find_object("/room/void"):
            await self.driver.move_object(self, self.driver.find_object("/room/void"))

    def query_player_ob(self, name):
        """Determines the player object type based on role."""
        master = self.driver.get_master()
        if master.query_administrator(name) or master.query_lord(name):
            return "/global/lord"
        if self.driver.player_handler().test_creator(name):
            return "/global/creator"
        if self.driver.playtester_handler().query_playtester(name):
            return "/global/playtester"
        return "/global/player"

    def query_prevent_shadow(self):
        """Prevents shadowing of this object."""
        return True

    def query_all_access(self):
        """Returns a copy of all site access settings."""
        return dict(self.site_access)

    def query_access(self, ob):
        """Checks access level for an object’s IP or hostname."""
        tmp = self.driver.query_ip_number(ob)
        while tmp:
            if tmp in self.site_access:
                return self.site_access[tmp][ACCESS_LEVEL]
            tmp = ".".join(tmp.split(".")[:-1])
        tmp = self.driver.query_ip_name(ob)
        while tmp:
            if tmp in self.site_access:
                return self.site_access[tmp][ACCESS_LEVEL]
            tmp = ".".join(tmp.split(".")[1:])
        return DEFAULT

    def query_multi(self, ob):
        """Checks if multi-user is allowed for an object’s IP or hostname."""
        tmp = self.driver.query_ip_number(ob)
        while tmp:
            if tmp in self.multiuser:
                return True
            tmp = ".".join(tmp.split(".")[:-1])
        tmp = self.driver.query_ip_name(ob)
        while tmp:
            if tmp in self.multiuser:
                return True
            tmp = ".".join(tmp.split(".")[1:])
        return False

    def query_all_multi(self):
        """Returns a copy of all multi-user settings."""
        return dict(self.multiuser)

    def query_reason(self, address):
        """Returns the reason for an access setting."""
        return self.site_access.get(address, [None])[ACCESS_REASON]

    def add_multi(self, address, multi, timeout):
        """Adds or removes a multi-user setting."""
        if not multi:
            self.multiuser.pop(address, None)
        else:
            self.multiuser[address] = timeout

    def add_access(self, address, level, reason, timeout):
        """Sets an access level for an address."""
        self.site_access[address] = [level, reason, timeout]

    def timeout_access(self):
        """Removes expired access and multi-user settings."""
        current_time = self.driver.time()
        for bit in list(self.site_access.keys()):
            if self.site_access[bit][ACCESS_TIMEOUT] < current_time or \
               self.site_access[bit][ACCESS_LEVEL] == 1:  # ACCESS assumed as 1
                self.site_access.pop(bit)
        for bit in list(self.multiuser.keys()):
            if self.multiuser[bit] < current_time:
                self.multiuser.pop(bit)

    def save_me(self):
        """Saves the object state."""
        self.driver.unguarded(lambda: self.driver.save_object(self.driver.base_name(self), 2))

    def change_access(self, address, level, reason, timeout):
        """Changes access settings for an address."""
        prev_ob = self.driver.previous_object(-1)
        master = self.driver.get_master()
        if not master.query_lord(prev_ob) and \
           self.driver.base_name(prev_ob) != "/cmds/creator/ban":
            return False
        if not isinstance(address, str) or not reason:
            self.driver.notify_fail("Invalid parameters.\n")
            return False
        if not timeout:
            timeout = self.driver.time() + 100 * 24 * 60 * 60  # 100 days
        self.add_access(address, level, reason, timeout)
        self.save_me()
        log_entry = f"{datetime.fromtimestamp(self.driver.time()).strftime('%b %d %H:%M:%S')} " \
                    f"{address} set to {PERM_NAMES.get(level, 'unknown')} for {reason} " \
                    f"until {datetime.fromtimestamp(timeout)} by " \
                    f"{self.driver.this_player().query_name()}.\n"
        self.driver.unguarded(lambda: self.driver.write_file("/log/ACCESS", log_entry))
        return True

    def change_multi(self, address, multi, timeout):
        """Changes multi-user settings for an address."""
        prev_ob = self.driver.previous_object(-1)
        master = self.driver.get_master()
        if not master.query_lord(prev_ob) and \
           self.driver.base_name(prev_ob) != "/cmds/creator/multipl_ayer":
            return False
        if not isinstance(address, str):
            self.driver.notify_fail("Invalid parameters.\n")
            return False
        if not timeout:
            timeout = self.driver.time() + 100 * 24 * 60 * 60  # 100 days
        self.add_multi(address, multi, timeout)
        self.save_me()
        log_entry = f"{datetime.fromtimestamp(self.driver.time()).strftime('%b %d %H:%M:%S')} " \
                    f"{address} set to {'allow' if multi else 'disallow'} multiple users " \
                    f"until {datetime.fromtimestamp(timeout)} by " \
                    f"{self.driver.this_player().query_name()}.\n"
        self.driver.unguarded(lambda: self.driver.write_file("/log/ACCESS", log_entry))
        return True

    def suspend_person(self, name, tim, reason):
        """Suspends a player for a specified duration."""
        prev_ob = self.driver.previous_object(-1)
        master = self.driver.get_master()
        if not master.query_lord(prev_ob) and \
           self.driver.base_name(prev_ob) != "/cmds/creator/suspend":
            return False
        if not self.driver.player_handler().test_user(name):
            return False
        reason = reason or "you have been bad"
        self.suspended[name] = [self.driver.time() + tim, reason]
        self.save_me()
        log_entry = f"{datetime.fromtimestamp(self.driver.time()).strftime('%b %d %H:%M:%S')} " \
                    f"{name} suspended until {datetime.fromtimestamp(self.driver.time() + tim)} " \
                    f"by {self.driver.this_player().query_name()} because {reason}.\n"
        self.driver.unguarded(lambda: self.driver.write_file("/log/SUSPEND", log_entry))
        self.driver.playerinfo_handler().add_entry(
            self.driver.this_player(), name, "suspend",
            f"Suspended until {datetime.fromtimestamp(self.driver.time() + tim)} for {reason}"
        )
        return True

    def unsuspend_person(self, name):
        """Removes suspension from a player."""
        prev_ob = self.driver.previous_object(-1)
        master = self.driver.get_master()
        if not master.query_lord(prev_ob) and \
           self.driver.base_name(prev_ob) != "/cmds/creator/unsuspend":
            return False
        self.suspended.pop(name, None)
        self.driver.unguarded(lambda: self.driver.save_object(self.driver.base_name(self), 2))
        log_entry = f"{datetime.fromtimestamp(self.driver.time()).strftime('%b %d %H:%M:%S')} " \
                    f"{name} unsuspended.\n"
        self.driver.unguarded(lambda: self.driver.write_file("/log/SUSPEND", log_entry))
        self.driver.playerinfo_handler().add_entry(self.driver.this_player(), name, "suspend", "Unsuspended.")
        return True

    def query_suspended(self, name):
        """Queries suspension status for a player."""
        if name in self.suspended:
            if self.suspended[name][SUSPEND_TIME] > self.driver.time():
                return list(self.suspended[name])
            self.suspended.pop(name)
            self.save_me()
        return self.suspended.get(name)

    def lockout_person(self, name, tim, reason):
        """Locks out a player for a specified duration."""
        prev_ob = self.driver.previous_object(-1)
        master = self.driver.get_master()
        if not master.query_lord(prev_ob) and \
           self.driver.base_name(prev_ob) != "/cmds/player/lockout":
            return False
        if not self.driver.player_handler().test_user(name):
            return False
        reason = reason or "you have been bad"
        self.lockedout[name] = [self.driver.time() + tim, reason]
        self.save_me()
        log_entry = f"{datetime.fromtimestamp(self.driver.time()).strftime('%b %d %H:%M:%S')} " \
                    f"{name} lockedout until {datetime.fromtimestamp(self.driver.time() + tim)} " \
                    f"by {self.driver.this_player().query_name()} because {reason}.\n"
        self.driver.unguarded(lambda: self.driver.write_file("/log/LOCKOUT", log_entry))
        self.driver.playerinfo_handler().add_entry(
            self.driver.this_player(), name, "lockedout",
            f"Locked out until {datetime.fromtimestamp(self.driver.time() + tim)} for {reason}"
        )
        return True

    def query_lockedout(self, name):
        """Queries lockout status for a player."""
        if name in self.lockedout:
            if self.lockedout[name][SUSPEND_TIME] > self.driver.time():
                return list(self.lockedout[name])
            self.lockedout.pop(name)
            self.save_me()
        return self.lockedout.get(name)

    def set_temp_password(self, name, password):
        """Sets a temporary password for a player."""
        self.temp_passwords[name] = [self.driver.time(), password]
        self.save_me()
        return True

    def query_temp_password(self, name):
        """Queries a temporary password, clearing expired ones."""
        current_time = self.driver.time()
        found = False
        for tmp in list(self.temp_passwords.keys()):
            if self.temp_passwords[tmp][0] < (current_time - TIMEOUT_TIME):
                self.temp_passwords.pop(tmp)
                found = True
        if found:
            self.save_me()
        return list(self.temp_passwords.get(name)) if name in self.temp_passwords else None

    def clear_temp_password(self, name):
        """Clears a temporary password."""
        if name in self.temp_passwords:
            self.temp_passwords.pop(name)
            self.save_me()