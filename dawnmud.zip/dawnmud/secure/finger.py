# /secure/finger.py
# Translated from /secure/finger.c (2003 Discworld MUD library)
# Purpose: Provides finger, refer, and domain/club info for players and entities
# Last modified in original: Unknown

import html
from datetime import datetime

# Constants from finger.h, config.h, etc.
NO_EMAIL_TIME = 7776000  # 90 days
WWW_REPLACEMENTS = {"%^BOLD%^": "<b>", "%^EBOLD%^": "</b>", "%^RESET%^": "", "\n": "<br>\n"}
REPLACEMENTS = {"%^EBOLD%^": "%^RESET%^", "<br>": ""}
UNKNOWN_BIRTHDAY = "Unknown"  # Assumed constant from player.h

class Finger:
    def __init__(self, driver):
        self.driver = driver
        self.driver.seteuid("Root")

    async def init(self, driver):
        pass  # No additional init needed

    def htmlise(self, text):
        """Escapes HTML characters."""
        return html.escape(text)

    def banish_finger(self, name, caller):
        """Returns finger info for a banished player."""
        file_content = self.driver.read_file(f"/banish/{name[0]}/{name}.o")
        file_lines = file_content.split("\n") if file_content else []
        retval = f"{'Login name : ' + name:<35}{'Real name : Banished':<35}\n"
        retval += "Not really many seconds old.\n"
        retval += "No mail ever.\n"
        retval += "No plan.\nNo future.\n"
        if caller and len(file_lines) == 3:
            retval += "\n".join(file_lines) + "\n"
        elif caller:
            retval += "Banish info not in the correct format.\n"
        if self.driver.club_handler().is_club(name):
            retval += f"\nThere is also a club of this name, try: 'refer club {name}' " \
                      "for information on the club.\n"
        return retval.replace("@@", "@ @ ")

    def time_elapsed_string(self, time_elapsed):
        """Converts time to a human-readable string."""
        return self.driver.query_time_string(time_elapsed, -1)

    def get_additional_info(self, name, no_colour, user_colour, width, caller):
        """Gets detailed player info."""
        retval = "%^BOLD%^" if not no_colour else ""
        master = self.driver.get_master()
        ph = self.driver.player_handler()
        pth = self.driver.playtester_handler()

        if ph.test_creator(name):
            if master.query_trustee(name):
                retval += f"{name.capitalize()} is a Trustee.\n"
            elif master.query_director(name):
                retval += f"{name.capitalize()} is a Director.\n"
            elif master.query_senior(name):
                retval += f"{name.capitalize()} is a Senior Creator.\n"
            else:
                retval += f"{name.capitalize()} is a Creator.\n"
            domains = master.query_domains()
            tmp = ""
            tmp_leader = ""
            domain_leader = domain_deputy = domain_developer = False
            for domain in domains:
                dmaster = self.driver.find_object(f"/d/{domain}/master")
                if dmaster.query_lord() == name:
                    tmp_leader += f"Leader of the {domain.capitalize()} domain.\n"
                    domain_leader = True
                elif dmaster.query_deputy(name):
                    tmp += f"Deputy of the {domain.capitalize()} domain.\n"
                    domain_deputy = True
                elif not dmaster.query_member(name) and domain not in ["fluffy", "liaison"]:
                    domain_developer = True
                else:
                    tmp += f"Project in the {domain.capitalize()} domain: " \
                           f"{dmaster.query_project(name)}\n"
            tmp = tmp_leader + tmp
            if not domains and not domain_leader and not domain_deputy and not domain_developer:
                tmp += "Not a member of any domain.\n"
            roles = []
            if self.driver.find_object("/d/admin/master").query_member(name):
                roles.append("Administrator")
            if domain_leader:
                roles.append("Domain Leader")
            if domain_deputy:
                roles.append("Domain Deputy")
            if self.driver.find_object("/d/liaison/master").query_member(name):
                roles.append("Liaison")
            elif domain_developer:
                roles.append("Developer")
            if roles:
                retval += f"Roles : {self.driver.query_multiple_short(roles)}.\n"
            if tmp:
                retval += f"Domains : {tmp:<{width - 10}}\n"
        elif pth.query_playtester(name):
            roles = ["Playtester"]
            if pth.query_pt_exec(name):
                roles.append("Playtesting Executive")
            if pth.query_senior_playtester(name):
                retval += f"{name.capitalize()} is a Senior Playtester.\n"
            else:
                retval += f"{name.capitalize()} is a Playtester.\n"
            retval += f"Roles : {self.driver.query_multiple_short(roles)}.\n"

        retval += "%^EBOLD%^" if not no_colour else ""
        start_time = ph.test_start_time(name)
        if start_time:
            retval += f"First logged on {datetime.fromtimestamp(start_time)}.\n"
        retval += f"{self.time_elapsed_string(-ph.test_age(name)).capitalize()} old.\n"
        ob = self.driver.find_player(name)
        if ob and (caller >= ob.query_invis() or 
                   (self.driver.this_player() and self.driver.reference_allowed(ob, self.driver.this_player()))):
            last = ph.test_last(name)
            retval += f"On since {datetime.fromtimestamp(last)} " \
                      f"({self.time_elapsed_string(self.driver.time() - last).capitalize()}).\n"
        else:
            i = self.driver.time() - ph.test_last(name)
            retval += f"Last logged off {self.time_elapsed_string(i)} ago.\n"
        
        if caller > 1:
            if not ob:
                retval += f"{ph.test_last_on_from(name)}  "
                need_new = True
            else:
                retval += f"{self.driver.query_ip_name(ob)} ({self.driver.query_ip_number(ob)})\n"
                need_new = False
        else:
            need_new = False

        if ob and (caller >= ob.query_invis() or 
                   (self.driver.this_player() and self.driver.reference_allowed(ob, self.driver.this_player()))):
            if ob.is_interactive():
                retval += f"Idle for {self.time_elapsed_string(self.driver.query_idle(ob))}.\n"
                need_new = False
            else:
                retval += "Net dead.\n"
                need_new = False
        if need_new:
            retval += "\n"

        retval += self.driver.mailer().finger_mail(name)
        project = ph.query_project(name)
        if no_colour or not user_colour:
            project = self.driver.strip_colours(project)
            project = project.replace("%^", " ")
        if project:
            used_colour = "%^" in project
            retval += f"%^BOLD%^Project:%^EBOLD%^\n{project}\n%^RESET%^" if not no_colour else f"Project:\n{project}\n"
        else:
            retval += "No project.\n"

        plan = ph.query_plan(name)
        if no_colour or not user_colour:
            plan = self.driver.strip_colours(plan)
            plan = plan.replace("%^", " ")
        if plan:
            used_colour = used_colour or "%^" in plan
            retval += f"%^BOLD%^Plan:%^EBOLD%^\n{plan}\n%^RESET%^" if not no_colour else f"Plan:\n{plan}\n"
        else:
            retval += "No plan.\n"

        if used_colour and not no_colour:
            retval += "%^RESET%^%^BOLD%^---  End of finger ---%^EBOLD%^\n"
        return retval

    def remote_finger(self, name):
        """Returns finger info for remote queries."""
        if not name or not self.driver.player_handler().test_user(name):
            return None
        ob = self.driver.find_player(name)
        cname = self.driver.player_handler().query_cap_name(name) or name.capitalize()
        retval = [None] * 9
        retval[0] = cname
        retval[1] = cname
        retval[2] = self.driver.player_handler().test_real_name(name) or "???"
        retval[3] = "0"
        if ob and not ob.query_invis():
            retval[4] = datetime.fromtimestamp(ob.query_last_log_on()).ctime()
            retval[5] = self.driver.query_idle(ob)
        else:
            retval[4] = self.time_elapsed_string(self.driver.time() - 
                                                 self.driver.player_handler().test_last(name)).capitalize()
            retval[5] = -1
        retval[6] = 0
        retval[7] = 0
        retval[8] = self.get_additional_info(name, True, False, 80, 0)
        return retval

    def link_name(self, name):
        """Creates an HTML link for a name."""
        return f"<a href=\"finger.c?player={name}\">{name.capitalize()}</a>"

    def domain_finger(self, name, width, www):
        """Returns finger info for a domain."""
        master = self.driver.find_object(f"/d/{name}/master")
        ret = master.generate_string()
        if not isinstance(ret, str):
            ret = f"%^BOLD%^The domain of {name.capitalize()}.\n"
            lord = master.query_lord()
            ret += f"The leader for this domain is " \
                   f"{self.link_name(lord) if www else lord.capitalize()}.\n"
            deputies = master.query_deputies()
            if deputies:
                ret += f"The {'deputies' if len(deputies) > 1 else 'deputy'} for the domain " \
                       f"{'are' if len(deputies) > 1 else 'is'} " \
                       f"{self.driver.query_multiple_short([self.link_name(d) if www else d.capitalize() for d in deputies])}.\n"
            ret += "%^EBOLD%^"
            ret += "The current members of this domain are :\n"
            members = master.query_members()
            projects = ""
            if www:
                ret += "<table cols=\"2\" rules=\"none\" border=\"0\" width=\"100%\">"
            for member in members:
                project = "[deputy] " + master.query_project(member) if master.query_deputy(member) else master.query_project(member)
                if www:
                    ret += f"<tr> <td>{self.link_name(member)}</td> <td>{project}</td> </tr>"
                else:
                    ret += f"{member.capitalize():<12} {project:<{width - 14}}\n"
            if www:
                ret += "</table>"
        info = master.query_info()
        if info:
            ret += f"{info:<{width}}\n"
        idle_mess = master.query_idle_mess()
        ret += idle_mess if idle_mess else "It hasn't been idle, it just hasn't had a lunch break in years.\n"
        return ret

    def club_finger(self, name):
        """Returns finger info for a club."""
        return self.driver.club_info_string(name, False, "gumball lord")

    def family_finger(self, name):
        """Returns finger info for a family."""
        return self.driver.family_info_string(name, "gumball lord")

    def deity_finger(self, name):
        """Returns finger info for a deity (placeholder)."""
        return None

    def other_finger(self, name, no_colour, user_colour, width, caller, www):
        """Handles non-player finger info."""
        master = self.driver.get_master()
        club_handler = self.driver.club_handler()
        if name in master.query_domains():
            return self.domain_finger(name, width, www)
        if self.driver.file_size(f"/save/deities/{name}.o") > 0 or \
           self.driver.file_size(f"/save/deities/{name}.o.gz") > 0:
            return self.deity_finger(name)
        if name.startswith("club ") and club_handler.is_club(name[5:]) and not club_handler.is_family(name[5:]):
            return self.club_finger(name[5:])
        elif name.startswith("domain ") and name[7:] in master.query_domains():
            return self.domain_finger(name[7:], width, www)
        elif name.startswith("family ") and club_handler.is_family(name[7:]):
            return self.family_finger(name[7:])
        elif club_handler.is_club(name):
            return self.family_finger(name) if club_handler.is_family(name) else self.club_finger(name)
        if self.driver.file_size(f"/banish/{name[0]}/{name}.o") > 0:
            return self.banish_finger(name, caller)
        return None

    def internal_finger_info(self, name, no_colour, user_colour, width, caller, www):
        """Core finger info generation."""
        ph = self.driver.player_handler()
        if not self.driver.find_player(name) and not ph.test_user(name):
            return self.other_finger(name, no_colour, user_colour, width, caller, www)
        
        cap_name = ph.query_cap_name(name) or ""
        real_name = ph.test_real_name(name) or "???"
        retval = f"{'Login name : ' + self.driver.strip_colours(cap_name) + ('<br>' if www else ''):<{(width - 2) // 2}}" \
                 f"Real name : {self.htmlise(self.driver.strip_colours(real_name[:31])):<{(width - 2) // 2 - 12}}\n" \
                 if not no_colour else f"Login name : {cap_name:<{(width - 2) // 2}}Real name : {real_name:<{(width - 2) // 2 - 12}}\n"
        
        email = ph.test_email(name)
        birthday = ph.test_birthday(name)
        if email:
            if email[0] == ":" or www or (ph.test_last(name) + NO_EMAIL_TIME < self.driver.time()):
                if caller == 0:
                    email = ""
        if email:
            email = self.htmlise(email)
            if birthday and birthday != UNKNOWN_BIRTHDAY:
                birthday = self.htmlise(birthday)
                retval += f"Birthday : {birthday + ('<br>' if www else ''):<{(width - 2) // 2}}Email : {email:<{(width - 2) // 2}}\n"
            else:
                retval += f"Email : {email[:31]:<{width - 2 // 2 - 8}}\n"
        elif birthday and birthday != UNKNOWN_BIRTHDAY:
            birthday = self.htmlise(birthday)
            retval += f"Birthday : {birthday + ('<br>' if www else ''):<{width - 2 // 2 - 11}}\n"

        deleting = ph.test_deleting(name)
        if deleting:
            days_left = 10 - ((self.driver.time() - deleting) // (60 * 60 * 24))
            days_text = f"{days_left} day{'s' if days_left > 1 else ''}" if days_left > 1 else "1 day"
            retval += f"%^RED%^This character is marked to be deleted in {days_text}.\n%^RESET%^" if not no_colour else \
                      f"This character is marked to be deleted in {days_text}.\n"

        appealing = ph.test_appealing(name)
        if appealing:
            days_left = 28 - ((self.driver.time() - appealing) // (60 * 60 * 24))
            days_text = f"{days_left} day{'s' if days_left > 1 else ''}" if days_left > 1 else "1 day"
            retval += f"%^RED%^This character is marked to be deleted in {days_text} pending appeal.\n%^RESET%^" if not no_colour else \
                      f"This character is marked to be deleted in {days_text} pending appeal.\n"

        home_dir = ph.test_home_dir(name)
        if home_dir:
            retval += f"Home directory : {home_dir + ('<br>' if www else ''):<{(width - 2) // 2}}\n"

        guild = ph.test_guild(name)
        if guild:
            try:
                retval += f"Member of the {guild.query_short()}.\n"
            except:
                retval += "Member of a very broken guild.\n"
        else:
            retval += "Member of the Adventurers' guild.\n"

        if not no_colour:
            retval += "%^EBOLD%^"
        
        location = ph.test_location(name)
        if location:
            retval += f"Location : {self.htmlise(location[:31])}\n"
        
        homepage = ph.test_homepage(name)
        if homepage:
            retval += f"Home Page: {self.htmlise(homepage)}\n"

        suspended = self.driver.find_object("/secure/bastards").query_suspended(name)
        if suspended:
            tmp = f"{name.capitalize()} has been suspended until {datetime.fromtimestamp(suspended[0]).ctime()}"
            tmp += f" for {suspended[1]}.\n" if caller else ".\n"
            retval += f"%^YELLOW%^{tmp[:11]:<11}{tmp[11:]:<{width - 11}}%^RESET%^" if not no_colour else tmp

        lockedout = self.driver.find_object("/secure/bastards").query_lockedout(name)
        if lockedout:
            tmp = f"{name.capitalize()} is locked out until {datetime.fromtimestamp(lockedout[0]).ctime()}"
            tmp += f" because {lockedout[1]}.\n" if caller else ".\n"
            retval += f"%^YELLOW%^{tmp[:11]:<11}{tmp[11:]:<{width - 11}}%^RESET%^" if not no_colour else tmp

        retval += self.htmlise(self.get_additional_info(name, no_colour, user_colour, width, caller))
        return retval

    def make_html(self, text):
        """Extracts and formats URLs for HTML."""
        pos = text.find("http:")
        if pos == -1:
            return "http://www.discworld.starturtle.net/lpc/"
        text = text[pos:]
        pos = text.find(" ")
        if pos != -1:
            text = text[:pos]
        return text

    def finger_info(self, name, no_colour):
        """Main finger info function."""
        tp = self.driver.this_player()
        user = tp.query_name() if tp else ""
        user_colour = tp.query_property("PLAYER_ALLOW_COLOURED_SOULS") if tp else False
        nick = tp.expand_nickname(name) if tp else name
        name = nick if nick else name
        width = tp.query_cols() if tp else 80
        master = self.driver.get_master()
        caller = 3 if master.query_director(user) else \
                 2 if master.is_liaison_deputy(user) else \
                 1 if self.driver.player_handler().test_creator(user) else 0
        retval = self.internal_finger_info(name, no_colour, user_colour, width, caller, False)
        if not retval:
            return None
        for old, new in REPLACEMENTS.items():
            retval = retval.replace(old, new)
        return retval

    def www_finger_info(self, name, user):
        """Finger info for web display."""
        master = self.driver.get_master()
        caller = 3 if user and master.query_director(user) else \
                 2 if user and master.is_liaison_deputy(user) else \
                 1 if user and self.driver.player_handler().test_creator(user) else 0
        retval = self.internal_finger_info(name, False, True, 80, caller, True)
        if not retval:
            return None
        for old, new in WWW_REPLACEMENTS.items():
            retval = retval.replace(old, new)
        return self.driver.strip_colours(retval)

    def refer_info(self, name):
        """Refer info for players and entities."""
        tp = self.driver.this_player()
        nick = tp.expand_nickname(name) if tp else name
        name = nick if nick else name
        width = tp.query_cols() if tp else 80
        ph = self.driver.player_handler()
        if not ph.test_user(name):
            retval = self.other_finger(name, False, False, width, 0, False)
            if retval:
                for old, new in REPLACEMENTS.items():
                    retval = retval.replace(old, new)
            return retval
        
        retval = ""
        family = ph.test_family_name(name) or ""
        title = ph.test_player_title(name)
        cap_name = ph.query_cap_name(name)
        if not cap_name:
            return None
        retval += f"{cap_name} {family}"
        master = self.driver.get_master()
        if self.driver.find_object("/d/liaison/master").query_member(name):
            retval += " (%^YELLOW%^Liaison%^RESET%^)"
        elif ph.test_creator(name):
            if master.query_trustee(name):
                retval += " (%^RED%^Trustee%^RESET%^)"
            elif master.query_director(name):
                retval += " (%^RED%^Director%^RESET%^)"
            elif master.query_senior(name):
                retval += " (%^RED%^Senior%^RESET%^)"
            else:
                retval += " (%^RED%^Creator%^RESET%^)"
        
        ob = self.driver.find_player(name)
        if ob:
            gtitle = ob.query_gtitle() or "the Adventurer"
            ptitle = ob.query_property("player_title")
            title = ob.query_title()
            retval += f" {gtitle}"
            if ptitle:
                retval += f", {ptitle}"
            if title:
                retval += f", {title}"
        
        pth = self.driver.playtester_handler()
        if pth.query_playtester(name):
            retval += ", (%^BOLD%^%^CYAN%^Senior Playtester%^RESET%^)" if pth.query_senior_playtester(name) else \
                      ", (%^CYAN%^Playtester%^RESET%^)"
        
        if ob:
            retval += "."
            nat = ob.query_nationality_name()
            if nat:
                poss = "his" if ob.query_gender() == 1 else "her" if ob.query_gender() == 2 else "its"
                reg = ob.query_nationality_region()
                retval += f"\n{poss.capitalize()} nationality is {nat.capitalize()}" + \
                          (f" and {ob.query_pronoun()} is from {reg.capitalize()}" if reg else "") + ".\n"
        else:
            retval += " (not currently logged in)\n"
        
        desc = ph.test_desc(name)
        if desc:
            if not tp.query_property("PLAYER_ALLOW_COLOURED_SOULS"):
                desc = self.driver.strip_colours(desc)
            gender = ph.test_gender(name)
            pronoun = "He" if gender == 1 else "She" if gender == 2 else "It"
            retval += f"{pronoun} {desc}\n"
        else:
            retval += "No description.\n"
        
        nomic = self.driver.nomic_handler()
        for area in nomic.query_citizenship_areas():
            if nomic.is_magistrate_of(area, name):
                retval += f"Magistrate in {area}.\n"
            elif nomic.is_citizen_of(area, name):
                retval += f"Citizen in {area}.\n"
        
        rels = self.driver.player_relationships_string(name)
        if rels:
            retval += f"{cap_name} {ph.test_family(name)} is the {rels}\n"
        
        if ph.test_player_killer(name):
            retval += f"{cap_name} is a player killer.\n"
        
        ref = ph.query_reference(name)
        if not tp.query_property("PLAYER_ALLOW_COLOURED_SOULS"):
            ref = self.driver.strip_colours(ref)
        if ref:
            retval += f"\n{ref}\n%^RESET%^"
            if "%^" in ref:
                retval += "--- End of Reference --\n"
        else:
            retval += "No reference.\n"
        
        return retval